using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GamepadOrbiter : MonoBehaviour
{
    [SerializeField] Player player;

    [Header("Rotation")]
    [SerializeField] float radius = 0.5f;

    Transform target;
    Transform pivot;

    // Start is called before the first frame update
    void Awake()
    {
        // rotation
        target = transform.parent;
        pivot = new GameObject().transform;
        pivot.name = "Equipped Item";
        pivot.parent = target.transform;
        transform.parent = pivot;
    }

    // Update is called once per frame
    void Update()
    {
        RotateAroundPlayer();
    }

    void RotateAroundPlayer()
    {
        if (player.IsGamepad)
        {
            if (Mathf.Abs(player.AimDirection.x) > player.GamepadDeadzone || Mathf.Abs(player.AimDirection.y) > player.GamepadDeadzone)
            {
                float angle = Mathf.Atan2(player.AimDirection.y, player.AimDirection.x) * Mathf.Rad2Deg;

                Vector2 newPosition = Quaternion.AngleAxis(angle, Vector3.forward) * (Vector3.right * radius);
                transform.position = (Vector2)target.position + newPosition;

                pivot.SetPositionAndRotation(target.position, Quaternion.AngleAxis(angle, Vector3.forward));
            }
        }
    }

    public Quaternion GetPivotRotation()
    {
        return pivot.rotation;
    }
}
