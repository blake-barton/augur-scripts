using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class BorderOnHover : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler, ISelectHandler, IDeselectHandler
{
    [SerializeField] Vector2 outlineSizeNotHovered = new Vector2();
    [SerializeField] Vector2 outlineSizeHovered = new Vector2();
    [SerializeField] Outline outline;

    public void OnPointerEnter(PointerEventData eventData)
    {
        outline.effectDistance = outlineSizeHovered;
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        outline.effectDistance = outlineSizeNotHovered;
    }

    public void OnSelect(BaseEventData eventData)
    {
        outline.effectDistance = outlineSizeHovered;
    }

    public void OnDeselect(BaseEventData eventData)
    {
        outline.effectDistance = outlineSizeNotHovered;
    }
}
