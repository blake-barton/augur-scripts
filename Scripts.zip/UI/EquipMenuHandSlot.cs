using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class EquipMenuHandSlot : MonoBehaviour, IPointerClickHandler, IPointerEnterHandler, IPointerExitHandler
{
    [SerializeField] HandPanel.HandSlot slotLocation;
    [SerializeField] Sprite emptySprite;
    [SerializeField] string slotTitle;
    [SerializeField] int quickEquipIndex = -1;

    [Header("Spell")]
    public Spell spell;                 // contains all data

    [Header("Item")]
    public Item item;
    [SerializeField] int itemIndex;

    [SerializeField] Equippable.EquippableType type;

    // state
    bool isHovered = false;             // is the pointer over the panel?

    // cached reference
    TabMenuManager tabMenuManager;
    Inventory playerInventory;
    Equipment equipment;
    Focus focus;
    EquipmentPanel equipmentPanel;
    Image slotImage;
    QuickAidManager quickAidManager;

    public Equippable.EquippableType Type { get => type; set => type = value; }
    public int ItemIndex { get => itemIndex; set => itemIndex = value; }

    void Awake()
    {
        tabMenuManager = FindObjectOfType<TabMenuManager>();
        playerInventory = FindObjectOfType<Player>().GetComponent<Inventory>();
        equipment = FindObjectOfType<Player>().GetComponent<Equipment>();
        focus = FindObjectOfType<Player>().GetComponent<Focus>();
        equipmentPanel = FindObjectOfType<EquipmentPanel>();
        slotImage = transform.GetChild(0).GetComponent<Image>();
        quickAidManager = FindObjectOfType<QuickAidManager>();
    }

    void Update()
    {
        if (type != Equippable.EquippableType.NULL)
        {
            ToggleDescriptionPanel();
            ClearSlot();
        }
    }

    public void OnPointerClick(PointerEventData eventData)
    {
        // load the hand panel
        if (slotLocation == HandPanel.HandSlot.MAINHAND || slotLocation == HandPanel.HandSlot.OFFHAND || slotLocation == HandPanel.HandSlot.QUICKEQUIP)
        {
            tabMenuManager.ShowHandPanel(slotLocation, quickEquipIndex);
        }
        else if (slotLocation == HandPanel.HandSlot.OUTFIT)
        {
            tabMenuManager.ShowOutfitEquipPanel();
        }
        else if (slotLocation == HandPanel.HandSlot.FOCUSIMPLANT)
        {
            tabMenuManager.ShowFocusImplantEquipPanel();
        }
        else if (slotLocation == HandPanel.HandSlot.QUICK_AID)
        {
            tabMenuManager.ShowQuickAidEquipPanel(quickEquipIndex);
        }
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        isHovered = true;

        equipmentPanel.SetSlotTitleText(slotTitle);
        equipmentPanel.SetEquippableNameTitleText("");

        if (type != Equippable.EquippableType.NULL)
        {
            ActivateTabManagerInfoPanelLoad();
        }
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        isHovered = false;
    }

    private void ActivateTabManagerInfoPanelLoad()
    {
        // clear current item info
        tabMenuManager.DestroyInfoPanel();

        if (type == Equippable.EquippableType.ITEM)
        {
            // get item count
            int itemCount = playerInventory.GetItemCountAtIndex(itemIndex);

            // load an info panel with this item's data
            tabMenuManager.LoadItemInfoPanel(item, itemCount);

            // set name of equipment panel
            equipmentPanel.SetEquippableNameTitleText(item.ItemName);
        }
        else if (type == Equippable.EquippableType.SPELL)
        {
            // load an info panel with this spell's data
            tabMenuManager.LoadSpellInfoPanel(spell);

            // set name of equipment panel
            equipmentPanel.SetEquippableNameTitleText(spell.SpellName);
        }
    }

    private void ToggleDescriptionPanel()
    {
        if (Input.GetKeyDown(KeyCode.LeftShift) && isHovered)
        {
            if (type == Equippable.EquippableType.ITEM)
            {
                // get item count
                int itemCount = playerInventory.GetItemCountAtIndex(itemIndex);

                // load and display description panel or info panel depending on state
                tabMenuManager.ToggleDescriptionPanel(item, itemCount);
            }
            else if (type == Equippable.EquippableType.SPELL)
            {
                // load and display description panel or info panel depending on state
                tabMenuManager.ToggleDescriptionPanelSpell(spell);
            }
        }
    }

    private void ClearSlot()
    {
        // when R is clicked, clear the slot, unequipping the item
        if (Input.GetKeyDown(KeyCode.R) && isHovered && type != Equippable.EquippableType.NULL)
        {
            if (type == Equippable.EquippableType.ITEM)
            {
                // if handslot, outfit slot, or focus slot, unequip
                if (slotLocation == HandPanel.HandSlot.MAINHAND)
                {
                    equipment.EquipMainHandWeapon(itemIndex);
                }
                else if (slotLocation == HandPanel.HandSlot.OFFHAND)
                {
                    equipment.EquipOffHandWeapon(itemIndex);

                }
                else if (slotLocation == HandPanel.HandSlot.OUTFIT)
                {
                    equipment.EquipOutfit(itemIndex);
                }
                else if (slotLocation == HandPanel.HandSlot.FOCUSIMPLANT)
                {
                    focus.EquipImplant(itemIndex);
                }
                else if (slotLocation == HandPanel.HandSlot.QUICKEQUIP)
                {
                    equipment.ClearQuickWeaponSlot(quickEquipIndex);
                }
                else if (slotLocation == HandPanel.HandSlot.QUICK_AID)
                {
                    quickAidManager.ClearItem(quickEquipIndex);
                }

                ResetItemSlot();
            }
            else
            {
                // spells
                if (slotLocation == HandPanel.HandSlot.MAINHAND)
                {
                    equipment.EquipMainHandSpell(spell);
                }
                else if (slotLocation == HandPanel.HandSlot.OFFHAND)
                {
                    equipment.EquipOffHandSpell(spell);
                }
                else if (slotLocation == HandPanel.HandSlot.QUICKEQUIP)
                {
                    equipment.ClearQuickWeaponSlot(quickEquipIndex);
                }
                ResetSpellSlot();
            }
        }
    }

    private void ResetItemSlot()
    {
        item = null;
        type = Equippable.EquippableType.NULL;
        itemIndex = -1;
        slotImage.sprite = emptySprite;
    }

    private void ResetSpellSlot()
    {
        spell = null;
        type = Equippable.EquippableType.NULL;
        slotImage.sprite = emptySprite;
    }
}
