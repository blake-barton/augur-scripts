using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class StatusMessageManager : MonoBehaviour
{
    [SerializeField] float timeToDisplay = 3f;

    [Header("Floating Text")]
    [SerializeField] GameObject floatingText;
    [SerializeField] Transform playerTransform;

    [Header("Audio")]
    [SerializeField] AudioSource effectsAudioSource;
    [SerializeField] AudioClip criticalHitAudioClip;
    [SerializeField] [Range(0, 1)] float criticalHitAudioVolume = 1f;

    public void DisplayMessage(string message)
    {
        GameObject instantiatedMessage = Instantiate(floatingText, playerTransform.position, Quaternion.identity);
        instantiatedMessage.transform.GetChild(0).GetComponent<TextMeshPro>().text = message;   // drop shadow
        instantiatedMessage.transform.GetChild(1).GetComponent<TextMeshPro>().text = message;   // text
        Destroy(instantiatedMessage, timeToDisplay);
    }

    public void DisplayMessage(string message, AudioClip audioClip, float volume)
    {
        DisplayMessage(message);
        AudioUtility.PlaySound(effectsAudioSource, audioClip, volume);
    }

    public void DisplayCriticalHitMessage()
    {
        DisplayMessage("CRITICAL HIT!");
        AudioUtility.PlaySound(effectsAudioSource, criticalHitAudioClip, criticalHitAudioVolume);
    }
}
