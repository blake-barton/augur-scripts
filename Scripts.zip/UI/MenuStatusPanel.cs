using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.EventSystems;

public class MenuStatusPanel : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    // state
    [SerializeField] bool isHovered = false;
    [SerializeField] TextMeshProUGUI statusMessage;

    [Header("Audio")]
    [SerializeField] AudioClip statusSound;
    [SerializeField] [Range(0, 1)] float statusVolume = .5f;

    private void Awake()
    {
        GameObject.FindWithTag("UISound").GetComponent<AudioSource>().PlayOneShot(statusSound, statusVolume);
    }

    // Update is called once per frame
    void Update()
    {
        CancelOnOuterClick();
    }

    public void SetStatusMessage(string message)
    {
        statusMessage.text = message;
    }

    private void CancelOnOuterClick()
    {
        if (!isHovered && (Input.GetMouseButtonDown(0) || Input.GetMouseButtonDown(1)))
        {
            CancelOperation();
        }
    }

    public void CancelOperation()
    {
        Destroy(gameObject);
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        isHovered = true;
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        isHovered = false;
    }
}
