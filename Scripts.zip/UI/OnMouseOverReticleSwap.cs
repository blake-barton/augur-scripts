using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class OnMouseOverReticleSwap : MonoBehaviour
{
    [SerializeField] Sprite normalCursor;
    [SerializeField] Sprite mouseOverCursor;

    Image cursorImage;

    private void Awake()
    {
        cursorImage = GameObject.FindGameObjectWithTag("Cursor").GetComponent<Image>();
    }

    private void OnMouseEnter()
    {
        cursorImage.sprite = mouseOverCursor;
    }

    private void OnMouseExit()
    {
        cursorImage.sprite = normalCursor;
    }
}
