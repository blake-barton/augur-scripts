using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ExitGamePanel : MonoBehaviour
{
    SceneLoader sceneLoader;
    TabMenuManager tabMenuManager;

    private void Awake()
    {
        sceneLoader = FindObjectOfType<SceneLoader>();
        tabMenuManager = FindObjectOfType<TabMenuManager>();
    }

    // button
    public void ExitToDesktop()
    {
        sceneLoader.QuitGame();
    }

    // button
    public void RestartAtHomeBunker()
    {
        tabMenuManager.ExitMenu();
        sceneLoader.LoadSceneByName("HomeBunker");
    }

    public void MainMenu()
    {
        tabMenuManager.ExitMenu();
        sceneLoader.LoadFirstScene();
    }
}
