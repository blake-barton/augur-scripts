using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using TMPro;
using UnityEngine.UI;

public class RewardOptionClickable : MonoBehaviour, IPointerClickHandler
{
    [SerializeField] int itemID;

    [Header("Child Objects")]
    [SerializeField] TextMeshProUGUI itemName;
    [SerializeField] TextMeshProUGUI itemRarity;
    [SerializeField] TextMeshProUGUI itemDescription;
    [SerializeField] Image itemSprite;
    [SerializeField] TextMeshProUGUI quantity;
    [SerializeField] Image requiredSkillImage;
    [SerializeField] TextMeshProUGUI requiredSkillText;

    [Header("Rarity Colors")]
    [SerializeField] Color commonColor;
    [SerializeField] Color uncommonColor;
    [SerializeField] Color rareColor;
    [SerializeField] Color epicColor;

    [Header("Required Skills")]
    [SerializeField] Color skillRequirementNotMetColor;
    [SerializeField] Sprite rifles;
    [SerializeField] Sprite pistols;
    [SerializeField] Sprite throwing;
    [SerializeField] Sprite heavyWeapons;
    [SerializeField] Sprite explosives;
    [SerializeField] Sprite bludgeoning;
    [SerializeField] Sprite polearms;
    [SerializeField] Sprite blade;

    RoomManager roomManager;
    AttributeScores playerAttributes;

    private void Awake()
    {
        roomManager = FindObjectOfType<RoomManager>();
        playerAttributes = FindObjectOfType<AttributeScores>();
    }

    public void OnPointerClick(PointerEventData eventData)
    {
        // tell room manager to spawn the item corresponding to this option, destroy the selection menu, and reenable player movement
        roomManager.SubmitRewardSelection(itemID);
    }

    public void SetOptionClickableFields(int _itemID, Item item)
    {
        itemID = _itemID;
        itemName.text = item.ItemName;

        itemRarity.text = item.Rarity.ToString();
        SetItemRarityColor(item.Rarity);

        itemDescription.text = item.Description;
        itemSprite.sprite = item.Sprite;

        quantity.text = "QUANTITY: " + item.NumberToReward.ToString();

        // Required skill
        if (item is Weapon weapon)
        {
            // Color requirement red if inadequate
            if (playerAttributes.GetSkillValue(weapon.WeaponSkill) < weapon.WeaponSkillRequirement)
            {
                requiredSkillText.color = skillRequirementNotMetColor;
            }

            SetRequiredSkillSprite(weapon.WeaponSkill);
            requiredSkillText.text = weapon.WeaponSkillRequirement.ToString();
        }
        else
        {
            requiredSkillImage.enabled = false;
            requiredSkillText.text = "";
        }
    }

    void SetRequiredSkillSprite(AttributeScores.Skills skill)
    {
        switch (skill)
        {
            case AttributeScores.Skills.BLADE:
                requiredSkillImage.sprite = blade;
                break;
            case AttributeScores.Skills.BLUDGEONING:
                requiredSkillImage.sprite = bludgeoning;
                break;
            case AttributeScores.Skills.EXPLOSIVES:
                requiredSkillImage.sprite = explosives;
                break;
            case AttributeScores.Skills.HEAVY_WEAPONS:
                requiredSkillImage.sprite = heavyWeapons;
                break;
            case AttributeScores.Skills.PISTOLS:
                requiredSkillImage.sprite = pistols;
                break;
            case AttributeScores.Skills.POLEARMS:
                requiredSkillImage.sprite = polearms;
                break;
            case AttributeScores.Skills.RIFLES:
                requiredSkillImage.sprite = rifles;
                break;
            case AttributeScores.Skills.THROWING:
                requiredSkillImage.sprite = throwing;
                break;
            default:
                break;
        }
    }

    void SetItemRarityColor(Item.ItemRarity rarity)
    {
        switch (rarity)
        {
            case Item.ItemRarity.COMMON:
                itemRarity.color = commonColor;
                break;
            case Item.ItemRarity.UNCOMMON:
                itemRarity.color = uncommonColor;
                break;
            case Item.ItemRarity.RARE:
                itemRarity.color = rareColor;
                break;
            case Item.ItemRarity.EPIC:
                itemRarity.color = epicColor;
                break;
            default:
                break;
        }
    }

    /* Not yet implemented */
    void SetSkillRequirement(AttributeScores.Skills requiredSkill, int skillRequirement)
    {
        GameObject skillPrefab = null;

        switch (requiredSkill)
        {
            case AttributeScores.Skills.BLADE:
                break;
            case AttributeScores.Skills.BLUDGEONING:
                break;
            case AttributeScores.Skills.ENKIISM:
                break;
            case AttributeScores.Skills.EREBANCY:
                break;
            case AttributeScores.Skills.EXPLOSIVES:
                break;
            case AttributeScores.Skills.GAIANISM:
                break;
            case AttributeScores.Skills.HEAVY_WEAPONS:
                break;
            case AttributeScores.Skills.HERMETICISM:
                break;
            case AttributeScores.Skills.IKTOMANCY:
                break;
            case AttributeScores.Skills.PISTOLS:
                break;
            case AttributeScores.Skills.POLEARMS:
                break;
            case AttributeScores.Skills.RESHEPHISM:
                break;
            case AttributeScores.Skills.RIFLES:
                break;
            case AttributeScores.Skills.THROWING:
                break;
            default:
                break;
        }

        // textmeshpro is the second child element
        skillPrefab.transform.GetChild(1).GetComponent<TextMeshProUGUI>().text = skillRequirement.ToString();
    }
}
