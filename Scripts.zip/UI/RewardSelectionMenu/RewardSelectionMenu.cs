using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RewardSelectionMenu : MonoBehaviour
{
    [SerializeField] GameObject rewardOptionTemplate;

    [Header("Cached Transforms")]
    [SerializeField] Transform optionGroup;

    RoomManager roomManager;

    private void Awake()
    {
        roomManager = FindObjectOfType<RoomManager>();
    }

    // Start is called before the first frame update
    void Start()
    {
        LoadRewardSelections();
    }

    void LoadRewardSelections()
    {
        int itemID;
        for (int i = 0; i < roomManager.RewardItemIDs.Count; i++)
        {
            itemID = roomManager.RewardItemIDs[i];
            Item currentReward = roomManager.GetItemFromDatabase(itemID);

            // instantiate a reward selection game object
            GameObject rewardOption = Instantiate(rewardOptionTemplate, optionGroup);
            rewardOption.GetComponent<RewardOptionClickable>().SetOptionClickableFields(itemID, currentReward);
        }
    }
}
