using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;
using UnityEngine.InputSystem;

public class QuickAidManager : MonoBehaviour
{
    [SerializeField] SortedDictionary<int, Pair<Item, int>> quickAidItems = new SortedDictionary<int, Pair<Item, int>>();
    [SerializeField] int activeKey = 0;
    [SerializeField] int quickAidSize = 12;

    [Header("HUD")]
    [SerializeField] Image hudItemBorder;
    [SerializeField] Image hudItemImage;
    [SerializeField] TextMeshProUGUI hudCountText;

    [Header("Cached References")]
    [SerializeField] Player player;
    [SerializeField] PlayerMovement playerMovement;
    [SerializeField] Inventory playerInventory;
    [SerializeField] TabMenuManager tabMenuManager;
    [SerializeField] WeaponWheelManager weaponWheelManager;

    [Header("Visuals")]
    [SerializeField] Color borderDefaultColor;
    [SerializeField] Color nextItemColorFlash;
    [SerializeField] float nextItemColorFlashTime = 0.1f;

    [Header("Audio")]
    [SerializeField] AudioSource uiSounds;
    [SerializeField] AudioClip nextItemAudio;
    [SerializeField] [Range(0, 1)] float nextItemAudioVolume = 1f;

    public SortedDictionary<int, Pair<Item, int>> QuickAidItems { get => quickAidItems; set => quickAidItems = value; }
    public int ActiveKey { get => activeKey; set => activeKey = value; }

    private void Start()
    {
        ClearQuickAidHUD();
    }

    public void OnUseActiveItem(InputAction.CallbackContext context)
    {
        if (!player.Character.Incapacitated && !player.IsBusy && !playerMovement.Dodging && !tabMenuManager.InMenu && !player.InDialogue && !weaponWheelManager.WheelDisplayed)
        {
            UseActiveItem();
        }
    }

    public void OnNextActiveItem(InputAction.CallbackContext context)
    {
        if (!player.Character.Incapacitated && !player.IsBusy && !playerMovement.Dodging && !tabMenuManager.InMenu && !player.InDialogue && !weaponWheelManager.WheelDisplayed)
        {
            EquipNextItem();
        }
    }

    public void AddItemPair(int index, Pair<Item, int> itemPair)
    {
        // If quick aid already has this item, clear it
        if (QuickAidItems.ContainsValue(itemPair))
        {
            int valueKey = -1;

            foreach (var element in QuickAidItems)
            {
                // look the matching value
                if (element.Value.First.ItemID == itemPair.First.ItemID)
                {
                    valueKey = element.Key;
                    break;
                }
            }

            // last check that we got a key
            if (valueKey > -1)
            {
                ClearItem(valueKey);
            }
        }

        if (QuickAidItems.ContainsKey(index))
        {
            // clear this index 
            ClearItem(index);
        }

        // equip this item if map is empty
        if (QuickAidItems.Count == 0)
        {
            ActiveKey = index;
        }

        // set item pair quick aid equipped value
        itemPair.First.QuickAidIndex = index;

        // add item pair to quick items
        QuickAidItems.Add(index, itemPair);

        // update hud
        UpdateHUDToActiveKey();
    }

    public void AddItemToFirstOpenSlot(Pair<Item, int> itemPair)
    {
        // Add item if there's an open slot
        if (quickAidItems.Count < quickAidSize)
        {
            for (int i = 0; i < quickAidSize; i++)
            {
                // Add the item to the first open slot
                if (!QuickAidItems.ContainsKey(i))
                {
                    AddItemPair(i, itemPair);
                    break;
                }
            }
        }
    }

    private void UseActiveItem()
    {
        if (QuickAidItems.Count > 0)
        {
            if (QuickAidItems[ActiveKey] != null)
            {
                ((Misc)QuickAidItems[ActiveKey].First).usable.Use();
                bool stillInInventory = playerInventory.RemoveItem(QuickAidItems[ActiveKey], 1, false);

                if (!stillInInventory)
                {
                    ClearItem(ActiveKey);
                }
                else
                {
                    // update HUD with new quantity
                    UpdateHUDToActiveKey();
                }
            }
        }
    }
    
    private void EquipNextItem()
    {
        bool foundItem = false;

        foreach (var element in QuickAidItems)
        {
            // look for a higher key
            if (element.Key > ActiveKey)
            {
                ActiveKey = element.Key;
                foundItem = true;
                break;
            }
        }

        // loop from start if no item found
        if (!foundItem)
        {
            foreach (var element in QuickAidItems)
            {
                // look for a the next lowest active key (or reselect the same item)
                if (element.Key <= ActiveKey)
                {
                    ActiveKey = element.Key;
                    foundItem = true;
                    break;
                }
            }
        }

        // HUD
        if (foundItem)
        {
            UpdateHUDToActiveKey();
        }
        else
        {
            // clear hud
            ClearQuickAidHUD();
        }

        // audio
        uiSounds.PlayOneShot(nextItemAudio, nextItemAudioVolume);

        // visuals
        StartCoroutine(BorderColorFlash());
    }

    public void ClearItem(int index)
    {
        if (QuickAidItems.ContainsKey(index))
        {
            // clear the item's quick aid index
            QuickAidItems[index].First.QuickAidIndex = -1;

            // remove the item from the quick aid list
            QuickAidItems.Remove(index);

            if (index == ActiveKey)
            {
                // reset active key so that nothing is equal to it
                ActiveKey = -1;
            }

            // move to the next item
            EquipNextItem();
        }
    }

    public void SetActiveKey(int index)
    {
        if (QuickAidItems.ContainsKey(index))
        {
            ActiveKey = index;

            UpdateHUDToActiveKey();
        }
    }

    public void UpdateHUDToActiveKey()
    {
        if (QuickAidItems.ContainsKey(ActiveKey))
        {
            hudItemImage.enabled = true;
            hudItemImage.sprite = QuickAidItems[ActiveKey].First.Sprite;

            hudCountText.transform.parent.gameObject.SetActive(true);
            hudCountText.text = QuickAidItems[ActiveKey].Second.ToString();
        }
    }

    private void ClearQuickAidHUD()
    {
        hudItemImage.enabled = false;
        hudCountText.text = "";
        hudCountText.transform.parent.gameObject.SetActive(false);
    }

    IEnumerator BorderColorFlash()
    {
        hudItemBorder.color = nextItemColorFlash;

        yield return new WaitForSeconds(nextItemColorFlashTime);

        hudItemBorder.color = borderDefaultColor;
    }
}
