using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class SelectXDropBehavior : MonoBehaviour
{
    [SerializeField] Slider slider;
    [SerializeField] int itemIndex;

    // cache
    TabMenuManager tabMenuManager;
    Inventory playerInventory;
    InventoryPanel inventoryPanel;

    public int ItemIndex { get => itemIndex; set => itemIndex = value; }

    private void Awake()
    {
        tabMenuManager = FindObjectOfType<TabMenuManager>();
        playerInventory = FindObjectOfType<Player>().GetComponent<Inventory>();
        inventoryPanel = FindObjectOfType<InventoryPanel>();
    }

    public void DropItems()
    {
        // tell the player's inventory to drop the item at this slot's index
        bool stillInInventory = playerInventory.DropItem(itemIndex, (int)slider.value);

        if (!stillInInventory)
        {
            // clear the info panel if quantity is 0
            tabMenuManager.DestroyInfoPanel();
            tabMenuManager.LoadTestInfoPanel();

            // clear item name from header
            inventoryPanel.SetItemNameTitleText("");

            // delete the slot
            inventoryPanel.DestroySlotAtIndex(itemIndex);
        }
        else
        {
            // reload info panel to reflect new quantity
            ActivateTabManagerInfoPanelLoad();
            inventoryPanel.UpdateSlotCountAtIndex(itemIndex, (int)slider.value);
        }

        // destroy the select x popup panel
        Destroy(gameObject);
    }

    private void ActivateTabManagerInfoPanelLoad()
    {
        // clear current item info
        tabMenuManager.DestroyInfoPanel();

        // get item data from player inventory
        Item item = playerInventory.Items[itemIndex].First;

        // get item count
        int itemCount = playerInventory.GetItemCountAtIndex(itemIndex);

        // load an info panel with this item's data
        tabMenuManager.LoadItemInfoPanel(item, itemCount);
    }
}
