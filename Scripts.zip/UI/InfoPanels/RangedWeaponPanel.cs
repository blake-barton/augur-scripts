using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class RangedWeaponPanel : MonoBehaviour
{
    [Header("Item Data")]
    [SerializeField] TextMeshProUGUI itemName;
    [SerializeField] Image itemImage;
    [SerializeField] TextMeshProUGUI crypto;
    [SerializeField] TextMeshProUGUI weight;

    [Header("Damage Values")]
    [SerializeField] TextMeshProUGUI blunt;
    [SerializeField] TextMeshProUGUI piercing;
    [SerializeField] TextMeshProUGUI slashing;
    [SerializeField] TextMeshProUGUI energy;
    [SerializeField] TextMeshProUGUI fire;
    [SerializeField] TextMeshProUGUI frost;
    [SerializeField] TextMeshProUGUI shock;
    [SerializeField] TextMeshProUGUI acid;
    [SerializeField] TextMeshProUGUI poison;
    [SerializeField] TextMeshProUGUI psionic;

    [Header("Ranged Weapon Stats")]
    [SerializeField] TextMeshProUGUI rangedWeaponType;
    [SerializeField] TextMeshProUGUI optimalRange;
    [SerializeField] TextMeshProUGUI maxRange;
    [SerializeField] TextMeshProUGUI reloadTime;
    [SerializeField] TextMeshProUGUI bonusCritChance;
    [SerializeField] TextMeshProUGUI chargeTime;
    [SerializeField] TextMeshProUGUI fireRate;
    [SerializeField] TextMeshProUGUI velocity;
    [SerializeField] TextMeshProUGUI force;
    [SerializeField] TextMeshProUGUI ammoPerShot;
    [SerializeField] TextMeshProUGUI projectilesPerShot;
    [SerializeField] TextMeshProUGUI bonusCritMult;
    [SerializeField] TextMeshProUGUI spread;

    [Header("Ammo")]
    [SerializeField] TextMeshProUGUI ammoText;  // contains type and count

    [Header("Required Attributes")]
    [SerializeField] Transform requiredSkillsGrid;
    [SerializeField] TextMeshProUGUI requiredStrengthValue;
    [SerializeField] GameObject strengthPrefab;
    [SerializeField] GameObject perceptionPrefab;
    [SerializeField] GameObject endurancePrefab;
    [SerializeField] GameObject intelligencePrefab;
    [SerializeField] GameObject agilityPrefab;
    [SerializeField] GameObject aberrancePrefab;

    [Header("Required Skills")]
    [SerializeField] GameObject riflesPrefab;
    [SerializeField] GameObject pistolsPrefab;
    [SerializeField] GameObject throwingPrefab;
    [SerializeField] GameObject heavyWeaponsPrefab;
    [SerializeField] GameObject explosivesPrefab;

    [Header("Colors")]
    [SerializeField] Color inadequateRequirementsColor;

    // cache
    Player player;
    AmmoCounter playerAmmo;
    AttributeScores playerAttributes;

    private void Awake()
    {
        player = FindObjectOfType<Player>();
        playerAmmo = player.GetComponent<AmmoCounter>();
        playerAttributes = player.GetComponent<AttributeScores>();
    }

    public void SetPanelText(Item item)
    {
        RangedWeapon rangedWeapon = (RangedWeapon)item;

        itemName.text = rangedWeapon.ItemName;
        itemImage.sprite = rangedWeapon.Sprite;
        crypto.text = rangedWeapon.Value.ToString() + "g";
        weight.text = rangedWeapon.Weight.ToString() + "kg";

        SetDamageValues((Weapon)item);

        rangedWeaponType.text = rangedWeapon.RangedWeaponTypesToString();
        optimalRange.text = System.Math.Round(rangedWeapon.EffectiveRange, 1).ToString() + "m";
        maxRange.text = System.Math.Round(rangedWeapon.MaxRange, 1).ToString() + "m";

        if (rangedWeapon.ReloadTime < 0)
        {
            reloadTime.text = "N/A";
        }
        else
        {
            reloadTime.text = System.Math.Round(rangedWeapon.ReloadTime, 1).ToString() + "s";
        }

        bonusCritChance.text = rangedWeapon.BonusCritChance.ToString() + "%";
        chargeTime.text = System.Math.Round(rangedWeapon.ChargeTime, 1).ToString() + "s";
        fireRate.text = Mathf.Round(rangedWeapon.AttackRate).ToString() + "rps";
        velocity.text = System.Math.Round(rangedWeapon.ProjectileSpeed, 1).ToString() + "m/s";
        force.text = System.Math.Round(rangedWeapon.ForceDamage, 1).ToString() + "N";
        ammoPerShot.text = rangedWeapon.AmmoUsedPerShot.ToString();
        projectilesPerShot.text = rangedWeapon.ProjectilesPerShot.ToString();
        bonusCritMult.text = System.Math.Round(rangedWeapon.BonusCritMultiplier, 1).ToString() + "x";
        spread.text = System.Math.Round(rangedWeapon.Spread).ToString();

        if (rangedWeapon.AmmunitionType == Item.AmmoType.NOT_APPLICABLE)
        {
            ammoText.text = "N/A";
        }
        else
        {
            ammoText.text = Item.AmmoTypeToString(rangedWeapon.AmmunitionType) + " " + rangedWeapon.AmmoInClip + "/" + playerAmmo.GetAmmoCountByType(rangedWeapon.AmmunitionType);
        }
        
        requiredStrengthValue.text = rangedWeapon.StrengthRequirement.ToString();

        // color strength requirement red if inadequate
        if (playerAttributes.Strength < rangedWeapon.StrengthRequirement)
        {
            requiredStrengthValue.color = inadequateRequirementsColor;
        }

        LoadRequiredAttributes(rangedWeapon);
    }

    void LoadRequiredAttributes(Weapon weapon)
    {
        GameObject skillPrefab = null;

        switch (weapon.WeaponSkill)
        {
            case AttributeScores.Skills.RIFLES:
                skillPrefab = Instantiate(riflesPrefab, requiredSkillsGrid);
                break;
            case AttributeScores.Skills.PISTOLS:
                skillPrefab = Instantiate(pistolsPrefab, requiredSkillsGrid);
                break;
            case AttributeScores.Skills.THROWING:
                skillPrefab = Instantiate(throwingPrefab, requiredSkillsGrid);
                break;
            case AttributeScores.Skills.HEAVY_WEAPONS:
                skillPrefab = Instantiate(heavyWeaponsPrefab, requiredSkillsGrid);
                break;
            case AttributeScores.Skills.EXPLOSIVES:
                skillPrefab = Instantiate(explosivesPrefab, requiredSkillsGrid);
                break;
        }

        // textmeshpro is the second child element
        skillPrefab.transform.GetChild(1).GetComponent<TextMeshProUGUI>().text = Mathf.Round(weapon.WeaponSkillRequirement).ToString();

        // color requirement red if inadequate
        if (playerAttributes.GetSkillValue(weapon.WeaponSkill) < weapon.WeaponSkillRequirement)
        {
            skillPrefab.transform.GetChild(1).GetComponent<TextMeshProUGUI>().color = inadequateRequirementsColor;
        }
    }

    private void SetDamageValues(Weapon weapon)
    {
        // loop through the weapon's damage types
        for (int i = 0; i < weapon.DamageTypes.Count; i++)
        {
            switch (weapon.DamageTypes[i])
            {
                case DamageEffects.DamageType.BLUNT:
                    blunt.text = Mathf.Round(weapon.Damages[i]).ToString();
                    break;
                case DamageEffects.DamageType.PIERCING:
                    piercing.text = Mathf.Round(weapon.Damages[i]).ToString();
                    break;
                case DamageEffects.DamageType.SLASHING:
                    slashing.text = Mathf.Round(weapon.Damages[i]).ToString();
                    break;
                case DamageEffects.DamageType.ENERGY:
                    energy.text = Mathf.Round(weapon.Damages[i]).ToString();
                    break;
                case DamageEffects.DamageType.FIRE:
                    fire.text = Mathf.Round(weapon.Damages[i]).ToString();
                    break;
                case DamageEffects.DamageType.FROST:
                    frost.text = Mathf.Round(weapon.Damages[i]).ToString();
                    break;
                case DamageEffects.DamageType.SHOCK:
                    shock.text = Mathf.Round(weapon.Damages[i]).ToString();
                    break;
                case DamageEffects.DamageType.ACID:
                    acid.text = Mathf.Round(weapon.Damages[i]).ToString();
                    break;
                case DamageEffects.DamageType.POISON:
                    poison.text = Mathf.Round(weapon.Damages[i]).ToString();
                    break;
                case DamageEffects.DamageType.PSIONIC:
                    psionic.text = Mathf.Round(weapon.Damages[i]).ToString();
                    break;
            }
        }
    }
}
