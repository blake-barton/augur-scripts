using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class SpellPanel : MonoBehaviour
{
    [Header("Spell Data")]
    [SerializeField] TextMeshProUGUI spellName;
    [SerializeField] TextMeshProUGUI spellSchool;
    [SerializeField] Image spellImage;
    [SerializeField] TextMeshProUGUI mpCost;
    [SerializeField] TextMeshProUGUI castTime;
    [SerializeField] TextMeshProUGUI spellEffect;

    [Header("Required Skills")]
    [SerializeField] Transform requiredSkillsGrid;
    [SerializeField] GameObject enkiismPrefab;
    [SerializeField] GameObject erebancyPrefab;
    [SerializeField] GameObject gaianismPrefab;
    [SerializeField] GameObject hermeticismPrefab;
    [SerializeField] GameObject iktomancyPrefab;
    [SerializeField] GameObject reshephismPrefab;

    [Header("Colors")]
    [SerializeField] Color inadequateRequirementsColor;

    // cache
    Player player;
    AttributeScores playerAttributes;

    private void Awake()
    {
        player = FindObjectOfType<Player>();
        playerAttributes = player.GetComponent<AttributeScores>();
    }

    public void SetPanelInfo(Spell spell)
    {
        spellName.text = spell.SpellName;
        spellSchool.text = spell.SpellSchool.ToString();
        spellImage.sprite = spell.SpellSprite;
        mpCost.text = spell.MpCost.ToString();

        if (spell.ConstantCast)
        {
            castTime.text = "CONSTANT";
        }
        else
        {
            castTime.text = spell.CastTime.ToString() + "s";
        }

        spellEffect.text = spell.EffectDescription;

        LoadRequiredSkills(spell);
    }

    void LoadRequiredSkills(Spell spell)
    {
        GameObject skillPrefab = null;

        switch (spell.RequiredSkill)
        {
            case AttributeScores.Skills.ENKIISM:
                skillPrefab = Instantiate(enkiismPrefab, requiredSkillsGrid);
                break;
            case AttributeScores.Skills.EREBANCY:
                skillPrefab = Instantiate(erebancyPrefab, requiredSkillsGrid);
                break;
            case AttributeScores.Skills.GAIANISM:
                skillPrefab = Instantiate(gaianismPrefab, requiredSkillsGrid);
                break;
            case AttributeScores.Skills.HERMETICISM:
                skillPrefab = Instantiate(hermeticismPrefab, requiredSkillsGrid);
                break;
            case AttributeScores.Skills.IKTOMANCY:
                skillPrefab = Instantiate(iktomancyPrefab, requiredSkillsGrid);
                break;
            case AttributeScores.Skills.RESHEPHISM:
                skillPrefab = Instantiate(reshephismPrefab, requiredSkillsGrid);
                break;
        }

        // textmeshpro is the second child element
        skillPrefab.transform.GetChild(1).GetComponent<TextMeshProUGUI>().text = spell.SkillRequirement.ToString();

        // color requirement red if inadequate
        if (playerAttributes.GetSkillValue(spell.RequiredSkill) < spell.SkillRequirement)
        {
            skillPrefab.transform.GetChild(1).GetComponent<TextMeshProUGUI>().color = inadequateRequirementsColor;
        }
    }
}
