using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class OutfitPanel : MonoBehaviour
{
    [Header("Item Data")]
    [SerializeField] TextMeshProUGUI itemName;
    [SerializeField] Image itemImage;
    [SerializeField] TextMeshProUGUI crypto;
    [SerializeField] TextMeshProUGUI weight;

    [Header("Outfit Data")]
    [SerializeField] TextMeshProUGUI outfitType;
    [SerializeField] TextMeshProUGUI outfitEffect;
    [SerializeField] TextMeshProUGUI poise;

    [Header("Damage Thresholds")]
    [SerializeField] TextMeshProUGUI bluntDT;
    [SerializeField] TextMeshProUGUI piercingDT;
    [SerializeField] TextMeshProUGUI slashingDT;
    [SerializeField] TextMeshProUGUI energyDT;
    [SerializeField] TextMeshProUGUI fireDT;
    [SerializeField] TextMeshProUGUI frostDT;
    [SerializeField] TextMeshProUGUI shockDT;
    [SerializeField] TextMeshProUGUI acidDT;
    [SerializeField] TextMeshProUGUI poisonDT;
    [SerializeField] TextMeshProUGUI psionicDT;

    [Header("Damage Type Grids")]
    [SerializeField] Transform vulnerabilityGrid;
    [SerializeField] Transform resistanceGrid;
    [SerializeField] Transform immunityGrid;

    [Header("Damage Type Icons")]
    [SerializeField] GameObject blunt;
    [SerializeField] GameObject piercing;
    [SerializeField] GameObject slashing;
    [SerializeField] GameObject energy;
    [SerializeField] GameObject fire;
    [SerializeField] GameObject frost;
    [SerializeField] GameObject shock;
    [SerializeField] GameObject acid;
    [SerializeField] GameObject poison;
    [SerializeField] GameObject psionic;

    public void SetPanelInfo(Item item)
    {
        Outfit outfit = (Outfit)item;

        itemName.text = item.ItemName;
        itemImage.sprite = item.Sprite;
        crypto.text = item.Value.ToString() + "g";
        weight.text = item.Weight.ToString() + "kg";

        outfitType.text = outfit.GetOutfitTypeAsString();
        outfitEffect.text = outfit.OutfitEffectsDescription.ToString();
        poise.text = outfit.Poise.ToString();

        LoadDamageThresholds(outfit);

        LoadVulnerabilityIcons(outfit);
        LoadResistanceIcons(outfit);
        LoadImmunityIcons(outfit);
    }

    void LoadDamageThresholds(Outfit outfit)
    {
        bluntDT.text = outfit.BluntDT.ToString();
        piercingDT.text = outfit.PiercingDT.ToString();
        slashingDT.text = outfit.SlashingDT.ToString();
        energyDT.text = outfit.EnergyDT.ToString();
        fireDT.text = outfit.FireDT.ToString();
        frostDT.text = outfit.FrostDT.ToString();
        shockDT.text = outfit.ShockDT.ToString();
        acidDT.text = outfit.AcidDT.ToString();
        poisonDT.text = outfit.PoisonDT.ToString();
        psionicDT.text = outfit.PsionicDT.ToString();
    }

    void LoadVulnerabilityIcons(Outfit outfit)
    {
        foreach (DamageEffects.DamageType vuln in outfit.Vulnerabilities)
        {
            switch (vuln)
            {
                case DamageEffects.DamageType.BLUNT:
                    Instantiate(blunt, vulnerabilityGrid);
                    break;
                case DamageEffects.DamageType.PIERCING:
                    Instantiate(piercing, vulnerabilityGrid);
                    break;
                case DamageEffects.DamageType.SLASHING:
                    Instantiate(slashing, vulnerabilityGrid);
                    break;
                case DamageEffects.DamageType.ENERGY:
                    Instantiate(energy, vulnerabilityGrid);
                    break;
                case DamageEffects.DamageType.FIRE:
                    Instantiate(fire, vulnerabilityGrid);
                    break;
                case DamageEffects.DamageType.FROST:
                    Instantiate(frost, vulnerabilityGrid);
                    break;
                case DamageEffects.DamageType.SHOCK:
                    Instantiate(shock, vulnerabilityGrid);
                    break;
                case DamageEffects.DamageType.ACID:
                    Instantiate(acid, vulnerabilityGrid);
                    break;
                case DamageEffects.DamageType.POISON:
                    Instantiate(poison, vulnerabilityGrid);
                    break;
                case DamageEffects.DamageType.PSIONIC:
                    Instantiate(psionic, vulnerabilityGrid);
                    break;
            }
        }
    }

    void LoadResistanceIcons(Outfit outfit)
    {
        foreach (DamageEffects.DamageType res in outfit.Resistances)
        {
            switch (res)
            {
                case DamageEffects.DamageType.BLUNT:
                    Instantiate(blunt, resistanceGrid);
                    break;
                case DamageEffects.DamageType.PIERCING:
                    Instantiate(piercing, resistanceGrid);
                    break;
                case DamageEffects.DamageType.SLASHING:
                    Instantiate(slashing, resistanceGrid);
                    break;
                case DamageEffects.DamageType.ENERGY:
                    Instantiate(energy, resistanceGrid);
                    break;
                case DamageEffects.DamageType.FIRE:
                    Instantiate(fire, resistanceGrid);
                    break;
                case DamageEffects.DamageType.FROST:
                    Instantiate(frost, resistanceGrid);
                    break;
                case DamageEffects.DamageType.SHOCK:
                    Instantiate(shock, resistanceGrid);
                    break;
                case DamageEffects.DamageType.ACID:
                    Instantiate(acid, resistanceGrid);
                    break;
                case DamageEffects.DamageType.POISON:
                    Instantiate(poison, resistanceGrid);
                    break;
                case DamageEffects.DamageType.PSIONIC:
                    Instantiate(psionic, resistanceGrid);
                    break;
            }
        }
    }

    void LoadImmunityIcons(Outfit outfit)
    {
        foreach (DamageEffects.DamageType imm in outfit.Immunities)
        {
            switch (imm)
            {
                case DamageEffects.DamageType.BLUNT:
                    Instantiate(blunt, immunityGrid);
                    break;
                case DamageEffects.DamageType.PIERCING:
                    Instantiate(piercing, immunityGrid);
                    break;
                case DamageEffects.DamageType.SLASHING:
                    Instantiate(slashing, immunityGrid);
                    break;
                case DamageEffects.DamageType.ENERGY:
                    Instantiate(energy, immunityGrid);
                    break;
                case DamageEffects.DamageType.FIRE:
                    Instantiate(fire, immunityGrid);
                    break;
                case DamageEffects.DamageType.FROST:
                    Instantiate(frost, immunityGrid);
                    break;
                case DamageEffects.DamageType.SHOCK:
                    Instantiate(shock, immunityGrid);
                    break;
                case DamageEffects.DamageType.ACID:
                    Instantiate(acid, immunityGrid);
                    break;
                case DamageEffects.DamageType.POISON:
                    Instantiate(poison, immunityGrid);
                    break;
                case DamageEffects.DamageType.PSIONIC:
                    Instantiate(psionic, immunityGrid);
                    break;
            }
        }
    }
}
