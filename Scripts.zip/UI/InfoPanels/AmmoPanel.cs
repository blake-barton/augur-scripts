using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class AmmoPanel : MonoBehaviour
{
    [Header("Item Data")]
    [SerializeField] TextMeshProUGUI itemName;
    [SerializeField] Image itemImage;
    [SerializeField] TextMeshProUGUI crypto;
    [SerializeField] TextMeshProUGUI numberHeld;
    [SerializeField] TextMeshProUGUI numberStored;

    public void SetPanelText(Item item, int itemCount)
    {
        Ammo ammo = (Ammo)item;

        itemName.text = ammo.ItemName;
        itemImage.sprite = ammo.Sprite;
        crypto.text = ammo.Value.ToString() + "g";

        numberHeld.text = itemCount.ToString() + "/" + ammo.HeldMax;
        numberStored.text = "0/" + ammo.StoredMax;                      //TODO
    }
}