using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class MiscPanel : MonoBehaviour
{
    [Header("Item Data")]
    [SerializeField] TextMeshProUGUI itemName;
    [SerializeField] Image itemImage;
    [SerializeField] TextMeshProUGUI crypto;
    [SerializeField] TextMeshProUGUI numberHeld;
    [SerializeField] TextMeshProUGUI numberStored;
    [SerializeField] TextMeshProUGUI itemEffect;

    public void SetPanelText(Item item, int itemCount)
    {
        Misc misc = (Misc)item;

        itemName.text = misc.ItemName;
        itemImage.sprite = misc.Sprite;
        crypto.text = misc.Value.ToString() + "g";

        numberHeld.text = itemCount.ToString() + "/" + misc.HeldMax;
        numberStored.text = "0/" + misc.StoredMax;                      //TODO

        itemEffect.text = misc.MiscEffectDescription;
    }
}

