using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class MeleeWeaponPanel : MonoBehaviour
{
    [Header("Item Data")]
    [SerializeField] TextMeshProUGUI itemName;
    [SerializeField] Image itemImage;
    [SerializeField] TextMeshProUGUI crypto;
    [SerializeField] TextMeshProUGUI weight;

    [Header("Damage Values")]
    [SerializeField] TextMeshProUGUI blunt;
    [SerializeField] TextMeshProUGUI piercing;
    [SerializeField] TextMeshProUGUI slashing;
    [SerializeField] TextMeshProUGUI energy;
    [SerializeField] TextMeshProUGUI fire;
    [SerializeField] TextMeshProUGUI frost;
    [SerializeField] TextMeshProUGUI shock;
    [SerializeField] TextMeshProUGUI acid;
    [SerializeField] TextMeshProUGUI poison;
    [SerializeField] TextMeshProUGUI psionic;

    [Header("Melee Weapon Stats")]
    [SerializeField] TextMeshProUGUI meleeWeaponType;
    [SerializeField] TextMeshProUGUI range;
    [SerializeField] TextMeshProUGUI attackSpeed;
    [SerializeField] TextMeshProUGUI attackRate;
    [SerializeField] TextMeshProUGUI force;
    [SerializeField] TextMeshProUGUI bonusCritChance;

    [Header("Required Attributes")]
    [SerializeField] Transform requiredSkillsGrid;
    [SerializeField] TextMeshProUGUI requiredStrengthValue;
    [SerializeField] GameObject strengthPrefab;
    [SerializeField] GameObject perceptionPrefab;
    [SerializeField] GameObject endurancePrefab;
    [SerializeField] GameObject intelligencePrefab;
    [SerializeField] GameObject agilityPrefab;
    [SerializeField] GameObject aberrancePrefab;

    [Header("Required Skills")]
    [SerializeField] GameObject bladePrefab;
    [SerializeField] GameObject bludgeoningPrefab;
    [SerializeField] GameObject polearmPrefab;

    [Header("Colors")]
    [SerializeField] Color inadequateRequirementsColor;

    // cache
    Player player;
    AttributeScores playerAttributes;

    private void Awake()
    {
        player = FindObjectOfType<Player>();
        playerAttributes = player.GetComponent<AttributeScores>();
    }

    public void SetPanelText(Item item)
    {
        MeleeWeapon meleeWeapon = (MeleeWeapon)item;

        itemName.text = meleeWeapon.ItemName;
        itemImage.sprite = meleeWeapon.Sprite;
        crypto.text = Mathf.Round(meleeWeapon.Value).ToString() + "g";
        weight.text = Mathf.Round(meleeWeapon.Weight).ToString() + "kg";

        SetDamageValues((Weapon)item);

        meleeWeaponType.text = meleeWeapon.MeleeType.ToString();
        range.text = meleeWeapon.Range.ToString();
        attackSpeed.text = meleeWeapon.AttackSpeed.ToString();
        attackRate.text = Mathf.Round(meleeWeapon.AttackRate).ToString() + "/s";
        force.text = Mathf.Round(meleeWeapon.ForceDamage).ToString() + "N";
        bonusCritChance.text = Mathf.Round(meleeWeapon.BonusCritChance).ToString() + "%";

        requiredStrengthValue.text = meleeWeapon.StrengthRequirement.ToString();

        // color strength requirement red if inadequate
        if (playerAttributes.Strength < meleeWeapon.StrengthRequirement)
        {
            requiredStrengthValue.color = inadequateRequirementsColor;
        }

        LoadRequiredAttributes(meleeWeapon);
    }

    void LoadRequiredAttributes(Weapon weapon)
    {
        GameObject skillPrefab = null;

        switch (weapon.WeaponSkill)
        {
            case AttributeScores.Skills.BLADE:
                skillPrefab = Instantiate(bladePrefab, requiredSkillsGrid);
                break;
            case AttributeScores.Skills.BLUDGEONING:
                skillPrefab = Instantiate(bludgeoningPrefab, requiredSkillsGrid);
                break;
            case AttributeScores.Skills.POLEARMS:
                skillPrefab = Instantiate(polearmPrefab, requiredSkillsGrid);
                break;
        }

        // textmeshpro is the second child element
        skillPrefab.transform.GetChild(1).GetComponent<TextMeshProUGUI>().text = Mathf.Round(weapon.WeaponSkillRequirement).ToString();

        // color requirement red if inadequate
        if (playerAttributes.GetSkillValue(weapon.WeaponSkill) < weapon.WeaponSkillRequirement)
        {
            skillPrefab.transform.GetChild(1).GetComponent<TextMeshProUGUI>().color = inadequateRequirementsColor;
        }
    }

    private void SetDamageValues(Weapon weapon)
    {
        // loop through the weapon's damage types
        for (int i = 0; i < weapon.DamageTypes.Count; i++)
        {
            switch (weapon.DamageTypes[i])
            {
                case DamageEffects.DamageType.BLUNT:
                    blunt.text = Mathf.Round(weapon.Damages[i]).ToString();
                    break;
                case DamageEffects.DamageType.PIERCING:
                    piercing.text = Mathf.Round(weapon.Damages[i]).ToString();
                    break;
                case DamageEffects.DamageType.SLASHING:
                    slashing.text = Mathf.Round(weapon.Damages[i]).ToString();
                    break;
                case DamageEffects.DamageType.ENERGY:
                    energy.text = Mathf.Round(weapon.Damages[i]).ToString();
                    break;
                case DamageEffects.DamageType.FIRE:
                    fire.text = Mathf.Round(weapon.Damages[i]).ToString();
                    break;
                case DamageEffects.DamageType.FROST:
                    frost.text = Mathf.Round(weapon.Damages[i]).ToString();
                    break;
                case DamageEffects.DamageType.SHOCK:
                    shock.text = Mathf.Round(weapon.Damages[i]).ToString();
                    break;
                case DamageEffects.DamageType.ACID:
                    acid.text = Mathf.Round(weapon.Damages[i]).ToString();
                    break;
                case DamageEffects.DamageType.POISON:
                    poison.text = Mathf.Round(weapon.Damages[i]).ToString();
                    break;
                case DamageEffects.DamageType.PSIONIC:
                    psionic.text = Mathf.Round(weapon.Damages[i]).ToString();
                    break;
            }
        }
    }
}
