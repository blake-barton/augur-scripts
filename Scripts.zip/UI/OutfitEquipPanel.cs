using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class OutfitEquipPanel : MonoBehaviour
{
    [Header("Outfit Grid")]
    [SerializeField] GameObject itemSlotTemplate;
    [SerializeField] GameObject itemGrid;

    [Header("Text")]
    [SerializeField] TextMeshProUGUI categoryTitleText;
    [SerializeField] TextMeshProUGUI equippableNameTitleText;

    // cached references
    Inventory playerInventory;

    private void Awake()
    {
        playerInventory = FindObjectOfType<Player>().gameObject.GetComponent<Inventory>();
    }

    // Start is called before the first frame update
    void Start()
    {
        LoadPlayerInventoryIntoGrid();
        categoryTitleText.text = "Outfits";
        equippableNameTitleText.text = "";

        ToggleInventoryCategory(2); // outfits
    }

    void LoadPlayerInventoryIntoGrid()
    {
        foreach (Pair<Item, int> pair in playerInventory.Items)
        {
            // insert the slot into the grid
            GameObject newSlot = Instantiate(itemSlotTemplate, itemGrid.transform);

            // fill the slot with data
            FillItemSlotTemplate(newSlot, pair.First.ItemName, pair.First.Type, pair.First.Sprite, pair.Second, pair.First.EquippedMain, pair.First.EquippedOff, pair.First.Equipped);
        }
    }

    void FillItemSlotTemplate(GameObject newSlot, string itemName, Item.ItemType itemType, Sprite itemSprite, int itemCount, bool equippedMain, bool equippedOff, bool itemEquipped)
    {
        InventoryClickable clickable = newSlot.GetComponent<InventoryClickable>();
        Image itemImage = newSlot.transform.GetChild(0).GetComponent<Image>();

        clickable.SlotType = InventoryClickable.ClickableType.OUTFIT_EQUIP_SLOT;

        clickable.itemType = itemType;
        clickable.itemName = itemName;
        clickable.ItemCount = itemCount;
        clickable.UpdateCountPanelText();
        itemImage.sprite = itemSprite;

        // equip panels
        clickable.EquippedMain = equippedMain;
        clickable.EquippedOff = equippedOff;
        clickable.ItemEquipped = itemEquipped;
        clickable.UpdateEquipPanels();
    }

    // Disable all item panels that are not of the given type
    // NOTE: BECAUSE ENUMS ARE NOT SUPPORTED THIS IS PASSED AN INTEGER ARGUMENT, MEANING THAT IF THE ENUM IN Item.cs IS EVER CHANGED THE BUTTONS WILL NEED TO BE CHANGED
    public void ToggleInventoryCategory(int type)
    {
        itemGrid.SetActive(true);

        foreach (RectTransform child in itemGrid.transform)
        {
            if ((int)child.gameObject.GetComponent<InventoryClickable>().itemType != type)
            {
                child.gameObject.SetActive(false);
            }
            else
            {
                child.gameObject.SetActive(true);
            }
        }

        switch (type)
        {
            case (int)Item.ItemType.RANGEDWEAPON:
                categoryTitleText.text = "Ranged Weapons";
                break;
            case (int)Item.ItemType.MELEEWEAPON:
                categoryTitleText.text = "Melee Weapons";
                break;
        }

        SetEquippableNameTitleText("");
    }

    public void SetEquippableNameTitleText(string itemName)
    {
        equippableNameTitleText.text = itemName;
    }
}