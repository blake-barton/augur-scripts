using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class QuestGuiManager : MonoBehaviour
{
    [SerializeField] GameObject questSelectionMenu;

    [Header("Selection Menu Elements")]
    [SerializeField] TextMeshProUGUI questNameText;
    [SerializeField] Transform objectivesGroup;
    [SerializeField] Transform rewardsGroup;
    [SerializeField] TextMeshProUGUI quoteText;

    [Header("UI Prefabs")]
    [SerializeField] GameObject bulletPointTemplate;

    [Header("State")]
    [SerializeField] bool isInQuestSelection = false;

    [Header("Cache")]
    [SerializeField] DialogueManager dialogueManager;
    [SerializeField] QuestManager questManager;
    [SerializeField] StatusMessageManager statusMessageManager;

    public bool IsInQuestSelection { get => isInQuestSelection; set => isInQuestSelection = value; }

    private void Start()
    {
        questSelectionMenu.SetActive(false);
    }

    private void Update()
    {
        // escape or tab leaves selection
        if (isInQuestSelection && (Input.GetKeyDown(KeyCode.Tab) || Input.GetKeyDown(KeyCode.Escape)))
        {
            StartCoroutine(CloseQuestSelectionMenuWithDelay());
        }
    }

    public void ShowQuestSelectionMenu()
    {
        IsInQuestSelection = true;

        dialogueManager.HideDialogue();
        questSelectionMenu.SetActive(true);

        // load quest
        LoadQuestToSelectionMenu(dialogueManager.DialogueOwner.NpcQuest);
    }

    void LoadQuestToSelectionMenu(Quest quest)
    {
        questNameText.text = quest.QuestName;

        // load objectives
        foreach (QuestObjectiveBase objective in quest.QuestObjectives)
        {
            // create a new bullet point
            GameObject bulletPoint = Instantiate(bulletPointTemplate, objectivesGroup);

            // Fill in the bullet point text
            bulletPoint.transform.GetChild(1).GetComponent<TextMeshProUGUI>().text = objective.ToString();
        }

        // load rewards
        foreach (QuestResultBase result in quest.QuestResults)
        {
            // create a new bullet point
            GameObject bulletPoint = Instantiate(bulletPointTemplate, rewardsGroup);

            // Fill in the bullet point text
            bulletPoint.transform.GetChild(1).GetComponent<TextMeshProUGUI>().text = result.ToString();
        }

        // load npc quote
        quoteText.text = quest.Description;
    }

    // Called from button
    public void AcceptQuest()
    {
        questManager.AddQuestToActiveQuests(dialogueManager.DialogueOwner.NpcQuest);
        dialogueManager.DialogueOwner.RemoveQuest();
        dialogueManager.HideQuestButton();
        CloseQuestSelectionMenu();

        statusMessageManager.DisplayMessage("Quest accepted!");
    }

    // Called from button
    public void DeclineQuest()
    {
        dialogueManager.DialogueOwner.RemoveQuest();
        dialogueManager.HideQuestButton();
        CloseQuestSelectionMenu();
    }

    public void CloseQuestSelectionMenu()
    {
        DestroyObjectivesAndResults();

        questSelectionMenu.SetActive(false);
        dialogueManager.UnhideDialogue();

        IsInQuestSelection = false;
    }

    IEnumerator CloseQuestSelectionMenuWithDelay()
    {
        DestroyObjectivesAndResults();

        questSelectionMenu.SetActive(false);
        dialogueManager.UnhideDialogue();

        yield return new WaitForEndOfFrame();

        IsInQuestSelection = false;
    }

    void DestroyObjectivesAndResults()
    {
        // destroy results + objectives
        foreach (Transform child in objectivesGroup)
        {
            Destroy(child.gameObject);
        }

        foreach (Transform child in rewardsGroup)
        {
            Destroy(child.gameObject);
        }
    }
}
