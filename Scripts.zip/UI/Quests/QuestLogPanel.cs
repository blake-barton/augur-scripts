using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class QuestLogPanel : MonoBehaviour
{
    [Header("Panel Elements")]
    [SerializeField] Transform questNameClickableGroup;

    [Header("Quest Form Elements")]
    [SerializeField] TextMeshProUGUI questNameText;
    [SerializeField] Transform objectivesGroup;
    [SerializeField] Transform rewardsGroup;
    [SerializeField] TextMeshProUGUI quoteText;
    [SerializeField] GameObject completeButton;

    [Header("UI Prefabs")]
    [SerializeField] GameObject bulletPointTemplate;
    [SerializeField] GameObject questNameClickableTemplate;

    Quest selectedQuest;

    // cache
    QuestManager questManager;

    private void Awake()
    {
        questManager = FindObjectOfType<QuestManager>();
    }

    private void Start()
    {
        InitializeQuestLog();
    }

    void InitializeQuestLog()
    {
        LoadQuestList();

        questNameText.text = "";
        quoteText.text = "";

        // load in first quest in list
        if (questManager.ActiveQuests.Count > 0)
        {
            LoadQuestForm(questManager.ActiveQuests[0]);

            // enable bullet point
            QuestNameClickable firstClickable = questNameClickableGroup.GetChild(0).GetComponent<QuestNameClickable>();
            firstClickable.EnableBulletPoint();
        }
    }

    void LoadQuestList()
    {
        foreach (Quest quest in questManager.ActiveQuests)
        {
            GameObject newClickable = Instantiate(questNameClickableTemplate, questNameClickableGroup);

            // set clickable properties
            QuestNameClickable questNameClickable = newClickable.GetComponent<QuestNameClickable>();
            questNameClickable.Quest = quest;
            questNameClickable.QuestNameText.text = quest.QuestName;
        }
    }

    public void LoadQuestForm(Quest quest)
    {
        // clear first
        DestroyObjectivesAndResults();

        questNameText.text = quest.QuestName.ToUpper() + " (" + quest.AssignerName + ")";

        // load objectives
        foreach (QuestObjectiveBase objective in quest.QuestObjectives)
        {
            // create a new bullet point
            GameObject bulletPoint = Instantiate(bulletPointTemplate, objectivesGroup);

            // Fill in the bullet point text
            TextMeshProUGUI bulletText = bulletPoint.transform.GetChild(1).GetComponent<TextMeshProUGUI>();
            bulletText.text = objective.ToString() + " (" + objective.GetCurrentProgressAsString() + ")";

            // Strike through if objective is complete
            if (objective.IsComplete)
            {
                bulletText.fontStyle = FontStyles.Strikethrough;
            }

        }

        // load rewards
        foreach (QuestResultBase result in quest.QuestResults)
        {
            // create a new bullet point
            GameObject bulletPoint = Instantiate(bulletPointTemplate, rewardsGroup);

            // Fill in the bullet point text
            bulletPoint.transform.GetChild(1).GetComponent<TextMeshProUGUI>().text = result.ToString();
        }

        // load npc quote
        quoteText.text = quest.Description;

        // load button if quest complete
        if (quest.State == Quest.QuestState.COMPLETED)
        {
            completeButton.SetActive(true);
        }
        else
        {
            completeButton.SetActive(false);
        }

        selectedQuest = quest;
    }

    void DestroyObjectivesAndResults()
    {
        // destroy results + objectives
        foreach (Transform child in objectivesGroup)
        {
            Destroy(child.gameObject);
        }

        foreach (Transform child in rewardsGroup)
        {
            Destroy(child.gameObject);
        }
    }

    public void DisableAllBulletPoints()
    {
        foreach (Transform child in questNameClickableGroup)
        {
            child.GetChild(0).GetComponent<Image>().enabled = false;
        }
    }

    void ReloadQuestLog()
    {
        // Clear form
        DestroyObjectivesAndResults();

        // Clear quest list
        foreach (Transform child in questNameClickableGroup)
        {
            Destroy(child.gameObject);
        }

        // Initialize
        InitializeQuestLog();
    }

    // Called from button
    public void CompleteQuest()
    {
        if (selectedQuest != null)
        {
            // Complete Quest
            selectedQuest.CompleteQuest();

            // Reload menu
            ReloadQuestLog();
        }
    }
}
