using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using TMPro;

public class QuestNameClickable : MonoBehaviour, IPointerClickHandler, IPointerEnterHandler, IPointerExitHandler
{
    [SerializeField] Image bulletPoint;
    [SerializeField] TextMeshProUGUI questNameText;

    [Header("State")]
    [SerializeField] bool isHovered = false;

    Quest quest;

    // cache
    QuestLogPanel questLogPanel;

    void Awake()
    {
        questLogPanel = FindObjectOfType<QuestLogPanel>();
    }

    public Quest Quest { get => quest; set => quest = value; }
    public TextMeshProUGUI QuestNameText { get => questNameText; set => questNameText = value; }

    public void OnPointerClick(PointerEventData eventData)
    {
        // disable other bullet points
        questLogPanel.DisableAllBulletPoints();

        // load quest data to UI
        questLogPanel.LoadQuestForm(Quest);

        // turn on bullet point
        bulletPoint.enabled = true;
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        isHovered = true;
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        isHovered = false;
    }

    public void EnableBulletPoint()
    {
        bulletPoint.enabled = true;
    }
}
