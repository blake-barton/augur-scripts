using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class ValueBar : MonoBehaviour
{
    [SerializeField] float widthMultiplier = 3f;

    [Header("Slow Bar")]
    [SerializeField] Slider slowSlider;
    [SerializeField] RectTransform slowSliderTransform;
    [SerializeField] float slowSlideRate = 1.0f;

    [Header("Border")]
    [SerializeField] RectTransform middleBorder;
    [SerializeField] RectTransform rightBorder;
    [SerializeField] float middleBorderScaleFactor = 8f;

    [Header("Text")]
    [SerializeField] TextMeshProUGUI valueText;
    [SerializeField] TextMeshProUGUI dropShadowText;

    // cache
    Slider slider;
    RectTransform sliderTransform;

    // util
    float slideTime = 0f;

    private void Awake()
    {
        slider = GetComponent<Slider>();
        sliderTransform = GetComponent<RectTransform>();
    }

    private void Update()
    {
        SlowSlide();
    }

    public void SetValue(float val)
    {
        slider.value = val;
        slideTime = 0;

        if (valueText)
        {
            valueText.text = Mathf.Round(slider.value).ToString() + "/" + Mathf.Round(slider.maxValue).ToString();

            if (dropShadowText)
            {
                dropShadowText.text = valueText.text;
            }
        }
    }

    public void SetMaxValue(float max)
    {
        slider.maxValue = max;
        sliderTransform.sizeDelta = new Vector2(max * widthMultiplier, sliderTransform.sizeDelta.y);    // widen bar

        if (slowSlider)
        {
            slowSlider.maxValue = max;
            slowSliderTransform.sizeDelta = new Vector2(max * widthMultiplier, sliderTransform.sizeDelta.y);    // widen bar
        }

        if (middleBorder && rightBorder)    // widen borders
        {
            rightBorder.anchoredPosition = new Vector2(sliderTransform.sizeDelta.x, rightBorder.anchoredPosition.y);    // move right border out
            middleBorder.sizeDelta = new Vector2(sliderTransform.sizeDelta.x * middleBorderScaleFactor, middleBorder.sizeDelta.y);  // stretch middle border
        }
    }

    private void SlowSlide()
    {
        if (slowSlider)
        {
            if (slowSlider.value != slider.value)
            {
                slowSlider.value = Mathf.Lerp(slowSlider.value, slider.value, slideTime);
                slideTime += slowSlideRate * Time.deltaTime;
            }
        }
    }
}
