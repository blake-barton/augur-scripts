using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class DeathMenuManager : MonoBehaviour
{
    [Header("Timing")]
    [SerializeField] float timeBeforeDeathMessageSlideUp = 3f;

    [Header("Death Message")]
    [SerializeField] GameObject deathMessage;

    [Header("Cached References")]
    [SerializeField] Transform deathMenuTarget;
    [SerializeField] SceneLoader sceneLoader;

    Animator deathMessageAnimator;

    public void TriggerDeathMenu()
    {
        StartCoroutine(ShowDeathMenu());
    }

    IEnumerator ShowDeathMenu()
    {
        var message = Instantiate(deathMessage, deathMenuTarget);
        deathMessageAnimator = message.GetComponent<Animator>();

        yield return new WaitForSeconds(timeBeforeDeathMessageSlideUp);

        // slide message up
        // deathMessageAnimator.SetTrigger("DeathMessageMoveUp");

        // in future might have a stats screen. For now just go back to bunker.
        sceneLoader.LoadSceneByName("HomeBunker");
    }
}
