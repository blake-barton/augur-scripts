using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class DescriptionPanel : MonoBehaviour
{
    [Header("Item Data")]
    [SerializeField] TextMeshProUGUI title;
    [SerializeField] Image image;
    [SerializeField] TextMeshProUGUI description;

    public void SetItemPanelText(Item item)
    {
        title.text = item.ItemName;
        image.sprite = item.Sprite;
        description.text = item.Description;
    }

    public void SetSpellPanelText(Spell spell)
    {
        title.text = spell.SpellName;
        image.sprite = spell.SpellSprite;
        description.text = spell.Description;
    }
}
