using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using TMPro;

public class InventoryClickable : MonoBehaviour, IPointerClickHandler, IPointerEnterHandler, IPointerExitHandler
{
    [Header("Item")]
    [SerializeField] Pair<Item, int> itemPair;
    public Item.ItemType itemType;      // used for categorizing slots
    public string itemName;
    bool isHovered = false;             // is the pointer over the slot

    public enum ClickableType
    {
        INVENTORY_GRID_SLOT,
        HAND_PANEL_GRID_SLOT,
        OUTFIT_EQUIP_SLOT,
        ITEM_EQUIP_SLOT,
        TRADING_SLOT
    }
    [SerializeField] ClickableType slotType;

    [Header("Count Panel")]
    [SerializeField] int itemCount = 0;
    [SerializeField] GameObject countPanel;
    [SerializeField] TextMeshProUGUI countPanelText;

    [Header("Mainhand Panel")]
    [SerializeField] bool equippedMain = false;
    [SerializeField] GameObject leftClickPanel;

    [Header("Offhand Panel")]
    [SerializeField] bool equippedOff = false;
    [SerializeField] GameObject rightClickPanel;

    [Header("Item Equipped Panel")]
    [SerializeField] bool itemEquipped = false;
    [SerializeField] GameObject itemEquipPanel;

    [Header("Visuals")]
    [SerializeField] Color backgroundNotHovered;
    [SerializeField] Color backgroundHovered;
    [SerializeField] Color outlineNotHovered;
    [SerializeField] Color outlineHovered;
    [SerializeField] Vector2 outlineSizeNotHovered = new Vector2();
    [SerializeField] Vector2 outlineSizeHovered = new Vector2();

    [Header("Trading")]
    public TradingPanel.InventoryOwner owner;
    [SerializeField] bool markedForTrade = false;
    [SerializeField] GameObject markedForTradePanel;
    [SerializeField] Image markedForTradePanelSymbol;
    [SerializeField] TextMeshProUGUI markedForTradePanelNumber;
    [SerializeField] int numberMarkedForTrade = 0;

    [Header("Audio")]
    [SerializeField] AudioClip hoverSound;
    [SerializeField] [Range(0, 1)] float hoverVolume = .5f;

    // cached references
    Player player;
    Inventory playerInventory;
    Equipment equipment;
    Focus focus;
    InventoryPanel inventoryPanel;
    TabMenuManager tabMenuManager;
    Image backgroundImage;
    Outline outline;
    HandPanel handPanel;
    OutfitEquipPanel outfitPanel;
    EquipItemGridPanel equipItemGridPanel;
    TradingManager tradingManager;
    TradingPanel playerTradingPanel;
    TradingPanel npcTradingPanel;
    AudioSource uiSounds;
    QuickAidManager quickAidManager;

    public int ItemCount { get => itemCount; set => itemCount = value; }
    public bool EquippedMain { get => equippedMain; set => equippedMain = value; }
    public bool EquippedOff { get => equippedOff; set => equippedOff = value; }
    public bool ItemEquipped { get => itemEquipped; set => itemEquipped = value; }
    public ClickableType SlotType { get => slotType; set => slotType = value; }
    public bool MarkedForTrade { get => markedForTrade; set => markedForTrade = value; }
    public int NumberMarkedForTrade { get => numberMarkedForTrade; set => numberMarkedForTrade = value; }
    public Pair<Item, int> ItemPair { get => itemPair; set => itemPair = value; }

    void Start()
    {
        player = FindObjectOfType<Player>();
        playerInventory = player.GetComponent<Inventory>();
        equipment = player.GetComponent<Equipment>();
        focus = player.GetComponent<Focus>();
        inventoryPanel = FindObjectOfType<InventoryPanel>();
        tabMenuManager = FindObjectOfType<TabMenuManager>();
        backgroundImage = GetComponent<Image>();
        outline = GetComponent<Outline>();
        handPanel = FindObjectOfType<HandPanel>();
        outfitPanel = FindObjectOfType<OutfitEquipPanel>();
        equipItemGridPanel = FindObjectOfType<EquipItemGridPanel>();
        tradingManager = FindObjectOfType<TradingManager>();
        var tradingPanels = FindObjectsOfType<TradingPanel>();
        quickAidManager = FindObjectOfType<QuickAidManager>();

        if (tradingPanels.Length > 0)
        {
            npcTradingPanel = tradingPanels[0];
            playerTradingPanel = tradingPanels[1];
        }

        uiSounds = GameObject.FindWithTag("UISound").GetComponent<AudioSource>();
    }
    
    void Update()
    {
        if (slotType == ClickableType.INVENTORY_GRID_SLOT)
        {
            DropItem();
        }

        if (slotType == ClickableType.TRADING_SLOT)
        {
            ToggleTradingDescriptionPanel();
        }
        else
        {
            ToggleDescriptionPanel();
        }
    }

    public void OnPointerClick(PointerEventData eventData)
    {
        switch (slotType)
        {
            case ClickableType.INVENTORY_GRID_SLOT:
                HandleInventorySlotClick(eventData);
                break;
            case ClickableType.HAND_PANEL_GRID_SLOT:
                HandleHandPanelSlotClick();
                break;
            case ClickableType.OUTFIT_EQUIP_SLOT:
                HandleOutfitPanelSlotClick();
                break;
            case ClickableType.ITEM_EQUIP_SLOT:
                HandleItemEquipPanelSlotClick();
                break;
            case ClickableType.TRADING_SLOT:
                HandleTradingSlotClick();
                break;
        }
    }

    void HandleTradingSlotClick()
    {
        // removing item from this trading panel
        if (ItemPair.Second > 1)
        {
            // tell menu manager to spawn a drop x popup and handle removal from there
            tradingManager.LoadSelectXPopup(owner, tradingManager, playerInventory, this, ItemPair);
        }
        else
        {
            if (ItemPair.First.MarkedForTrade)
            {
                // already marked for trade, mark as no longer marked for trade
                ItemPair.First.MarkedForTrade = false;
                ItemPair.First.NumberMarkedForTrade = 0;

                MarkedForTrade = false;
                NumberMarkedForTrade = 0;

                tradingManager.AdjustTransactionCost(owner, ItemPair, -1);
            }
            else
            {
                // not yet marked for trade, mark item for trade quantity = 1
                ItemPair.First.MarkedForTrade = true;
                ItemPair.First.NumberMarkedForTrade = 1;

                MarkedForTrade = true;
                NumberMarkedForTrade = 1;

                tradingManager.AdjustTransactionCost(owner, ItemPair, 1);
            }

            // update trade marker
            UpdateEquipPanels();
        }
    }

    void HandleItemEquipPanelSlotClick()
    {
        switch (itemType)
        {
            case Item.ItemType.OUTFIT:
                equipment.EquipOutfit(gameObject.transform.GetSiblingIndex());
                break;
            case Item.ItemType.FOCUSIMPLANT:
                focus.EquipImplant(gameObject.transform.GetSiblingIndex());
                break;
            case Item.ItemType.AID:
                // add aid item to quick aid list
                quickAidManager.AddItemPair(equipItemGridPanel.QuickAidIndex, ItemPair);
                break;
        }

        // return to equipment screen
        tabMenuManager.ShowEquipment();
    }

    private void HandleOutfitPanelSlotClick()
    {
        // equip outfit
        equipment.EquipOutfit(gameObject.transform.GetSiblingIndex());

        // return to equipment screen
        tabMenuManager.ShowEquipment();
    }

    private void HandleHandPanelSlotClick()
    {
        // equip based on panel destination
        switch (handPanel.SlotDestination)
        {
            case HandPanel.HandSlot.MAINHAND:
                switch (itemType)
                {
                    case Item.ItemType.RANGEDWEAPON:
                        equipment.EquipMainHandWeapon(gameObject.transform.GetSiblingIndex());
                        break;
                    case Item.ItemType.MELEEWEAPON:
                        equipment.EquipMainHandWeapon(gameObject.transform.GetSiblingIndex());
                        break;
                }
                break;

            case HandPanel.HandSlot.OFFHAND:
                switch (itemType)
                {
                    case Item.ItemType.RANGEDWEAPON:
                        equipment.EquipOffHandWeapon(gameObject.transform.GetSiblingIndex());
                        break;
                    case Item.ItemType.MELEEWEAPON:
                        equipment.EquipOffHandWeapon(gameObject.transform.GetSiblingIndex());
                        break;
                }
                break;

            case HandPanel.HandSlot.QUICKEQUIP:
                // place the item in the correct quick equip index
                equipment.PlaceEquippable(playerInventory.Items[gameObject.transform.GetSiblingIndex()].First, handPanel.QuickEquippableIndex);
                break;
        }

        // return to the equipment screen
        tabMenuManager.ShowEquipment();
    }

    private void HandleInventorySlotClick(PointerEventData eventData)
    {
        if (eventData.button == PointerEventData.InputButton.Left)
        {
            switch (itemType)
            {
                case Item.ItemType.RANGEDWEAPON:
                    equipment.EquipMainHandWeapon(gameObject.transform.GetSiblingIndex());
                    inventoryPanel.ReloadGrid();
                    break;
                case Item.ItemType.MELEEWEAPON:
                    equipment.EquipMainHandWeapon(gameObject.transform.GetSiblingIndex());
                    inventoryPanel.ReloadGrid();
                    break;
                case Item.ItemType.OUTFIT:
                    equipment.EquipOutfit(gameObject.transform.GetSiblingIndex());
                    inventoryPanel.ReloadGrid();
                    tabMenuManager.ReloadPlayerStats();
                    break;
                case Item.ItemType.AID:
                    ((Misc)playerInventory.Items[gameObject.transform.GetSiblingIndex()].First).usable.Use();
                    RemoveItem();
                    break;
                case Item.ItemType.MISC:
                    ((Misc)playerInventory.Items[gameObject.transform.GetSiblingIndex()].First).usable.Use();
                    RemoveItem();
                    break;
                case Item.ItemType.FOCUSIMPLANT:
                    focus.EquipImplant(gameObject.transform.GetSiblingIndex());
                    inventoryPanel.ReloadGrid();
                    break;
            }
        }
        else if (eventData.button == PointerEventData.InputButton.Middle)
        {

        }
        else if (eventData.button == PointerEventData.InputButton.Right)
        {
            switch (itemType)
            {
                case Item.ItemType.RANGEDWEAPON:
                    equipment.EquipOffHandWeapon(gameObject.transform.GetSiblingIndex());
                    inventoryPanel.ReloadGrid();
                    break;
                case Item.ItemType.MELEEWEAPON:
                    equipment.EquipOffHandWeapon(gameObject.transform.GetSiblingIndex());
                    inventoryPanel.ReloadGrid();
                    break;
                case Item.ItemType.OUTFIT:
                    equipment.EquipOutfit(gameObject.transform.GetSiblingIndex());
                    inventoryPanel.ReloadGrid();
                    tabMenuManager.ReloadPlayerStats();
                    break;
                case Item.ItemType.AID:
                    ((Misc)playerInventory.Items[gameObject.transform.GetSiblingIndex()].First).usable.Use();
                    playerInventory.RemoveItem(gameObject.transform.GetSiblingIndex());
                    RemoveItem();
                    break;
                case Item.ItemType.MISC:
                    ((Misc)playerInventory.Items[gameObject.transform.GetSiblingIndex()].First).usable.Use();
                    RemoveItem();
                    break;
                case Item.ItemType.FOCUSIMPLANT:
                    focus.EquipImplant(gameObject.transform.GetSiblingIndex());
                    inventoryPanel.ReloadGrid();
                    break;
            }
        }
    }

    // highlights slot and spawns info panel
    public void OnPointerEnter(PointerEventData eventData)
    {
        isHovered = true;

        ActivateHoverVisuals();

        uiSounds.PlayOneShot(hoverSound, hoverVolume);

        // set inventory panel item name title text
        switch (slotType)
        {
            case ClickableType.INVENTORY_GRID_SLOT:
                inventoryPanel.SetItemNameTitleText(itemName);
                break;
            case ClickableType.HAND_PANEL_GRID_SLOT:
                handPanel.SetEquippableNameTitleText(itemName);
                break;
            case ClickableType.OUTFIT_EQUIP_SLOT:
                outfitPanel.SetEquippableNameTitleText(itemName);
                break;
            case ClickableType.ITEM_EQUIP_SLOT:
                equipItemGridPanel.SetEquippableNameTitleText(itemName);
                break;
            case ClickableType.TRADING_SLOT:

                if (owner == TradingPanel.InventoryOwner.PLAYER)
                    playerTradingPanel.SetItemNameTitleText(itemName);
                else
                    npcTradingPanel.SetItemNameTitleText(itemName);

                tradingManager.SetCurrentCryptoValue(ItemPair.First.Value, owner);
                break;
        }

        if (slotType == ClickableType.TRADING_SLOT)
        {
            ActivateTradingManagerInfoPanelLoad();
        }
        else
        {
            ActivateTabManagerInfoPanelLoad();
        }
    }

    private void DropItem()
    {
        // ability to remove item
        if (Input.GetKeyDown(KeyCode.R) && isHovered)
        {
            Item item = playerInventory.Items[gameObject.transform.GetSiblingIndex()].First;

            // get item count
            int itemCount = playerInventory.GetItemCountAtIndex(gameObject.transform.GetSiblingIndex());

            if (itemCount > item.DropXThreshold)
            {
                // tell menu manager to spawn a drop x popup and handle dropping from there
                tabMenuManager.LoadSelectXPopup(gameObject.transform.GetSiblingIndex(), itemCount);
            }
            else
            {
                // tell the player's inventory to drop the item at this slot's index
                bool stillInInventory = playerInventory.DropItem(gameObject.transform.GetSiblingIndex(), 1);

                if (!stillInInventory)
                {
                    // clear the info panel if quantity is 0
                    tabMenuManager.DestroyInfoPanel();
                    tabMenuManager.LoadTestInfoPanel();

                    // clear item name from header
                    inventoryPanel.SetItemNameTitleText("");

                    // delete the slot
                    Destroy(gameObject);
                }
                else
                {
                    // reload info panel to reflect new quantity
                    ActivateTabManagerInfoPanelLoad();

                    // update count panel
                    ItemCount--;
                    UpdateCountPanelText();
                }
            }
        }
    }

    // same as drop but doesn't spawn scene object
    private void RemoveItem()
    {
        bool stillInInventory = playerInventory.RemoveItem(gameObject.transform.GetSiblingIndex());

        if (!stillInInventory)
        {
            // clear the info panel if quantity is 0
            tabMenuManager.DestroyInfoPanel();
            tabMenuManager.LoadTestInfoPanel();

            // clear item name from header
            inventoryPanel.SetItemNameTitleText("");

            // delete the slot
            Destroy(gameObject);
        }
        else
        {
            // reload info panel to reflect new quantity
            ActivateTabManagerInfoPanelLoad();

            // update count panel
            ItemCount--;
            UpdateCountPanelText();
        }
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        isHovered = false;
        DeactivateHoverVisuals();
    }

    private void ActivateHoverVisuals()
    {
        backgroundImage.color = backgroundHovered;
        outline.effectColor = outlineHovered;

        outline.effectDistance = outlineSizeHovered;
    }

    private void DeactivateHoverVisuals()
    {
        backgroundImage.color = backgroundNotHovered;
        outline.effectColor = outlineNotHovered;

        outline.effectDistance = outlineSizeNotHovered;
    }

    private void ActivateTabManagerInfoPanelLoad()
    {
        // clear current item info
        tabMenuManager.DestroyInfoPanel();

        // get item data from player inventory
        Item item = playerInventory.Items[gameObject.transform.GetSiblingIndex()].First;

        // get item count
        int itemCount = playerInventory.GetItemCountAtIndex(gameObject.transform.GetSiblingIndex());

        // load an info panel with this item's data
        tabMenuManager.LoadItemInfoPanel(item, itemCount);
    }


    private void ActivateTradingManagerInfoPanelLoad()
    {
        // clear current item info
        tradingManager.DestroyInfoPanel();

        // load an info panel with this item's data
        tradingManager.LoadItemInfoPanel(ItemPair);
    }

    private void ToggleDescriptionPanel()
    {
        if (Input.GetKeyDown(KeyCode.LeftShift) && isHovered)
        {
            Item item = playerInventory.Items[gameObject.transform.GetSiblingIndex()].First;

            // get item count
            int itemCount = playerInventory.GetItemCountAtIndex(gameObject.transform.GetSiblingIndex());

            // load and display description panel or info panel depending on state
            tabMenuManager.ToggleDescriptionPanel(item, itemCount);
        }
    }

    private void ToggleTradingDescriptionPanel()
    {
        if (Input.GetKeyDown(KeyCode.LeftShift) && isHovered)
        {
            // load and display description panel or info panel depending on state
            tradingManager.ToggleDescriptionPanel(ItemPair);
        }
    }

    public void UpdateCountPanelText()
    {
        // deactivate panel if there is only one item, otherwise update the count display
        if (ItemCount > 1)
        {
            countPanel.SetActive(true);
            countPanelText.text = itemCount.ToString();
        }
        else
        {
            countPanel.SetActive(false);
        }
    }

    public void UpdateEquipPanels()
    {
        if (EquippedMain)
        {
            leftClickPanel.SetActive(true);
        }
        else
        {
            leftClickPanel.SetActive(false);
        }

        if (EquippedOff)
        {
            rightClickPanel.SetActive(true);
        }
        else
        {
            rightClickPanel.SetActive(false);
        }

        if (ItemEquipped)
        {
            itemEquipPanel.SetActive(true);
        }
        else
        {
            itemEquipPanel.SetActive(false);
        }

        if (MarkedForTrade)
        {
            markedForTradePanel.SetActive(true);
            markedForTradePanelNumber.enabled = false;
            markedForTradePanelSymbol.enabled = false;

            if (NumberMarkedForTrade > 1)
            {
                markedForTradePanelNumber.enabled = true;
                markedForTradePanelNumber.text = NumberMarkedForTrade.ToString();
            }
            else
            {
                markedForTradePanelSymbol.enabled = true;
            }
        }
        else
        {
            markedForTradePanel.SetActive(false);
        }
    }
}
