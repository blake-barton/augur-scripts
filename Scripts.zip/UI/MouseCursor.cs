using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;

public class MouseCursor : MonoBehaviour
{
    [SerializeField] Image cursorImage;

    private void Awake()
    {
        Cursor.visible = false;
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 cursorPos = Input.mousePosition;
        transform.position = cursorPos;
    }

    public void OnDeviceChange(PlayerInput pi)
    {
        // Hide cursor on gamepad. Show on m/k.
        if (pi.currentControlScheme.Equals("Gamepad"))
        {
            cursorImage.enabled = false;
        }
        else
        {
            cursorImage.enabled = true;
        }
    }
}
