using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Audio;

public class SettingsMenu : MonoBehaviour
{
    [Header("Volume Defaults")]
    [SerializeField] float masterVolumeDefault;
    [SerializeField] float musicVolumeDefault;
    [SerializeField] float effectsVolumeDefault;
    [SerializeField] float uiVolumeDefault;

    [Header("Volume Sliders")]
    [SerializeField] Slider masterVolume;
    [SerializeField] Slider musicVolume;
    [SerializeField] Slider effectsVolume;
    [SerializeField] Slider uiVolume;

    [Header("State")]
    [SerializeField] bool changesSaved = true;
    [SerializeField] GameObject unsavedChangesText;

    public bool ChangesSaved
    {
        get { return changesSaved; }
        set
        {
            if (value == changesSaved)
                return;

            changesSaved = value;

            // display message if changes are not saved
            unsavedChangesText.SetActive(!changesSaved);
        }
    }


    private void Start()
    {
        LoadSettings();
        ChangesSaved = true;
    }

    // pull values from static Settings class into the menu
    private void LoadSettings()
    {
        // volume
        masterVolume.value = Settings.masterVolume;
        musicVolume.value = Settings.musicVolume;
        effectsVolume.value = Settings.effectsVolume;
        uiVolume.value = Settings.uiVolume;
    }

    // store the values in the settings menu in the Settings static class
    public void ApplySettings()
    {
        // volume
        Settings.masterVolume = masterVolume.value;
        Settings.musicVolume = musicVolume.value;
        Settings.effectsVolume = effectsVolume.value;
        Settings.uiVolume = uiVolume.value;

        ChangesSaved = true;
    }

    // reset in-menu values and then apply them
    public void ApplyDefaults()
    {
        // volume
        masterVolume.value = masterVolumeDefault;
        musicVolume.value = musicVolumeDefault;
        effectsVolume.value = effectsVolumeDefault;
        uiVolume.value = uiVolumeDefault;
    }

    private void OnDestroy()
    {
        if (!ChangesSaved)
        {
            LoadSettings();
        }
    }
}
