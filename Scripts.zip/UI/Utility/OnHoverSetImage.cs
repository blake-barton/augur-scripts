using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class OnHoverSetImage : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler, ISelectHandler, IDeselectHandler
{
    [SerializeField] Sprite spriteToSet;
    [SerializeField] Image image;

    public void OnPointerEnter(PointerEventData eventData)
    {
        image.sprite = spriteToSet;
    }

    public void OnPointerExit(PointerEventData eventData)
    {
    }

    public void OnSelect(BaseEventData eventData)
    {
        image.sprite = spriteToSet;
    }

    public void OnDeselect(BaseEventData eventData)
    {
    }
}