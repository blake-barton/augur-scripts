using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class HoverAudio : MonoBehaviour, IPointerEnterHandler, ISelectHandler
{
    [SerializeField] AudioClip hoverSound;
    [SerializeField] [Range(0, 1)] float hoverVolume = .6f;

    AudioSource uiSounds;

    private void Awake()
    {
        uiSounds = GameObject.FindWithTag("UISound").GetComponent<AudioSource>();
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        uiSounds.PlayOneShot(hoverSound, hoverVolume);
    }

    public void OnSelect(BaseEventData eventData)
    {
        uiSounds.PlayOneShot(hoverSound, hoverVolume);
    }
}
