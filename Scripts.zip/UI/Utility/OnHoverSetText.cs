using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using TMPro;

public class OnHoverSetText : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    [TextArea(15, 20)]
    [SerializeField] string textToSet;
    [SerializeField] TextMeshProUGUI textBox;

    public void OnPointerEnter(PointerEventData eventData)
    {
        textBox.text = textToSet;
    }

    public void OnPointerExit(PointerEventData eventData)
    {
    }

    public void InitializeText(string _text, TextMeshProUGUI _textBox)
    {
        textToSet = _text;
        textBox = _textBox;
    }
}