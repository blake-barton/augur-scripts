using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class HoverVisuals : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler
{
    [Header("Background")]
    [SerializeField] Color backgroundNotHovered;
    [SerializeField] Color backgroundHovered;

    [Header("Outline")]
    [SerializeField] Color outlineNotHovered;
    [SerializeField] Color outlineHovered;
    [SerializeField] Vector2 outlineSizeNotHovered = new Vector2();
    [SerializeField] Vector2 outlineSizeHovered = new Vector2();

    [Header("Sprite Swap")]
    public bool spriteSwap = true;
    [SerializeField] Sprite spriteNotHovered;
    [SerializeField] Sprite spriteHovered;
    [SerializeField] Image foregroundImage;

    //cache 
    Image backgroundImage;
    Outline outline;

    void Awake()
    {
        backgroundImage = GetComponent<Image>();
        outline = GetComponent<Outline>();
    }

    private void ActivateHoverVisuals()
    {
        backgroundImage.color = backgroundHovered;
        outline.effectColor = outlineHovered;

        outline.effectDistance = outlineSizeHovered;

        if (spriteSwap)
        {
            foregroundImage.sprite = spriteHovered;
        }
    }

    private void DeactivateHoverVisuals()
    {
        backgroundImage.color = backgroundNotHovered;
        outline.effectColor = outlineNotHovered;

        outline.effectDistance = outlineSizeNotHovered;

        if (spriteSwap)
        {
            foregroundImage.sprite = spriteNotHovered;
        }
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        ActivateHoverVisuals();
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        DeactivateHoverVisuals();
    }
}
