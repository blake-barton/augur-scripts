using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;
using TMPro;

public class WeaponWheelButton : MonoBehaviour, IPointerClickHandler, IPointerEnterHandler, IPointerExitHandler
{
    public Equippable equippable;

    [SerializeField] TextMeshProUGUI wheelText;

    // cache
    Player player;
    Inventory inventory;
    Equipment equipment;

    void Awake()
    {
        player = FindObjectOfType<Player>();
        inventory = player.GetComponent<Inventory>();
        equipment = player.GetComponent<Equipment>();
    }

    public void OnPointerClick(PointerEventData eventData)
    {
        // left click == main hand
        if (eventData.button == PointerEventData.InputButton.Left)
        {
            // weapons
            if (equippable.equippableType == Equippable.EquippableType.ITEM)
            {
                if (equippable.item.Type == Item.ItemType.RANGEDWEAPON || equippable.item.Type == Item.ItemType.MELEEWEAPON)
                {
                    equipment.EquipMainHandWeapon(equippable);
                }
            }
            // spells
            else if (equippable.equippableType == Equippable.EquippableType.SPELL)
            {
                equipment.EquipMainHandSpell(equippable.spell);
            }
        }
        // right click == off hand
        else if (eventData.button == PointerEventData.InputButton.Right)
        {
            // weapons
            if (equippable.equippableType == Equippable.EquippableType.ITEM)
            {
                if (equippable.item.Type == Item.ItemType.RANGEDWEAPON || equippable.item.Type == Item.ItemType.MELEEWEAPON)
                {
                    equipment.EquipOffHandWeapon(equippable);
                }
            }
            // spells
            else if (equippable.equippableType == Equippable.EquippableType.SPELL)
            {
                equipment.EquipOffHandSpell(equippable.spell);
            }
        }
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        wheelText.text = equippable.GetName();
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        wheelText.text = "";
    }
}
