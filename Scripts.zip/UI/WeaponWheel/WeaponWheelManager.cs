using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class WeaponWheelManager : MonoBehaviour
{
    [SerializeField] GameObject weaponWheel;
    [SerializeField] Transform buttons;

    [Header("State")]
    private bool wheelDisplayed = false;

    // cache
    TabMenuManager tabMenuManager;
    Player player;
    PlayerMovement playerMovement;

    public bool WheelDisplayed { get => wheelDisplayed; set => wheelDisplayed = value; }

    private void Awake()
    {
        tabMenuManager = FindObjectOfType<TabMenuManager>();
        player = FindObjectOfType<Player>();
        playerMovement = player.GetComponent<PlayerMovement>();
    }

    // Start is called before the first frame update
    void Start()
    {
        weaponWheel.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        if (!tabMenuManager.InMenu && player.Health.Alive && !player.Character.Incapacitated && !player.InDialogue)
        {
            HandleKeyboardInput();
        }
    }

    void HandleKeyboardInput()
    {
        if (Input.GetKeyDown(KeyCode.LeftShift))
        {
            OpenWeaponWheel();
        }

        if (Input.GetKeyUp(KeyCode.LeftShift))
        {
            CloseWeaponWheel();
        }
    }

    void OpenWeaponWheel()
    {
        if (!WheelDisplayed)
        {
            weaponWheel.SetActive(true);
            WheelDisplayed = true;
        }
    }

    void CloseWeaponWheel()
    {
        if (WheelDisplayed)
        {
            weaponWheel.SetActive(false);
            WheelDisplayed = false;
        }
    }

    public void SetWeaponWheelButton(Equippable equippable, int index)
    {
        WeaponWheelButton button = buttons.GetChild(index).GetComponent<WeaponWheelButton>();

        // set equippable
        button.equippable = equippable;

        if (equippable.equippableType == Equippable.EquippableType.NULL)
        {
            // set image
            button.transform.GetChild(0).GetComponent<Image>().sprite = null;
            button.transform.GetChild(0).GetComponent<Image>().enabled = false;
        }
        else
        {
            // set image
            button.transform.GetChild(0).GetComponent<Image>().enabled = true;
            button.transform.GetChild(0).GetComponent<Image>().sprite = equippable.GetSprite();
        }
    }
}
