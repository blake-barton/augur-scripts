using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using TMPro;

public class OnHoverChangeTextColor : MonoBehaviour, IPointerEnterHandler, IPointerExitHandler, ISelectHandler, IDeselectHandler
{
    [SerializeField] Color startingColor;
    [SerializeField] Color hoverColor;
    TextMeshProUGUI text;

    private void Awake()
    {
        text = GetComponent<TextMeshProUGUI>();
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        text.color = hoverColor;
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        text.color = startingColor;
    }

    public void InitializeColors(Color _startingColor, Color _hoverColor)
    {
        startingColor = _startingColor;
        hoverColor = _hoverColor;
    }

    public void OnSelect(BaseEventData eventData)
    {
        text.color = hoverColor;
    }

    public void OnDeselect(BaseEventData eventData)
    {
        text.color = startingColor;
    }
}
