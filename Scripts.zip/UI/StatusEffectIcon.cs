using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class StatusEffectIcon : MonoBehaviour
{
    [SerializeField] Image icon;

    StatusEffect statusEffect;

    public StatusEffect StatusEffect { get => statusEffect; set => statusEffect = value; }

    public void InitializeIcon(StatusEffect _statusEffect)
    {
        StatusEffect = _statusEffect;

        icon.sprite = StatusEffect.EffectSprite;
    }
}
