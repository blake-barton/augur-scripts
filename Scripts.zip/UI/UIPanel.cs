using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UIPanel : MonoBehaviour
{
    [Header("UI Panel")]
    [SerializeField] protected string panelName;
    [SerializeField] protected UIPanel previousPanel;

    public string PanelName { get => panelName; set => panelName = value; }
    public UIPanel PreviousPanel { get => previousPanel; set => previousPanel = value; }
}
