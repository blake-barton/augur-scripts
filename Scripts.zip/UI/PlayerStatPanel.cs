using System;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class PlayerStatPanel : MonoBehaviour
{
    [Header("Ability Scores")]
    [SerializeField] TextMeshProUGUI level;
    [SerializeField] TextMeshProUGUI strength;
    [SerializeField] TextMeshProUGUI perception;
    [SerializeField] TextMeshProUGUI endurance;
    [SerializeField] TextMeshProUGUI intelligence;
    [SerializeField] TextMeshProUGUI agility;
    [SerializeField] TextMeshProUGUI aberrance;

    [Header("Bars")]
    [SerializeField] TextMeshProUGUI hp;
    [SerializeField] TextMeshProUGUI mp;
    [SerializeField] TextMeshProUGUI fp;

    [Header("Bar Regen")]
    [SerializeField] TextMeshProUGUI hpRegen;
    [SerializeField] TextMeshProUGUI mpRegen;
    [SerializeField] TextMeshProUGUI fpRegen;

    [Header("Damage Type Grids")]
    [SerializeField] Transform vulnerabilityGrid;
    [SerializeField] Transform resistanceGrid;
    [SerializeField] Transform immunityGrid;

    [Header("Equipment Stats")]
    [SerializeField] TextMeshProUGUI equipLoad;
    [SerializeField] TextMeshProUGUI weightRatio;
    [SerializeField] TextMeshProUGUI poiseVal;
    [SerializeField] TextMeshProUGUI itemDiscovery;

    [Header("Damage Type Icons")]
    [SerializeField] GameObject blunt;
    [SerializeField] GameObject piercing;
    [SerializeField] GameObject slashing;
    [SerializeField] GameObject energy;
    [SerializeField] GameObject fire;
    [SerializeField] GameObject frost;
    [SerializeField] GameObject shock;
    [SerializeField] GameObject acid;
    [SerializeField] GameObject poison;
    [SerializeField] GameObject psionic;

    // cache
    Player player;
    AttributeScores attributes;
    Health health;
    Magic magic;
    Focus focus;
    Equipment equipment;
    DamageEffects damageEffects;
    Poise poise;

    private void Awake()
    {
        player = FindObjectOfType<Player>();
        attributes = player.GetComponent<AttributeScores>();
        health = player.GetComponent<Health>();
        magic = player.GetComponent<Magic>();
        focus = player.GetComponent<Focus>();
        equipment = player.GetComponent<Equipment>();
        damageEffects = player.GetComponent<DamageEffects>();
        poise = player.GetComponent<Poise>();
    }

    private void Start()
    {
        SetPanelInfo();
    }

    private void Update()
    {
        TrackBars();
        TrackEquipLoad();
    }

    void SetPanelInfo()
    {
        level.text = attributes.level.ToString();

        strength.text = attributes.Strength.ToString();
        perception.text = attributes.Perception.ToString();
        endurance.text = attributes.Endurance.ToString();
        intelligence.text = attributes.Intelligence.ToString();
        agility.text = attributes.Agility.ToString();
        aberrance.text = attributes.Aberrance.ToString();

        SetRegenValues();

        LoadVulnerabilityIcons();
        LoadResistanceIcons();
        LoadImmunityIcons();

        itemDiscovery.text = attributes.itemDiscovery.ToString();
    }

    void TrackBars()
    {
        //.text = Mathf.Round(val).ToString();
        hp.text = Math.Round(health.CurrentHealth, 1).ToString() + "/" + Math.Round(health.MaxHealth.GetCurrentValue());
        mp.text = Math.Round(magic.MagicPoints, 1).ToString() + "/" + Math.Round(magic.MaxMagicPoints);
        fp.text = Math.Round(focus.FocusPoints, 1).ToString() + "/" + Math.Round(focus.MaxFocusPoints);
    }

    void SetRegenValues()
    {
        hpRegen.text = Math.Round(health.HpRegenPerTick * health.HpTicksPerSecond, 1).ToString() + "/s";
        mpRegen.text = Math.Round(magic.MpRegenPerTick * magic.MpTicksPerSecond, 1).ToString() + "/s";
        fpRegen.text = Math.Round(focus.FpRegenPerTick * focus.FpTicksPerSecond, 1).ToString() + "/s";
    }

    void TrackEquipLoad()
    {
        equipLoad.text = Math.Round(equipment.CurrentEquipLoad, 2).ToString() + "/" + equipment.MaxEquipLoad + "kg";
        weightRatio.text = Math.Round(equipment.EquipLoadRatio * 100f, 2).ToString() + "%";

        // poise
        poiseVal.text = Math.Round(poise.CurrentPoise, 2).ToString() + " / " + poise.MaxPoise.ToString();
    }

    void LoadVulnerabilityIcons()
    {
        foreach (DamageEffects.DamageType vuln in damageEffects.Vulnerabilities)
        {
            switch (vuln)
            {
                case DamageEffects.DamageType.BLUNT:
                    Instantiate(blunt, vulnerabilityGrid);
                    break;
                case DamageEffects.DamageType.PIERCING:
                    Instantiate(piercing, vulnerabilityGrid);
                    break;
                case DamageEffects.DamageType.SLASHING:
                    Instantiate(slashing, vulnerabilityGrid);
                    break;
                case DamageEffects.DamageType.ENERGY:
                    Instantiate(energy, vulnerabilityGrid);
                    break;
                case DamageEffects.DamageType.FIRE:
                    Instantiate(fire, vulnerabilityGrid);
                    break;
                case DamageEffects.DamageType.FROST:
                    Instantiate(frost, vulnerabilityGrid);
                    break;
                case DamageEffects.DamageType.SHOCK:
                    Instantiate(shock, vulnerabilityGrid);
                    break;
                case DamageEffects.DamageType.ACID:
                    Instantiate(acid, vulnerabilityGrid);
                    break;
                case DamageEffects.DamageType.POISON:
                    Instantiate(poison, vulnerabilityGrid);
                    break;
                case DamageEffects.DamageType.PSIONIC:
                    Instantiate(psionic, vulnerabilityGrid);
                    break;
            }
        }
    }

    void LoadResistanceIcons()
    {
        foreach (DamageEffects.DamageType res in damageEffects.Resistances)
        {
            switch (res)
            {
                case DamageEffects.DamageType.BLUNT:
                    Instantiate(blunt, resistanceGrid);
                    break;
                case DamageEffects.DamageType.PIERCING:
                    Instantiate(piercing, resistanceGrid);
                    break;
                case DamageEffects.DamageType.SLASHING:
                    Instantiate(slashing, resistanceGrid);
                    break;
                case DamageEffects.DamageType.ENERGY:
                    Instantiate(energy, resistanceGrid);
                    break;
                case DamageEffects.DamageType.FIRE:
                    Instantiate(fire, resistanceGrid);
                    break;
                case DamageEffects.DamageType.FROST:
                    Instantiate(frost, resistanceGrid);
                    break;
                case DamageEffects.DamageType.SHOCK:
                    Instantiate(shock, resistanceGrid);
                    break;
                case DamageEffects.DamageType.ACID:
                    Instantiate(acid, resistanceGrid);
                    break;
                case DamageEffects.DamageType.POISON:
                    Instantiate(poison, resistanceGrid);
                    break;
                case DamageEffects.DamageType.PSIONIC:
                    Instantiate(psionic, resistanceGrid);
                    break;
            }
        }
    }

    void LoadImmunityIcons()
    {
        foreach (DamageEffects.DamageType imm in damageEffects.Immunities)
        {
            switch (imm)
            {
                case DamageEffects.DamageType.BLUNT:
                    Instantiate(blunt, immunityGrid);
                    break;
                case DamageEffects.DamageType.PIERCING:
                    Instantiate(piercing, immunityGrid);
                    break;
                case DamageEffects.DamageType.SLASHING:
                    Instantiate(slashing, immunityGrid);
                    break;
                case DamageEffects.DamageType.ENERGY:
                    Instantiate(energy, immunityGrid);
                    break;
                case DamageEffects.DamageType.FIRE:
                    Instantiate(fire, immunityGrid);
                    break;
                case DamageEffects.DamageType.FROST:
                    Instantiate(frost, immunityGrid);
                    break;
                case DamageEffects.DamageType.SHOCK:
                    Instantiate(shock, immunityGrid);
                    break;
                case DamageEffects.DamageType.ACID:
                    Instantiate(acid, immunityGrid);
                    break;
                case DamageEffects.DamageType.POISON:
                    Instantiate(poison, immunityGrid);
                    break;
                case DamageEffects.DamageType.PSIONIC:
                    Instantiate(psionic, immunityGrid);
                    break;
            }
        }
    }
}
