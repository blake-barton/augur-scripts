using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.InputSystem;

public class TabMenuManager : MonoBehaviour
{
    [SerializeField] GameObject tabMenu;

    [Header("Location States")]
    [SerializeField] bool inMenu = false;
    [SerializeField] bool inEquipment = false;
    [SerializeField] bool inInventory = false;
    [SerializeField] bool inMagic = false;
    [SerializeField] bool inPlayerStatsDetailed = false;
    [SerializeField] bool inQuestLog = false;
    [SerializeField] bool inSettings = false;
    [SerializeField] bool inExitMenu = false;
    [SerializeField] bool inHandPanel = false;
    [SerializeField] bool inOutfitEquipPanel = false;
    [SerializeField] bool inFocusImplantEquipPanel = false;
    [SerializeField] bool inQuickAidEquipPanel = false;

    [Header("Input States")]
    [SerializeField] bool descriptionMode = false;

    [Header("Panels")]
    [SerializeField] GameObject equipmentPanel;
    [SerializeField] GameObject inventoryPanel;
    [SerializeField] GameObject magicPanel;
    [SerializeField] GameObject playerStatsBriefPanel;
    [SerializeField] GameObject settingsPanel;
    [SerializeField] GameObject exitMenuPanel;
    [SerializeField] GameObject questLogPanel;
    [SerializeField] GameObject playerStatsDetailedPanel;
        
    [Header("Equip Panels")]
    [SerializeField] GameObject handPanel;
    [SerializeField] GameObject outfitEquipPanel;
    [SerializeField] GameObject focusImplantEquipPanel;
    [SerializeField] GameObject quickAidEquipPanel;

    [Header("Info Panels")]
    [SerializeField] GameObject testItemPanel;
    [SerializeField] GameObject spellInfoPanel;
    [SerializeField] GameObject rangedWeaponPanel;
    [SerializeField] GameObject meleeWeaponPanel;
    [SerializeField] GameObject outfitPanel;
    [SerializeField] GameObject ammoPanel;
    [SerializeField] GameObject itemPanel;
    [SerializeField] GameObject descriptionPanel;

    [Header("Areas")]
    [SerializeField] Transform panelsArea;

    [Header("Grids")]
    [SerializeField] Transform panelsGrid;

    [Header("Toggles")]
    [SerializeField] Toggle inventoryToggle;
    [SerializeField] Toggle magicToggle;

    [Header("Text")]
    [SerializeField] TextMeshProUGUI menuTitleText;
    [SerializeField] TextMeshProUGUI footerText;
    [SerializeField] TextMeshProUGUI creditsText;
    [SerializeField] TextMeshProUGUI buttonsText;

    [Header("Popups")]
    [SerializeField] GameObject selectXAmountPanel;

    // time
    [Header("Time")]
    [SerializeField] float gameTimeScale = 1f;

    [Header("Instantiated Panels")]
    [SerializeField] GameObject instantiatedSettingsPanel;
    [SerializeField] GameObject instantiatedExitMenuPanel;
    [SerializeField] GameObject instantiatedQuestLogPanel;
    [SerializeField] GameObject instantiatedPlayerStatsDetailedPanel;

    [Header("Cache")]
    [SerializeField] WeaponWheelManager weaponWheelManager;

    // cache
    HUDManager HUD;
    Player player;

    public bool InMenu { get => inMenu; set => inMenu = value; }
    public bool InEquipment { get => inEquipment; set => inEquipment = value; }
    public bool InInventory { get => inInventory; set => inInventory = value; }
    public bool InMagic { get => inMagic; set => inMagic = value; }
    public bool InPlayerStatsDetailed { get => inPlayerStatsDetailed; set => inPlayerStatsDetailed = value; }
    public bool InQuestLog { get => inQuestLog; set => inQuestLog = value; }
    public bool InSettings { get => inSettings; set => inSettings = value; }
    public bool InExitMenu { get => inExitMenu; set => inExitMenu = value; }
    public bool InHandPanel { get => inHandPanel; set => inHandPanel = value; }
    public bool InOutfitEquipPanel { get => inOutfitEquipPanel; set => inOutfitEquipPanel = value; }
    public bool InFocusImplantEquipPanel { get => inFocusImplantEquipPanel; set => inFocusImplantEquipPanel = value; }
    public bool InQuickAidEquipPanel { get => inQuickAidEquipPanel; set => inQuickAidEquipPanel = value; }
    public bool DescriptionMode { get => descriptionMode; set => descriptionMode = value; }

    private void Awake()
    {
        HUD = FindObjectOfType<HUDManager>();
        player = FindObjectOfType<Player>();
    }

    // Start is called before the first frame update
    void Start()
    {
        menuTitleText.text = "";
        footerText.text = "";
        creditsText.text = "";
        buttonsText.text = "";
        tabMenu.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        if (player.Health.Alive && !player.Character.Incapacitated && !player.InDialogue && !weaponWheelManager.WheelDisplayed)
        {
            HandleKeyboardInput();
        }
    }

    void HandleKeyboardInput()
    {
        if (Input.GetKeyDown(KeyCode.I) && !InInventory)
        {
            ShowInventory();
        }
        else if (Input.GetKeyDown(KeyCode.I) && InInventory)
        {
            ToggleMenu();
        }

        if (Input.GetKeyDown(KeyCode.M) && !InMagic)
        {
            ShowMagic();
        }
        else if (Input.GetKeyDown(KeyCode.M) && InMagic)
        {
            ToggleMenu();
        }

        if (Input.GetKeyDown(KeyCode.K) && !InEquipment)
        {
            ShowEquipment();
        }
        else if (Input.GetKeyDown(KeyCode.K) && InEquipment)
        {
            ToggleMenu();
        }

        if (Input.GetKeyDown(KeyCode.O) && !InSettings)
        {
            ShowSettings();
        }
        else if (Input.GetKeyDown(KeyCode.O) && InSettings)
        {
            ToggleMenu();
        }

        if (Input.GetKeyDown(KeyCode.L) && !InQuestLog)
        {
            ShowQuestLog();
        }
        else if (Input.GetKeyDown(KeyCode.L) && InQuestLog)
        {
            ToggleMenu();
        }

        if (Input.GetKeyDown(KeyCode.P) && !InPlayerStatsDetailed)
        {
            ShowPlayerStatsDetailed();
        }
        else if (Input.GetKeyDown(KeyCode.P) && InPlayerStatsDetailed)
        {
            ToggleMenu();
        }
    }

    void ToggleMenu()
    {
        if (tabMenu.activeInHierarchy)
        {
            DestroyPanels();
            tabMenu.SetActive(false);
            InMenu = false;

            // back to real time
            Time.timeScale = gameTimeScale;
        }
        else
        {
            DestroyPanels();    // in case anything got left over

            tabMenu.SetActive(true);
            InMenu = true;

            footerText.text = "Select a menu from the list above.";
            creditsText.text = "Gossamer: " + player.Character.GetComponent<Crypto>().CurrentCurrency.ToString(); 

            // set timescale to 0
            gameTimeScale = Time.timeScale;
            Time.timeScale = 0;
        }

        HUD.ToggleHUD();
    }

    // ONLY opens the menu; or does nothing
    public void OpenMenu()
    {
        if (!InMenu)
        {
            DestroyPanels();    // in case anything got left over

            tabMenu.SetActive(true);
            InMenu = true;

            footerText.text = "Select a menu from the list above.";
            creditsText.text = "Gossamer: " + player.Character.GetComponent<Crypto>().CurrentCurrency.ToString();

            // set timescale to 0
            gameTimeScale = Time.timeScale;
            Time.timeScale = 0;

            HUD.DisableHUD();
        }
    }

    // ONLY leaves the menu; or does nothing
    public void ExitMenu()
    {
        if (tabMenu.activeInHierarchy)
        {
            DestroyPanels();
            tabMenu.SetActive(false);
            InMenu = false;

            // back to real time
            Time.timeScale = gameTimeScale;

            HUD.EnableHUD();
        }
    }

    public void ShowEquipment()
    {
        if (!InMenu)
        {
            ToggleMenu();
        }

        if (!InEquipment)
        {
            DestroyPanels();

            // instatiate inventory panel, info panel, player stats panel
            Instantiate(equipmentPanel, panelsGrid);
            Instantiate(testItemPanel, panelsGrid);
            Instantiate(playerStatsBriefPanel, panelsGrid);

            InEquipment = true;

            menuTitleText.text = "Equipment";
            footerText.text = "Select a slot to equip an item, weapon, spell, or outfit.";
            buttonsText.text = "R) Clear slot  L-Shift) Description Mode";
        }
    }

    public void ShowInventory()
    {
        // make sure the menu is open
        if (!InMenu)
        {
            ToggleMenu();
        }

        // disable whatever panels are currently open if they aren't the inventory
        if (!InInventory)
        {
            DestroyPanels();

            // instantiate the panels required for the inventory
            Instantiate(inventoryPanel, panelsGrid);
            Instantiate(testItemPanel, panelsGrid);                 // eventually want this to depend on the first item in the inventory
            Instantiate(playerStatsBriefPanel, panelsGrid);

            InInventory = true;

            menuTitleText.text = "Inventory";
            footerText.text = "Hover over an item slot to view information on the item.";
            buttonsText.text = "LMB) Equip/Unequip Mainhand  RMB) Equip/Unequip Offhand  R) Drop item  L-Shift) Description Mode";
        }
    }

    public void ShowMagic()
    {
        // make sure the menu is open
        if (!InMenu)
        {
            ToggleMenu();
        }

        // disable whatever panels are currently open if they aren't in magic
        if (!InMagic)
        {
            DestroyPanels();

            // instantiate the panels required for the magic menu
            Instantiate(magicPanel, panelsGrid);
            Instantiate(testItemPanel, panelsGrid);                 // eventually want this to depend on the first item in the inventory
            Instantiate(playerStatsBriefPanel, panelsGrid);

            InMagic = true;

            menuTitleText.text = "Magic";
            footerText.text = "Hover over a spell to view information on the spell.";
            buttonsText.text = "LMB) Equip/Unequip Mainhand  RMB) Equip/Unequip Offhand  L-Shift) Description Mode";
        }
    }

    public void ShowSettings()
    {
        // make sure the menu is open
        if (!InMenu)
        {
            ToggleMenu();
        }

        // disable whatever panels are currently open if they aren't in magic
        if (!InSettings)
        {
            DestroyPanels();

            // instantiate the settings panel as a child to the game canvas
            instantiatedSettingsPanel = Instantiate(settingsPanel, tabMenu.transform.parent);

            InSettings = true;

            menuTitleText.text = "Settings";
            footerText.text = "Adjust the sliders to change values.";
        }
    }

    public void ShowExitMenu()
    {
        // make sure the menu is open
        if (!InMenu)
        {
            ToggleMenu();
        }

        // disable whatever panels are currently open if they aren't in magic
        if (!InExitMenu)
        {
            DestroyPanels();

            // instantiate the exit menu panel as a child to the game canvas
            instantiatedExitMenuPanel = Instantiate(exitMenuPanel, tabMenu.transform.parent);

            InExitMenu = true;

            menuTitleText.text = "Exit Game";
            footerText.text = "";
        }
    }

    public void ShowQuestLog()
    {
        if (!InMenu)
        {
            ToggleMenu();
        }

        if (!InQuestLog)
        {
            DestroyPanels();

            // instantiate the exit menu panel as a child to the game canvas
            instantiatedQuestLogPanel = Instantiate(questLogPanel, tabMenu.transform.parent);

            InQuestLog = true;

            menuTitleText.text = "Quest Log";
            footerText.text = "Select a quest from the list to view its details.";
        }
    }

    public void ShowPlayerStatsDetailed()
    {
        if (!InMenu)
        {
            ToggleMenu();
        }

        if (!InPlayerStatsDetailed)
        {
            DestroyPanels();

            // instantiate the exit menu panel as a child to the game canvas
            instantiatedPlayerStatsDetailedPanel = Instantiate(playerStatsDetailedPanel, tabMenu.transform.parent);

            InPlayerStatsDetailed = true;

            menuTitleText.text = "Player Stats";
            footerText.text = "";
        }
    }

    public void ShowHandPanel(HandPanel.HandSlot slotDestination, int quickEquippableIndex = -1)
    {
        // make sure the menu is open
        if (!InMenu)
        {
            ToggleMenu();
        }

        // disable whatever panels are currently open if they aren't in magic
        if (!InHandPanel)
        {
            DestroyPanels();

            // instantiate the panels required for the magic menu
            var newPanel = Instantiate(handPanel, panelsGrid);
            HandPanel newHandPanel = newPanel.GetComponent<HandPanel>();
            newHandPanel.SlotDestination = slotDestination;
            newHandPanel.QuickEquippableIndex = quickEquippableIndex;

            Instantiate(testItemPanel, panelsGrid);                 // eventually want this to depend on the first item in the inventory
            Instantiate(playerStatsBriefPanel, panelsGrid);

            InHandPanel = true;

            menuTitleText.text = "Equipment";
            footerText.text = "Click on an item or spell to equip it in the selected hand or quick slot.";
        }
    }

    public void ShowOutfitEquipPanel()
    {
        // make sure the menu is open
        if (!InMenu)
        {
            ToggleMenu();
        }

        // disable whatever panels are currently open if they aren't in outfits
        if (!InOutfitEquipPanel)
        {
            DestroyPanels();

            // instantiate the panels required for the outfit menu
            var newPanel = Instantiate(outfitEquipPanel, panelsGrid);

            Instantiate(testItemPanel, panelsGrid);                 // eventually want this to depend on the first item in the inventory
            Instantiate(playerStatsBriefPanel, panelsGrid);

            InOutfitEquipPanel = true;

            menuTitleText.text = "Equipment";
            footerText.text = "Click on an outfit to equip it.";
        }
    }

    public void ShowFocusImplantEquipPanel()
    {
        // make sure the menu is open
        if (!InMenu)
        {
            ToggleMenu();
        }

        // disable whatever panels are currently open if they aren't in magic
        if (!InFocusImplantEquipPanel)
        {
            DestroyPanels();

            // instantiate the panels required for the focus implant equip menu
            var newPanel = Instantiate(focusImplantEquipPanel, panelsGrid);

            Instantiate(testItemPanel, panelsGrid);                 // eventually want this to depend on the first item in the inventory
            Instantiate(playerStatsBriefPanel, panelsGrid);

            InFocusImplantEquipPanel = true;

            menuTitleText.text = "Equipment";
            footerText.text = "Click on a focus implant to equip it.";
        }
    }

    public void ShowQuickAidEquipPanel(int quickAidIndex)
    {
        // make sure the menu is open
        if (!InMenu)
        {
            ToggleMenu();
        }

        // disable whatever panels are currently open if they aren't in magic
        if (!InQuickAidEquipPanel)
        {
            DestroyPanels();

            // instantiate the panels required for the focus implant equip menu
            var newPanel = Instantiate(quickAidEquipPanel, panelsGrid);

            EquipItemGridPanel equipItemGridPanel = newPanel.GetComponent<EquipItemGridPanel>();
            equipItemGridPanel.QuickAidIndex = quickAidIndex;

            Instantiate(testItemPanel, panelsGrid);                 // eventually want this to depend on the first item in the inventory
            Instantiate(playerStatsBriefPanel, panelsGrid);

            InQuickAidEquipPanel = true;

            menuTitleText.text = "Equipment";
            footerText.text = "Click on an aid item to equip it in the selected slot.";
        }
    }

    private void DisablePanels()
    {
        foreach (RectTransform child in panelsGrid.transform)
        {
            child.gameObject.SetActive(false);
        }
    }

    private void DestroyPanels()
    {
        foreach (RectTransform child in panelsGrid.transform)
        {
            Destroy(child.gameObject);
        }

        if (instantiatedSettingsPanel)
            Destroy(instantiatedSettingsPanel);

        if (instantiatedExitMenuPanel)
            Destroy(instantiatedExitMenuPanel);

        if (instantiatedQuestLogPanel)
            Destroy(instantiatedQuestLogPanel);

        if (instantiatedPlayerStatsDetailedPanel)
            Destroy(instantiatedPlayerStatsDetailedPanel);

        ClearPanelState();
    }

    public void DestroyInfoPanel()
    {
        // The info panel will always be the second child
        if (panelsGrid.transform.childCount >= 3)
        {
            Destroy(panelsGrid.transform.GetChild(1).gameObject);
        }
    }

    public void LoadItemInfoPanel(Item item, int itemCount)
    {
        if (DescriptionMode)
        {
            var panel = Instantiate(descriptionPanel, panelsGrid);
            panel.transform.SetSiblingIndex(1);

            panel.GetComponent<DescriptionPanel>().SetItemPanelText(item);
        }
        else
        {
            switch (item.Type)
            {
                case Item.ItemType.RANGEDWEAPON:
                    // load ranged weapon panel
                    var rangedInfoPanel = Instantiate(rangedWeaponPanel, panelsGrid);
                    rangedInfoPanel.transform.SetSiblingIndex(1);

                    // load data into panel
                    rangedInfoPanel.GetComponent<RangedWeaponPanel>().SetPanelText(item);

                    break;
                case Item.ItemType.MELEEWEAPON:
                    // load melee weapon panel
                    var meleeInfoPanel = Instantiate(meleeWeaponPanel, panelsGrid);
                    meleeInfoPanel.transform.SetSiblingIndex(1);

                    // load data into panel
                    meleeInfoPanel.GetComponent<MeleeWeaponPanel>().SetPanelText(item);
                    break;
                case Item.ItemType.OUTFIT:
                    // load outfit panel
                    var outfitInfoPanel = Instantiate(outfitPanel, panelsGrid);
                    outfitInfoPanel.transform.SetSiblingIndex(1);

                    // load data into panel
                    outfitInfoPanel.GetComponent<OutfitPanel>().SetPanelInfo(item);
                    break;
                case Item.ItemType.AMMO:
                    var ammoInfoPanel = Instantiate(ammoPanel, panelsGrid);
                    ammoInfoPanel.transform.SetSiblingIndex(1);

                    // load data into panel
                    ammoInfoPanel.GetComponent<AmmoPanel>().SetPanelText(item, itemCount);
                    break;
                default:
                    // load item panel
                    var itemInfoPanel = Instantiate(itemPanel, panelsGrid);
                    itemInfoPanel.transform.SetSiblingIndex(1);

                    // load data into panel
                    itemInfoPanel.GetComponent<MiscPanel>().SetPanelText(item, itemCount);
                    break;
            }
        }
    }

    public void LoadSpellInfoPanel(Spell spell)
    {
        if (DescriptionMode)
        {
            var panel = Instantiate(descriptionPanel, panelsGrid);
            panel.transform.SetSiblingIndex(1);

            panel.GetComponent<DescriptionPanel>().SetSpellPanelText(spell);
        }
        else
        {
            var panel = Instantiate(spellInfoPanel, panelsGrid);
            panel.transform.SetSiblingIndex(1);

            // load data into panel
            panel.GetComponent<SpellPanel>().SetPanelInfo(spell);
        }
    }

    private void ClearPanelState()
    {
        InEquipment = false;
        InInventory = false;
        InMagic = false;
        InPlayerStatsDetailed = false;
        InQuestLog = false;
        InSettings = false;
        InHandPanel = false;
        InOutfitEquipPanel = false;
        InFocusImplantEquipPanel = false;
        InExitMenu = false;
        InQuickAidEquipPanel = false;

        menuTitleText.text = "";
        buttonsText.text = "";
        footerText.text = "";
    }

    public void LoadTestInfoPanel()
    {
        var testPanel = Instantiate(testItemPanel, panelsGrid);                 // eventually want this to depend on the first item in the inventory
        testPanel.transform.SetSiblingIndex(1);
    }

    public void ToggleDescriptionPanel(Item item, int itemCount)
    {
        DestroyInfoPanel();

        if (DescriptionMode)
        {
            // showing description. Delete description panel and spawn info panel
            DescriptionMode = false;
            LoadItemInfoPanel(item, itemCount);
        }
        else
        {
            // Not showing description. Set description mode and spawn description panel.
            DescriptionMode = true;
            LoadItemInfoPanel(item, itemCount);
        }
    }

    public void ToggleDescriptionPanelSpell(Spell spell)
    {
        DestroyInfoPanel();

        if (DescriptionMode)
        {
            // showing description. Delete description panel and spawn info panel
            DescriptionMode = false;
            LoadSpellInfoPanel(spell);
        }
        else
        {
            // Not showing description. Set description mode and spawn description panel.
            DescriptionMode = true;
            LoadSpellInfoPanel(spell);
        }
    }

    public void LoadSelectXPopup(int dropIndex, int itemCount)
    {
        var selectX = Instantiate(selectXAmountPanel, panelsArea);
        selectX.GetComponent<SelectXPanel>().SetSliderLimits(1, itemCount);
        selectX.GetComponent<SelectXDropBehavior>().ItemIndex = dropIndex;
    }

    public void DestroyPlayerStats()
    {
        // The player info panel will always be the third child (under circumstances where we'd want to destroy it)
        if (panelsGrid.transform.childCount >= 3)
        {
            Destroy(panelsGrid.transform.GetChild(2).gameObject);
        }
    }

    public void ReloadPlayerStats()
    {
        DestroyPlayerStats();
        Instantiate(playerStatsBriefPanel, panelsGrid);
    }

    public void OnMenu(InputAction.CallbackContext context)
    {
        if (player.Health.Alive && !player.Character.Incapacitated && !player.InDialogue && !weaponWheelManager.WheelDisplayed)
        {
            if (context.performed)
            {
                if (InMenu)
                {
                    ExitMenu();
                }
                else
                {
                    OpenMenu();
                }
            }
        }
    }

    public void OnCancel(InputAction.CallbackContext context)
    {
        if (player.Health.Alive && !player.Character.Incapacitated && !player.InDialogue && !weaponWheelManager.WheelDisplayed)
        {
            if (context.performed)
            {
                if (InMenu)
                {
                    Cancel();
                }
            }
        }
    }

    public void OnExit(InputAction.CallbackContext context)
    {
        if (player.Health.Alive && !player.Character.Incapacitated && !player.InDialogue && !weaponWheelManager.WheelDisplayed)
        {
            if (context.performed)
            {
                if (InMenu)
                {
                    ExitMenu();
                }
                else
                {
                    ShowExitMenu();
                }
            }
        }
    }

    void Cancel()
    {
    }
}
