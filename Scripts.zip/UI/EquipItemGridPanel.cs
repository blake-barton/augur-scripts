using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class EquipItemGridPanel : MonoBehaviour
{
    [Header("Item Grid")]
    [SerializeField] GameObject itemSlotTemplate;
    [SerializeField] GameObject itemGrid;

    [Header("Text")]
    [SerializeField] TextMeshProUGUI categoryTitleText;
    [SerializeField] TextMeshProUGUI equippableNameTitleText;

    [Header("Starting Values")]
    public Item.ItemType startingCategory;

    int quickAidIndex;

    // cached references
    Inventory playerInventory;

    public int QuickAidIndex { get => quickAidIndex; set => quickAidIndex = value; }

    private void Awake()
    {
        playerInventory = FindObjectOfType<Player>().gameObject.GetComponent<Inventory>();
    }

    // Start is called before the first frame update
    void Start()
    {
        LoadPlayerInventoryIntoGrid();
        categoryTitleText.text = "";
        equippableNameTitleText.text = "";

        ToggleInventoryCategory((int)startingCategory);
    }

    void LoadPlayerInventoryIntoGrid()
    {
        foreach (Pair<Item, int> pair in playerInventory.Items)
        {
            // insert the slot into the grid
            GameObject newSlot = Instantiate(itemSlotTemplate, itemGrid.transform);

            // fill the slot with data
            FillItemSlotTemplate(newSlot, pair, pair.First.ItemName, pair.First.Type, pair.First.Sprite, pair.Second, pair.First.EquippedMain, pair.First.EquippedOff, pair.First.Equipped);
        }
    }                                                                                                                             

    void FillItemSlotTemplate(GameObject newSlot, Pair<Item, int> itemPair, string itemName, Item.ItemType itemType, Sprite itemSprite, int itemCount, bool equippedMain, bool equippedOff, bool itemEquipped)
    {
        InventoryClickable clickable = newSlot.GetComponent<InventoryClickable>();
        Image itemImage = newSlot.transform.GetChild(0).GetComponent<Image>();

        clickable.ItemPair = itemPair;

        clickable.SlotType = InventoryClickable.ClickableType.ITEM_EQUIP_SLOT;

        clickable.itemType = itemType;
        clickable.itemName = itemName;
        clickable.ItemCount = itemCount;
        clickable.UpdateCountPanelText();
        itemImage.sprite = itemSprite;

        // equip panels
        clickable.EquippedMain = equippedMain;
        clickable.EquippedOff = equippedOff;
        clickable.ItemEquipped = itemEquipped;
        clickable.UpdateEquipPanels();
    }

    // Disable all item panels that are not of the given type
    // NOTE: BECAUSE ENUMS ARE NOT SUPPORTED THIS IS PASSED AN INTEGER ARGUMENT, MEANING THAT IF THE ENUM IN Item.cs IS EVER CHANGED THE BUTTONS WILL NEED TO BE CHANGED
    public void ToggleInventoryCategory(int type)
    {
        foreach (RectTransform child in itemGrid.transform)
        {
            if ((int)child.gameObject.GetComponent<InventoryClickable>().itemType != type)
            {
                child.gameObject.SetActive(false);
            }
            else
            {
                child.gameObject.SetActive(true);
            }
        }

        switch (type)
        {
            case (int)Item.ItemType.RANGEDWEAPON:
                categoryTitleText.text = "Ranged Weapons";
                break;
            case (int)Item.ItemType.MELEEWEAPON:
                categoryTitleText.text = "Melee Weapons";
                break;
            case (int)Item.ItemType.OUTFIT:
                categoryTitleText.text = "Outfits";
                break;
            case (int)Item.ItemType.AID:
                categoryTitleText.text = "Aid";
                break;
            case (int)Item.ItemType.MISC:
                categoryTitleText.text = "Miscellaneous";
                break;
            case (int)Item.ItemType.AMMO:
                categoryTitleText.text = "Ammunition";
                break;
            case (int)Item.ItemType.AUGMENTATION:
                categoryTitleText.text = "Augmentations";
                break;
            case (int)Item.ItemType.FOCUSIMPLANT:
                categoryTitleText.text = "Focus Implants";
                break;
        }

        SetEquippableNameTitleText("");
    }

    public void SetEquippableNameTitleText(string itemName)
    {
        equippableNameTitleText.text = itemName;
    }

    public void SetCategoryTitleText(string categoryName)
    {
        categoryTitleText.text = categoryName;
    }
}