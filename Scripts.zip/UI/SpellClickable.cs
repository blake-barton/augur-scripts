using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class SpellClickable : MonoBehaviour, IPointerClickHandler, IPointerEnterHandler, IPointerExitHandler
{
    public Spell spell;                 // contains all data
    bool isHovered = false;             // is the pointer over the panel?

    [SerializeField] InventoryClickable.ClickableType slotType;

    [Header("Mainhand Panel")]
    [SerializeField] bool equippedMain = false;
    [SerializeField] GameObject leftClickPanel;

    [Header("Offhand Panel")]
    [SerializeField] bool equippedOff = false;
    [SerializeField] GameObject rightClickPanel;

    [Header("Visuals")]
    [SerializeField] Color backgroundNotHovered;
    [SerializeField] Color backgroundHovered;
    [SerializeField] Color outlineNotHovered;
    [SerializeField] Color outlineHovered;
    [SerializeField] Vector2 outlineSizeNotHovered = new Vector2();
    [SerializeField] Vector2 outlineSizeHovered = new Vector2();

    // cached references
    Equipment equipment;
    MagicPanel magicPanel;
    TabMenuManager tabMenuManager;
    Image backgroundImage;
    Outline outline;
    HandPanel handPanel;

    public bool EquippedMain { get => equippedMain; set => equippedMain = value; }
    public bool EquippedOff { get => equippedOff; set => equippedOff = value; }
    public InventoryClickable.ClickableType SlotType { get => slotType; set => slotType = value; }

    void Start()
    {
        equipment = FindObjectOfType<Player>().GetComponent<Equipment>();
        magicPanel = FindObjectOfType<MagicPanel>();
        tabMenuManager = FindObjectOfType<TabMenuManager>();
        backgroundImage = GetComponent<Image>();
        outline = GetComponent<Outline>();
        handPanel = FindObjectOfType<HandPanel>();
    }

    void Update()
    {
        ToggleDescriptionPanel();
    }

    public void OnPointerClick(PointerEventData eventData)
    {
        switch (slotType)
        {
            case InventoryClickable.ClickableType.INVENTORY_GRID_SLOT:
                HandleMagicMenuSlotClick(eventData);
                break;
            case InventoryClickable.ClickableType.HAND_PANEL_GRID_SLOT:
                HandleHandPanelSlotClick();
                break;
        }
    }

    private void HandleHandPanelSlotClick()
    {
        // equip based on panel destination
        switch (handPanel.SlotDestination)
        {
            case HandPanel.HandSlot.MAINHAND:
                equipment.EquipMainHandSpell(spell);
                break;
            case HandPanel.HandSlot.OFFHAND:
                equipment.EquipOffHandSpell(spell);
                break;
            case HandPanel.HandSlot.QUICKEQUIP:
                // place the item in the correct quick equip index
                equipment.PlaceEquippable(spell, handPanel.QuickEquippableIndex);
                break;
        }

        // return to the equipment screen
        tabMenuManager.ShowEquipment();
    }

    private void HandleMagicMenuSlotClick(PointerEventData eventData)
    {
        if (eventData.button == PointerEventData.InputButton.Left)
        {
            equipment.EquipMainHandSpell(spell);
            magicPanel.ReloadGrid();
        }
        else if (eventData.button == PointerEventData.InputButton.Middle)
        {

        }
        else if (eventData.button == PointerEventData.InputButton.Right)
        {
            // equip spell
            equipment.EquipOffHandSpell(spell);
            magicPanel.ReloadGrid();
        }
    }

    // sends information about the item this panel represents to the InventoryUI manager to be loaded in the info panel
    public void OnPointerEnter(PointerEventData eventData)
    {
        isHovered = true;

        ActivateHoverVisuals();

        switch (slotType)
        {
            case InventoryClickable.ClickableType.INVENTORY_GRID_SLOT:
                magicPanel.SetSpellNameTitleText(spell.SpellName);
                break;
            case InventoryClickable.ClickableType.HAND_PANEL_GRID_SLOT:
                handPanel.SetEquippableNameTitleText(spell.SpellName);
                break;
        }

        ActivateTabManagerInfoPanelLoad();
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        isHovered = false;
        DeactivateHoverVisuals();
    }

    private void ActivateHoverVisuals()
    {
        backgroundImage.color = backgroundHovered;
        outline.effectColor = outlineHovered;

        outline.effectDistance = outlineSizeHovered;
    }

    private void DeactivateHoverVisuals()
    {
        backgroundImage.color = backgroundNotHovered;
        outline.effectColor = outlineNotHovered;

        outline.effectDistance = outlineSizeNotHovered;
    }

    private void ActivateTabManagerInfoPanelLoad()
    {
        // clear current item info
        tabMenuManager.DestroyInfoPanel();

        // load an info panel with this spell's data
        tabMenuManager.LoadSpellInfoPanel(spell);
    }

    private void ToggleDescriptionPanel()
    {
        if (Input.GetKeyDown(KeyCode.LeftShift) && isHovered)
        {
            // load and display description panel or info panel depending on state
            tabMenuManager.ToggleDescriptionPanelSpell(spell);
        }
    }

    public void UpdateEquipPanels()
    {
        if (EquippedMain)
        {
            leftClickPanel.SetActive(true);
        }
        else
        {
            leftClickPanel.SetActive(false);
        }

        if (EquippedOff)
        {
            rightClickPanel.SetActive(true);
        }
        else
        {
            rightClickPanel.SetActive(false);
        }
    }
}
