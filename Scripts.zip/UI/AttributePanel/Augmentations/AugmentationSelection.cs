using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using TMPro;

public class AugmentationSelection : MonoBehaviour, IPointerClickHandler, IPointerEnterHandler, IPointerExitHandler
{
    [SerializeField] TextMeshProUGUI augmentationName;
    [SerializeField] Image selectedBox;
    [SerializeField] Color purchasableColor;
    [SerializeField] Color lockedColor;
    [SerializeField] Color hoveredLockedColor;

    Augmentation augmentation;
    TextMeshProUGUI descriptionText;
    TextMeshProUGUI levelRequirementText;
    TextMeshProUGUI attributeRequirementsText;
    TextMeshProUGUI skillRequirementsText;
    TextMeshProUGUI costText;
    bool isPurchasable;

    // cached references
    AugmentationMenu augmentationMenu;

    public void OnPointerClick(PointerEventData eventData)
    {
        if (isPurchasable)
        {
            // enable select box
            selectedBox.enabled = !selectedBox.enabled;

            // select/deselect for purchase
            if (selectedBox.enabled)
            {
                augmentationMenu.SelectAugmentationForPurchase(augmentation);
            }
            else
            {
                augmentationMenu.DeselectAugmentationForPurchase(augmentation);
            }
        }
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        ClearText();

        // description text
        descriptionText.text = augmentation.Description;

        // level requirements text
        levelRequirementText.text = augmentation.LevelRequirement.ToString();

        // cost text
        costText.text = augmentation.AugmentationPointCost.ToString();

        // attribute requirements text
        for (int i = 0; i < augmentation.AttributeRequirements.Count; i++)
        {
            if (i == augmentation.AttributeRequirements.Count - 1)
            {
                // last requirement
                attributeRequirementsText.text += AttributeScores.GetAttributeAsStringAbbreviated(augmentation.AttributeRequirements[i].attribute) + " " + augmentation.AttributeRequirements[i].requirement.ToString();
            }
            else
            {
                attributeRequirementsText.text += AttributeScores.GetAttributeAsStringAbbreviated(augmentation.AttributeRequirements[i].attribute) + " " + augmentation.AttributeRequirements[i].requirement.ToString() + ", ";
            }
        }

        // skill requirements text
        for (int i = 0; i < augmentation.SkillRequirements.Count; i++)
        {
            if (i == augmentation.SkillRequirements.Count - 1)
            {
                // last requirement
                skillRequirementsText.text += AttributeScores.GetSkillAsString(augmentation.SkillRequirements[i].skill) + " " + augmentation.SkillRequirements[i].requirement.ToString();
            }
            else
            {
                skillRequirementsText.text += AttributeScores.GetSkillAsString(augmentation.SkillRequirements[i].skill) + " " + augmentation.SkillRequirements[i].requirement.ToString() + ", ";
            }
        }
    }

    public void OnPointerExit(PointerEventData eventData)
    {

    }

    public void InitializeAugmentationSelection(AugmentationMenu _augmentationMenu, Augmentation _augmentation, bool purchasable, TextMeshProUGUI _descriptionText, TextMeshProUGUI _levelRequirementsText, TextMeshProUGUI _attributeRequirementsText, TextMeshProUGUI _skillRequirementsText, TextMeshProUGUI _costText)
    {
        augmentationMenu = _augmentationMenu;
        augmentation = _augmentation;

        augmentationName.text = augmentation.AugmentationName;

        isPurchasable = purchasable;

        if (purchasable)
        {
            augmentationName.color = purchasableColor;
        }
        else
        {
            augmentationName.color = lockedColor;

            // hover colors
            augmentationName.GetComponent<OnHoverChangeTextColor>().InitializeColors(lockedColor, hoveredLockedColor);
        }


        descriptionText = _descriptionText;
        levelRequirementText = _levelRequirementsText;
        attributeRequirementsText = _attributeRequirementsText;
        skillRequirementsText = _skillRequirementsText;
        costText = _costText;
    }

    void ClearText()
    {
        descriptionText.text = "";
        levelRequirementText.text = "";
        attributeRequirementsText.text = "";
        skillRequirementsText.text = "";
    }
}
