using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class PresetListModal : UIPanel
{
    [Header("References")]
    [SerializeField] Transform scrollContent;
    [SerializeField] TextMeshProUGUI header;

    [Header("Prefabs")]
    [SerializeField] GameObject presetSelectionTemplate;

    List<PlayerPreset> playerPresets = new List<PlayerPreset>();

    private void Start()
    {
        // load in the presets JSON
        playerPresets = SaveSystem.LoadPlayerPresets().playerPresets;

        if (playerPresets.Count > 0)
        {
            // load in selection prefabs
            foreach (PlayerPreset preset in playerPresets)
            {
                var newSelection = Instantiate(presetSelectionTemplate, scrollContent);

                // assign elements to newSelection
                newSelection.GetComponent<PresetSelection>().InitializePresetSelection(preset);
            }

            // Select the first preset
            scrollContent.GetChild(0).GetComponent<PresetSelection>().Select();

            if (playerPresets.Count > 1)
            {
                // Navigation pass
                for (int i = 0; i < playerPresets.Count; i++)
                {
                    PresetSelection selection = scrollContent.GetChild(i).GetComponent<PresetSelection>();
                    Navigation navigation = selection.navigation;

                    if (i == 0)
                    {
                        // First. Set down to next child
                        navigation.selectOnDown = (scrollContent.GetChild(i + 1).GetComponent<PresetSelection>());
                    }
                    else if (i == playerPresets.Count - 1)
                    {
                        // Last. Set up to previous child.
                        navigation.selectOnUp = (scrollContent.GetChild(i - 1).GetComponent<PresetSelection>());
                    }
                    else
                    {
                        // Middle. Set up and down
                        navigation.selectOnUp = scrollContent.GetChild(i - 1).GetComponent<PresetSelection>();
                        navigation.selectOnDown = (scrollContent.GetChild(i + 1).GetComponent<PresetSelection>());
                    }

                    // Reassign navigation
                    selection.navigation = navigation;
                }
            }

        }
        else
        {
            header.text = "No presets saved.";
        }
    }
}
