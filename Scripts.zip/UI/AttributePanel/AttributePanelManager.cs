using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.InputSystem;

public class AttributePanelManager : MonoBehaviour
{
    [Header("Prefabs")]
    [SerializeField] GameObject attributeMenu;
    [SerializeField] GameObject skillsMenu;
    [SerializeField] GameObject levelUpMenu;
    [SerializeField] GameObject augmentationsMenu;
    [SerializeField] GameObject levelUpOrAugmentationsPopup;

    [Header("Config")]
    [SerializeField] bool spawnMenuOnAwake = true;
    [SerializeField] float timeBeforeSpawn = 6f;

    [Header("Equipped Items")]
    [SerializeField] Equippable mainhandEquippable;
    [SerializeField] Equippable offhandEquippable;

    // time
    [Header("Time")]
    [SerializeField] float gameTimeScale = 1f;

    [Header("State")]
    [SerializeField] bool inMenu = false;
    [SerializeField] UIPanel currentPanel;

    // cache
    Player player;
    Equipment playerEquipment;
    public AttributeScores attributes;
    Canvas canvas;

    GameObject instantiatedAttributeMenu;
    GameObject instantiatedSkillsMenu;
    GameObject instantiatedLevelUpMenu;
    GameObject instantiatedAugmentationsMenu;
    GameObject instantiatedLevelUpOrAugmentationsPopup;

    public bool InMenu { get => inMenu; set => inMenu = value; }

    private void Awake()
    {
        player = FindObjectOfType<Player>();
        playerEquipment = player.GetComponent<Equipment>();
        attributes = player.GetComponent<AttributeScores>();
        canvas = GameObject.FindGameObjectWithTag("GameCanvas").GetComponent<Canvas>();
    }

    // Start is called before the first frame update
    void Start()
    {
        if (spawnMenuOnAwake)
        {
            StartCoroutine(SpawnAttributeMenu());
        }
    }

    IEnumerator SpawnAttributeMenu()
    {
        yield return new WaitForSeconds(timeBeforeSpawn);

        instantiatedAttributeMenu = Instantiate(attributeMenu, canvas.transform);

        currentPanel = instantiatedAttributeMenu.GetComponent<UIPanel>();

        InitMenu();
    }

    public void SpawnLevelUpMenu()
    {
        instantiatedLevelUpMenu = Instantiate(levelUpMenu, canvas.transform);

        // track equipped weapons/spells
        mainhandEquippable = playerEquipment.GetMainhandAsEquippable();
        offhandEquippable = playerEquipment.GetOffhandAsEquippable();

        // unequip player weapons
        playerEquipment.UnequipHands(false);

        if (instantiatedLevelUpOrAugmentationsPopup)
        {
            Destroy(instantiatedLevelUpOrAugmentationsPopup);
        }
    }

    public void SpawnAugmentationsMenu()
    {
        instantiatedAugmentationsMenu = Instantiate(augmentationsMenu, canvas.transform);

        // track equipped weapons/spells
        mainhandEquippable = playerEquipment.GetMainhandAsEquippable();
        offhandEquippable = playerEquipment.GetOffhandAsEquippable();

        // unequip player weapons
        playerEquipment.UnequipHands(false);

        if (instantiatedLevelUpOrAugmentationsPopup)
        {
            Destroy(instantiatedLevelUpOrAugmentationsPopup);
        }
    }

    public void SpawnLevelUpOrAugmentationsPopup()
    {
        instantiatedLevelUpOrAugmentationsPopup = Instantiate(levelUpOrAugmentationsPopup, canvas.transform);

        // freeze time
        InitMenu();
    }

    void InitMenu()
    {
        InMenu = true;

        // freeze player
        player.IsBusy = true;
        player.Character.Incapacitated = true;
        player.GetComponent<PlayerMovement>().FreezeMovement();

        // set timescale to 0
        gameTimeScale = Time.timeScale;
        Time.timeScale = 0;
    }

    void ExitMenu()
    {
        InMenu = false;

        player.IsBusy = false;
        player.Character.Incapacitated = false;

        // back to real time
        Time.timeScale = gameTimeScale;
    }

    public void CancelLevelUp()
    {
        Destroy(instantiatedLevelUpMenu);

        ExitMenu();

        // reequip weapons/spells
        ReequipPlayer();
    }

    public void CloseAugmentationsMenu()
    {
        Destroy(instantiatedAugmentationsMenu);

        ExitMenu();

        // reequip weapons/spells
        ReequipPlayer();
    }

    public void CancelLevelUpOrAugmentationsSelection()
    {
        Destroy(instantiatedLevelUpOrAugmentationsPopup);

        ExitMenu();
    }

    public void SubmitAttributes(int _strength, int _perception, int _endurance, int _intelligence, int _agility, int _aberrance, int _pointsAvailable)
    {
        attributes.SetAttributes(_strength, _perception, _endurance, _intelligence, _agility, _aberrance, _pointsAvailable);

        instantiatedSkillsMenu = Instantiate(skillsMenu, canvas.transform);

        currentPanel = instantiatedSkillsMenu.GetComponent<UIPanel>();
    }

    public void SubmitSkills(bool[] proficiencies)
    {
        for (int i = 0; i < proficiencies.Length; i++)
        {
            if (proficiencies[i])
            {
                attributes.SetProficiency((AttributeScores.Skills)i);
            }
        }

        // unfreeze time
        ExitMenu();

        player.ActivateIdleAnimation();

        Destroy(instantiatedAttributeMenu);
        Destroy(instantiatedSkillsMenu);
    }

    public void SubmitSkills(int newLevel, int cost, int _acrobatics, int _barter, int _blade, int _bludgeoning, int _enkiism, int _erebancy, int _explosives, int _gaianism, int _heavyWeapons, int _hermeticism, int _iktomancy, int _pistols, int _polearms, int _reshephism, int _resourcefulness, int _rifles, int _sleightOfHand, int _thrown)
    {
        attributes.LevelUp(newLevel, cost, _acrobatics, _barter, _blade, _bludgeoning, _enkiism, _erebancy, _explosives, _gaianism, _heavyWeapons, _hermeticism, _iktomancy, _pistols, _polearms, _reshephism, _resourcefulness, _rifles, _sleightOfHand, _thrown);

        // unfreeze time
        ExitMenu();

        player.ActivateIdleAnimation();

        Destroy(instantiatedLevelUpMenu);

        // reequip weapons/spells
        ReequipPlayer();
    }

    // Load a preset and close the attribute allocation menu
    public void SubmitPreset(PlayerPreset preset)
    {
        // submit attributes
        int pointsAvailable = attributes.TotalAttributePoints - preset.strength + preset.perception + preset.endurance + preset.intelligence + preset.agility + preset.aberrance;
        attributes.SetAttributes(preset.strength, preset.perception, preset.endurance, preset.intelligence, preset.agility, preset.aberrance, pointsAvailable);

        // add proficiencies
        foreach (int prof in preset.proficiencies)
        {
            attributes.SetProficiency((AttributeScores.Skills)prof);
        }

        // unfreeze time
        ExitMenu();

        player.ActivateIdleAnimation();

        Destroy(instantiatedAttributeMenu);
    }

    private void ReequipPlayer()
    {
        if (mainhandEquippable != null)
        {
            if (mainhandEquippable.equippableType == Equippable.EquippableType.ITEM)
            {
                playerEquipment.EquipMainHandWeapon(mainhandEquippable, false);
            }
            else if (mainhandEquippable.equippableType == Equippable.EquippableType.SPELL)
            {
                playerEquipment.EquipMainHandSpell(mainhandEquippable.spell, false);
            }
        }

        if (offhandEquippable != null)
        {
            if (offhandEquippable.equippableType == Equippable.EquippableType.ITEM)
            {
                playerEquipment.EquipOffHandWeapon(offhandEquippable, false);
            }
            else if (offhandEquippable.equippableType == Equippable.EquippableType.SPELL)
            {
                playerEquipment.EquipOffHandSpell(offhandEquippable.spell, false);
            }
        }

        // clear equippables
        mainhandEquippable = null;
        offhandEquippable = null;
    }

    // button click
    public void DisplayModal(GameObject modal, Transform parentPanel)
    {
        GameObject newModal = Instantiate(modal, parentPanel);

        currentPanel = newModal.GetComponent<UIPanel>();
    }

    public void OnCancel(InputAction.CallbackContext context)
    {
        if (context.performed && InMenu)
        {
            Cancel();
        }
    }

    public void OnExit(InputAction.CallbackContext context)
    {
        if (context.performed && InMenu)
        {
            Cancel();
        }
    }

    void Cancel()
    {
        if (currentPanel)
        {
            switch (currentPanel.PanelName)
            {
                case "Skill Proficiency Panel":
                    Destroy(currentPanel.gameObject);
                    instantiatedAttributeMenu.GetComponent<AttributePanel>().SelectStartingButton();
                    break;
                case "Preset Modal":
                    Destroy(currentPanel.gameObject);
                    break;
                case "Save Preset Modal":
                    Destroy(currentPanel.gameObject);
                    break;
            }
        }
    }
}
