using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LevelUpOrAugmentationsPopup : MonoBehaviour
{
    AttributePanelManager attributePanelManager;

    private void Awake()
    {
        attributePanelManager = FindObjectOfType<AttributePanelManager>();
    }

    public void SpawnLevelUpMenu()
    {
        attributePanelManager.SpawnLevelUpMenu();
    }

    public void SpawnAugmentationsMenu()
    {
        attributePanelManager.SpawnAugmentationsMenu();
    }

    public void Cancel()
    {
        attributePanelManager.CancelLevelUpOrAugmentationsSelection();
    }
}
