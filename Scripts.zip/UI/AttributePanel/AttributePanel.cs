using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class AttributePanel : UIPanel
{
    [Header("Panel Elements")]
    [SerializeField] Image attributeSprite;
    [SerializeField] TextMeshProUGUI description;

    [Header("Text")]
    [SerializeField] TextMeshProUGUI strengthText;
    [SerializeField] TextMeshProUGUI perceptionText;
    [SerializeField] TextMeshProUGUI enduranceText;
    [SerializeField] TextMeshProUGUI intelligenceText;
    [SerializeField] TextMeshProUGUI agilityText;
    [SerializeField] TextMeshProUGUI aberranceText;
    [SerializeField] TextMeshProUGUI pointsAvailableText;

    // values
    [Header("Values")]
    [SerializeField] int pointsAvailable;
    [SerializeField] int strength = 0;
    [SerializeField] int perception = 0;
    [SerializeField] int endurance = 0;
    [SerializeField] int intelligence = 0;
    [SerializeField] int agility = 0;
    [SerializeField] int aberrance = 0;
    [SerializeField] int attributePointMax = 10;

    [Header("Sound")]
    [SerializeField] AudioClip arrowIncrementSound;
    [SerializeField] [Range(0, 1)] float arrowIncrementVolume = .5f;
    [SerializeField] AudioClip arrowDecrementSound;
    [SerializeField] [Range(0, 1)] float arrowDecrementVolume = .5f;

    [Header("Modals")]
    [SerializeField] GameObject presetListModal;

    [Header("Navigation")]
    [SerializeField] Button startingButton;

    private enum AttributeSelector
    {
        STRENGTH,
        PERCEPTION,
        ENDURANCE,
        INTELLIGENCE,
        AGILITY,
        ABERRANCE
    }

    // cache
    Player player;
    AttributePanelManager attributePanelManager;
    AudioSource uiSounds;

    private void Awake()
    {
        player = FindObjectOfType<Player>();
        attributePanelManager = FindObjectOfType<AttributePanelManager>();
        uiSounds = GameObject.FindWithTag("UISound").GetComponent<AudioSource>();
    }

    // Start is called before the first frame update
    void Start()
    {
        pointsAvailable = player.GetComponent<AttributeScores>().TotalAttributePoints - (strength + perception + endurance + intelligence + agility + aberrance);
        pointsAvailableText.text = pointsAvailable.ToString();

        // attribute text
        strengthText.text = strength.ToString();
        perceptionText.text = strength.ToString();
        enduranceText.text = strength.ToString();
        intelligenceText.text = strength.ToString();
        agilityText.text = strength.ToString();
        aberranceText.text = strength.ToString();

        // select starting button
        startingButton.Select();
    }

    public void IncrementOnArrowClick(int attributeSelection)
    {
        bool incremented = false;

        if (pointsAvailable - 1 >= 0)
        {
            switch (attributeSelection)
            {
                case (int)AttributeSelector.STRENGTH:
                    if (strength + 1 <= attributePointMax)
                    {
                        strength++;
                        strengthText.text = strength.ToString();
                        incremented = true;
                    }
                    break;
                case (int)AttributeSelector.PERCEPTION:
                    if (perception + 1 <= attributePointMax)
                    {
                        perception++;
                        perceptionText.text = perception.ToString();
                        incremented = true;
                    }
                    break;
                case (int)AttributeSelector.ENDURANCE:
                    if (endurance + 1 <= attributePointMax)
                    {
                        endurance++;
                        enduranceText.text = endurance.ToString();
                        incremented = true;
                    }
                    break;
                case (int)AttributeSelector.INTELLIGENCE:
                    if (intelligence + 1 <= attributePointMax)
                    {
                        intelligence++;
                        intelligenceText.text = intelligence.ToString();
                        incremented = true;
                    }
                    break;
                case (int)AttributeSelector.AGILITY:
                    if (agility + 1 <= attributePointMax)
                    {
                        agility++;
                        agilityText.text = agility.ToString();
                        incremented = true;
                    }
                    break;
                case (int)AttributeSelector.ABERRANCE:
                    if (aberrance + 1 <= attributePointMax)
                    {
                        aberrance++;
                        aberranceText.text = aberrance.ToString();
                        incremented = true;
                    }
                    break;
            }

            if (incremented)
            {
                pointsAvailable--;
                pointsAvailableText.text = pointsAvailable.ToString();
                uiSounds.PlayOneShot(arrowIncrementSound, arrowIncrementVolume);
            }
        }
    }

    public void DecrementOnArrowClick(int attributeSelection)
    {
        bool decremented = false;

        switch (attributeSelection)
        {
            case (int)AttributeSelector.STRENGTH:
                if (strength - 1 >= 0)
                {
                    strength--;
                    strengthText.text = strength.ToString();
                    decremented = true;
                }
                break;
            case (int)AttributeSelector.PERCEPTION:
                if (perception - 1 >= 0)
                {
                    perception--;
                    perceptionText.text = perception.ToString();
                    decremented = true;
                }
                break;
            case (int)AttributeSelector.ENDURANCE:
                if (endurance - 1 >= 0)
                {
                    endurance--;
                    enduranceText.text = endurance.ToString();
                    decremented = true;
                }
                break;
            case (int)AttributeSelector.INTELLIGENCE:
                if (intelligence - 1 >= 0)
                {
                    intelligence--;
                    intelligenceText.text = intelligence.ToString();
                    decremented = true;
                }
                break;
            case (int)AttributeSelector.AGILITY:
                if (agility - 1 >= 0)
                {
                    agility--;
                    agilityText.text = agility.ToString();
                    decremented = true;
                }
                break;
            case (int)AttributeSelector.ABERRANCE:
                if (aberrance - 1 >= 0)
                {
                    aberrance--;
                    aberranceText.text = aberrance.ToString();
                    decremented = true;
                }
                break;
        }

        if (decremented)
        {
            pointsAvailable++;
            pointsAvailableText.text = pointsAvailable.ToString();
            uiSounds.PlayOneShot(arrowDecrementSound, arrowDecrementVolume);
        }
    }

    // button click
    public void ConfirmValuesAndClosePanel()
    {
        attributePanelManager.SubmitAttributes(strength, perception, endurance, intelligence, agility, aberrance, pointsAvailable);
    }

    // button click
    public void ShowPresetsModal()
    {
        attributePanelManager.DisplayModal(presetListModal, transform);
    }

    public void SelectStartingButton()
    {
        startingButton.Select();
    }
}
