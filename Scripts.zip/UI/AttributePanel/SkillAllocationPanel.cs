using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class SkillAllocationPanel : UIPanel
{
    [Header("Config")]
    [SerializeField] int skillMax = 100;
    [SerializeField] bool tagPanel = true;

    [Header("Text")]
    [SerializeField] TextMeshProUGUI acrobaticsText;
    [SerializeField] TextMeshProUGUI barterText;
    [SerializeField] TextMeshProUGUI bladeText;
    [SerializeField] TextMeshProUGUI bludgeoningText;
    [SerializeField] TextMeshProUGUI enkiismText;
    [SerializeField] TextMeshProUGUI erebancyText;
    [SerializeField] TextMeshProUGUI explosivesText;
    [SerializeField] TextMeshProUGUI gaianismText;
    [SerializeField] TextMeshProUGUI heavyWeaponsText;
    [SerializeField] TextMeshProUGUI hermeticismText;
    [SerializeField] TextMeshProUGUI iktomancyText;
    [SerializeField] TextMeshProUGUI pistolsText;
    [SerializeField] TextMeshProUGUI polearmsText;
    [SerializeField] TextMeshProUGUI reshephismText;
    [SerializeField] TextMeshProUGUI resourcefulnessText;
    [SerializeField] TextMeshProUGUI riflesText;
    [SerializeField] TextMeshProUGUI sleightOfHandText;
    [SerializeField] TextMeshProUGUI throwingText;
    [SerializeField] TextMeshProUGUI tagsText;

    [Header("Tags")]
    [SerializeField] RectTransform tagImageGroup;
    [SerializeField] RectTransform valueGroup;

    [Header("Level")]
    [SerializeField] TextMeshProUGUI levelText;
    [SerializeField] TextMeshProUGUI gossamerText;
    [SerializeField] TextMeshProUGUI costText;
    [SerializeField] TextMeshProUGUI maxHPText;
    [SerializeField] TextMeshProUGUI maxMPText;
    [SerializeField] TextMeshProUGUI maxFPText;
    [SerializeField] Color costTextValidColor;
    [SerializeField] Color costTextUnaffordableColor;
    [SerializeField] Color skillValueTextNormalColor;
    [SerializeField] Color skillValueTextChangedColor;

    // values
    [Header("Values")]
    [SerializeField] int tagsUsed = 0;
    [SerializeField] int totalTagsAvailable;
    [SerializeField] int acrobatics;
    [SerializeField] int barter;
    [SerializeField] int blade;
    [SerializeField] int bludgeoning;
    [SerializeField] int enkiism;
    [SerializeField] int erebancy;
    [SerializeField] int explosives;
    [SerializeField] int gaianism;
    [SerializeField] int heavyWeapons;
    [SerializeField] int hermeticism;
    [SerializeField] int iktomancy;
    [SerializeField] int pistols;
    [SerializeField] int polearms;
    [SerializeField] int reshephism;
    [SerializeField] int resourcefulness;
    [SerializeField] int rifles;
    [SerializeField] int sleightOfHand;
    [SerializeField] int throwing;
    [SerializeField] int tags;

    [Header("Starting Values")]
    [SerializeField] int startingAcrobatics;
    [SerializeField] int startingBarter;
    [SerializeField] int startingBlade;
    [SerializeField] int startingBludgeoning;
    [SerializeField] int startingEnkiism;
    [SerializeField] int startingErebancy;
    [SerializeField] int startingExplosives;
    [SerializeField] int startingGaianism;
    [SerializeField] int startingHeavyWeapons;
    [SerializeField] int startingHermeticism;
    [SerializeField] int startingIktomancy;
    [SerializeField] int startingPistols;
    [SerializeField] int startingPolearms;
    [SerializeField] int startingReshephism;
    [SerializeField] int startingResourcefulness;
    [SerializeField] int startingRifles;
    [SerializeField] int startingSleightOfHand;
    [SerializeField] int startingThrowing;

    [Header("Sound")]
    [SerializeField] AudioClip tagSound;
    [SerializeField] [Range(0, 1)] float tagVolume = .5f;
    [SerializeField] AudioClip untagSound;
    [SerializeField] [Range(0, 1)] float untagVolume = .5f;

    [Header("Modals")]
    [SerializeField] GameObject savePresetForm;

    [Header("Status Messages")]
    [SerializeField] GameObject menuStatusPanelTemplate;

    [Header("Navigation")]
    [SerializeField] Button startingButton;

    bool[] proficiencies = new bool[18];
    int startingLevel;
    float startingMaxHP;
    float startingMaxMP;
    float startingMaxFP;
    int level;
    float maxHP;
    float maxMP;
    float maxFP;
    int levelUpCost;

    // cache
    Player player;
    Health playerHealth;
    Magic playerMagic;
    Focus playerFocus;
    AttributeScores playerAttributes;
    AttributePanelManager attributePanelManager;
    Crypto playerCurrency;
    AudioSource uiSounds;

    public bool[] Proficiencies { get => proficiencies; set => proficiencies = value; }

    private void Awake()
    {
        player = FindObjectOfType<Player>();
        playerHealth = player.GetComponent<Health>();
        playerMagic = player.GetComponent<Magic>();
        playerFocus = player.GetComponent<Focus>();
        playerAttributes = player.GetComponent<AttributeScores>();
        playerCurrency = player.GetComponent<Crypto>();
        attributePanelManager = FindObjectOfType<AttributePanelManager>();
        uiSounds = GameObject.FindWithTag("UISound").GetComponent<AudioSource>();
    }

    // Start is called before the first frame update
    void Start()
    {
        SetStartingSkillValues(playerAttributes);

        if (tagPanel)
        {
            totalTagsAvailable = playerAttributes.totalTagsAvailable;
            tagsText.text = "Proficiencies allocated: " + tagsUsed.ToString() + "/" + totalTagsAvailable.ToString();
        }
        else
        {
            startingLevel = playerAttributes.level;
            level = playerAttributes.level;

            startingMaxHP = playerHealth.MaxHealth.GetCurrentValue();
            startingMaxMP = playerMagic.MaxMagicPoints;
            startingMaxFP = playerFocus.MaxFocusPoints;

            maxHP = playerHealth.MaxHealth.GetCurrentValue();
            maxMP = playerMagic.MaxMagicPoints;
            maxFP = playerFocus.MaxFocusPoints;

            levelText.text = playerAttributes.level.ToString();
            gossamerText.text = playerCurrency.CurrentCurrency.ToString();
            levelUpCost = 0;
            costText.text = levelUpCost.ToString();
            maxHPText.text = playerHealth.MaxHealth.ToString();
            maxMPText.text = maxMP.ToString();
            maxFPText.text = maxFP.ToString();

            if (playerCurrency.CurrentCurrency < levelUpCost)
            {
                costText.color = costTextUnaffordableColor;
            }

            LoadProficiencies();
        }

        // select starting button
        startingButton.Select();
    }

    public void SetStartingSkillValues(AttributeScores attributeScores)
    {
        acrobatics = attributeScores.acrobatics;
        barter = attributeScores.barter;
        blade = attributeScores.blade;
        bludgeoning = attributeScores.bludgeoning;
        enkiism = attributeScores.enkiism;
        erebancy = attributeScores.erebancy;
        explosives = attributeScores.explosives;
        gaianism = attributeScores.gaianism;
        heavyWeapons = attributeScores.heavyWeapons;
        hermeticism = attributeScores.hermeticism;
        iktomancy = attributeScores.iktomancy;
        pistols = attributeScores.pistols;
        polearms = attributeScores.polearms;
        reshephism = attributeScores.reshephism;
        resourcefulness = attributeScores.resourcefulness;
        rifles = attributeScores.rifles;
        sleightOfHand = attributeScores.sleightOfHand;
        throwing = attributeScores.throwing;

        startingAcrobatics = attributeScores.acrobatics;
        startingBarter = attributeScores.barter;
        startingBlade = attributeScores.blade;
        startingBludgeoning = attributeScores.bludgeoning;
        startingEnkiism = attributeScores.enkiism;
        startingErebancy = attributeScores.erebancy;
        startingExplosives = attributeScores.explosives;
        startingGaianism = attributeScores.gaianism;
        startingHeavyWeapons = attributeScores.heavyWeapons;
        startingHermeticism = attributeScores.hermeticism;
        startingIktomancy = attributeScores.iktomancy;
        startingPistols = attributeScores.pistols;
        startingPolearms = attributeScores.polearms;
        startingReshephism = attributeScores.reshephism;
        startingResourcefulness = attributeScores.resourcefulness;
        startingRifles = attributeScores.rifles;
        startingSleightOfHand = attributeScores.sleightOfHand;
        startingThrowing = attributeScores.throwing;

        acrobaticsText.text = acrobatics.ToString();
        barterText.text = barter.ToString();
        bladeText.text = blade.ToString();
        bludgeoningText.text = bludgeoning.ToString();
        enkiismText.text = enkiism.ToString();
        erebancyText.text = erebancy.ToString();
        explosivesText.text = explosives.ToString();
        gaianismText.text = gaianism.ToString();
        heavyWeaponsText.text = heavyWeapons.ToString();
        hermeticismText.text = hermeticism.ToString();
        iktomancyText.text = iktomancy.ToString();
        pistolsText.text = pistols.ToString();
        polearmsText.text = polearms.ToString();
        reshephismText.text = reshephism.ToString();
        resourcefulnessText.text = resourcefulness.ToString();
        riflesText.text = rifles.ToString();
        sleightOfHandText.text = sleightOfHand.ToString();
        throwingText.text = throwing.ToString();
    }

    void LoadProficiencies()
    {
        // load in proficiencies
        for (int i = 0; i < playerAttributes.Proficiencies.Length; i++)
        {
            if (playerAttributes.Proficiencies[i])
            {
                Proficiencies[i] = true;
            }
        }

        // visuals
        for (int i = 0; i < Proficiencies.Length; i++)
        {
            if (Proficiencies[i])
            {
                tagImageGroup.GetChild(i).GetComponent<Image>().enabled = true;
            }
        }
    }

    // called by button click
    public void TagSkillProficient(int skillIndex)
    {
        // toggle image at this skill's index
        Image tagSquare =  tagImageGroup.GetChild(skillIndex).GetComponent<Image>();
        tagSquare.enabled = !tagSquare.enabled;

        int tagBonus = attributePanelManager.attributes.tagBonus;

        // adjust tags remaining
        if (tagSquare.enabled)
        {
            tagsUsed++;
        }
        else
        {
            tagsUsed--;
            tagBonus *= -1;
        }

        bool tagAllowed = true;

        if (tagsUsed > totalTagsAvailable)
        {
            // unset
            tagSquare.enabled = false;
            tagAllowed = false;
            tagsUsed = totalTagsAvailable;
        }

        tagsText.text = "Proficiencies allocated: " + tagsUsed.ToString() + "/" + totalTagsAvailable.ToString();

        if (tagAllowed)
        {
            // increase value of skill
            switch ((AttributeScores.Skills)skillIndex)
            {
                case AttributeScores.Skills.ACROBATICS:
                    acrobatics += tagBonus;
                    acrobaticsText.text = acrobatics.ToString();
                    break;
                case AttributeScores.Skills.BARTER:
                    barter += tagBonus;
                    barterText.text = barter.ToString();
                    break;
                case AttributeScores.Skills.BLADE:
                    blade += tagBonus;
                    bladeText.text = blade.ToString();
                    break;
                case AttributeScores.Skills.BLUDGEONING:
                    bludgeoning += tagBonus;
                    bludgeoningText.text = bludgeoning.ToString();
                    break;
                case AttributeScores.Skills.ENKIISM:
                    enkiism += tagBonus;
                    enkiismText.text = enkiism.ToString();
                    break;
                case AttributeScores.Skills.EREBANCY:
                    erebancy += tagBonus;
                    erebancyText.text = erebancy.ToString();
                    break;
                case AttributeScores.Skills.EXPLOSIVES:
                    explosives += tagBonus;
                    explosivesText.text = explosives.ToString();
                    break;
                case AttributeScores.Skills.GAIANISM:
                    gaianism += tagBonus;
                    gaianismText.text = gaianism.ToString();
                    break;
                case AttributeScores.Skills.HEAVY_WEAPONS:
                    heavyWeapons += tagBonus;
                    heavyWeaponsText.text = heavyWeapons.ToString();
                    break;
                case AttributeScores.Skills.HERMETICISM:
                    hermeticism += tagBonus;
                    hermeticismText.text = hermeticism.ToString();
                    break;
                case AttributeScores.Skills.IKTOMANCY:
                    iktomancy += tagBonus;
                    iktomancyText.text = iktomancy.ToString();
                    break;
                case AttributeScores.Skills.PISTOLS:
                    pistols += tagBonus;
                    pistolsText.text = pistols.ToString();
                    break;
                case AttributeScores.Skills.POLEARMS:
                    polearms += tagBonus;
                    polearmsText.text = polearms.ToString();
                    break;
                case AttributeScores.Skills.RESHEPHISM:
                    reshephism += tagBonus;
                    reshephismText.text = reshephism.ToString();
                    break;
                case AttributeScores.Skills.RESOURCEFULNESS:
                    resourcefulness += tagBonus;
                    resourcefulnessText.text = resourcefulness.ToString();
                    break;
                case AttributeScores.Skills.RIFLES:
                    rifles += tagBonus;
                    riflesText.text = rifles.ToString();
                    break;
                case AttributeScores.Skills.SLEIGHT_OF_HAND:
                    sleightOfHand += tagBonus;
                    sleightOfHandText.text = sleightOfHand.ToString();
                    break;
                case AttributeScores.Skills.THROWING:
                    throwing += tagBonus;
                    throwingText.text = throwing.ToString();
                    break;
            }

            Proficiencies[skillIndex] = !Proficiencies[skillIndex];
        }
    }

    public void IncrementSkillOnArrowClick(int skillNum)
    {
        AttributeScores.Skills skill = (AttributeScores.Skills)skillNum;

        bool incremented = false;

        switch (skill)
        {
            case AttributeScores.Skills.ACROBATICS:
                if (acrobatics + 1 <= skillMax)
                {
                    if (Proficiencies[skillNum])
                    {
                        acrobatics += 2;

                        if (acrobatics > skillMax)
                            acrobatics = skillMax;
                    }
                    else
                    {
                        acrobatics++;
                    }

                    ChangeSkillValueText(acrobaticsText, acrobatics, startingAcrobatics);
                    incremented = true;
                }
                break;
            case AttributeScores.Skills.BARTER:
                if (barter + 1 <= skillMax)
                {
                    if (Proficiencies[skillNum])
                    {
                        barter += 2;

                        if (barter > skillMax)
                            barter = skillMax;
                    }
                    else
                    {
                        barter++;
                    }

                    ChangeSkillValueText(barterText, barter, startingBarter);
                    incremented = true;
                }
                break;
            case AttributeScores.Skills.BLADE:
                if (blade + 1 <= skillMax)
                {
                    if (Proficiencies[skillNum])
                    {
                        blade += 2;
                        if (blade > skillMax)
                            blade = skillMax;
                    }
                    else
                    {
                        blade++;
                    }
                    ChangeSkillValueText(bladeText, blade, startingBlade);
                    incremented = true;
                }
                break;
            case AttributeScores.Skills.BLUDGEONING:
                if (bludgeoning + 1 <= skillMax)
                {
                    if (Proficiencies[skillNum])
                    {
                        bludgeoning += 2;
                        if (bludgeoning > skillMax)
                            bludgeoning = skillMax;
                    }
                    else
                    {
                        bludgeoning++;
                    }
                    ChangeSkillValueText(bludgeoningText, bludgeoning, startingBludgeoning);
                    incremented = true;
                }
                break;
            case AttributeScores.Skills.ENKIISM:
                if (enkiism + 1 <= skillMax)
                {
                    if (Proficiencies[skillNum])
                    {
                        enkiism += 2;
                        if (enkiism > skillMax)
                            enkiism = skillMax;
                    }
                    else
                    {
                        enkiism++;
                    }
                    ChangeSkillValueText(enkiismText, enkiism, startingEnkiism);
                    incremented = true;
                }
                break;
            case AttributeScores.Skills.EREBANCY:
                if (erebancy + 1 <= skillMax)
                {
                    if (Proficiencies[skillNum])
                    {
                        erebancy += 2;
                        if (erebancy > skillMax)
                            erebancy = skillMax;
                    }
                    else
                    {
                        erebancy++;
                    }
                    ChangeSkillValueText(erebancyText, erebancy, startingErebancy);
                    incremented = true;
                }
                break;
            case AttributeScores.Skills.EXPLOSIVES:
                if (explosives + 1 <= skillMax)
                {
                    if (Proficiencies[skillNum])
                    {
                        explosives += 2;
                        if (explosives > skillMax)
                            explosives = skillMax;
                    }
                    else
                    {
                        explosives++;
                    }
                    ChangeSkillValueText(explosivesText, explosives, startingExplosives);
                    incremented = true;
                }
                break;
            case AttributeScores.Skills.GAIANISM:
                if (gaianism + 1 <= skillMax)
                {
                    if (Proficiencies[skillNum])
                    {
                        gaianism += 2;
                        if (gaianism > skillMax)
                            gaianism = skillMax;
                    }
                    else
                    {
                        gaianism++;
                    }
                    ChangeSkillValueText(gaianismText, gaianism, startingGaianism);
                    incremented = true;
                }
                break;
            case AttributeScores.Skills.HEAVY_WEAPONS:
                if (heavyWeapons + 1 <= skillMax)
                {
                    if (Proficiencies[skillNum])
                    {
                        heavyWeapons += 2;
                        if (heavyWeapons > skillMax)
                            heavyWeapons = skillMax;
                    }
                    else
                    {
                        heavyWeapons++;
                    }
                    ChangeSkillValueText(heavyWeaponsText, heavyWeapons, startingHeavyWeapons);
                    incremented = true;
                }
                break;
            case AttributeScores.Skills.HERMETICISM:
                if (hermeticism + 1 <= skillMax)
                {
                    if (Proficiencies[skillNum])
                    {
                        hermeticism += 2;
                        if (hermeticism > skillMax)
                            hermeticism = skillMax;
                    }
                    else
                    {
                        hermeticism++;
                    }
                    ChangeSkillValueText(hermeticismText, hermeticism, startingHermeticism);
                    incremented = true;
                }
                break;
            case AttributeScores.Skills.IKTOMANCY:
                if (iktomancy + 1 <= skillMax)
                {
                    if (Proficiencies[skillNum])
                    {
                        iktomancy += 2;
                        if (iktomancy > skillMax)
                            iktomancy = skillMax;
                    }
                    else
                    {
                        iktomancy++;
                    }
                    ChangeSkillValueText(iktomancyText, iktomancy, startingIktomancy);
                    incremented = true;
                }
                break;
            case AttributeScores.Skills.PISTOLS:
                if (pistols + 1 <= skillMax)
                {
                    if (Proficiencies[skillNum])
                    {
                        pistols += 2;
                        if (pistols > skillMax)
                            pistols = skillMax;
                    }
                    else
                    {
                        pistols++;
                    }
                    ChangeSkillValueText(pistolsText, pistols, startingPistols);
                    incremented = true;
                }
                break;
            case AttributeScores.Skills.POLEARMS:
                if (polearms + 1 <= skillMax)
                {
                    if (Proficiencies[skillNum])
                    {
                        polearms += 2;
                        if (polearms > skillMax)
                            polearms = skillMax;
                    }
                    else
                    {
                        polearms++;
                    }
                    ChangeSkillValueText(polearmsText, polearms, startingPolearms);
                    incremented = true;
                }
                break;
            case AttributeScores.Skills.RESHEPHISM:
                if (reshephism + 1 <= skillMax)
                {
                    if (Proficiencies[skillNum])
                    {
                        reshephism += 2;
                        if (reshephism > skillMax)
                            reshephism = skillMax;
                    }
                    else
                    {
                        reshephism++;
                    }
                    ChangeSkillValueText(reshephismText, reshephism, startingReshephism);
                    incremented = true;
                }
                break;
            case AttributeScores.Skills.RESOURCEFULNESS:
                if (resourcefulness + 1 <= skillMax)
                {
                    if (Proficiencies[skillNum])
                    {
                        resourcefulness += 2;
                        if (resourcefulness > skillMax)
                            resourcefulness = skillMax;
                    }
                    else
                    {
                        resourcefulness++;
                    }
                    ChangeSkillValueText(resourcefulnessText, resourcefulness, startingResourcefulness);
                    incremented = true;
                }
                break;
            case AttributeScores.Skills.RIFLES:
                if (rifles + 1 <= skillMax)
                {
                    if (Proficiencies[skillNum])
                    {
                        rifles += 2;
                        if (rifles > skillMax)
                            rifles = skillMax;
                    }
                    else
                    {
                        rifles++;
                    }
                    ChangeSkillValueText(riflesText, rifles, startingRifles);
                    incremented = true;
                }
                break;
            case AttributeScores.Skills.SLEIGHT_OF_HAND:
                if (sleightOfHand + 1 <= skillMax)
                {
                    if (Proficiencies[skillNum])
                    {
                        sleightOfHand += 2;
                        if (sleightOfHand > skillMax)
                            sleightOfHand = skillMax;
                    }
                    else
                    {
                        sleightOfHand++;
                    }
                    ChangeSkillValueText(sleightOfHandText, sleightOfHand, startingSleightOfHand);
                    incremented = true;
                }
                break;
            case AttributeScores.Skills.THROWING:
                if (throwing + 1 <= skillMax)
                {
                    if (Proficiencies[skillNum])
                    {
                        throwing += 2;
                        if (throwing > skillMax)
                            throwing = skillMax;
                    }
                    else
                    {
                        throwing++;
                    }
                    ChangeSkillValueText(throwingText, throwing, startingThrowing);
                    incremented = true;
                }
                break;
        }

        if (incremented)
        {
            // increase level by 1
            AdjustLevel(1);
        }
    }

    public void DecrementSkillOnArrowClick(int skillNum)
    {
        AttributeScores.Skills skill = (AttributeScores.Skills)skillNum;

        bool decremented = false;

        switch (skill)
        {
            case AttributeScores.Skills.ACROBATICS:
                if (acrobatics - 1 >= startingAcrobatics && level - 1 >= startingLevel)
                {
                    if (Proficiencies[skillNum])
                    {
                        acrobatics -= 2;
                        if (acrobatics < startingAcrobatics)
                            acrobatics = startingAcrobatics;
                    }
                    else
                    {
                        acrobatics--;
                    }
                    ChangeSkillValueText(acrobaticsText, acrobatics, startingAcrobatics);
                    decremented = true;
                }
                break;
            case AttributeScores.Skills.BARTER:
                if (barter - 1 >= startingBarter && level - 1 >= startingLevel)
                {
                    if (Proficiencies[skillNum])
                    {
                        barter -= 2;
                        if (barter < startingBarter)
                            barter = startingBarter;
                    }
                    else
                    {
                        barter--;
                    }
                    ChangeSkillValueText(barterText, barter, startingBarter);
                    decremented = true;
                }
                break;
            case AttributeScores.Skills.BLADE:
                if (blade - 1 >= startingBlade && level - 1 >= startingLevel)
                {
                    if (Proficiencies[skillNum])
                    {
                        blade -= 2;
                        if (blade < startingBlade)
                            blade = startingBlade;
                    }
                    else
                    {
                        blade--;
                    }
                    ChangeSkillValueText(bladeText, blade, startingBlade);
                    decremented = true;
                }
                break;
            case AttributeScores.Skills.BLUDGEONING:
                if (bludgeoning - 1 >= startingBludgeoning && level - 1 >= startingLevel)
                {
                    if (Proficiencies[skillNum])
                    {
                        bludgeoning -= 2;
                        if (bludgeoning < startingBludgeoning)
                            bludgeoning = startingBludgeoning;
                    }
                    else
                    {
                        bludgeoning--;
                    }
                    ChangeSkillValueText(bludgeoningText, bludgeoning, startingBludgeoning);
                    decremented = true;
                }
                break;
            case AttributeScores.Skills.ENKIISM:
                if (enkiism - 1 >= startingEnkiism && level - 1 >= startingLevel)
                {
                    if (Proficiencies[skillNum])
                    {
                        enkiism -= 2;
                        if (enkiism < startingEnkiism)
                            enkiism = startingEnkiism;
                    }
                    else
                    {
                        enkiism--;
                    }
                    ChangeSkillValueText(enkiismText, enkiism, startingEnkiism);
                    decremented = true;
                }
                break;
            case AttributeScores.Skills.EREBANCY:
                if (erebancy - 1 >= startingErebancy && level - 1 >= startingLevel)
                {
                    if (Proficiencies[skillNum])
                    {
                        erebancy -= 2;
                        if (erebancy < startingErebancy)
                            erebancy = startingErebancy;
                    }
                    else
                    {
                        erebancy--;
                    }
                    ChangeSkillValueText(erebancyText, erebancy, startingErebancy);
                    decremented = true;
                }
                break;
            case AttributeScores.Skills.EXPLOSIVES:
                if (explosives - 1 >= startingExplosives && level - 1 >= startingLevel)
                {
                    if (Proficiencies[skillNum])
                    {
                        explosives -= 2;
                        if (explosives < startingExplosives)
                            explosives = startingExplosives;
                    }
                    else
                    {
                        explosives--;
                    }
                    ChangeSkillValueText(explosivesText, explosives, startingExplosives);
                    decremented = true;
                }
                break;
            case AttributeScores.Skills.GAIANISM:
                if (gaianism - 1 >= startingGaianism && level - 1 >= startingLevel)
                {
                    if (Proficiencies[skillNum])
                    {
                        gaianism -= 2;
                        if (gaianism < startingGaianism)
                            gaianism = startingGaianism;
                    }
                    else
                    {
                        gaianism--;
                    }
                    ChangeSkillValueText(gaianismText, gaianism, startingGaianism);
                    decremented = true;
                }
                break;
            case AttributeScores.Skills.HEAVY_WEAPONS:
                if (heavyWeapons - 1 >= startingHeavyWeapons && level - 1 >= startingLevel)
                {
                    if (Proficiencies[skillNum])
                    {
                        heavyWeapons -= 2;
                        if (heavyWeapons < startingHeavyWeapons)
                            heavyWeapons = startingHeavyWeapons;
                    }
                    else
                    {
                        heavyWeapons--;
                    }
                    ChangeSkillValueText(heavyWeaponsText, heavyWeapons, startingHeavyWeapons);
                    decremented = true;
                }
                break;
            case AttributeScores.Skills.HERMETICISM:
                if (hermeticism - 1 >= startingHermeticism && level - 1 >= startingLevel)
                {
                    if (Proficiencies[skillNum])
                    {
                        hermeticism -= 2;
                        if (hermeticism < startingHermeticism)
                            hermeticism = startingHermeticism;
                    }
                    else
                    {
                        hermeticism--;
                    }
                    ChangeSkillValueText(hermeticismText, hermeticism, startingHermeticism);
                    decremented = true;
                }
                break;
            case AttributeScores.Skills.IKTOMANCY:
                if (iktomancy - 1 >= startingIktomancy && level - 1 >= startingLevel)
                {
                    if (Proficiencies[skillNum])
                    {
                        iktomancy -= 2;
                        if (iktomancy < startingIktomancy)
                            iktomancy = startingIktomancy;
                    }
                    else
                    {
                        iktomancy--;
                    }
                    ChangeSkillValueText(iktomancyText, iktomancy, startingIktomancy);
                    decremented = true;
                }
                break;
            case AttributeScores.Skills.PISTOLS:
                if (pistols - 1 >= startingPistols && level - 1 >= startingLevel)
                {
                    if (Proficiencies[skillNum])
                    {
                        pistols -= 2;
                        if (pistols < startingPistols)
                            pistols = startingPistols;
                    }
                    else
                    {
                        pistols--;
                    }
                    ChangeSkillValueText(pistolsText, pistols, startingPistols);
                    decremented = true;
                }
                break;
            case AttributeScores.Skills.POLEARMS:
                if (polearms - 1 >= startingPolearms && level - 1 >= startingLevel)
                {
                    if (Proficiencies[skillNum])
                    {
                        polearms -= 2;
                        if (polearms < startingPolearms)
                            polearms = startingPolearms;
                    }
                    else
                    {
                        polearms--;
                    }
                    ChangeSkillValueText(polearmsText, polearms, startingPolearms);
                    decremented = true;
                }
                break;
            case AttributeScores.Skills.RESHEPHISM:
                if (reshephism - 1 >= startingReshephism && level - 1 >= startingLevel)
                {
                    if (Proficiencies[skillNum])
                    {
                        reshephism -= 2;
                        if (reshephism < startingReshephism)
                            reshephism = startingReshephism;
                    }
                    else
                    {
                        reshephism--;
                    }
                    ChangeSkillValueText(reshephismText, reshephism, startingReshephism);
                    decremented = true;
                }
                break;
            case AttributeScores.Skills.RESOURCEFULNESS:
                if (resourcefulness - 1 >= startingResourcefulness && level - 1 >= startingLevel)
                {
                    if (Proficiencies[skillNum])
                    {
                        resourcefulness -= 2;
                        if (resourcefulness < startingResourcefulness)
                            resourcefulness = startingResourcefulness;
                    }
                    else
                    {
                        resourcefulness--;
                    }
                    ChangeSkillValueText(resourcefulnessText, resourcefulness, startingResourcefulness);
                    decremented = true;
                }
                break;
            case AttributeScores.Skills.RIFLES:
                if (rifles - 1 >= startingRifles && level - 1 >= startingLevel)
                {
                    if (Proficiencies[skillNum])
                    {
                        rifles -= 2;
                        if (rifles < startingRifles)
                            rifles = startingRifles;
                    }
                    else
                    {
                        rifles--;
                    }
                    ChangeSkillValueText(riflesText, rifles, startingRifles);
                    decremented = true;
                }
                break;
            case AttributeScores.Skills.SLEIGHT_OF_HAND:
                if (sleightOfHand - 1 >= startingSleightOfHand && level - 1 >= startingLevel)
                {
                    if (Proficiencies[skillNum])
                    {
                        sleightOfHand -= 2;
                        if (sleightOfHand < startingSleightOfHand)
                            sleightOfHand = startingSleightOfHand;
                    }
                    else
                    {
                        sleightOfHand--;
                    }
                    ChangeSkillValueText(sleightOfHandText, sleightOfHand, startingSleightOfHand);
                    decremented = true;
                }
                break;
            case AttributeScores.Skills.THROWING:
                if (throwing - 1 >= startingThrowing && level - 1 >= startingLevel)
                {
                    if (Proficiencies[skillNum])
                    {
                        throwing -= 2;
                        if (throwing < startingThrowing)
                            throwing = startingThrowing;
                    }
                    else
                    {
                        throwing--;
                    }
                    ChangeSkillValueText(throwingText, throwing, startingThrowing);
                    decremented = true;
                }
                break;
        }

        if (decremented)
        {
            // decrease level by 1
            AdjustLevel(-1);
        }
    }

    void AdjustLevel(int val)
    {
        int oldLevel = level;

        // adjust values
        level += val;
        maxHP += val * playerAttributes.maxHitPointsPerLevel;
        maxMP += val * playerAttributes.maxMagicPointsPerLevel;
        maxFP += val * playerAttributes.maxFocusPointsPerLevel;

        // adjust cost
        if (level > oldLevel)
        {
            // level increased, add to cost
            levelUpCost += AttributeScores.GetLevelCost(level, playerAttributes.Intelligence);
        }
        else
        {
            // level decreased, remove from cost
            levelUpCost -= AttributeScores.GetLevelCost(oldLevel, playerAttributes.Intelligence);
        }

        // set text
        ChangeSkillValueText(levelText, level, startingLevel);
        ChangeSkillValueText(maxHPText, (int)maxHP, (int)startingMaxHP);
        ChangeSkillValueText(maxMPText, (int)maxMP, (int)startingMaxMP);
        ChangeSkillValueText(maxFPText, (int)maxFP, (int)startingMaxFP);
        costText.text = levelUpCost.ToString();

        if (playerCurrency.CurrentCurrency < levelUpCost)
        {
            costText.color = costTextUnaffordableColor;
        }
        else
        {
            costText.color = costTextValidColor;
        }
    }

    void ChangeSkillValueText(TextMeshProUGUI valueText, int value, int startingValue)
    {
        valueText.text = value.ToString();

        if (value == startingValue)
        {
            valueText.color = skillValueTextNormalColor;
        }
        else
        {
            valueText.color = skillValueTextChangedColor;
        }
    }

    public void ConfirmValuesAndClosePanel()
    {
        if (tagPanel)
        {
            attributePanelManager.SubmitSkills(Proficiencies);
            Destroy(gameObject);
        }
        else
        {
            if (playerCurrency.CurrentCurrency >= levelUpCost)
            {
                attributePanelManager.SubmitSkills(level, levelUpCost, acrobatics, barter, blade, bludgeoning, enkiism, erebancy, explosives, gaianism, heavyWeapons, hermeticism, iktomancy, pistols, polearms, reshephism, resourcefulness, rifles, sleightOfHand, throwing);
            }
            else
            {
                // spawn message stating that player cannot afford transaction
                var message = Instantiate(menuStatusPanelTemplate, transform);
                message.GetComponent<MenuStatusPanel>().SetStatusMessage("Not enough gossamer.");
            }
        }
    }

    public void CancelLevelUp()
    {
        attributePanelManager.CancelLevelUp();
    }

    public void CancelTaggingPanel()
    {
        Destroy(gameObject);
    }

    // button press
    public void ShowSavePresetForm()
    {
        attributePanelManager.DisplayModal(savePresetForm, transform);
    }
}
