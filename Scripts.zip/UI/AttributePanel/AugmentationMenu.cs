using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class AugmentationMenu : MonoBehaviour
{
    [SerializeField] Transform augmentationList;
    [SerializeField] GameObject augmentationSelectionTemplate;
    [SerializeField] TextMeshProUGUI descriptionText;
    [SerializeField] TextMeshProUGUI augmentationPointsText;
    [SerializeField] TextMeshProUGUI levelRequirementText;
    [SerializeField] TextMeshProUGUI attributeRequirementsText;
    [SerializeField] TextMeshProUGUI skillRequirementsText;
    [SerializeField] TextMeshProUGUI costText;

    [Header("Colors")]
    [SerializeField] Color positivePointsColor;
    [SerializeField] Color negativePointsColor;

    // cached references
    Player player;
    Augmentations playerAugmentations;
    ItemDatabase database;
    AttributePanelManager attributePanelManager;

    int availableAugmentationPoints;

    List<Augmentation> purchasableAugmentations = new List<Augmentation>();
    List<Augmentation> lockedAugmentations = new List<Augmentation>();

    HashSet<Augmentation> selectedForPurchase = new HashSet<Augmentation>();

    public int AvailableAugmentationPoints 
    {
        get => availableAugmentationPoints;
        set
        {
            availableAugmentationPoints = value;

            // update text
            UpdateAugmentationPointsText();
        }
    }

    private void Awake()
    {
        player = FindObjectOfType<Player>();
        playerAugmentations = player.GetComponent<Augmentations>();
        database = FindObjectOfType<ItemDatabase>();
        attributePanelManager = FindObjectOfType<AttributePanelManager>();
    }

    private void Start()
    {
        AvailableAugmentationPoints = playerAugmentations.AugmentationPoints;

        LoadAugmentationsIntoList();
    }

    void LoadAugmentationsIntoList()
    {
        // iterate through list of augmentations
        foreach (Augmentation augmentation in database.augmentationList)
        {
            // only add if player doesn't already have it
            if (!playerAugmentations.AugmentationList.Contains(augmentation))
            {
                // check if player could purchase this augmentation
                if (playerAugmentations.CheckIfPurchasable(augmentation))
                {
                    // place in purchasable list
                    purchasableAugmentations.Add(augmentation);
                }
                else
                {
                    // place in not purchaseable list
                    lockedAugmentations.Add(augmentation);
                }
            }
        }

        // sort each list alphabetically
        SortListsByNameAscending();

        // instantiate purchasable augmentations
        foreach (Augmentation augmentation in purchasableAugmentations)
        {
            GameObject newAugmentationSelectionObject = Instantiate(augmentationSelectionTemplate, augmentationList);
            AugmentationSelection newAugmentationSelection = newAugmentationSelectionObject.GetComponent<AugmentationSelection>();

            newAugmentationSelection.InitializeAugmentationSelection(this, augmentation, true, descriptionText, levelRequirementText, attributeRequirementsText, skillRequirementsText, costText);
        }

        // instantiate locked augmentations
        foreach (Augmentation augmentation in lockedAugmentations)
        {
            GameObject newAugmentationSelectionObject = Instantiate(augmentationSelectionTemplate, augmentationList);
            AugmentationSelection newAugmentationSelection = newAugmentationSelectionObject.GetComponent<AugmentationSelection>();

            newAugmentationSelection.InitializeAugmentationSelection(this, augmentation, false, descriptionText, levelRequirementText, attributeRequirementsText, skillRequirementsText, costText);
        }
    }

    public void SelectAugmentationForPurchase(Augmentation augmentation)
    {
        selectedForPurchase.Add(augmentation);

        AvailableAugmentationPoints -= augmentation.AugmentationPointCost;
    }

    public void DeselectAugmentationForPurchase(Augmentation augmentation)
    {
        selectedForPurchase.Remove(augmentation);

        AvailableAugmentationPoints += augmentation.AugmentationPointCost;
    }

    void UpdateAugmentationPointsText()
    {
        augmentationPointsText.text = "Augmentation Points: " + AvailableAugmentationPoints.ToString();

        // change color
        if (AvailableAugmentationPoints >= 0)
        {
            augmentationPointsText.color = positivePointsColor;
        }
        else
        {
            augmentationPointsText.color = negativePointsColor;
        }
    }

    private void SortListsByNameAscending()
    {
        purchasableAugmentations.Sort((x, y) => x.AugmentationName.CompareTo(y.AugmentationName));
        lockedAugmentations.Sort((x, y) => x.AugmentationName.CompareTo(y.AugmentationName));
    }

    public void SubmitAugmentations()
    {
        if (AvailableAugmentationPoints >= 0)
        {
            // add all selected augmentations to the player's augmentations
            foreach (Augmentation augmentation in selectedForPurchase)
            {
                playerAugmentations.AddAugmentation(augmentation);
                playerAugmentations.AugmentationPoints = availableAugmentationPoints;
            }

            CloseMenu();
        }
        else
        {
            // play bad sound
        }
    }

    public void CloseMenu()
    {
        attributePanelManager.CloseAugmentationsMenu();
    }
}
