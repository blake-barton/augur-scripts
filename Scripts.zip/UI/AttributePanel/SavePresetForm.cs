using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class SavePresetForm : UIPanel
{
    [Header("Attribute Fields")]
    [SerializeField] TextMeshProUGUI strengthValue;
    [SerializeField] TextMeshProUGUI perceptionValue;
    [SerializeField] TextMeshProUGUI enduranceValue;
    [SerializeField] TextMeshProUGUI intelligenceValue;
    [SerializeField] TextMeshProUGUI agilityValue;
    [SerializeField] TextMeshProUGUI aberranceValue;

    [Header("Proficiency Fields")]
    [SerializeField] TextMeshProUGUI prof1;
    [SerializeField] TextMeshProUGUI prof2;
    [SerializeField] TextMeshProUGUI prof3;

    [Header("Error Messages")]
    [SerializeField] GameObject nameInputError;

    [SerializeField] string presetNameInput;

    // cached references
    AttributeScores playerAttributes;
    SkillAllocationPanel skillAllocationPanel;

    List<int> proficiencies = new List<int>();

    private void Awake()
    {
        playerAttributes = FindObjectOfType<Player>().GetComponent<AttributeScores>();
        skillAllocationPanel = FindObjectOfType<SkillAllocationPanel>();
    }

    private void Start()
    {
        LoadAttributeScores();
        LoadProficiencies();
    }

    private void LoadProficiencies()
    {
        int proficienciesPrinted = 0;

        // get proficiencies from SkillAllocationPanel
        for (int i = 0; i < skillAllocationPanel.Proficiencies.Length; i++)
        {
            if (skillAllocationPanel.Proficiencies[i])
            {
                switch (proficienciesPrinted)
                {
                    case 0:
                        prof1.text = AttributeScores.GetSkillAsString((AttributeScores.Skills)i);
                        break;
                    case 1:
                        prof2.text = AttributeScores.GetSkillAsString((AttributeScores.Skills)i);
                        break;
                    case 2:
                        prof3.text = AttributeScores.GetSkillAsString((AttributeScores.Skills)i);
                        break;
                }

                proficiencies.Add(i);
                proficienciesPrinted++;
            }
        }
    }

    private void LoadAttributeScores()
    {
        // get attribute scores from player attributes
        strengthValue.text = playerAttributes.Strength.ToString();
        perceptionValue.text = playerAttributes.Perception.ToString();
        enduranceValue.text = playerAttributes.Endurance.ToString();
        intelligenceValue.text = playerAttributes.Intelligence.ToString();
        agilityValue.text = playerAttributes.Agility.ToString();
        aberranceValue.text = playerAttributes.Aberrance.ToString();
    }

    public void ReadStringInput(string input)
    {
        presetNameInput = input;
    }

    public void SavePreset()
    {
        // create a new preset object and save it to file
        if (presetNameInput != "")
        {
            PlayerPreset newPreset = new PlayerPreset(presetNameInput, playerAttributes.Strength, playerAttributes.Perception, playerAttributes.Endurance, playerAttributes.Intelligence, playerAttributes.Agility, playerAttributes.Aberrance, proficiencies);
            SaveSystem.SavePlayerPreset(newPreset);
            GetComponent<MenuStatusPanel>().CancelOperation();
        }
        else
        {
            nameInputError.SetActive(true);
        }
    }
}
