using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class PresetSelection : Selectable, ISubmitHandler
{
    [SerializeField] PlayerPreset preset;

    [Header("References")]
    [SerializeField] TextMeshProUGUI presetName;
    [SerializeField] TextMeshProUGUI str;
    [SerializeField] TextMeshProUGUI per;
    [SerializeField] TextMeshProUGUI end;
    [SerializeField] TextMeshProUGUI intel;
    [SerializeField] TextMeshProUGUI agi;
    [SerializeField] TextMeshProUGUI abr;
    [SerializeField] TextMeshProUGUI proficiencies;

    [Header("Audio")]
    [SerializeField] AudioClip confirmSound;
    [SerializeField] [Range(0, 1)] float confirmSoundVolume = 0.5f;

    AttributePanelManager attributePanelManager;
    AudioSource uiSounds;

    protected override void Start()
    {
        attributePanelManager = FindObjectOfType<AttributePanelManager>();
        uiSounds = GameObject.FindWithTag("UISound").GetComponent<AudioSource>();
    }

    // Do this when the mouse is clicked over the selectable object this script is attached to.
    public override void OnPointerDown(PointerEventData eventData)
    {
        Submit();
    }

    public void OnSubmit(BaseEventData eventData)
    {
        Submit();
    }

    void Submit()
    {
        attributePanelManager.SubmitPreset(preset);

        uiSounds.PlayOneShot(confirmSound);

        // destroy modal
        Destroy(FindObjectOfType<PresetListModal>().gameObject);
    }

    public void InitializePresetSelection(PlayerPreset _preset)
    {
        presetName.text = _preset.name;

        str.text = "STR: " + _preset.strength.ToString();
        per.text = "PER: " + _preset.perception.ToString();
        end.text = "END: " + _preset.endurance.ToString();
        intel.text = "INT: " + _preset.intelligence.ToString();
        agi.text = "AGI: " + _preset.agility.ToString();
        abr.text = "ABR: " + _preset.aberrance.ToString();

        for (int i = 0; i < _preset.proficiencies.Count; i++)
        {
            if (i == _preset.proficiencies.Count - 1)
            {
                proficiencies.text += AttributeScores.GetSkillAsString((AttributeScores.Skills)_preset.proficiencies[i]);
            }
            else
            {
                proficiencies.text += AttributeScores.GetSkillAsString((AttributeScores.Skills)_preset.proficiencies[i]) + ", ";
            }
        }

        preset = _preset;
    }
}
