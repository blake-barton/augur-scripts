using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ButtonSounds : MonoBehaviour
{
    [Header("Sound")]
    [SerializeField] AudioClip positiveSound;
    [SerializeField] [Range(0, 1)] float positiveVolume = .5f;
    [SerializeField] AudioClip negativeSound;
    [SerializeField] [Range(0, 1)] float negativeVolume = .5f;
    [SerializeField] AudioClip confirmSound;
    [SerializeField] [Range(0, 1)] float confirmVolume = .5f;
    [SerializeField] AudioClip cancelSound;
    [SerializeField] [Range(0, 1)] float cancelVolume = .5f;

    AudioSource uiSounds;

    private void Awake()
    {
        uiSounds = GameObject.FindWithTag("UISound").GetComponent<AudioSource>();
    }

    public void PlayPositiveSound()
    {
        uiSounds.PlayOneShot(positiveSound, positiveVolume);
    }

    public void PlayNegativeSound()
    {
        uiSounds.PlayOneShot(negativeSound, negativeVolume);
    }

    public void PlayConfirmSound()
    {
        uiSounds.PlayOneShot(confirmSound, confirmVolume);
    }

    public void PlayCancelSound()
    {
        uiSounds.PlayOneShot(cancelSound, cancelVolume);
    }
}
