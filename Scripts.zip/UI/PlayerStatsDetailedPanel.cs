using System;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class PlayerStatsDetailedPanel : MonoBehaviour
{
    [Header("Ability Scores")]
    [SerializeField] TextMeshProUGUI level;
    [SerializeField] TextMeshProUGUI strength;
    [SerializeField] TextMeshProUGUI perception;
    [SerializeField] TextMeshProUGUI endurance;
    [SerializeField] TextMeshProUGUI intelligence;
    [SerializeField] TextMeshProUGUI agility;
    [SerializeField] TextMeshProUGUI aberrance;

    [Header("Bars")]
    [SerializeField] TextMeshProUGUI hp;
    [SerializeField] TextMeshProUGUI mp;
    [SerializeField] TextMeshProUGUI fp;

    [Header("Bar Regen")]
    [SerializeField] TextMeshProUGUI hpRegen;
    [SerializeField] TextMeshProUGUI mpRegen;
    [SerializeField] TextMeshProUGUI fpRegen;

    [Header("Damage Type Grids")]
    [SerializeField] Transform vulnerabilityGrid;
    [SerializeField] Transform resistanceGrid;
    [SerializeField] Transform immunityGrid;

    [Header("Equipment Stats")]
    [SerializeField] TextMeshProUGUI equipLoad;
    [SerializeField] TextMeshProUGUI weightRatio;
    [SerializeField] TextMeshProUGUI poiseVal;
    [SerializeField] TextMeshProUGUI itemDiscovery;

    [Header("Damage Type Icons")]
    [SerializeField] GameObject blunt;
    [SerializeField] GameObject piercing;
    [SerializeField] GameObject slashing;
    [SerializeField] GameObject energy;
    [SerializeField] GameObject fire;
    [SerializeField] GameObject frost;
    [SerializeField] GameObject shock;
    [SerializeField] GameObject acid;
    [SerializeField] GameObject poison;
    [SerializeField] GameObject psionic;

    [Header("Skill Values")]
    [SerializeField] TextMeshProUGUI acrobaticsText;
    [SerializeField] TextMeshProUGUI barterText;
    [SerializeField] TextMeshProUGUI bladeText;
    [SerializeField] TextMeshProUGUI bludgeoningText;
    [SerializeField] TextMeshProUGUI enkiismText;
    [SerializeField] TextMeshProUGUI erebancyText;
    [SerializeField] TextMeshProUGUI explosivesText;
    [SerializeField] TextMeshProUGUI gaianismText;
    [SerializeField] TextMeshProUGUI heavyWeaponsText;
    [SerializeField] TextMeshProUGUI hermeticismText;
    [SerializeField] TextMeshProUGUI iktomancyText;
    [SerializeField] TextMeshProUGUI pistolsText;
    [SerializeField] TextMeshProUGUI polearmsText;
    [SerializeField] TextMeshProUGUI reshephismText;
    [SerializeField] TextMeshProUGUI resourcefulnessText;
    [SerializeField] TextMeshProUGUI riflesText;
    [SerializeField] TextMeshProUGUI sleightOfHandText;
    [SerializeField] TextMeshProUGUI throwingText;

    [Header("Proficiency Tags")]
    [SerializeField] RectTransform tagImageGroup;

    [Header("Damage Thresholds")]
    [SerializeField] TextMeshProUGUI bluntDT;
    [SerializeField] TextMeshProUGUI piercingDT;
    [SerializeField] TextMeshProUGUI slashingDT;
    [SerializeField] TextMeshProUGUI energyDT;
    [SerializeField] TextMeshProUGUI fireDT;
    [SerializeField] TextMeshProUGUI frostDT;
    [SerializeField] TextMeshProUGUI shockDT;
    [SerializeField] TextMeshProUGUI acidDT;
    [SerializeField] TextMeshProUGUI poisonDT;
    [SerializeField] TextMeshProUGUI psionicDT;

    [Header("Stats Effect Thresholds")]
    [SerializeField] TextMeshProUGUI burningThreshold;
    [SerializeField] TextMeshProUGUI freezingThreshold;
    [SerializeField] TextMeshProUGUI shockedThreshold;
    [SerializeField] TextMeshProUGUI decayedThreshold;
    [SerializeField] TextMeshProUGUI poisonedThreshold;
    [SerializeField] TextMeshProUGUI insanityThreshold;
    [SerializeField] TextMeshProUGUI bleedThreshold;
    [SerializeField] TextMeshProUGUI bleedReduction;

    [Header("Criticals")]
    [SerializeField] TextMeshProUGUI criticalHitChance;
    [SerializeField] TextMeshProUGUI criticalHitMultiplier;

    [Header("Augmentations")]
    [SerializeField] TextMeshProUGUI augmentationPoints;

    bool[] proficiencies = new bool[18];

    // cache
    Player player;
    AttributeScores attributes;
    Health health;
    Magic magic;
    Focus focus;
    Equipment equipment;
    DamageEffects damageEffects;
    Poise poise;
    StatusEffects statusEffects;
    Augmentations augmentations;
    DamageThresholds damageThresholds;
    PlayerMovement playerMovement;

    public bool[] Proficiencies { get => proficiencies; set => proficiencies = value; }

    private void Awake()
    {
        player = FindObjectOfType<Player>();
        attributes = player.GetComponent<AttributeScores>();
        health = player.GetComponent<Health>();
        magic = player.GetComponent<Magic>();
        focus = player.GetComponent<Focus>();
        equipment = player.GetComponent<Equipment>();
        damageEffects = player.GetComponent<DamageEffects>();
        poise = player.GetComponent<Poise>();
        statusEffects = player.GetComponent<StatusEffects>();
        augmentations = player.GetComponent<Augmentations>();
        damageThresholds = player.GetComponent<DamageThresholds>();
        playerMovement = player.GetComponent<PlayerMovement>();
    }

    private void Start()
    {
        SetPanelInfo();
    }

    void SetPanelInfo()
    {
        level.text = attributes.level.ToString();

        strength.text = attributes.Strength.ToString();
        perception.text = attributes.Perception.ToString();
        endurance.text = attributes.Endurance.ToString();
        intelligence.text = attributes.Intelligence.ToString();
        agility.text = attributes.Agility.ToString();
        aberrance.text = attributes.Aberrance.ToString();

        SetBars();
        SetRegenValues();

        LoadVulnerabilityIcons();
        LoadResistanceIcons();
        LoadImmunityIcons();

        itemDiscovery.text = attributes.itemDiscovery.ToString();

        SetEquipLoad();

        // skills
        LoadSkills();

        // Damage Thresholds
        LoadDamageThresholds();

        // Status effect thresholds
        LoadStatusEffectThresholds();

        // Crits
        criticalHitChance.text = attributes.critChance.ToString() + "%";
        criticalHitMultiplier.text = attributes.critDamageMultiplier.ToString();

        // Augmentations
        augmentationPoints.text = augmentations.AugmentationPoints.ToString();
    }

    void SetBars()
    {
        //.text = Mathf.Round(val).ToString();
        hp.text = Math.Round(health.CurrentHealth, 1).ToString() + "/" + Math.Round(health.MaxHealth.GetCurrentValue());
        mp.text = Math.Round(magic.MagicPoints, 1).ToString() + "/" + Math.Round(magic.MaxMagicPoints);
        fp.text = Math.Round(focus.FocusPoints, 1).ToString() + "/" + Math.Round(focus.MaxFocusPoints);
    }

    void SetRegenValues()
    {
        hpRegen.text = Math.Round(health.HpRegenPerTick * health.HpTicksPerSecond, 1).ToString() + "/s";
        mpRegen.text = Math.Round(magic.MpRegenPerTick * magic.MpTicksPerSecond, 1).ToString() + "/s";
        fpRegen.text = Math.Round(focus.FpRegenPerTick * focus.FpTicksPerSecond, 1).ToString() + "/s";
    }

    void SetEquipLoad()
    {
        equipLoad.text = Math.Round(equipment.CurrentEquipLoad, 2).ToString() + "/" + equipment.MaxEquipLoad + "kg";

        weightRatio.text = Math.Round(equipment.EquipLoadRatio * 100f, 2).ToString() + "% " + playerMovement.GetEquipLoadRatioAsString(equipment.EquipLoadRatio);

        // poise
        poiseVal.text = Math.Round(poise.CurrentPoise, 2).ToString() + " / " + poise.MaxPoise.ToString();
    }

    void LoadVulnerabilityIcons()
    {
        foreach (DamageEffects.DamageType vuln in damageEffects.Vulnerabilities)
        {
            switch (vuln)
            {
                case DamageEffects.DamageType.BLUNT:
                    Instantiate(blunt, vulnerabilityGrid);
                    break;
                case DamageEffects.DamageType.PIERCING:
                    Instantiate(piercing, vulnerabilityGrid);
                    break;
                case DamageEffects.DamageType.SLASHING:
                    Instantiate(slashing, vulnerabilityGrid);
                    break;
                case DamageEffects.DamageType.ENERGY:
                    Instantiate(energy, vulnerabilityGrid);
                    break;
                case DamageEffects.DamageType.FIRE:
                    Instantiate(fire, vulnerabilityGrid);
                    break;
                case DamageEffects.DamageType.FROST:
                    Instantiate(frost, vulnerabilityGrid);
                    break;
                case DamageEffects.DamageType.SHOCK:
                    Instantiate(shock, vulnerabilityGrid);
                    break;
                case DamageEffects.DamageType.ACID:
                    Instantiate(acid, vulnerabilityGrid);
                    break;
                case DamageEffects.DamageType.POISON:
                    Instantiate(poison, vulnerabilityGrid);
                    break;
                case DamageEffects.DamageType.PSIONIC:
                    Instantiate(psionic, vulnerabilityGrid);
                    break;
            }
        }
    }

    void LoadResistanceIcons()
    {
        foreach (DamageEffects.DamageType res in damageEffects.Resistances)
        {
            switch (res)
            {
                case DamageEffects.DamageType.BLUNT:
                    Instantiate(blunt, resistanceGrid);
                    break;
                case DamageEffects.DamageType.PIERCING:
                    Instantiate(piercing, resistanceGrid);
                    break;
                case DamageEffects.DamageType.SLASHING:
                    Instantiate(slashing, resistanceGrid);
                    break;
                case DamageEffects.DamageType.ENERGY:
                    Instantiate(energy, resistanceGrid);
                    break;
                case DamageEffects.DamageType.FIRE:
                    Instantiate(fire, resistanceGrid);
                    break;
                case DamageEffects.DamageType.FROST:
                    Instantiate(frost, resistanceGrid);
                    break;
                case DamageEffects.DamageType.SHOCK:
                    Instantiate(shock, resistanceGrid);
                    break;
                case DamageEffects.DamageType.ACID:
                    Instantiate(acid, resistanceGrid);
                    break;
                case DamageEffects.DamageType.POISON:
                    Instantiate(poison, resistanceGrid);
                    break;
                case DamageEffects.DamageType.PSIONIC:
                    Instantiate(psionic, resistanceGrid);
                    break;
            }
        }
    }

    void LoadImmunityIcons()
    {
        foreach (DamageEffects.DamageType imm in damageEffects.Immunities)
        {
            switch (imm)
            {
                case DamageEffects.DamageType.BLUNT:
                    Instantiate(blunt, immunityGrid);
                    break;
                case DamageEffects.DamageType.PIERCING:
                    Instantiate(piercing, immunityGrid);
                    break;
                case DamageEffects.DamageType.SLASHING:
                    Instantiate(slashing, immunityGrid);
                    break;
                case DamageEffects.DamageType.ENERGY:
                    Instantiate(energy, immunityGrid);
                    break;
                case DamageEffects.DamageType.FIRE:
                    Instantiate(fire, immunityGrid);
                    break;
                case DamageEffects.DamageType.FROST:
                    Instantiate(frost, immunityGrid);
                    break;
                case DamageEffects.DamageType.SHOCK:
                    Instantiate(shock, immunityGrid);
                    break;
                case DamageEffects.DamageType.ACID:
                    Instantiate(acid, immunityGrid);
                    break;
                case DamageEffects.DamageType.POISON:
                    Instantiate(poison, immunityGrid);
                    break;
                case DamageEffects.DamageType.PSIONIC:
                    Instantiate(psionic, immunityGrid);
                    break;
            }
        }
    }

    void LoadSkills()
    {
        SetSkillValues();
        LoadProficiencies();
    }

    public void SetSkillValues()
    {
        acrobaticsText.text = attributes.acrobatics.ToString();
        barterText.text = attributes.barter.ToString();
        bladeText.text = attributes.blade.ToString();
        bludgeoningText.text = attributes.bludgeoning.ToString();
        enkiismText.text = attributes.enkiism.ToString();
        erebancyText.text = attributes.erebancy.ToString();
        explosivesText.text = attributes.explosives.ToString();
        gaianismText.text = attributes.gaianism.ToString();
        heavyWeaponsText.text = attributes.heavyWeapons.ToString();
        hermeticismText.text = attributes.hermeticism.ToString();
        iktomancyText.text = attributes.iktomancy.ToString();
        pistolsText.text = attributes.pistols.ToString();
        polearmsText.text = attributes.polearms.ToString();
        reshephismText.text = attributes.reshephism.ToString();
        resourcefulnessText.text = attributes.resourcefulness.ToString();
        riflesText.text = attributes.rifles.ToString();
        sleightOfHandText.text = attributes.sleightOfHand.ToString();
        throwingText.text = attributes.throwing.ToString();
    }

    void LoadProficiencies()
    {
        // load in proficiencies
        for (int i = 0; i < attributes.Proficiencies.Length; i++)
        {
            if (attributes.Proficiencies[i])
            {
                Proficiencies[i] = true;
            }
        }

        // visuals
        for (int i = 0; i < Proficiencies.Length; i++)
        {
            if (Proficiencies[i])
            {
                tagImageGroup.GetChild(i).GetComponent<Image>().enabled = true;
            }
        }
    }

    void LoadDamageThresholds()
    {
        bluntDT.text = damageThresholds.BluntDT.ToString();
        piercingDT.text = damageThresholds.PiercingDT.ToString();
        slashingDT.text = damageThresholds.SlashingDT.ToString();
        energyDT.text = damageThresholds.EnergyDT.ToString();
        fireDT.text = damageThresholds.FireDT.ToString();
        frostDT.text = damageThresholds.FrostDT.ToString();
        shockDT.text = damageThresholds.ShockDT.ToString();
        acidDT.text = damageThresholds.AcidDT.ToString();
        poisonDT.text = damageThresholds.PoisonDT.ToString();
        psionicDT.text = damageThresholds.PsionicDT.ToString();
    }

    void LoadStatusEffectThresholds()
    {
        burningThreshold.text = statusEffects.BurningThreshold.ToString();
        freezingThreshold.text = statusEffects.FrostThreshold.ToString();
        shockedThreshold.text = statusEffects.ShockedThreshold.ToString();
        decayedThreshold.text = statusEffects.DecayThreshold.ToString();
        poisonedThreshold.text = statusEffects.PoisonedThreshold.ToString();
        insanityThreshold.text = statusEffects.InsanityThreshold.ToString();
        bleedThreshold.text = statusEffects.BleedThreshold.ToString();
        bleedReduction.text = statusEffects.BleedReduction.ToString();
    }
}
