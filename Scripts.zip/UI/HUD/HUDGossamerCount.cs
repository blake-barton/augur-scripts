using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class HUDGossamerCount : MonoBehaviour
{
    [SerializeField] TextMeshProUGUI countText;

    Crypto playerCrypto;

    private void Awake()
    {
        playerCrypto = FindObjectOfType<Player>().GetComponent<Crypto>();
    }

    // Update is called once per frame
    void Update()
    {
        countText.text = playerCrypto.CurrentCurrency.ToString();
    }
}
