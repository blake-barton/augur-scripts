using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HUDManager : MonoBehaviour
{
    [SerializeField] GameObject HUDPanel;

    [Header("State")]
    public bool HUDEnabled = true;

    public void ToggleHUD()
    {
        if (HUDPanel.activeInHierarchy)
        {
            HUDPanel.SetActive(false);
            HUDEnabled = false;
        }
        else
        {
            HUDPanel.SetActive(true);
            HUDEnabled = true;
        }
    }

    // ONLY enables the HUD; no toggle
    public void EnableHUD()
    {
        if (!HUDPanel.activeInHierarchy)
        {
            HUDPanel.SetActive(true);
            HUDEnabled = true;
        }
    }

    // ONLY disables the HUD; no toggle
    public void DisableHUD()
    {
        if (HUDPanel.activeInHierarchy)
        {
            HUDPanel.SetActive(false);
            HUDEnabled = false;
        }
    }
}
