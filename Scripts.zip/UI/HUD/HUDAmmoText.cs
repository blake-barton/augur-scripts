using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class HUDAmmoText : MonoBehaviour
{
    // config
    [Header("State")]
    public bool mainHandRangedWeaponEquipped = false;
    public bool offHandRangedWeaponEquipped = false;
    public bool mainHandThrowingWeaponEquipped = false;
    public bool offHandThrowingWeaponEquipped = false;

    [Header("Text")]
    [SerializeField] TextMeshProUGUI mainHandText;
    [SerializeField] TextMeshProUGUI offHandText;
    [SerializeField] TextMeshProUGUI mainHandTextDropShadow;
    [SerializeField] TextMeshProUGUI offHandTextDropShadow;
    [SerializeField] Color normalAmmoColor;
    [SerializeField] Color bonusDamageAmmoColor;

    [Header("Image Panels")]
    [SerializeField] Image mainHandImage;
    [SerializeField] Image offHandImage;
    [SerializeField] Image focusImplantImage;

    [Header("Inadquate Stat Images")]
    [SerializeField] Image mainHandInadequateStrength;
    [SerializeField] Image mainHandInadequateSkill;
    [SerializeField] Image offHandInadequateStrength;
    [SerializeField] Image offHandInadequateSkill;

    [Header("Skill Sprites")]
    [SerializeField] Sprite blade;
    [SerializeField] Sprite bludgeoning;
    [SerializeField] Sprite enkiism;
    [SerializeField] Sprite erebancy;
    [SerializeField] Sprite explosives;
    [SerializeField] Sprite gaianism;
    [SerializeField] Sprite heavyWeapons;
    [SerializeField] Sprite hermeticism;
    [SerializeField] Sprite iktomancy;
    [SerializeField] Sprite pistols;
    [SerializeField] Sprite polearms;
    [SerializeField] Sprite reshephism;
    [SerializeField] Sprite rifles;
    [SerializeField] Sprite thrown;

    [Header("Status Effect Icons")]
    [SerializeField] GameObject statusEffectIconPrefab;
    [SerializeField] Transform statusEffectIconGroup;

    // cache
    Player player;
    AmmoCounter playerAmmo;
    GameObject mainHand;
    GameObject offHand;
    Item.AmmoType mainHandAmmoType;
    Item.AmmoType offHandAmmoType;

    WeaponReloader mainHandReloader;
    WeaponReloader offHandReloader;

    AttributeScores playerAttributes;

    Pair<Item, int> mainHandItemPair;
    Pair<Item, int> offHandItemPair;

    // Start is called before the first frame update
    void Start()
    {
        player = FindObjectOfType<Player>();
        playerAmmo = player.GetComponent<AmmoCounter>();
        playerAttributes = player.GetComponent<AttributeScores>();

        mainHandText.text = "";
        offHandText.text = "";

        mainHandTextDropShadow.text = "";
        offHandTextDropShadow.text = "";

        mainHandInadequateStrength.gameObject.SetActive(false);
        mainHandInadequateSkill.gameObject.SetActive(false);
        offHandInadequateStrength.gameObject.SetActive(false);
        offHandInadequateSkill.gameObject.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        if (mainHandRangedWeaponEquipped)
        {
            SetMainHandAmmoText(mainHandReloader.AmmoInClip, playerAmmo.GetAmmoCountByType(mainHandAmmoType));
        }
        if (offHandRangedWeaponEquipped)
        {
            SetOffHandAmmoText(offHandReloader.AmmoInClip, playerAmmo.GetAmmoCountByType(offHandAmmoType));
        }

        if (mainHandThrowingWeaponEquipped)
        {
            SetMainHandAmmoText(1, mainHandItemPair.Second - 1);
        }
        if (offHandThrowingWeaponEquipped)
        {
            SetOffHandAmmoText(1, offHandItemPair.Second - 1);
        }
    }

    public void SetMainHandAmmoText(int ammoInClip, int ammoInReserves)
    {
        mainHandText.text = ammoInClip.ToString() + "/" + ammoInReserves.ToString();
        mainHandTextDropShadow.text = mainHandText.text;

        if (mainHandReloader)
        {
            if (mainHandReloader.BonusDamageRoundsLoaded > 0)
            {
                mainHandText.color = bonusDamageAmmoColor;
            }
            else
            {
                mainHandText.color = normalAmmoColor;
            }
        }
    }

    public void SetOffHandAmmoText(int ammoInClip, int ammoInReserves)
    {
        offHandText.text = ammoInClip.ToString() + "/" + ammoInReserves.ToString();
        offHandTextDropShadow.text = offHandText.text;

        if (offHandReloader)
        {
            if (offHandReloader.BonusDamageRoundsLoaded > 0)
            {
                offHandText.color = bonusDamageAmmoColor;
            }
            else
            {
                offHandText.color = normalAmmoColor;
            }
        }
    }

    public void SetMainHandRangedWeapon(GameObject newWeapon)
    {
        mainHand = newWeapon;

        RangedWeapon mainhandWeapon = (RangedWeapon)newWeapon.GetComponent<EquippedWeapon>().ItemData;

        mainHandImage.enabled = true;
        mainHandImage.sprite = mainhandWeapon.Sprite;

        if (mainhandWeapon.IsThrowingWeapon)
        {
            mainHandItemPair = newWeapon.GetComponent<EquippedWeapon>().itemPair;
            mainHandThrowingWeaponEquipped = true;
        }
        else
        {
            mainHandAmmoType = mainhandWeapon.AmmunitionType;

            mainHandReloader = newWeapon.GetComponent<WeaponReloader>();

            mainHandRangedWeaponEquipped = true;
        }

        // strength and skill
        if (playerAttributes.Strength < mainhandWeapon.StrengthRequirement)
        {
            mainHandInadequateStrength.gameObject.SetActive(true);
        }
        if (playerAttributes.GetSkillValue(mainhandWeapon.WeaponSkill) < mainhandWeapon.WeaponSkillRequirement)
        {
            mainHandInadequateSkill.gameObject.SetActive(true);
            mainHandInadequateSkill.sprite = SelectSkillSprite(mainhandWeapon.WeaponSkill);
        }
    }

    public void SetOffHandRangedWeapon(GameObject newWeapon)
    {
        offHand = newWeapon;

        RangedWeapon offhandWeapon = (RangedWeapon)newWeapon.GetComponent<EquippedWeapon>().ItemData;

        offHandImage.enabled = true;
        offHandImage.sprite = offhandWeapon.Sprite;

        if (offhandWeapon.IsThrowingWeapon)
        {
            offHandItemPair = newWeapon.GetComponent<EquippedWeapon>().itemPair;
            offHandThrowingWeaponEquipped = true;
        }
        else
        {
            offHandAmmoType = offhandWeapon.AmmunitionType;

            offHandReloader = newWeapon.GetComponent<WeaponReloader>();

            offHandRangedWeaponEquipped = true;
        }

        // strength and skill
        if (playerAttributes.Strength < offhandWeapon.StrengthRequirement)
        {
            offHandInadequateStrength.gameObject.SetActive(true);
        }
        if (playerAttributes.GetSkillValue(offhandWeapon.WeaponSkill) < offhandWeapon.WeaponSkillRequirement)
        {
            offHandInadequateSkill.gameObject.SetActive(true);
            offHandInadequateSkill.sprite = SelectSkillSprite(offhandWeapon.WeaponSkill);
        }
    }

    public void SetMainHandMeleeWeapon(GameObject newWeapon)
    {
        mainHand = newWeapon;

        Weapon mainhandWeapon = (Weapon)newWeapon.GetComponent<EquippedWeapon>().ItemData;

        mainHandImage.enabled = true;
        mainHandImage.sprite = mainhandWeapon.Sprite;

        // strength and skill
        if (playerAttributes.Strength < mainhandWeapon.StrengthRequirement)
        {
            mainHandInadequateStrength.gameObject.SetActive(true);
        }
        if (playerAttributes.GetSkillValue(mainhandWeapon.WeaponSkill) < mainhandWeapon.WeaponSkillRequirement)
        {
            mainHandInadequateSkill.gameObject.SetActive(true);
            mainHandInadequateSkill.sprite = SelectSkillSprite(mainhandWeapon.WeaponSkill);
        }
    }

    public void SetOffHandMeleeWeapon(GameObject newWeapon)
    {
        offHand = newWeapon;

        Weapon offhandWeapon = (Weapon)newWeapon.GetComponent<EquippedWeapon>().ItemData;

        offHandImage.enabled = true;
        offHandImage.sprite = offhandWeapon.Sprite;

        // strength and skill
        if (playerAttributes.Strength < offhandWeapon.StrengthRequirement)
        {
            offHandInadequateStrength.gameObject.SetActive(true);
        }
        if (playerAttributes.GetSkillValue(offhandWeapon.WeaponSkill) < offhandWeapon.WeaponSkillRequirement)
        {
            offHandInadequateSkill.gameObject.SetActive(true);
            offHandInadequateSkill.sprite = SelectSkillSprite(offhandWeapon.WeaponSkill);
        }
    }

    public void SetMainHandSpell(Spell spell)
    {
        mainHandImage.enabled = true;
        mainHandImage.sprite = spell.SpellSprite;

        // skill requirement
        if (playerAttributes.GetSkillValue(spell.RequiredSkill) < spell.SkillRequirement)
        {
            mainHandInadequateSkill.gameObject.SetActive(true);
            mainHandInadequateSkill.sprite = SelectSkillSprite(spell.RequiredSkill);
        }
    }

    public void SetOffHandSpell(Spell spell)
    {
        offHandImage.enabled = true;
        offHandImage.sprite = spell.SpellSprite;

        // skill requirement
        if (playerAttributes.GetSkillValue(spell.RequiredSkill) < spell.SkillRequirement)
        {
            offHandInadequateSkill.gameObject.SetActive(true);
            offHandInadequateSkill.sprite = SelectSkillSprite(spell.RequiredSkill);
        }
    }

    public void SetFocusImplantIcon(Item implant)
    {
        focusImplantImage.enabled = true;
        focusImplantImage.sprite = implant.Sprite;
    }

    public void AddStatusEffectIcon(StatusEffect statusEffect)
    {
        GameObject newIcon = Instantiate(statusEffectIconPrefab, statusEffectIconGroup);

        newIcon.GetComponent<StatusEffectIcon>().InitializeIcon(statusEffect);
    }

    public void RemoveStatusEffectIcon(StatusEffect statusEffect)
    {
        for (int i = statusEffectIconGroup.childCount - 1; i >= 0; i--)
        {
            StatusEffectIcon currentIcon = statusEffectIconGroup.GetChild(i).GetComponent<StatusEffectIcon>();

            if (currentIcon.StatusEffect == statusEffect)
            {
                // Remove from group
                Destroy(statusEffectIconGroup.GetChild(i).gameObject);
            }
        }
    }

    public void ClearFocusImplantIcon()
    {
        focusImplantImage.sprite = null;
        focusImplantImage.enabled = false;
    }

    public void ClearMainHand()
    {
        mainHandRangedWeaponEquipped = false;
        mainHandThrowingWeaponEquipped = false;
        mainHandText.text = "";
        mainHandTextDropShadow.text = "";

        mainHandImage.sprite = null;
        mainHandImage.enabled = false;

        mainHandReloader = null;

        mainHandItemPair = null;

        mainHandInadequateStrength.gameObject.SetActive(false);
        mainHandInadequateSkill.gameObject.SetActive(false);
    }

    public void ClearOffHand()
    {
        offHandRangedWeaponEquipped = false;
        offHandThrowingWeaponEquipped = false;
        offHandText.text = "";
        offHandTextDropShadow.text = "";

        offHandImage.sprite = null;
        offHandImage.enabled = false;

        offHandReloader = null;

        offHandItemPair = null;

        offHandInadequateStrength.gameObject.SetActive(false);
        offHandInadequateSkill.gameObject.SetActive(false);
    }

    private Sprite SelectSkillSprite(AttributeScores.Skills skill)
    {
        return skill switch
        {
            AttributeScores.Skills.BLADE => blade,
            AttributeScores.Skills.BLUDGEONING => bludgeoning,
            AttributeScores.Skills.ENKIISM => enkiism,
            AttributeScores.Skills.EREBANCY => erebancy,
            AttributeScores.Skills.EXPLOSIVES => explosives,
            AttributeScores.Skills.GAIANISM => gaianism,
            AttributeScores.Skills.HEAVY_WEAPONS => heavyWeapons,
            AttributeScores.Skills.HERMETICISM => hermeticism,
            AttributeScores.Skills.IKTOMANCY => iktomancy,
            AttributeScores.Skills.PISTOLS => pistols,
            AttributeScores.Skills.POLEARMS => polearms,
            AttributeScores.Skills.RESHEPHISM => reshephism,
            AttributeScores.Skills.RIFLES => rifles,
            AttributeScores.Skills.THROWING => thrown,
            _ => null,
        };
    }
}
