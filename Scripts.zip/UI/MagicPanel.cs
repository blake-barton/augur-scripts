using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class MagicPanel : MonoBehaviour
{
    [Header("Grid")]
    [SerializeField] GameObject spellSlotTemplate;
    [SerializeField] GameObject spellGrid;

    [Header("Text")]
    [SerializeField] TextMeshProUGUI schoolTitleText;
    [SerializeField] TextMeshProUGUI spellNameTitleText;

    // cached references
    Magic playerMagic;

    private void Awake()
    {
        playerMagic = FindObjectOfType<Player>().gameObject.GetComponent<Magic>();
    }

    // Start is called before the first frame update
    void Start()
    {
        LoadPlayerSpellsIntoGrid();
        schoolTitleText.text = "All Spells";
        spellNameTitleText.text = "";
    }

    void LoadPlayerSpellsIntoGrid()
    {
        foreach (Spell spell in playerMagic.SpellList)
        {
            // insert the slot into the grid
            GameObject newSlot = Instantiate(spellSlotTemplate, spellGrid.transform);

            // fill the slot with data
            FillSpellSlotTemplate(newSlot, spell);
        }
    }

    void FillSpellSlotTemplate(GameObject newSlot, Spell spell)
    {
        SpellClickable clickable = newSlot.GetComponent<SpellClickable>();
        Image spellImage = newSlot.transform.GetChild(0).GetComponent<Image>();

        clickable.SlotType = InventoryClickable.ClickableType.INVENTORY_GRID_SLOT;

        clickable.spell = spell;
        spellImage.sprite = spell.SpellSprite;

        // equip panels
        clickable.EquippedMain = spell.EquippedMain;
        clickable.EquippedOff = spell.EquippedOff;
        clickable.UpdateEquipPanels();
    }

    // Disable all spell panels that are not of the given school
    // NOTE: BECAUSE ENUMS ARE NOT SUPPORTED THIS IS PASSED AN INTEGER ARGUMENT, MEANING THAT IF THE ENUM IN Item.cs IS EVER CHANGED THE BUTTONS WILL NEED TO BE CHANGED
    public void ToggleSpellSchool(int school)
    {
        foreach (RectTransform child in spellGrid.transform)
        {
            if ((int)child.gameObject.GetComponent<SpellClickable>().spell.SpellSchool != school)
            {
                child.gameObject.SetActive(false);
            }
            else
            {
                child.gameObject.SetActive(true);
            }
        }

        switch (school)
        {
            case (int)Spell.School.ENKIISM:
                schoolTitleText.text = "Enkiism";
                break;
            case (int)Spell.School.EREBANCY:
                schoolTitleText.text = "Erebancy";
                break;
            case (int)Spell.School.GAIANISM:
                schoolTitleText.text = "Gaianism";
                break;
            case (int)Spell.School.HERMETICISM:
                schoolTitleText.text = "Hermeticism";
                break;
            case (int)Spell.School.IKTOMANCY:
                schoolTitleText.text = "Iktomancy";
                break;
            case (int)Spell.School.RESHEPHISM:
                schoolTitleText.text = "Reshephism";
                break;
        }

        SetSpellNameTitleText("");
    }

    public void ShowAllSchools()
    {
        foreach (RectTransform child in spellGrid.transform)
        {
            child.gameObject.SetActive(true);
        }

        schoolTitleText.text = "All Spells";
    }

    public void SetSpellNameTitleText(string itemName)
    {
        spellNameTitleText.text = itemName;
    }

    public void DestroySlotAtIndex(int slotIndex)
    {
        Destroy(spellGrid.transform.GetChild(slotIndex).gameObject);
    }

    public void ReloadGrid()
    {
        foreach (RectTransform child in spellGrid.transform)
        {
            Destroy(child.gameObject);
        }

        LoadPlayerSpellsIntoGrid();
    }
}
