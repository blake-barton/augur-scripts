using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class FloatingText : MonoBehaviour
{
    [Header("Movement")]
    [SerializeField] float speed = 1f;
    [SerializeField] float timeToDestroy = 1.25f;
    [SerializeField] float minX = -1f;
    [SerializeField] float maxX = 1f;
    [SerializeField] float minY = 0;
    [SerializeField] float maxY = 1f;

    [Header("Colors")]
    [SerializeField] Color physicalDamageColor = Color.white;
    [SerializeField] Color energyDamageColor;
    [SerializeField] Color fireDamageColor;
    [SerializeField] Color frostDamageColor;
    [SerializeField] Color shockDamageColor;
    [SerializeField] Color poisonDamageColor;
    [SerializeField] Color acidDamageColor;
    [SerializeField] Color psionicDamageColor;
    [SerializeField] Color bleedDamageColor = Color.red;

    [Header("Cached References")]
    [SerializeField] TextMeshPro textMeshPro;

    private Vector2 target;

    // Start is called before the first frame update
    void Start()
    {
        // calculate the target
        float targetX = Random.Range(minX, maxX);
        float targetY = Random.Range(minY, maxY);

        target = new Vector2(targetX + transform.position.x, targetY + transform.position.y);
    }

    // Update is called once per frame
    void Update()
    {
        Move();
    }

    void Move()
    {
        float step = speed * Time.deltaTime;    // distance to move this frame
        transform.position = Vector3.MoveTowards(transform.position, target, step);
    }

    public void SetParameters(float damage, DamageEffects.DamageType damageType)
    {
        textMeshPro.text = Mathf.Round(damage).ToString();
        transform.GetChild(0).GetComponent<TextMeshPro>().text = textMeshPro.text;   // drop shadow

        switch (damageType)
        {
            case DamageEffects.DamageType.BLUNT:
                textMeshPro.color = physicalDamageColor;
                break;
            case DamageEffects.DamageType.PIERCING:
                textMeshPro.color = physicalDamageColor;
                break;
            case DamageEffects.DamageType.SLASHING:
                textMeshPro.color = physicalDamageColor;
                break;
            case DamageEffects.DamageType.ENERGY:
                textMeshPro.color = energyDamageColor;
                break;
            case DamageEffects.DamageType.FIRE:
                textMeshPro.color = fireDamageColor;
                break;
            case DamageEffects.DamageType.FROST:
                textMeshPro.color = frostDamageColor;
                break;
            case DamageEffects.DamageType.SHOCK:
                textMeshPro.color = shockDamageColor;
                break;
            case DamageEffects.DamageType.ACID:
                textMeshPro.color = acidDamageColor;
                break;
            case DamageEffects.DamageType.POISON:
                textMeshPro.color = poisonDamageColor;
                break;
            case DamageEffects.DamageType.PSIONIC:
                textMeshPro.color = psionicDamageColor;
                break;
            case DamageEffects.DamageType.BLEED:
                textMeshPro.color = bleedDamageColor;
                break;
            default:
                break;
        }

        Destroy(gameObject, timeToDestroy);
    }
}
