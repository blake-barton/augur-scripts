using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class HandPanel : MonoBehaviour
{
    [Header("Weapon Grid")]
    [SerializeField] GameObject itemSlotTemplate;
    [SerializeField] GameObject itemGrid;

    [Header("Spell Grid")]
    [SerializeField] GameObject spellSlotTemplate;
    [SerializeField] GameObject spellGrid;

    [Header("Text")]
    [SerializeField] TextMeshProUGUI categoryTitleText;
    [SerializeField] TextMeshProUGUI equippableNameTitleText;

    public enum HandSlot
    {
        MAINHAND,
        OFFHAND,
        OUTFIT,
        FOCUSIMPLANT,
        QUICKEQUIP,
        QUICK_AID
    }
    [SerializeField] HandSlot slotDestination;
    private int quickEquippableIndex;

    // cached references
    Inventory playerInventory;
    Magic playerMagic;

    public HandSlot SlotDestination { get => slotDestination; set => slotDestination = value; }
    public int QuickEquippableIndex { get => quickEquippableIndex; set => quickEquippableIndex = value; }

    private void Awake()
    {
        playerInventory = FindObjectOfType<Player>().gameObject.GetComponent<Inventory>();
        playerMagic = FindObjectOfType<Player>().gameObject.GetComponent<Magic>();
    }

    // Start is called before the first frame update
    void Start()
    {
        LoadPlayerSpellsIntoGrid();
        LoadPlayerInventoryIntoGrid();
        categoryTitleText.text = "Ranged Weapons";
        equippableNameTitleText.text = "";

        ToggleInventoryCategory(0); // ranged weapons
    }

    void LoadPlayerInventoryIntoGrid()
    {
        foreach (Pair<Item, int> pair in playerInventory.Items)
        {
            // insert the slot into the grid
            GameObject newSlot = Instantiate(itemSlotTemplate, itemGrid.transform);

            // fill the slot with data
            FillItemSlotTemplate(newSlot, pair.First.ItemName, pair.First.Type, pair.First.Sprite, pair.Second, pair.First.EquippedMain, pair.First.EquippedOff, pair.First.Equipped);
        }
    }

    void FillItemSlotTemplate(GameObject newSlot, string itemName, Item.ItemType itemType, Sprite itemSprite, int itemCount, bool equippedMain, bool equippedOff, bool itemEquipped)
    {
        InventoryClickable clickable = newSlot.GetComponent<InventoryClickable>();
        Image itemImage = newSlot.transform.GetChild(0).GetComponent<Image>();

        clickable.SlotType = InventoryClickable.ClickableType.HAND_PANEL_GRID_SLOT;

        clickable.itemType = itemType;
        clickable.itemName = itemName;
        clickable.ItemCount = itemCount;
        clickable.UpdateCountPanelText();
        itemImage.sprite = itemSprite;

        // equip panels
        clickable.EquippedMain = equippedMain;
        clickable.EquippedOff = equippedOff;
        clickable.ItemEquipped = itemEquipped;
        clickable.UpdateEquipPanels();
    }

    void LoadPlayerSpellsIntoGrid()
    {
        foreach (Spell spell in playerMagic.SpellList)
        {
            // insert the slot into the grid
            GameObject newSlot = Instantiate(spellSlotTemplate, spellGrid.transform);

            // fill the slot with data
            FillSpellSlotTemplate(newSlot, spell);
        }
    }

    void FillSpellSlotTemplate(GameObject newSlot, Spell spell)
    {
        SpellClickable clickable = newSlot.GetComponent<SpellClickable>();
        Image spellImage = newSlot.transform.GetChild(0).GetComponent<Image>();

        clickable.SlotType = InventoryClickable.ClickableType.HAND_PANEL_GRID_SLOT;

        clickable.spell = spell;
        spellImage.sprite = spell.SpellSprite;

        // equip panels
        clickable.EquippedMain = spell.EquippedMain;
        clickable.EquippedOff = spell.EquippedOff;
        clickable.UpdateEquipPanels();
    }

    // Disable all item panels that are not of the given type
    // NOTE: BECAUSE ENUMS ARE NOT SUPPORTED THIS IS PASSED AN INTEGER ARGUMENT, MEANING THAT IF THE ENUM IN Item.cs IS EVER CHANGED THE BUTTONS WILL NEED TO BE CHANGED
    public void ToggleInventoryCategory(int type)
    {
        spellGrid.SetActive(false);
        itemGrid.SetActive(true);

        foreach (RectTransform child in itemGrid.transform)
        {
            if ((int)child.gameObject.GetComponent<InventoryClickable>().itemType != type)
            {
                child.gameObject.SetActive(false);
            }
            else
            {
                child.gameObject.SetActive(true);
            }
        }

        switch (type)
        {
            case (int)Item.ItemType.RANGEDWEAPON:
                categoryTitleText.text = "Ranged Weapons";
                break;
            case (int)Item.ItemType.MELEEWEAPON:
                categoryTitleText.text = "Melee Weapons";
                break;
        }

        SetEquippableNameTitleText("");
    }

    public void ToggleSpellSchool(int school)
    {
        itemGrid.SetActive(false);
        spellGrid.SetActive(true);

        foreach (RectTransform child in spellGrid.transform)
        {
            if ((int)child.gameObject.GetComponent<SpellClickable>().spell.SpellSchool != school)
            {
                child.gameObject.SetActive(false);
            }
            else
            {
                child.gameObject.SetActive(true);
            }
        }

        switch (school)
        {
            case (int)Spell.School.ENKIISM:
                categoryTitleText.text = "Enkiism";
                break;
            case (int)Spell.School.EREBANCY:
                categoryTitleText.text = "Erebancy";
                break;
            case (int)Spell.School.GAIANISM:
                categoryTitleText.text = "Gaianism";
                break;
            case (int)Spell.School.HERMETICISM:
                categoryTitleText.text = "Hermeticism";
                break;
            case (int)Spell.School.IKTOMANCY:
                categoryTitleText.text = "Iktomancy";
                break;
            case (int)Spell.School.RESHEPHISM:
                categoryTitleText.text = "Reshephism";
                break;
        }

        SetEquippableNameTitleText("");
    }

    public void SetEquippableNameTitleText(string itemName)
    {
        equippableNameTitleText.text = itemName;
    }
}
