using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class EquipmentPanel : MonoBehaviour
{
    [Header("Hand Panels")]
    [SerializeField] EquipMenuHandSlot mainHandSlot;
    [SerializeField] EquipMenuHandSlot offHandSlot;
    [SerializeField] EquipMenuHandSlot outfitSlot;
    [SerializeField] EquipMenuHandSlot focusImplantSlot;

    [Header("Grids")]
    [SerializeField] Transform quickEquipGrid;
    [SerializeField] Transform quickAidGrid;

    [Header("Text")]
    [SerializeField] TextMeshProUGUI slotTitleText;
    [SerializeField] TextMeshProUGUI equippableNameText;

    // cached references
    Player player;
    Inventory playerInventory;
    Magic playerMagic;
    Equipment playerEquipment;
    Focus playerFocus;
    QuickAidManager quickAidManager;

    private void Awake()
    {
        quickAidManager = FindObjectOfType<QuickAidManager>();
        player = FindObjectOfType<Player>();
        playerInventory = player.GetComponent<Inventory>();
        playerMagic = player.GetComponent<Magic>();
        playerEquipment = player.GetComponent<Equipment>();
        playerFocus = player.GetComponent<Focus>();
    }

    // Start is called before the first frame update
    void Start()
    {
        LoadHandSlots();
        LoadOutfitSlot();
        LoadFocusImplantSlot();
        LoadQuickEquipSlots();
        LoadQuickAidSlots();
    }

    private void LoadHandSlots()
    {
        // pull equipment and fill slots
        Item mainEquippedItem = playerInventory.GetItemEquippedMain();
        Item offEquippedItem = playerInventory.GetItemEquippedOff();

        Spell mainEquippedSpell = null;
        Spell offEquippedSpell = null;

        if (!mainEquippedItem)
        {
            mainEquippedSpell = playerMagic.GetSpellEquippedMain();
        }

        if (!offEquippedItem)
        {
            offEquippedSpell = playerMagic.GetSpellEquippedOff();
        }

        if (mainEquippedItem)
        {
            LoadSlotWithItem(mainHandSlot, mainEquippedItem, playerInventory.GetIndexOfMainHandWeapon(), Equippable.EquippableType.ITEM);
        }

        if (offEquippedItem)
        {
            LoadSlotWithItem(offHandSlot, offEquippedItem, playerInventory.GetIndexOfOffHandWeapon(), Equippable.EquippableType.ITEM);
        }

        if (mainEquippedSpell)
        {
            LoadSlotWithSpell(mainHandSlot, mainEquippedSpell);
        }

        if (offEquippedSpell)
        {
            LoadSlotWithSpell(offHandSlot, offEquippedSpell);
        }
    }

    private void LoadOutfitSlot()
    {
        Outfit equippedOutfit = playerEquipment.EquippedOutfit;

        if (equippedOutfit)
        {
            LoadSlotWithItem(outfitSlot, equippedOutfit, playerInventory.GetIndexOfEquippedOutfit(), Equippable.EquippableType.ITEM);
        }
    }

    private void LoadFocusImplantSlot()
    {
        Misc equippedImplant = playerFocus.implantItem;

        if (equippedImplant)
        {
            LoadSlotWithItem(focusImplantSlot, equippedImplant, playerInventory.GetIndexOfEquippedFocusImplant(), Equippable.EquippableType.ITEM);
        }
    }

    private void LoadQuickEquipSlots()
    {
        for (int i = 0; i < playerEquipment.QuickEquippables.Length; i++)
        {
            Equippable equippable = playerEquipment.QuickEquippables[i];
            Equippable.EquippableType equippableType = equippable.equippableType;

            if (equippableType != Equippable.EquippableType.NULL)
            {
                Transform child = quickEquipGrid.GetChild(i);

                // turn off sprite swap
                child.GetComponent<HoverVisuals>().spriteSwap = false;

                Image slotImage = child.GetChild(0).GetComponent<Image>();
                slotImage.sprite = equippable.GetSprite();

                // assign item or spell
                EquipMenuHandSlot slot = child.GetComponent<EquipMenuHandSlot>();

                if (equippableType == Equippable.EquippableType.ITEM)
                {
                    slot.item = equippable.item;
                }
                else
                {
                    slot.spell = equippable.spell;
                }

                // set type
                slot.Type = equippableType;
            }
        }
    }

    private void LoadQuickAidSlots()
    {
        for (int i = 0; i < quickAidGrid.childCount; i++)
        {
            if (quickAidManager.QuickAidItems.ContainsKey(i))
            {
                Transform child = quickAidGrid.GetChild(i);

                // Set item
                EquipMenuHandSlot slot = child.GetComponent<EquipMenuHandSlot>();
                slot.item = quickAidManager.QuickAidItems[i].First;

                // turn off sprite swap
                child.GetComponent<HoverVisuals>().spriteSwap = false;

                // Set sprite
                Image slotImage = child.GetChild(0).GetComponent<Image>();
                slotImage.sprite = quickAidManager.QuickAidItems[i].First.Sprite;

                // set equippable type to item so that we can clear the slot
                slot.Type = Equippable.EquippableType.ITEM;
            }
        }
    }

    private void LoadSlotWithItem(EquipMenuHandSlot slot, Item item, int itemIndex, Equippable.EquippableType equipType)
    {
        Image itemImage = slot.transform.GetChild(0).GetComponent<Image>();
        itemImage.sprite = item.Sprite;

        slot.item = item;
        slot.ItemIndex = itemIndex;

        slot.Type = equipType;
    }

    private void LoadSlotWithSpell(EquipMenuHandSlot slot, Spell spell)
    {
        Image spellImage = slot.transform.GetChild(0).GetComponent<Image>();
        spellImage.sprite = spell.SpellSprite;

        slot.spell = spell;

        slot.Type = Equippable.EquippableType.SPELL;
    }

    public void SetEquippableNameTitleText(string equippableName)
    {
        equippableNameText.text = equippableName;
    }

    public void SetSlotTitleText(string slotTitle)
    {
        slotTitleText.text = slotTitle;
    }
}
