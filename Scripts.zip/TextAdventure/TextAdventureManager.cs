using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class TextAdventureManager : MonoBehaviour
{
    [Header("Config")]
    [SerializeField] int maxTextEntries = 20;

    [Header("Cached References")]
    [SerializeField] GameObject textAdventureInterface;
    [SerializeField] Player player;
    [SerializeField] TMP_InputField inputField;
    [SerializeField] RectTransform textGroup;
    [SerializeField] TextMeshProUGUI moveCountText;
    [SerializeField] TextAdventureActions textAdventureActions;

    [Header("Prefabs")]
    [SerializeField] GameObject textTemplate;
    [SerializeField] TextAdventureSyntaxes syntaxList;
    [SerializeField] TextAdventureObject roomsRootObject;

    [Header("Manager State")]
    [SerializeField] bool inTextAdventure;

    [Header("Game Globals")]
    [SerializeField] TextAdventureRoom currentRoom;
    [SerializeField] string parsedVerb;
    [SerializeField] TextAdventureObject parsedDirectObject;
    [SerializeField] TextAdventureObject parsedIndirectObject;
    [SerializeField] string parsedDirection;

    [Header("Player")]
    [SerializeField] List<TextAdventureObject> inventory = new List<TextAdventureObject>();
    [SerializeField] int inventoryCapacity = 10;

    CommandParser parser;
    float gameTimeScale;
    int currentTextEntries;
    int numMoves;

    // word lists
    HashSet<string> verbs = new HashSet<string>();
    HashSet<string> nouns = new HashSet<string>();
    HashSet<string> adjectives = new HashSet<string>();

    // THE WORLD
    TextAdventureObject worldRoot;
    List<TextAdventureRoom> rooms = new List<TextAdventureRoom>();

    public TextAdventureRoom CurrentRoom { get => currentRoom; set => currentRoom = value; }
    public string ParsedVerb { get => parsedVerb; set => parsedVerb = value; }
    public TextAdventureObject ParsedDirectObject { get => parsedDirectObject; set => parsedDirectObject = value; }
    public TextAdventureObject ParsedIndirectObject { get => parsedIndirectObject; set => parsedIndirectObject = value; }
    public string ParsedDirection { get => parsedDirection; set => parsedDirection = value; }
    public List<TextAdventureRoom> Rooms { get => rooms; set => rooms = value; }

    public void StartTextAdventure()
    {
        textAdventureInterface.SetActive(true);

        inTextAdventure = true;

        // set timescale to 0
        gameTimeScale = Time.timeScale;
        Time.timeScale = 0;

        player.Character.Incapacitated = true;

        inputField.Select();

        // Create all runtime objects
        LoadWorld();

        // Set room direction rooms
        LoadRoomDirections();

        // Load data
        LoadVerbs();

        // Create parser
        parser = new CommandParser(verbs, nouns, adjectives);
    }

    public void ExitTextAdventure()
    {
        textAdventureInterface.SetActive(false);

        inTextAdventure = false;

        // set timescale to 0
        Time.timeScale = gameTimeScale;

        player.Character.Incapacitated = false;
    }

    private void Update()
    {
        if (inTextAdventure)
        {
            if (Input.GetKeyDown(KeyCode.Return))
            {
                ReadInput(inputField.text);
            }
        }
    }

    public void ReadInput(string input)
    {
        // Parse commands
        List<ParsedCommand> parsedCommands = parser.Parse(input);

        // Try to perform each command
        foreach (ParsedCommand parsedCommand in parsedCommands)
        {
            // Repeat input
            Print(">" + input + "\n");
            
            // Check for errors
            if (parsedCommand.errorFlag)
            {
                Print(parsedCommand.errorMessage);
            }
            else
            {
                // Set global verb
                parsedVerb = parsedCommand.verb;

                // DEBUG
                //DebugPrintParseDetails(parsedCommand);

                bool matchedSyntax = false;

                // Execute actions
                foreach (TextAdventureSyntax syntax in syntaxList.syntaxes)
                {
                    if (syntax.Matches(parsedCommand))
                    {
                        matchedSyntax = true;

                        if (parsedCommand.directObjects.Count > 0)
                        {
                            // Execute the action for each direct object in the parsed command
                            foreach (ParsedCommand.AdjectiveNounPair directObjectPair in parsedCommand.directObjects)
                            {
                                // Set global objects for actions to use. Execute if found.
                                SetGlobalObjects(directObjectPair, parsedCommand.indirectObject);

                                // Execute
                                textAdventureActions.InvokeAction(syntax.textAdventureAction);
                            }
                        }
                        else
                        {
                            // Execute (only verb)
                            textAdventureActions.InvokeAction(syntax.textAdventureAction);
                        }
                    }
                }

                // Message if no syntax gets matched.
                if (!matchedSyntax)
                {
                    Print("I\'m not sure what you mean by that.");
                }
            }
        }

        // track moves
        numMoves++;
        moveCountText.text = "Moves: " + numMoves.ToString();

        // delete oldest entry if max is exceeded
        if (currentTextEntries >= maxTextEntries)
        {
            Destroy(textGroup.GetChild(0).gameObject);

            currentTextEntries--;
        }

        // reset input field
        inputField.text = "";
        inputField.Select();
        inputField.ActivateInputField();
    }

    void SetGlobalObjects(ParsedCommand.AdjectiveNounPair directObjectPair, ParsedCommand.AdjectiveNounPair indirectObjectPair)
    {
        // Directions check
        if (CommandParser.directions.Contains(directObjectPair.noun))
        {
            parsedDirection = directObjectPair.noun;
        }
        else
        {
            parsedDirection = "";
        }

        // Search the current room for a matching TextAdventureObject for the direct object
        parsedDirectObject = FindObject(currentRoom, directObjectPair);

        // Search the current room for a matching TextAdventureObject for the indirect object
        parsedIndirectObject = FindObject(currentRoom, indirectObjectPair);

        // If null results, check inventory
        if (!parsedDirectObject)
        {
            parsedDirectObject = FindObjectInInventory(directObjectPair);
        }

        if (!parsedIndirectObject)
        {
            parsedIndirectObject = FindObjectInInventory(indirectObjectPair);
        }
    }

    TextAdventureObject FindObject(TextAdventureObject parentObject, ParsedCommand.AdjectiveNounPair adjectiveNounPair)
    {
        // Check if this is the match
        if (parentObject.Synonyms.Contains(adjectiveNounPair.noun) && (parentObject.Adjectives.Contains(adjectiveNounPair.adjective) || adjectiveNounPair.adjective == null))
        {
            return parentObject;
        }

        // Search children
        foreach (TextAdventureObject childObject in parentObject.ChildObjects)
        {
            var result = FindObject(childObject, adjectiveNounPair);
            if (result != null)
            {
                return result;
            }
        }

        // If no children, return null
        return null;
    }

    void LoadWorld()
    {
        worldRoot = Instantiate(roomsRootObject);

        foreach (TextAdventureObject child in worldRoot.DataChildObjects)
        {
            LoadObjectChildren(child, worldRoot);
        }
    }

    void LoadObjectChildren(TextAdventureObject data, TextAdventureObject parent)
    {
        // Instantiate new object
        TextAdventureObject newObject = Instantiate(data);

        // Assign new object to its parent
        AssignParent(newObject, parent);

        // Load this object's adjectives and nouns
        LoadNounsAndAdjectives(newObject);

        // Add rooms to list of rooms
        if (newObject is TextAdventureRoom room)
        {
            if (room.IsStartingRoom)
            {
                CurrentRoom = room;
            }

            Rooms.Add(room);
        }

        // Recurse down for children
        foreach (TextAdventureObject child in newObject.DataChildObjects)
        {
            LoadObjectChildren(child, newObject);
        }
    }

    void AssignParent(TextAdventureObject child, TextAdventureObject parent)
    {
        // Add child to runtime objects
        parent.ChildObjects.Add(child);
        
        // Assign parent
        child.ParentObject = parent;
    }

    void LoadRoomDirections()
    {
        foreach (TextAdventureRoom room in Rooms)
        {
            // Find instantiated room that matches data for each direction
            if (room.NorthRoom.DestinationRoomData)
            {
                room.NorthRoom.DestinationRoom = Rooms.Find(r => r.ObjectName == room.NorthRoom.DestinationRoomData.ObjectName);
            }
            if (room.SouthRoom.DestinationRoomData)
            {
                room.SouthRoom.DestinationRoom = Rooms.Find(r => r.ObjectName == room.SouthRoom.DestinationRoomData.ObjectName);
            }
            if (room.EastRoom.DestinationRoomData)
            {
                room.EastRoom.DestinationRoom = Rooms.Find(r => r.ObjectName == room.EastRoom.DestinationRoomData.ObjectName);
            }
            if (room.WestRoom.DestinationRoomData)
            {
                room.WestRoom.DestinationRoom = Rooms.Find(r => r.ObjectName == room.WestRoom.DestinationRoomData.ObjectName);
            }
            if (room.NortheastRoom.DestinationRoomData)
            {
                room.NortheastRoom.DestinationRoom = Rooms.Find(r => r.ObjectName == room.NortheastRoom.DestinationRoomData.ObjectName);
            }
            if (room.SoutheastRoom.DestinationRoomData)
            {
                room.SoutheastRoom.DestinationRoom = Rooms.Find(r => r.ObjectName == room.SoutheastRoom.DestinationRoomData.ObjectName);
            }
            if (room.NorthwestRoom.DestinationRoomData)
            {
                room.NorthwestRoom.DestinationRoom = Rooms.Find(r => r.ObjectName == room.NorthwestRoom.DestinationRoomData.ObjectName);
            }
            if (room.SouthwestRoom.DestinationRoomData)
            {
                room.SouthwestRoom.DestinationRoom = Rooms.Find(r => r.ObjectName == room.SouthwestRoom.DestinationRoomData.ObjectName);
            }
            if (room.InRoom.DestinationRoomData)
            {
                room.InRoom.DestinationRoom = Rooms.Find(r => r.ObjectName == room.InRoom.DestinationRoomData.ObjectName);
            }
            if (room.OutRoom.DestinationRoomData)
            {
                room.OutRoom.DestinationRoom = Rooms.Find(r => r.ObjectName == room.OutRoom.DestinationRoomData.ObjectName);
            }
            if (room.UpRoom.DestinationRoomData)
            {
                room.UpRoom.DestinationRoom = Rooms.Find(r => r.ObjectName == room.UpRoom.DestinationRoomData.ObjectName);
            }
            if (room.DownRoom.DestinationRoomData)
            {
                room.DownRoom.DestinationRoom = Rooms.Find(r => r.ObjectName == room.DownRoom.DestinationRoomData.ObjectName);
            }
        }
    }

    void BreakChildParentLinks(TextAdventureObject textAdventureObject)
    {
        // Get index of object in parent children
        int objectIndex = textAdventureObject.ParentObject.ChildObjects.FindIndex(s => s.name == textAdventureObject.name);

        // Remove object from parent's children
        if (objectIndex != -1)
        {
            textAdventureObject.ParentObject.ChildObjects.RemoveAt(objectIndex);
        }

        // Remove parent from object
        textAdventureObject.ParentObject = null;
    }

    void LoadVerbs()
    {
        foreach (TextAdventureSyntax syntax in syntaxList.syntaxes)
        {
            verbs.Add(syntax.verb);
        }
    }

    void LoadNounsAndAdjectives(TextAdventureObject textAdventureObject)
    {
        if (textAdventureObject.Synonyms.Count > 0)
        {
            // add nouns
            nouns.UnionWith(textAdventureObject.Synonyms);
        }

        if (textAdventureObject.Adjectives.Count > 0)
        {
            // add adjectives
            adjectives.UnionWith(textAdventureObject.Adjectives);
        }
    }

    /* --- PLAYER --- */
    public int GetCurrentInventorySize()
    {
        int total = 0;

        foreach (TextAdventureObject textAdventureObject in inventory)
        {
            total += textAdventureObject.Size;
        }

        return total;
    }

    public void TakeDirectObject()
    {
        if (GetCurrentInventorySize() + ParsedDirectObject.Size > inventoryCapacity)
        {
            Print("You are carrying too much.");
        }
        else
        {
            // Place object in inventory
            inventory.Add(ParsedDirectObject);

            // Break links
            BreakChildParentLinks(ParsedDirectObject);

            // Add in_inventory flag. Remove other location flags first.
            ParsedDirectObject.ClearLocationFlags();
            ParsedDirectObject.AddLocationFlag(TextAdventureObject.TextAdventureLocationFlags.IN_INVENTORY);

            Print("You add the " + parsedDirectObject.Description + " to your inventory.");
        }
    }

    public void DropDirectObject()
    {
        if (inventory.Contains(ParsedDirectObject))
        {
            // Remove object from inventory
            inventory.Remove(ParsedDirectObject);

            // Place in current room
            AssignParent(ParsedDirectObject, CurrentRoom);

            // Remove location flags. On ground.
            ParsedDirectObject.ClearLocationFlags();
            ParsedDirectObject.AddLocationFlag(TextAdventureObject.TextAdventureLocationFlags.ON_GROUND);

            Print("You drop the " + ParsedDirectObject.Description);
        }
        else
        {
            Print("You can't drop what you don't have.");
        }
    }

    public void ShowInventory()
    {
        if (inventory.Count > 0)
        {
            string inventoryString = "You are carrying:\n";

            foreach (TextAdventureObject textAdventureObject in inventory)
            {
                inventoryString += "  " + textAdventureObject.Description + "\n";
            }

            Print(inventoryString);
        }
        else
        {
            Print("You're not carrying anything.");
        }
    }

    TextAdventureObject FindObjectInInventory(ParsedCommand.AdjectiveNounPair adjectiveNounPair)
    {
        // Search children
        foreach (TextAdventureObject childObject in inventory)
        {
            var result = FindObject(childObject, adjectiveNounPair);
            if (result != null)
            {
                return result;
            }
        }

        // If no children, return null
        return null;
    }

    /* --- PRINTING --- */

    public void Print(string output)
    {
        // instantiate response
        var instantiatedResponse = Instantiate(textTemplate, textGroup);
        TextMeshProUGUI responseTextMesh = instantiatedResponse.GetComponent<TextMeshProUGUI>();

        responseTextMesh.text = output;

        // track text number
        currentTextEntries++;
    }

    void DebugPrintParseDetails(ParsedCommand parsedCommand)
    {
        string directObjects = "";

        foreach (ParsedCommand.AdjectiveNounPair directObject in parsedCommand.directObjects)
        {
            directObjects += directObject.adjective + " " + directObject.noun + ", ";
        }

        // instantiate response
        var instantiatedResponse = Instantiate(textTemplate, textGroup);
        TextMeshProUGUI responseTextMesh = instantiatedResponse.GetComponent<TextMeshProUGUI>();

        // DEBUG: print what was parsed
        if (!parsedCommand.errorFlag)
        {
            responseTextMesh.text += "Verb: " + parsedCommand.verb + " | DO Preposition: " + parsedCommand.directObjectPreposition + " | Direct Objects: " + directObjects + "| IO Preposition: " + parsedCommand.indirectObjectPreposition + " | Indirect Object: " + parsedCommand.indirectObject.adjective + " " + parsedCommand.indirectObject.noun;
        }

        // track text number
        currentTextEntries++;
    }
}
