using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TextAdventureAction
{
    Action action;

    public TextAdventureAction(Action _action)
    {
        action = _action;
    }

    public void Invoke()
    {
        action.Invoke();
    }
}
