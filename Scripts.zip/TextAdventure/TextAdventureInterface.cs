using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TextAdventureInterface : MonoBehaviour
{
    [SerializeField] GameObject exitModal;

    GameObject spawnedExitModal;

    public void SpawnExitModal()
    {
        if (!spawnedExitModal)
        {
            spawnedExitModal = Instantiate(exitModal, transform);
        }
    }
}
