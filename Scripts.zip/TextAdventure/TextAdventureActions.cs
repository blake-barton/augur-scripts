using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TextAdventureActions : MonoBehaviour
{
    public static Dictionary<string, TextAdventureAction> textAdventureActions;

    // action declarations
    public static TextAdventureAction HYPOGEUM;
    public static TextAdventureAction READ;
    public static TextAdventureAction DESCRIBE_ROOM;
    public static TextAdventureAction DESCRIBE_OBJECTS;
    public static TextAdventureAction LOOK;
    public static TextAdventureAction LOOK_INSIDE;
    public static TextAdventureAction EXAMINE;
    public static TextAdventureAction TAKE;
    public static TextAdventureAction INVENTORY;
    public static TextAdventureAction DROP;
    public static TextAdventureAction NORTH;
    public static TextAdventureAction SOUTH;
    public static TextAdventureAction EAST;
    public static TextAdventureAction WEST;
    public static TextAdventureAction NORTHEAST;
    public static TextAdventureAction SOUTHEAST;
    public static TextAdventureAction NORTHWEST;
    public static TextAdventureAction SOUTHWEST;
    public static TextAdventureAction WALK;

    [SerializeField] TextAdventureManager textAdventureManager;

    private void Awake()
    {
        LoadActions();
    }

    public void LoadActions()
    {
        // Print out a debug message
        HYPOGEUM = new TextAdventureAction(() =>
        {
            if (textAdventureManager.CurrentRoom.NorthRoom.Evaluate())
            {
                textAdventureManager.Print("You are playing HYPOGEUM!!!");
            }
        });

        // Print out an object's text field
        READ = new TextAdventureAction(() =>
        {
            if (textAdventureManager.ParsedDirectObject)
            {
                if (textAdventureManager.ParsedDirectObject.HasFlag(TextAdventureObject.TextAdventureObjectFlags.READ))
                {
                    textAdventureManager.Print(textAdventureManager.ParsedDirectObject.Text);
                }
                else
                {
                    textAdventureManager.Print("There's nothing on that to read.");
                }
            }
            else
            {
                textAdventureManager.Print("Read what?");
            }
        });

        // Describe the room and what's in it
        DESCRIBE_ROOM = new TextAdventureAction(() =>
        {
            if (textAdventureManager.CurrentRoom)
            {
                textAdventureManager.Print(textAdventureManager.CurrentRoom.ObjectName);
                textAdventureManager.Print(textAdventureManager.CurrentRoom.LongDescription);
            }
        });

        // Describe objects in current room
        DESCRIBE_OBJECTS = new TextAdventureAction(() =>
        {
            if (textAdventureManager.CurrentRoom)
            {
                foreach (TextAdventureObject childObject in textAdventureManager.CurrentRoom.ChildObjects)
                {
                    if (childObject.HasLocationFlag(TextAdventureObject.TextAdventureLocationFlags.ON_GROUND))
                    {
                        textAdventureManager.Print("There is a " + childObject.Description + " on the ground.");
                    }
                    else
                    {
                        textAdventureManager.Print(childObject.LongDescription);
                    }
                }
            }
        });

        // Get a detailed look at an object
        LOOK = new TextAdventureAction(() =>
        {
            DESCRIBE_ROOM.Invoke();
            DESCRIBE_OBJECTS.Invoke();
        });

        // Get a detailed look at an object
        LOOK_INSIDE = new TextAdventureAction(() =>
        {
            if (textAdventureManager.ParsedDirectObject)
            {
                if (textAdventureManager.ParsedDirectObject.ChildObjects.Count > 0)
                {
                    string childrenString = "";

                    foreach (TextAdventureObject childObject in textAdventureManager.ParsedDirectObject.ChildObjects)
                    {
                        childrenString += "  " + childObject.LongDescription + "\n";
                    }

                    textAdventureManager.Print(childrenString);
                }
                else
                {
                    textAdventureManager.Print("The " + textAdventureManager.ParsedDirectObject.Description + " is empty.");
                }
            }
            else
            {
                textAdventureManager.Print("Perhaps you should look inward.");
            }
        });

        // Get a closer look at an object
        EXAMINE = new TextAdventureAction(() =>
        {
            if (textAdventureManager.ParsedDirectObject)
            {
                // Print long description
                textAdventureManager.Print(textAdventureManager.ParsedDirectObject.LongDescription);

                // If closed, say it's closed
                if (textAdventureManager.ParsedDirectObject.HasFlag(TextAdventureObject.TextAdventureObjectFlags.CLOSED))
                {
                    textAdventureManager.Print("The " + textAdventureManager.ParsedDirectObject.ObjectName + " is closed.");
                }

                // If surface, print what's on it
                if (textAdventureManager.ParsedDirectObject.HasFlag(TextAdventureObject.TextAdventureObjectFlags.SURFACE))
                {
                    if (textAdventureManager.ParsedDirectObject.ChildObjects.Count > 0)
                    {
                        textAdventureManager.Print("On the " + textAdventureManager.ParsedDirectObject.Description + ", you see:");

                        LOOK_INSIDE.Invoke();
                    }
                    else
                    {
                        textAdventureManager.Print("There is nothing on the " + textAdventureManager.ParsedDirectObject.Description + ".");
                    }
                }
            }
            else
            {
                textAdventureManager.Print("You examine the nothing. Not anything to write home about.");
            }
        });

        // Add an item to inventory
        TAKE = new TextAdventureAction(() =>
        {
            if (textAdventureManager.ParsedDirectObject)
            {
                if (textAdventureManager.ParsedDirectObject.HasFlag(TextAdventureObject.TextAdventureObjectFlags.TAKE))
                {
                    textAdventureManager.TakeDirectObject();
                }
                else
                {
                    textAdventureManager.Print("You can't take that!");
                }
            }
            else
            {
                textAdventureManager.Print("Um... take what exactly?");
            }
        });

        // Show inventory
        INVENTORY = new TextAdventureAction(() =>
        {
            textAdventureManager.ShowInventory();
        });

        // Drop item from inventory
        DROP = new TextAdventureAction(() =>
        {
            if (textAdventureManager.ParsedDirectObject)
            {
                textAdventureManager.DropDirectObject();
            }
            else
            {
                textAdventureManager.Print("Yes... and?");
            }
        });

        // Travel north
        NORTH = new TextAdventureAction(() =>
        {
            if (textAdventureManager.CurrentRoom.NorthRoom.DestinationRoom)
            {
                if (textAdventureManager.CurrentRoom.NorthRoom.Evaluate())
                {
                    // Move to north room
                    textAdventureManager.CurrentRoom = textAdventureManager.CurrentRoom.NorthRoom.DestinationRoom;

                    // Look around
                    LOOK.Invoke();
                }
                else
                {
                    textAdventureManager.Print(textAdventureManager.CurrentRoom.NorthRoom.ConditionsNotMetMessage);
                }
            }
            else
            {
                textAdventureManager.Print(textAdventureManager.CurrentRoom.NorthRoom.NoRoomMessage);
            }
        });

        // Travel south
        SOUTH = new TextAdventureAction(() =>
        {
            if (textAdventureManager.CurrentRoom.SouthRoom.DestinationRoom)
            {
                if (textAdventureManager.CurrentRoom.SouthRoom.Evaluate())
                {
                    // Move to north room
                    textAdventureManager.CurrentRoom = textAdventureManager.CurrentRoom.SouthRoom.DestinationRoom;

                    // Look around
                    LOOK.Invoke();
                }
                else
                {
                    textAdventureManager.Print(textAdventureManager.CurrentRoom.SouthRoom.ConditionsNotMetMessage);
                }
            }
            else
            {
                textAdventureManager.Print(textAdventureManager.CurrentRoom.SouthRoom.NoRoomMessage);
            }
        });

        // Travel east
        EAST = new TextAdventureAction(() =>
        {
            if (textAdventureManager.CurrentRoom.EastRoom.DestinationRoom)
            {
                if (textAdventureManager.CurrentRoom.EastRoom.Evaluate())
                {
                    // Move to north room
                    textAdventureManager.CurrentRoom = textAdventureManager.CurrentRoom.EastRoom.DestinationRoom;

                    // Look around
                    LOOK.Invoke();
                }
                else
                {
                    textAdventureManager.Print(textAdventureManager.CurrentRoom.EastRoom.ConditionsNotMetMessage);
                }
            }
            else
            {
                textAdventureManager.Print(textAdventureManager.CurrentRoom.EastRoom.NoRoomMessage);
            }
        });

        // Travel west
        WEST = new TextAdventureAction(() =>
        {
            if (textAdventureManager.CurrentRoom.WestRoom.DestinationRoom)
            {
                if (textAdventureManager.CurrentRoom.WestRoom.Evaluate())
                {
                    // Move to north room
                    textAdventureManager.CurrentRoom = textAdventureManager.CurrentRoom.WestRoom.DestinationRoom;

                    // Look around
                    LOOK.Invoke();
                }
                else
                {
                    textAdventureManager.Print(textAdventureManager.CurrentRoom.WestRoom.ConditionsNotMetMessage);
                }
            }
            else
            {
                textAdventureManager.Print(textAdventureManager.CurrentRoom.WestRoom.NoRoomMessage);
            }
        });

        // Travel northeast
        NORTHEAST = new TextAdventureAction(() =>
        {
            if (textAdventureManager.CurrentRoom.NortheastRoom.DestinationRoom)
            {
                if (textAdventureManager.CurrentRoom.NortheastRoom.Evaluate())
                {
                    // Move to north room
                    textAdventureManager.CurrentRoom = textAdventureManager.CurrentRoom.NortheastRoom.DestinationRoom;

                    // Look around
                    LOOK.Invoke();
                }
                else
                {
                    textAdventureManager.Print(textAdventureManager.CurrentRoom.NortheastRoom.ConditionsNotMetMessage);
                }
            }
            else
            {
                textAdventureManager.Print(textAdventureManager.CurrentRoom.NortheastRoom.NoRoomMessage);
            }
        });

        // Travel southeast
        SOUTHEAST = new TextAdventureAction(() =>
        {
            if (textAdventureManager.CurrentRoom.SoutheastRoom.DestinationRoom)
            {
                if (textAdventureManager.CurrentRoom.SoutheastRoom.Evaluate())
                {
                    // Move to north room
                    textAdventureManager.CurrentRoom = textAdventureManager.CurrentRoom.SoutheastRoom.DestinationRoom;

                    // Look around
                    LOOK.Invoke();
                }
                else
                {
                    textAdventureManager.Print(textAdventureManager.CurrentRoom.SoutheastRoom.ConditionsNotMetMessage);
                }
            }
            else
            {
                textAdventureManager.Print(textAdventureManager.CurrentRoom.SoutheastRoom.NoRoomMessage);
            }
        });

        // Travel northwest
        NORTHWEST = new TextAdventureAction(() =>
        {
            if (textAdventureManager.CurrentRoom.NorthwestRoom.DestinationRoom)
            {
                if (textAdventureManager.CurrentRoom.NorthwestRoom.Evaluate())
                {
                    // Move to north room
                    textAdventureManager.CurrentRoom = textAdventureManager.CurrentRoom.NorthwestRoom.DestinationRoom;

                    // Look around
                    LOOK.Invoke();
                }
                else
                {
                    textAdventureManager.Print(textAdventureManager.CurrentRoom.NorthwestRoom.ConditionsNotMetMessage);
                }
            }
            else
            {
                textAdventureManager.Print(textAdventureManager.CurrentRoom.NorthwestRoom.NoRoomMessage);
            }
        });

        // Travel southwest
        SOUTHWEST = new TextAdventureAction(() =>
        {
            if (textAdventureManager.CurrentRoom.SouthwestRoom.DestinationRoom)
            {
                if (textAdventureManager.CurrentRoom.SouthwestRoom.Evaluate())
                {
                    // Move to north room
                    textAdventureManager.CurrentRoom = textAdventureManager.CurrentRoom.SouthwestRoom.DestinationRoom;

                    // Look around
                    LOOK.Invoke();
                }
                else
                {
                    textAdventureManager.Print(textAdventureManager.CurrentRoom.SouthwestRoom.ConditionsNotMetMessage);
                }
            }
            else
            {
                textAdventureManager.Print(textAdventureManager.CurrentRoom.SouthwestRoom.NoRoomMessage);
            }
        });

        // Travel in a direction
        WALK = new TextAdventureAction(() =>
        {
            switch (textAdventureManager.ParsedDirection)
            {
                case "north":
                    NORTH.Invoke();
                    break;
                case "south":
                    SOUTH.Invoke();
                    break;
                case "east":
                    EAST.Invoke();
                    break;
                case "west":
                    WEST.Invoke();
                    break;
                case "northeast":
                    NORTHEAST.Invoke();
                    break;
                case "southeast":
                    SOUTHEAST.Invoke();
                    break;
                case "northwest":
                    NORTHWEST.Invoke();
                    break;
                case "southwest":
                    SOUTHWEST.Invoke();
                    break;
                default:
                    textAdventureManager.Print("Maybe try inputting a direction.");
                    break;
            }
        });

        textAdventureActions = new Dictionary<string, TextAdventureAction>()
        {
            { "HYPOGEUM", HYPOGEUM },
            { "READ", READ },
            { "DESCRIBE_ROOM", DESCRIBE_ROOM },
            { "DESCRIBE_OBJECTS", DESCRIBE_OBJECTS },
            { "LOOK", LOOK },
            { "LOOK_INSIDE", LOOK_INSIDE },
            { "EXAMINE", EXAMINE },
            { "TAKE", TAKE },
            { "INVENTORY", INVENTORY },
            { "DROP", DROP },
            { "NORTH", NORTH },
            { "SOUTH", SOUTH },
            { "EAST", EAST },
            { "WEST", WEST },
            { "NORTHEAST", NORTHEAST },
            { "SOUTHEAST", SOUTHEAST },
            { "NORTHWEST", NORTHWEST },
            { "SOUTHWEST", SOUTHWEST },
            { "WALK", WALK },
        };
    }

    public void InvokeAction(string action)
    {
        if (textAdventureActions.ContainsKey(action))
        {
            textAdventureActions[action].Invoke();
        }
    }
}
