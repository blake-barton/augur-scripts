using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TextAdventureExitModal : MonoBehaviour
{
    TextAdventureManager textAdventureManager;

    private void Awake()
    {
        textAdventureManager = FindObjectOfType<TextAdventureManager>();
    }

    public void Exit()
    {
        textAdventureManager.ExitTextAdventure();

        Destroy(gameObject);
    }
}
