using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class TextAdventureSyntax
{
    public string verb;
    public string directObjectPreposition;
    public bool hasDirectObject;
    public List<TextAdventureObject.TextAdventureObjectFlags> directObjectFlags;
    public List<TextAdventureObject.TextAdventureLocationFlags> directObjectLocationFlags;
    public string indirectObjectPreposition;
    public bool hasIndirectObject;
    public List<TextAdventureObject.TextAdventureObjectFlags> indirectObjectFlags;
    public List<TextAdventureObject.TextAdventureLocationFlags> indirectObjectLocationFlags;
    public List<string> verbSynonyms;
    public string textAdventureAction;

    public bool Matches(ParsedCommand parsedCommand)
    {
        //Debug.Log("Checking for match on syntax: " + verb);

        // Check verb and error flag
        if (parsedCommand.errorFlag)
        {
            //Debug.Log("Error flag");
            return false;
        }

        if (!parsedCommand.verb.Equals(verb))
        {
            //Debug.Log("Verb doesn't match.");
            return false;
        }

        // If the command has a DOP, check that it matches
        if (parsedCommand.directObjectPreposition != null)
        {
            if (parsedCommand.directObjectPreposition != directObjectPreposition)
            {
                //Debug.Log("DOP mismatch.");
                return false;
            }
        }

        // Return false if there is no direct object but syntax needs one
        if (parsedCommand.directObjects.Count == 0 && hasDirectObject)
        {
            //Debug.Log("Syntax needs direct object.");
            return false;
        }

        // Return false if there is a direct object but syntax doesn't accept one
        if (parsedCommand.directObjects.Count > 0 && !hasDirectObject)
        {
            //Debug.Log("Syntax does not have direct objects. First direction object noun: " + parsedCommand.directObjects[0].noun);
            return false;
        }

        // Check direct object flags

        // If the command has an IOP, check that it matches

        // Indirect object

        //Debug.Log("Matched Syntax! - " + verb);

        return true;
    }
}
