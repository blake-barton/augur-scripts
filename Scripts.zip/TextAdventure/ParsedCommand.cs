using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ParsedCommand
{
    public struct AdjectiveNounPair
    {
        public string adjective;
        public string noun;
    }

    public string verb;
    public string directObjectPreposition;
    public List<AdjectiveNounPair> directObjects = new List<AdjectiveNounPair>();
    public string indirectObjectPreposition;
    public AdjectiveNounPair indirectObject;
    public bool errorFlag = false;
    public string errorMessage;
}
