using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "TextAdventure/Room")]
public class TextAdventureRoom : TextAdventureObject
{
    [Header("Room")]
    [SerializeField] bool isStartingRoom;
    [SerializeField] TextAdventureDirectionFunction northRoom;
    [SerializeField] TextAdventureDirectionFunction southRoom;
    [SerializeField] TextAdventureDirectionFunction eastRoom;
    [SerializeField] TextAdventureDirectionFunction westRoom;
    [SerializeField] TextAdventureDirectionFunction northwestRoom;
    [SerializeField] TextAdventureDirectionFunction southwestRoom;
    [SerializeField] TextAdventureDirectionFunction northeastRoom;
    [SerializeField] TextAdventureDirectionFunction southeastRoom;
    [SerializeField] TextAdventureDirectionFunction inRoom;
    [SerializeField] TextAdventureDirectionFunction outRoom;
    [SerializeField] TextAdventureDirectionFunction upRoom;
    [SerializeField] TextAdventureDirectionFunction downRoom;

    public TextAdventureDirectionFunction NorthRoom { get => northRoom; set => northRoom = value; }
    public TextAdventureDirectionFunction SouthRoom { get => southRoom; set => southRoom = value; }
    public TextAdventureDirectionFunction EastRoom { get => eastRoom; set => eastRoom = value; }
    public TextAdventureDirectionFunction WestRoom { get => westRoom; set => westRoom = value; }
    public TextAdventureDirectionFunction NorthwestRoom { get => northwestRoom; set => northwestRoom = value; }
    public TextAdventureDirectionFunction SouthwestRoom { get => southwestRoom; set => southwestRoom = value; }
    public TextAdventureDirectionFunction NortheastRoom { get => northeastRoom; set => northeastRoom = value; }
    public TextAdventureDirectionFunction SoutheastRoom { get => southeastRoom; set => southeastRoom = value; }
    public TextAdventureDirectionFunction InRoom { get => inRoom; set => inRoom = value; }
    public TextAdventureDirectionFunction OutRoom { get => outRoom; set => outRoom = value; }
    public TextAdventureDirectionFunction UpRoom { get => upRoom; set => upRoom = value; }
    public TextAdventureDirectionFunction DownRoom { get => downRoom; set => downRoom = value; }
    public bool IsStartingRoom { get => isStartingRoom; set => isStartingRoom = value; }
}
