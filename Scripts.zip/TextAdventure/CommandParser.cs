using System.Collections;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using UnityEngine;

public class CommandParser
{
    private HashSet<string> verbs = new HashSet<string>();
    private HashSet<string> nouns = new HashSet<string>();
    private static readonly HashSet<string> prepositions = new HashSet<string> { "to", "at", "up", "into", "using", "with" };
    private static readonly HashSet<string> articles = new HashSet<string> { "a", "an", "the" };
    private static readonly HashSet<string> commandSeparators = new HashSet<string> { ".", "then" };
    private static readonly HashSet<string> nounSeparators = new HashSet<string> { ",", "and" };
    public static readonly HashSet<string> directions = new HashSet<string> { "north", "south", "east", "west", "northeast", "southeast", "northwest", "southwest", "n", "s", "e", "w", "ne", "se", "nw", "sw", "up", "down", "in", "out" };
    private HashSet<string> adjectives = new HashSet<string>();

    Queue<string> tokens = new Queue<string>();
    string currentToken;
    List<ParsedCommand> parsedCommands = new List<ParsedCommand>();

    public CommandParser(HashSet<string> _verbs, HashSet<string> _nouns, HashSet<string> _adjectives) 
    {
        verbs = _verbs;
        nouns = _nouns;
        adjectives = _adjectives;

        // Add directions to nouns
        nouns.UnionWith(directions);
    }

    public List<ParsedCommand> Parse(string input)
    {
        // Empty any previously parsed commands
        parsedCommands.Clear();

        // Empty the tokens list
        tokens.Clear();

        // ignore case
        input = input.ToLowerInvariant();

        // create tokens of words, numbers, and punctuation
        string pattern = @"(?:(?!\d)\w)+|\S+";
        Regex regex = new Regex(pattern);
        MatchCollection matches = regex.Matches(input);

        foreach (var match in matches)
        {
            tokens.Enqueue(match.ToString());
            Debug.Log(match.ToString());
        }

        // Start by popping the first token
        PopNextToken();

        // Start parsing with CommandSet
        CommandSet();

        Debug.Log("Done parsing. Size of parsed commands is: " + parsedCommands.Count);

        return parsedCommands;
    }

    void PopNextToken()
    {
        if (tokens.Count > 0)
        {
            currentToken = tokens.Dequeue();
            Debug.Log("Current token: " + currentToken);
        }
    }

    void CommandSet()
    {
        // Begin with command
        Command();

        // Optional next command set starts with command separator. Ignore trailing punctuation.
        if (commandSeparators.Contains(currentToken) && tokens.Count > 0)
        {
            CommandSeparator();

            CommandSet();
        }
    }

    void Command()
    {
        // Create a struct for this command
        ParsedCommand parsedCommand = new ParsedCommand();

        // Get verb
        if (Verb(parsedCommand))
        {
            // Optional direct object preposition
            if (prepositions.Contains(currentToken))
            {
                Preposition(parsedCommand, true);
            }

            // Optional direct object(s)
            if (nouns.Contains(currentToken) || adjectives.Contains(currentToken))
            {
                NounSet(parsedCommand, true);

                // Optional indirect objects
                if (prepositions.Contains(currentToken))
                {
                    // Indirect object preposition
                    Preposition(parsedCommand, false);

                    // Indirect object
                    Noun(parsedCommand, false);
                }
            }
        }

        // Add this command to the list
        parsedCommands.Add(parsedCommand);
    }

    // Terminal -- true = good, false = bad
    bool Verb(ParsedCommand parsedCommand)
    {
        if (verbs.Contains(currentToken))
        {
            // assign verb to parsedCommand
            parsedCommand.verb = currentToken;

            // next token
            PopNextToken();

            return true;
        }
        else
        {
            Debug.Log("Verb error on token: " + currentToken);

            parsedCommand.errorFlag = true;
            parsedCommand.errorMessage = "That's not a verb!";
            return false;
        }
    }

    // Terminal
    void Preposition(ParsedCommand parsedCommand, bool isDirectObject)
    {
        if (prepositions.Contains(currentToken))
        {
            // add preposition to command
            if (isDirectObject)
            {
                parsedCommand.directObjectPreposition = currentToken;
            }
            else
            {
                parsedCommand.indirectObjectPreposition = currentToken;
            }

            // next token
            PopNextToken();
        }
    }

    // Terminal
    void CommandSeparator()
    {
        if (commandSeparators.Contains(currentToken))
        {
            // ignore command seperator
            PopNextToken();
        }
    }

    void NounSet(ParsedCommand parsedCommand, bool isDirectObject)
    {
        // Required noun
        Noun(parsedCommand, isDirectObject);

        // Optional noun separator
        if (nounSeparators.Contains(currentToken))
        {
            NounSeparator();

            NounSet(parsedCommand, isDirectObject);
        }
    }

    bool Noun(ParsedCommand parsedCommand, bool isDirectObject)
    {
        // Optional article
        if (articles.Contains(currentToken))
        {
            Article();
        }

        ParsedCommand.AdjectiveNounPair newAdjectiveNounPair = new ParsedCommand.AdjectiveNounPair();

        // Optional adjective
        if (adjectives.Contains(currentToken))
        {
            newAdjectiveNounPair.adjective = Adjective(newAdjectiveNounPair);
        }

        // Add noun to adjectiveNounPair if it is in the noun set
        if (nouns.Contains(currentToken))
        {
            newAdjectiveNounPair.noun = currentToken;

            // Assign as direct or indirect object
            if (isDirectObject)
            {
                parsedCommand.directObjects.Add(newAdjectiveNounPair);
            }
            else
            {
                parsedCommand.indirectObject = newAdjectiveNounPair;
            }

            // next token
            PopNextToken();

            return true;
        }
        else
        {
            parsedCommand.errorFlag = true;
            parsedCommand.errorMessage = "I don't know what a " + currentToken + " is.";
            return false;
        }
    }

    // Terminal
    void NounSeparator()
    {
        if (nounSeparators.Contains(currentToken))
        {
            // ignore noun separator
            PopNextToken();
        }
    }

    // terminal
    void Article()
    {
        if (articles.Contains(currentToken))
        {
            // ignore article
            PopNextToken();
        }
    }

    string Adjective(ParsedCommand.AdjectiveNounPair adjectiveNounPair)
    {
        if (adjectives.Contains(currentToken))
        {
            string returnString = currentToken;

            // next token
            PopNextToken();

            return returnString;
        }

        return null;
    }
}
