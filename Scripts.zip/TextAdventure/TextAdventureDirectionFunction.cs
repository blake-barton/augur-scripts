using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class TextAdventureDirectionFunction
{
    [SerializeField] TextAdventureRoom destinationRoomData;
    [SerializeField] string noRoomMessage = "You can\'t go that way.";
    [SerializeField] string conditionsNotMetMessage = "You can\'t go that way.";

    TextAdventureRoom destinationRoom;

    public TextAdventureRoom DestinationRoom { get => destinationRoom; set => destinationRoom = value; }
    public string NoRoomMessage { get => noRoomMessage; set => noRoomMessage = value; }
    public string ConditionsNotMetMessage { get => conditionsNotMetMessage; set => conditionsNotMetMessage = value; }
    public TextAdventureRoom DestinationRoomData { get => destinationRoomData; set => destinationRoomData = value; }

    public bool Evaluate()
    {
        return true;
    }
}
