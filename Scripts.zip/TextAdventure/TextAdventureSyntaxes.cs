using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "TextAdventure/SyntaxList")]
public class TextAdventureSyntaxes : ScriptableObject
{
    public List<TextAdventureSyntax> syntaxes = new List<TextAdventureSyntax>();
}
