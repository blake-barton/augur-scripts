using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

[CreateAssetMenu(menuName = "TextAdventure/GameObject")]
public class TextAdventureObject : ScriptableObject
{
    public enum TextAdventureObjectFlags
    {
        ACTOR,
        BURN,
        CLIMB,
        CLOSED,
        CONTAINER,
        DOOR,
        DRINK,
        FOOD,
        LOCKED,
        ON,
        OPEN,
        READ,
        ROOM_LAND,
        SACRED,
        SEARCH,
        SURFACE,
        TAKE,
        TRANSPORT,
        TURN,
        UNLOCKED,
        WEAPON
    }

    public enum TextAdventureLocationFlags
    {
        IN_INVENTORY,
        ON_GROUND,
    }

    [SerializeField] string objectName;
    [SerializeField] TextAdventureObject parentObject;
    [SerializeField] List<TextAdventureObject> dataChildObjects;
    [SerializeField] List<string> synonyms = new List<string>();
    [SerializeField] List<string> adjectives = new List<string>();
    [SerializeField] string description;

    [TextArea(5, 10)]
    [SerializeField] string longDescription;

    [TextArea(5, 10)]
    [SerializeField] string firstDescription;   // For while item is still untouched
    [SerializeField] int capacity;
    [SerializeField] int strength;
    [SerializeField] int size;
    [SerializeField] int value;
    [SerializeField] int tradeValue;

    [TextArea(5, 10)]
    [SerializeField] string text;

    [Header("Flags")]
    [SerializeField] List<TextAdventureObjectFlags> flags = new List<TextAdventureObjectFlags>();
    [SerializeField] List<TextAdventureLocationFlags> locationFlags = new List<TextAdventureLocationFlags>();

    [Header("Action")]
    [SerializeField] string textAdventureAction;

    // Runtime
    List<TextAdventureObject> childObjects = new List<TextAdventureObject>();

    public string ObjectName { get => objectName; set => objectName = value; }
    public TextAdventureObject ParentObject { get => parentObject; set => parentObject = value; }
    public List<TextAdventureObject> DataChildObjects { get => dataChildObjects; set => dataChildObjects = value; }
    public List<string> Synonyms { get => synonyms; set => synonyms = value; }
    public List<string> Adjectives { get => adjectives; set => adjectives = value; }
    public string Description { get => description; set => description = value; }
    public string LongDescription { get => longDescription; set => longDescription = value; }
    public string FirstDescription { get => firstDescription; set => firstDescription = value; }
    public int Capacity { get => capacity; set => capacity = value; }
    public int Strength { get => strength; set => strength = value; }
    public int Size { get => size; set => size = value; }
    public int Value { get => value; set => this.value = value; }
    public int TradeValue { get => tradeValue; set => tradeValue = value; }
    public string Text { get => text; set => text = value; }
    public string TextAdventureAction { get => textAdventureAction; set => textAdventureAction = value; }
    public List<TextAdventureObjectFlags> Flags { get => flags; set => flags = value; }
    public List<TextAdventureLocationFlags> LocationFlags { get => locationFlags; set => locationFlags = value; }
    public List<TextAdventureObject> ChildObjects { get => childObjects; set => childObjects = value; }

    public bool HasFlags(List<TextAdventureObjectFlags> inFlags)
    {
        return !flags.Except(inFlags).Any();
    }

    public bool HasFlag(TextAdventureObjectFlags inFlag)
    {
        return flags.Contains(inFlag);
    }

    public bool HasLocationFlags(List<TextAdventureLocationFlags> inFlags)
    {
        return !locationFlags.Except(inFlags).Any();
    }

    public bool HasLocationFlag(TextAdventureLocationFlags inFlag)
    {
        return locationFlags.Contains(inFlag);
    }

    public bool AddFlag(TextAdventureObjectFlags inFlag)
    {
        // Add flag if not already there
        if (!Flags.Contains(inFlag))
        {
            Flags.Add(inFlag);

            return true;
        }

        return false;
    }

    public bool AddLocationFlag(TextAdventureLocationFlags inFlag)
    {
        // Add flag if not already there
        if (!LocationFlags.Contains(inFlag))
        {
            LocationFlags.Add(inFlag);

            return true;
        }

        return false;
    }

    public bool RemoveFlag(TextAdventureObjectFlags inFlag)
    {
        return Flags.Remove(inFlag);
    }

    public bool RemoveLocationFlag(TextAdventureLocationFlags inFlag)
    {
        return LocationFlags.Remove(inFlag);
    }

    public void ClearFlags()
    {
        Flags.Clear();
    }

    public void ClearLocationFlags()
    {
        LocationFlags.Clear();
    }
}
