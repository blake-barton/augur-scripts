using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LeadMagnetismShield : MonoBehaviour
{
    [SerializeField] string collideTag = "BallisticProjectile";
    [SerializeField] float newProjectileMaxRange = 100f;
    [SerializeField] float newProjectileEffectiveRange = 100f;
    [SerializeField] float newProjectileSpeed = 15f;

    [SerializeField] [Range(0, 32)] int holdingLayer = 0;
    [SerializeField] [Range(0, 32)] int throwingLayer = 8;

    List<ProjectileStandard> heldProjectiles = new List<ProjectileStandard>();

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag(collideTag))
        {
            collision.gameObject.layer = holdingLayer;

            ProjectileStandard projectile = collision.gameObject.GetComponent<ProjectileStandard>();

            heldProjectiles.Add(projectile);

            projectile.speed = 0f;
            projectile.maxRange = newProjectileMaxRange;
            projectile.effectiveRange = newProjectileEffectiveRange;

            FreezeObjectRelativeToTarget freezer = projectile.GetComponent<FreezeObjectRelativeToTarget>();
            freezer.enabled = true;

            Transform playerTransform = FindObjectOfType<Player>().transform;
            freezer.target = playerTransform;
            freezer.offset = projectile.transform.position - playerTransform.position;
        }
    }

    public void ReleaseProjectiles(float damageMultiplier)
    {
        foreach (ProjectileStandard projectile in heldProjectiles)
        {
            if (projectile != null)
            {
                projectile.GetComponent<FreezeObjectRelativeToTarget>().enabled = false;
                projectile.speed = newProjectileSpeed;
                projectile.direction = (projectile.transform.position - transform.position).normalized;
                projectile.GetComponent<DamageDealer>().MultiplyAllDamage(damageMultiplier);
                projectile.gameObject.layer = throwingLayer;
            }
        }
    }
}