using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FreezeObjectRelativeToTarget : MonoBehaviour
{
    public Transform target;
    public Vector2 offset;

    private void Update()
    {
        transform.position = target.position + (Vector3)offset;
    }
}
