using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LeadMagnetism : SpellScript
{
    [Header("Lead Magnetism")]
    [SerializeField] GameObject leadMagnetismShieldTemplate;
    GameObject spawnedLeadMagnetismShield;

    public override void ConstantCast()
    {
        spawnedLeadMagnetismShield = Instantiate(leadMagnetismShieldTemplate, player.transform);
    }

    public override void StopConstantCast()
    {
        if (spawnedLeadMagnetismShield)
        {
            spawnedLeadMagnetismShield.GetComponent<LeadMagnetismShield>().ReleaseProjectiles(playerAttributes.gaianismMod);
            Destroy(spawnedLeadMagnetismShield);
        }
    }
}
