using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ProjectileSpell : SpellScript
{
    [SerializeField] GameObject projectile;
    [SerializeField] Vector3 projectileOffset = new Vector3(0, 0, 0);
    [SerializeField] float projectileSpeed = 10f;
    [SerializeField] float maxRange = 15f;
    [SerializeField] bool canHitMultipleTargets = false;

    public override void Cast()
    {
        // subtract mp
        base.Cast();

        SpawnProjectile();
    }

    private void SpawnProjectile()
    {
        GameObject firedProjectile = Instantiate(projectile, transform.position + projectileOffset, equippedSpell.pivot.rotation);

        SetProjectileAttributes(firedProjectile);
    }

    private void SetProjectileAttributes(GameObject firedProjectile)
    {
        float zAngle = firedProjectile.transform.rotation.eulerAngles.z * (Mathf.PI / 180f);
        float xComponent = Mathf.Cos(zAngle);
        float yComponent = Mathf.Sin(zAngle);
        Vector2 pivotDirection = new Vector2(xComponent, yComponent);

        firedProjectile.GetComponent<SpellProjectileBase>().SetAttributes(equippedSpell.Owner, projectileSpeed, maxRange, canHitMultipleTargets, pivotDirection);
    }
}
