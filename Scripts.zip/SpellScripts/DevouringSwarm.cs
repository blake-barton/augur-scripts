using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DevouringSwarm : SpellScript
{
    public override void Cast()
    {
        // subtract mp
        base.Cast();

        Debug.Log("Devouring swarm cast!");
    }
}
