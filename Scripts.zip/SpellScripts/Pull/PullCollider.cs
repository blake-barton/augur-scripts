using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PullCollider : MonoBehaviour
{
    public float forceMagnitude = 1f;

    List<Rigidbody2D> enemyRigidBodies = new List<Rigidbody2D>();

    private void FixedUpdate()
    {
        foreach (Rigidbody2D rb in enemyRigidBodies)
        {
            Vector2 forceDirection = (transform.position - rb.transform.position).normalized;

            rb.AddForce(forceMagnitude * forceDirection);
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Enemy"))
        {
            Rigidbody2D rb = collision.GetComponent<Rigidbody2D>();
            enemyRigidBodies.Add(rb);

            Enemy enemy = collision.GetComponent<Enemy>();

            if (enemy)
            {
                enemy.Flying = true;
            }
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Enemy"))
        {
            Rigidbody2D rb = collision.GetComponent<Rigidbody2D>();
            enemyRigidBodies.Remove(rb);

            Enemy enemy = collision.GetComponent<Enemy>();

            if (enemy)
            {
                enemy.Flying = false;
            }
        }
    }
}
