using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pull : SpellScript
{
    [Header("Pull")]
    [SerializeField] GameObject pullColliderTemplate;
    GameObject spawnedPullCollider;

    public override void ConstantCast()
    {
        spawnedPullCollider = Instantiate(pullColliderTemplate, player.transform);
    }

    public override void StopConstantCast()
    {
        Destroy(spawnedPullCollider);
    }
}