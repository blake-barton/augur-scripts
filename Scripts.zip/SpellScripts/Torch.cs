using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class Torch : SpellScript
{
    [Header("Torch")]
    [SerializeField] ParticleSystem particles;
    [SerializeField] float tickTime = 1f;
    [SerializeField] bool ticking = false;

    [Header("Damages")]
    [SerializeField] List<float> damages = new List<float>();
    [SerializeField] List<DamageEffects.DamageType> damageTypes = new List<DamageEffects.DamageType>();

    [Header("Status Effects")]
    [SerializeField] int damageTicks;
    [SerializeField] int ticksPerSecond;
    [SerializeField] float statusEffectDamagePercentage = .1f;

    List<float> modifiedDamages = new List<float>();

    PolygonCollider2D hitbox;
    DamageDealer damageDealer;

    float timer = 0f;
    List<Collider2D> enemyColldiers = new List<Collider2D>();

    protected override void Awake()
    {
        base.Awake();

        hitbox = GetComponent<PolygonCollider2D>();
        damageDealer = GetComponent<DamageDealer>();
    }

    protected override void Start()
    {
        base.Start();

        particles.Stop();
        hitbox.enabled = false;

        // attribute modification
        CopyDamageListToModified();
        MultiplyAllDamageBySpellSchoolModifier(equippedSpell.Spell.RequiredSkill);

        // set damage and critical hit properties
        damageDealer.CopyDamageList(modifiedDamages);
        damageDealer.CopyDamageTypeList(damageTypes);
        //damageDealer.CritChance = playerAttributes.critChance;
        //damageDealer.CritMultiplier = playerAttributes.critDamageMultiplier;                          // commented out because crits make it too powerful
        damageDealer.SetStatusEffectDamagePercentage(statusEffectDamagePercentage);
    }

    void Update()
    {
        if (ticking)
        {
            timer += Time.deltaTime;

            if (timer >= tickTime)
            {
                timer = 0;
                Tick();
            }
        }
    }

    public override void ConstantCast()
    {
        particles.Play();
        hitbox.enabled = true;
        ticking = true;
    }

    public override void StopConstantCast()
    {
        particles.Stop();
        hitbox.enabled = false;
        ticking = false;
        timer = 0;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        Enemy enemy = collision.GetComponent<Enemy>();

        if (enemy)
        {
            enemyColldiers.Add(collision);
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        enemyColldiers.Remove(collision);
    }

    void Tick()
    {
        foreach (Collider2D enemyCollider in enemyColldiers)
        {
            damageDealer.CauseTorchDamage(enemyCollider, equippedSpell.Owner, null);
        }
    }

    private void MultiplyAllDamageBySpellSchoolModifier(AttributeScores.Skills school)
    {
        float damageMultiplier = 1;

        switch (school)
        {
            case AttributeScores.Skills.ENKIISM:
                damageMultiplier = playerAttributes.enkiismMod;
                break;
            case AttributeScores.Skills.EREBANCY:
                damageMultiplier = playerAttributes.erebancyMod;
                break;
            case AttributeScores.Skills.GAIANISM:
                damageMultiplier = playerAttributes.gaianismMod;
                break;
            case AttributeScores.Skills.HERMETICISM:
                damageMultiplier = playerAttributes.hermeticismMod;
                break;
            case AttributeScores.Skills.IKTOMANCY:
                damageMultiplier = playerAttributes.iktomancyMod;
                break;
            case AttributeScores.Skills.RESHEPHISM:
                damageMultiplier = playerAttributes.reshephismMod;
                break;
        }

        for (int i = 0; i < modifiedDamages.Count; i++)
        {
            modifiedDamages[i] = modifiedDamages[i] * damageMultiplier;
        }
    }

    private void CopyDamageListToModified()
    {
        modifiedDamages.Clear();

        foreach (float oldDamage in damages)
        {
            modifiedDamages.Add(oldDamage);
        }
    }
}
