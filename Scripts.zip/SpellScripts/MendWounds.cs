using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MendWounds : SpellScript
{
    [SerializeField] float startingHealthPerSecond = 5;
    [SerializeField] float healthPerSecond = 5;

    Health health;

    public override void ConstantCast()
    {
        health = player.GetComponent<Health>();
        healthPerSecond = startingHealthPerSecond * playerAttributes.hermeticismMod;

        health.IncreaseRegenPerSecond(healthPerSecond);
    }

    public override void StopConstantCast()
    {
        health.DecreaseRegenPerSecond(healthPerSecond);
    }
}
