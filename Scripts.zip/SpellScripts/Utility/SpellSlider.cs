using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SpellSlider : MonoBehaviour
{
    [Header("Properties")]
    [SerializeField] float backgroundWidth;
    [SerializeField] float backgroundHeight = 5f;

    [Header("Positioning")]
    public bool isMainHand = false;
    [SerializeField] Vector2 mainHandOffset = new Vector2();
    [SerializeField] Vector2 offHandOffset = new Vector2();

    [Header("Bars")]
    [SerializeField] RectTransform handleSlideArea;
    [SerializeField] RectTransform background;

    // cached references
    [SerializeField] Player player;
    [SerializeField] RectTransform sliderTransform;
    [SerializeField] Slider slider;

    // state
    [SerializeField] bool castComplete = false;

    private void Awake()
    {
        sliderTransform = GetComponent<RectTransform>();
        player = FindObjectOfType<Player>();
        slider = GetComponent<Slider>();
    }

    // Start is called before the first frame update
    void Start()
    {
        FormatBar();
    }

    // Update is called once per frame
    void Update()
    {
        LockToPlayer();

        if (!castComplete)
        {
            // immediately start moving the handle
            slider.value = Time.time;
        }
    }

    // handles the size of the background and slider
    public void FormatBar()
    {
        // size background
        background.sizeDelta = new Vector2(backgroundWidth, backgroundHeight);

        // size slider
        sliderTransform.sizeDelta = new Vector2(backgroundWidth, backgroundHeight);
    }

    private void LockToPlayer()
    {
        // lock position to player if player exists
        if (isMainHand)
        {
            if (player)
            {
                transform.position = Camera.main.WorldToScreenPoint((Vector2)player.transform.position + mainHandOffset);
            }
            else
            {
                Destroy(gameObject);
            }
        }
        else
        {
            if (player)
            {
                transform.position = Camera.main.WorldToScreenPoint((Vector2)player.transform.position + offHandOffset);
            }
            else
            {
                Destroy(gameObject);
            }
        }
    }

    public void SetParameters(bool isMainHand, float castTime)
    {
        // determines placement of slider
        this.isMainHand = isMainHand;

        // set speed of handle based on reload speed
        slider.minValue = Time.time;
        slider.maxValue = Time.time + castTime;
    }

    // returns true if the slider value is maxed out
    public bool CheckIfFinished()
    {
        // freeze slider
        castComplete = true;
        slider.value = slider.value;    // this might not be necessary?

        if (slider.value < slider.maxValue)
        {
            return false;
        }
        else
        {
            return true;
        }
    }
}