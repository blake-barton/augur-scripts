using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class SpellScript : WeaponScript
{
    [Header("Spell Slider")]
    [SerializeField] protected GameObject spellSliderTemplate;
    protected GameObject spellSlider;

    [Header("Sound")]
    [SerializeField] protected AudioSource audioSource;
    [SerializeField] AudioClip chargeSound;
    [SerializeField] [Range(0, 1)] float chargeVolume = 1f;
    [SerializeField] AudioClip castSound;
    [SerializeField] [Range(0, 1)] float castVolume = 1f;
    [SerializeField] AudioClip constantCastLoopSound;
    [SerializeField] [Range(0, 1)] float constantCastLoopSoundVolume = 1f;
    [SerializeField] AudioClip constantCastEndSound;
    [SerializeField] [Range(0, 1)] float constantCastEndSoundVolume = 1f;

    [Header("State")]
    [SerializeField] bool isCharging = false;
    [SerializeField] bool isConstantCasting = false;

    [Header("Particles")]
    [SerializeField] float angleIncrease = 10f;
    [SerializeField] float startLifetimeIncrease = 5f;
    [SerializeField] float startSpeedIncrease = 5f;
    [SerializeField] float startSizeIncrease = 0.4f;

    [Header("Skill Requirement Modifiers")]
    [SerializeField] float inadequateSkillMpCostMod = 3f;
    [SerializeField] float inadequateSkillCastTimeMod = 3f;

    // util
    float castTime;
    float mpCost;

    // cached references
    protected EquippedSpell equippedSpell;
    protected Magic ownerMagic;
    Canvas canvas;
    TabMenuManager tabMenuManager;
    protected Player player;
    WeaponWheelManager weaponWheelManager;
    protected AttributeScores playerAttributes;
    ParticleSystem ps;

    public bool IsConstantCasting { get => isConstantCasting; set => isConstantCasting = value; }
    public bool IsCharging { get => isCharging; set => isCharging = value; }

    protected virtual void Awake()
    {
        equippedSpell = GetComponent<EquippedSpell>();
        ps = GetComponent<ParticleSystem>();
        canvas = GameObject.FindGameObjectWithTag("GameCanvas").GetComponent<Canvas>();
        tabMenuManager = FindObjectOfType<TabMenuManager>();
        player = FindObjectOfType<Player>();
        playerAttributes = player.GetComponent<AttributeScores>();
        weaponWheelManager = FindObjectOfType<WeaponWheelManager>();
    }

    // Start is called before the first frame update
    protected virtual void Start()
    {
        ownerMagic = equippedSpell.Owner.GetComponent<Magic>();
        AdjustSpellCosandCastTimetBasedOnSkills();
    }

    public override void Use(InputAction.CallbackContext context)
    {
        if (!tabMenuManager.InMenu && !player.InDialogue && !weaponWheelManager.WheelDisplayed && !player.Character.Incapacitated)
        {
            // CONSTANT CAST
            if (equippedSpell.Spell.ConstantCast)
            {
                float mpRemaining = ownerMagic.MagicPoints - (mpCost / ownerMagic.MpTicksPerSecond);

                // burn if enough MP to cast
                if (mpRemaining >= 0)
                {
                    // player is busy
                    player.IsBusy = true;

                    // set state
                    IsConstantCasting = true;

                    // start constant casting
                    ConstantCast();

                    // decrease magic over time
                    ownerMagic.StartMPBurn(mpCost);

                    // cast sound
                    if (audioSource && castSound)
                    {
                        audioSource.PlayOneShot(castSound, castVolume);
                    }

                    // constant cast sound
                    if (audioSource && constantCastLoopSound)
                    {
                        audioSource.loop = true;
                        audioSource.clip = constantCastLoopSound;
                        audioSource.volume = constantCastLoopSoundVolume;
                        audioSource.Play();
                    }

                    // particles
                    var particleMain = ps.main;
                }
                else if (mpRemaining < 0)
                {
                    Debug.Log("Not enough mp to cast.");
                }
            }

            // CHARGE SLIDER
            else
            {
                float mpRemaining = ownerMagic.MagicPoints - mpCost;

                // charge if enough mp to cast
                if (mpRemaining >= 0)
                {
                    // player is busy
                    player.IsBusy = true;
                    IsCharging = true;

                    // Freeze mp regen
                    ownerMagic.FreezeMPRegen();

                    // show how many magic points will be decreased
                    ownerMagic.DecreaseMagicPoints(mpCost);

                    // spawn spell slider
                    spellSlider = Instantiate(spellSliderTemplate, canvas.transform);

                    // set properties
                    spellSlider.GetComponent<SpellSlider>().SetParameters(equippedSpell.isMainHand, castTime);

                    // audio
                    if (audioSource)
                    {
                        audioSource.clip = chargeSound;
                        audioSource.volume = chargeVolume;
                        audioSource.Play();
                    }
                }
                else if (mpRemaining < 0)
                {
                    Debug.Log("Not enough mp to cast.");
                }
            }
        }
    }

    public override void Release(InputAction.CallbackContext context)
    {
        if (!tabMenuManager.InMenu && !player.InDialogue && !weaponWheelManager.WheelDisplayed && !player.Character.Incapacitated)
        {
            // CONSTANT CAST
            if (equippedSpell.Spell.ConstantCast)
            {
                // Stop constant casting and burning mp
                if (IsConstantCasting)
                {
                    StopConstantCast();
                    StopMPBurn();
                }
            }

            // CHARGE SLIDER
            else if (IsCharging)
            {
                // player is no longer busy
                player.IsBusy = false;
                IsCharging = false;

                bool chargeComplete = false;

                // audio
                if (audioSource)
                {
                    audioSource.Stop();
                }

                // get slider state and destroy
                if (spellSlider)
                {
                    chargeComplete = spellSlider.GetComponent<SpellSlider>().CheckIfFinished();

                    Destroy(spellSlider);
                }

                if (chargeComplete)
                {
                    Cast();

                    // audio
                    if (audioSource)
                    {
                        audioSource.PlayOneShot(castSound, castVolume);
                    }
                }
                else
                {
                    // charge not complete, refund magic
                    ownerMagic.IncreaseMagicPoints(mpCost);
                }

                // resume mp regen
                ownerMagic.StartMPRegen();
            }
        }
    }

    public override void Utility(InputAction.CallbackContext context)
    {
        if (!tabMenuManager.InMenu && !player.InDialogue && !weaponWheelManager.WheelDisplayed && !player.Character.Incapacitated)
        {
            if (IsCharging && !equippedSpell.Spell.ConstantCast)
            {
                CancelCharge();
            }
        }
    }

    public override void Interrupt()
    {
        if (IsCharging && !equippedSpell.Spell.ConstantCast)
        {
            CancelCharge();
        }
        else if (IsConstantCasting)
        {
            StopConstantCast();
            StopMPBurn();
        }
    }

    public override void InterruptMagic()
    {   
        // Ran out of magic. Stop casting.
        if (IsConstantCasting)
        {
            StopConstantCast();
            StopMPBurn();
        }
    }

    public void CancelCharge()
    {
        // player is no longer busy
        player.IsBusy = false;
        IsCharging = false;

        // destroy slider
        if (spellSlider)
        {
            Destroy(spellSlider);
        }

        // refund magic points
        ownerMagic.IncreaseMagicPoints(mpCost);

        // resume mp regen
        ownerMagic.StartMPRegen();

        // stop charge sound
        if (audioSource)
        {
            audioSource.Stop();
        }
    }

    public void StopMPBurn()
    {
        // stop constant cast audio
        if (audioSource)
        {
            audioSource.loop = false;
            audioSource.Stop();
        }

        // done casting audio
        if (audioSource && constantCastEndSound)
        {
            audioSource.PlayOneShot(constantCastEndSound, constantCastEndSoundVolume);
        }

        // player is no longer busy
        player.IsBusy = false;

        // resume mp regen
        ownerMagic.StopMPBurn();
    }

    void AdjustSpellCosandCastTimetBasedOnSkills()
    {
        if (playerAttributes.GetSkillValue(equippedSpell.Spell.RequiredSkill) < equippedSpell.Spell.SkillRequirement)
        {
            // does not meet requirements
            castTime = equippedSpell.Spell.CastTime * inadequateSkillCastTimeMod;
            mpCost = equippedSpell.Spell.MpCost * inadequateSkillMpCostMod;
        }
        else
        {
            // meets requirements
            castTime = equippedSpell.Spell.CastTime * playerAttributes.GetSpellChargeModifier(equippedSpell.Spell.SpellSchool);
            mpCost = equippedSpell.Spell.MpCost * playerAttributes.GetSpellCostModifier(equippedSpell.Spell.SpellSchool);
        }
    }

    public virtual void Cast() {}

    public virtual void ConstantCast() {}

    public virtual void StopConstantCast() {}
}
