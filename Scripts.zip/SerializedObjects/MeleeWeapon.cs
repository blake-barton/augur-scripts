using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Item/Weapon/MeleeWeapon")]
public class MeleeWeapon : Weapon
{
    [Header("Melee Weapon Data")]
    [SerializeField] float attackTime = 0f;                                 // speed of the swing in quantitative terms
    [SerializeField] float chargedMovementSpeedSlowdownMultiplier = 0f;
    [SerializeField] float chargeTime = 0f;

    public enum MeleeRange
    {
        SHORT,
        MEDIUM,
        LONG
    }
    [SerializeField] MeleeRange range;

    public enum MeleeSpeed
    {
        SLOW,
        MEDIUM,
        FAST
    }
    [SerializeField] MeleeSpeed attackSpeed;    // speed of the swing in qualitative terms

    public enum MeleeWeaponType
    {
        SMALL,
        MEDIUM,
        LARGE,
        MASSIVE,
        BLADE,
        PIERCING,
        CLUB,
        SLASH,
        THRUST,
        SHIELD
    }
    [SerializeField] MeleeWeaponType meleeType;

    public enum MeleeAttackType
    {
        SWING,
        STAB
    }
    [SerializeField] MeleeAttackType attackType;

    public MeleeRange Range { get => range; set => range = value; }
    public float AttackTime { get => attackTime; set => attackTime = value; }
    public float ChargedMovementSpeedSlowdownMultiplier { get => chargedMovementSpeedSlowdownMultiplier; set => chargedMovementSpeedSlowdownMultiplier = value; }
    public float ChargeTime { get => chargeTime; set => chargeTime = value; }
    public MeleeWeaponType MeleeType { get => meleeType; set => meleeType = value; }
    public MeleeSpeed AttackSpeed { get => attackSpeed; set => attackSpeed = value; }
    public MeleeAttackType AttackType { get => attackType; set => attackType = value; }

    public override string ToString()
    {
        return base.ToString() + Range.ToString();
    }
}
