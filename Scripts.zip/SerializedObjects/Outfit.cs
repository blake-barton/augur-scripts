using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Item/Outfit")]
public class Outfit : Item
{
    [Header("Outfit")]
    [SerializeField] float poise;
    [SerializeField] List<DamageEffects.DamageType> resistances = new List<DamageEffects.DamageType>();
    [SerializeField] List<DamageEffects.DamageType> immunities = new List<DamageEffects.DamageType>();
    [SerializeField] List<DamageEffects.DamageType> vulnerabilities = new List<DamageEffects.DamageType>();
    [SerializeField] string outfitEffectsDescription = "";
    [SerializeField] Sprite wornSprite;
    [SerializeField] Sprite mainhandArm;
    [SerializeField] Sprite offhandArm;
    public RuntimeAnimatorController animatorController;

    [Header("Damage Thresholds")]
    [SerializeField] float bluntDT;
    [SerializeField] float piercingDT;
    [SerializeField] float slashingDT;
    [SerializeField] float energyDT;
    [SerializeField] float fireDT;
    [SerializeField] float frostDT;
    [SerializeField] float shockDT;
    [SerializeField] float acidDT;
    [SerializeField] float poisonDT;
    [SerializeField] float psionicDT;

    [Header("Status Effect Threshold Boosts")]
    [SerializeField] float burningThreshold;    // fire
    [SerializeField] float freezingThreshold;   // frost
    [SerializeField] float decayThreshold;      // acid
    [SerializeField] float shockedThreshold;    // shock
    [SerializeField] float insanityThreshold;   // psionic
    [SerializeField] float poisonedThreshold;   // poison
    [SerializeField] float bleedThreshold;      // bleed
    [SerializeField] float bleedReduction;      // bleed damage reduction

    public enum OutfitType
    {
        LIGHTARMOR,
        CLOTHING,
        MEDIUMARMOR,
        HEAVYARMOR,
        POWERARMOR
    }
    [SerializeField] OutfitType typeOutfit;

    public Usable usable;

    public List<DamageEffects.DamageType> Resistances { get => resistances; set => resistances = value; }
    public List<DamageEffects.DamageType> Immunities { get => immunities; set => immunities = value; }
    public List<DamageEffects.DamageType> Vulnerabilities { get => vulnerabilities; set => vulnerabilities = value; }
    public string OutfitEffectsDescription { get => outfitEffectsDescription; set => outfitEffectsDescription = value; }
    public Sprite MainhandArm { get => mainhandArm; set => mainhandArm = value; }
    public Sprite OffhandArm { get => offhandArm; set => offhandArm = value; }
    public OutfitType TypeOutfit { get => typeOutfit; set => typeOutfit = value; }
    public Sprite WornSprite { get => wornSprite; set => wornSprite = value; }
    public float Poise { get => poise; set => poise = value; }
    public float BluntDT { get => bluntDT; set => bluntDT = value; }
    public float PiercingDT { get => piercingDT; set => piercingDT = value; }
    public float SlashingDT { get => slashingDT; set => slashingDT = value; }
    public float EnergyDT { get => energyDT; set => energyDT = value; }
    public float FireDT { get => fireDT; set => fireDT = value; }
    public float FrostDT { get => frostDT; set => frostDT = value; }
    public float ShockDT { get => shockDT; set => shockDT = value; }
    public float AcidDT { get => acidDT; set => acidDT = value; }
    public float PoisonDT { get => poisonDT; set => poisonDT = value; }
    public float PsionicDT { get => psionicDT; set => psionicDT = value; }
    public float FreezingThreshold { get => freezingThreshold; set => freezingThreshold = value; }
    public float DecayThreshold { get => decayThreshold; set => decayThreshold = value; }
    public float ShockedThreshold { get => shockedThreshold; set => shockedThreshold = value; }
    public float InsanityThreshold { get => insanityThreshold; set => insanityThreshold = value; }
    public float BleedThreshold { get => bleedThreshold; set => bleedThreshold = value; }
    public float BleedReduction { get => bleedReduction; set => bleedReduction = value; }
    public float PoisonedThreshold { get => poisonedThreshold; set => poisonedThreshold = value; }
    public float BurningThreshold { get => burningThreshold; set => burningThreshold = value; }

    public override string ToString()
    {
        return base.ToString() + "Equipped" + Equipped.ToString() + "\n" + "Resistances: " + Resistances.ToString() + "\n" + "Immunities: " + Immunities.ToString() + "\n" + "Vulnerabilities: " + Vulnerabilities.ToString();
    }

    public string GetOutfitTypeAsString()
    {
        return typeOutfit switch
        {
            OutfitType.LIGHTARMOR => "Light Armor",
            OutfitType.CLOTHING => "Clothing",
            OutfitType.MEDIUMARMOR => "Medium Armor",
            OutfitType.HEAVYARMOR => "Heavy Armor",
            OutfitType.POWERARMOR => "Power Armor",
            _ => "N/A",
        };
    }
}
