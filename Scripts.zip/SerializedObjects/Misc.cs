using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Item/Misc")]
public class Misc : Item
{
    [Header("Misc")]
    [SerializeField] string miscEffectDescription = "";
    public Usable usable;

    public string MiscEffectDescription { get => miscEffectDescription; set => miscEffectDescription = value; }

    public override string ToString()
    {
        return base.ToString();
    }
}
