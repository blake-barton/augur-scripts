using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Spell")]
public class Spell : ScriptableObject
{
    [SerializeField] int spellID = -1;
    [SerializeField] string spellName = "N/A";
    [SerializeField] string effectDescription = "N/A";

    [TextArea(5, 10)]
    [SerializeField] string description = "N/A";

    [SerializeField] float mpCost = -1f;
    [SerializeField] AttributeScores.Skills requiredSkill;
    [SerializeField] int skillRequirement = 0;
    [SerializeField] Sprite spellSprite;
    [SerializeField] float castTime = -1f;
    [SerializeField] bool equippedMain = false;
    [SerializeField] bool equippedOff = false;
    [SerializeField] int quickEquippedIndex = -1;
    [SerializeField] bool constantCast = false;

    public enum School
    {
        ENKIISM,
        EREBANCY,
        GAIANISM,
        HERMETICISM,
        IKTOMANCY,
        RESHEPHISM
    }
    [SerializeField] School spellSchool;

    public GameObject equippedSpell;

    public int SpellID { get => spellID; set => spellID = value; }
    public string SpellName { get => spellName; set => spellName = value; }
    public string Description { get => description; set => description = value; }
    public float MpCost { get => mpCost; set => mpCost = value; }
    public int SkillRequirement { get => skillRequirement; set => skillRequirement = value; }
    public Sprite SpellSprite { get => spellSprite; set => spellSprite = value; }
    public School SpellSchool { get => spellSchool; set => spellSchool = value; }
    public float CastTime { get => castTime; set => castTime = value; }
    public bool EquippedMain { get => equippedMain; set => equippedMain = value; }
    public bool EquippedOff { get => equippedOff; set => equippedOff = value; }
    public string EffectDescription { get => effectDescription; set => effectDescription = value; }
    public bool ConstantCast { get => constantCast; set => constantCast = value; }
    public AttributeScores.Skills RequiredSkill { get => requiredSkill; set => requiredSkill = value; }
    public int QuickEquippedIndex { get => quickEquippedIndex; set => quickEquippedIndex = value; }
} 
