using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpellDescriptions : MonoBehaviour
{
    /* This class contains all descriptions for spells, as they need to be able to dynamicall update.
     * When a spell is learned, it sets its description using the description from this class
     * newSpell.Description = SpellDescriptions.descriptions[spellID];
     */

    List<string> descriptions = new List<string>();

    public string GetDescription(int spellID)
    {
        return descriptions[spellID];
    }

    public void PushDescriptions(AttributeScores attributeScores)
    {
        // 0
        string devouringSwarm = "Unleash a venemous swarm of insects which latches on to the first target it makes contact with.";
        descriptions.Add(devouringSwarm);

        // 1
        float fireballDamage = 15f * attributeScores.reshephismMod;
        string fireball = "Hurl a ball of fire, dealing " + fireballDamage + " fire damage to all enemies in the blast radius.";
        descriptions.Add(fireball);

        // 2
        float mendWoundsHealthPerSecond = 5f * attributeScores.hermeticismMod;
        string mendWounds = "While casting, heal " + mendWoundsHealthPerSecond + " health per second.";
        descriptions.Add(mendWounds);

        // 3
        string leadMagnetism = "While casting, all incoming ballistic projectiles freeze in place around you. When you release the spell, the projectiles fling outwards, dealing damage to any enemies they collide with. Reflected projectiles deal " + attributeScores.gaianismMod.ToString() + "x damage.";
        descriptions.Add(leadMagnetism);

        // 4
        string pull = "While casting, telekinetically pull all enemies towards you.";
        descriptions.Add(pull);

        // 5
        string raiseSkeleton = "Cast an orb of resurrection. When the orb strikes the corpse of an organic humanoid, the underworld summons a skeleton under your control.";
        descriptions.Add(raiseSkeleton);

        // 6
        string torch = "Deal some flame damage.";
        descriptions.Add(torch);
    }
}
