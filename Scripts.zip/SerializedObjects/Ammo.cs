using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Item/Ammo")]
public class Ammo : Item
{
    [Header("Ammo")]
    [SerializeField] AmmoType ammunitionType;

    public AmmoType AmmunitionType { get => ammunitionType; set => ammunitionType = value; }

    public override string ToString()
    {
        return base.ToString() + AmmunitionType.ToString();
    }
}
