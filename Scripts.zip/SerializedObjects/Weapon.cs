using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Weapon : Item
{
    [Header("Damage")]
    [SerializeField] List<float> damages = new List<float>();
    [SerializeField] List<DamageEffects.DamageType> damageTypes = new List<DamageEffects.DamageType>();
    [SerializeField] float attackRate = 0f;
    [SerializeField] bool canHitMultipleTargets = false;
    [SerializeField] float maxBonusChargeDamageAsFraction = 0.25f;

    [Header("Status Effects")]
    [SerializeField] [Range(0, 1)] float statusEffectDamagePercentage = .1f;
    [SerializeField] float bleedBuildup = 0;

    [Header("Explosives")]
    [SerializeField] bool isExplosive = false;      // flags that the projectile doesn't do damage, rather the resulting explosion does

    [Header("Thermal Weapons")]
    [SerializeField] bool isThermal = false;    // can this weapon overheat?
    [SerializeField] bool isOverheated = false;
    [SerializeField] float heatCapacity = 0f;
    [SerializeField] float heatIncreasePerShot = 0f;
    [SerializeField] float heatDecreaseSpeed = 0f;
    [SerializeField] float accumulatedHeat = 0f;

    [Header("Attributes and Skills")]
    [SerializeField] bool requirementsMet = false;
    [SerializeField] int strengthRequirement;
    [SerializeField] AttributeScores.Skills weaponSkill;
    [SerializeField] int weaponSkillRequirement;

    [Header("Equipped Info")]
    public GameObject equippedWeapon;

    [Header("Knockdown and Crits")]
    [SerializeField] float forceDamage = 0f;
    [SerializeField] int bonusCritChance = 0;
    [SerializeField] float bonusCritMultiplier = 0f;

    [Header("Knockback")]
    [SerializeField] float knockbackForce = 0f;
    [SerializeField] float knockbackTime = 0f;

    [Header("Lunge")]
    [SerializeField] float lungeForce = 0f;
    [SerializeField] float lungeTime = 0f;

    [Header("Camera Shake")]
    [SerializeField] float screenShakeDuration = 0f;
    [SerializeField] float screenShakeIntensity = 0f;

    public List<float> Damages { get => damages; set => damages = value; }
    public float AttackRate { get => attackRate; set => attackRate = value; }
    public List<DamageEffects.DamageType> DamageTypes { get => damageTypes; set => damageTypes = value; }
    public int BonusCritChance { get => bonusCritChance; set => bonusCritChance = value; }
    public float BonusCritMultiplier { get => bonusCritMultiplier; set => bonusCritMultiplier = value; }
    public float ForceDamage { get => forceDamage; set => forceDamage = value; }
    public float ScreenShakeDuration { get => screenShakeDuration; set => screenShakeDuration = value; }
    public float ScreenShakeIntensity { get => screenShakeIntensity; set => screenShakeIntensity = value; }
    public bool RequirementsMet { get => requirementsMet; set => requirementsMet = value; }
    public bool CanHitMultipleTargets { get => canHitMultipleTargets; set => canHitMultipleTargets = value; }
    public AttributeScores.Skills WeaponSkill { get => weaponSkill; set => weaponSkill = value; }
    public int WeaponSkillRequirement { get => weaponSkillRequirement; set => weaponSkillRequirement = value; }
    public int StrengthRequirement { get => strengthRequirement; set => strengthRequirement = value; }
    public bool IsExplosive { get => isExplosive; set => isExplosive = value; }
    public float StatusEffectDamagePercentage { get => statusEffectDamagePercentage; set => statusEffectDamagePercentage = value; }
    public float MaxBonusChargeDamageAsFraction { get => maxBonusChargeDamageAsFraction; set => maxBonusChargeDamageAsFraction = value; }
    public bool IsThermal { get => isThermal; set => isThermal = value; }
    public float AccumulatedHeat { get => accumulatedHeat; set => accumulatedHeat = value; }
    public float HeatCapacity { get => heatCapacity; set => heatCapacity = value; }
    public bool IsOverheated { get => isOverheated; set => isOverheated = value; }
    public float HeatIncreasePerShot { get => heatIncreasePerShot; set => heatIncreasePerShot = value; }
    public float HeatDecreaseSpeed { get => heatDecreaseSpeed; set => heatDecreaseSpeed = value; }
    public float BleedBuildup { get => bleedBuildup; set => bleedBuildup = value; }
    public float KnockbackForce { get => knockbackForce; set => knockbackForce = value; }
    public float KnockbackTime { get => knockbackTime; set => knockbackTime = value; }
    public float LungeForce { get => lungeForce; set => lungeForce = value; }
    public float LungeTime { get => lungeTime; set => lungeTime = value; }

    public float GetTotalDamage()
    {
        float total = 0;

        foreach (float damage in Damages)
        {
            total += damage;
        }

        return total;
    }

    public override string ToString()
    {
        return base.ToString() + "\n" + "Damage: " + Damages.ToString() + "\n" + "Attack Rate: " + AttackRate.ToString() + "\n" + "Damage Types: " + DamageTypes.ToString() + "\n" + "Strength Requirement: " + "\n" + "Bonus Crit. Chance: " + BonusCritChance.ToString();
    }
}
