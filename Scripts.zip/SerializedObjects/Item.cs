using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Item : ScriptableObject
{
    // base variables
    [Header("Base Item Info")]
    [SerializeField] string itemName = "";
    [SerializeField] int itemID = 0;
    [SerializeField] int value = 0;
    [SerializeField] float weight = 0f;

    [TextArea(5, 10)]
    [SerializeField] string description = "";

    [SerializeField] Sprite sprite;
    [SerializeField] bool copiesAllowed = false;
    [SerializeField] int dropXThreshold = 5;
    [SerializeField] bool equippedMain = false;
    [SerializeField] bool equippedOff = false;
    [SerializeField] bool equipped = false;
    [SerializeField] int quickEquippedIndex = -1;
    [SerializeField] int heldMax = 5;
    [SerializeField] int storedMax = 3;
    [SerializeField] bool markedForTrade;
    [SerializeField] int numberMarkedForTrade = 0;
    [SerializeField] bool requiresConsumableAnimation = false;
    [SerializeField] int quickAidIndex = -1;

    public enum ItemType
    {
        RANGEDWEAPON,
        MELEEWEAPON,
        OUTFIT,
        AID,
        MISC,
        AMMO,
        AUGMENTATION,
        FOCUSIMPLANT
    }
    [SerializeField] ItemType type;

    public enum ItemRarity
    {
        COMMON,
        UNCOMMON,
        RARE,
        EPIC
    }
    [SerializeField] ItemRarity rarity;
    [SerializeField] RoomManager.RewardCategory rewardCategory;
    [SerializeField] int numberToReward = 1;
    [SerializeField] List<StatusEffect> onEquipStatusEffects = new List<StatusEffect>();
    [SerializeField] List<StatusEffect> onUseStatusEffects = new List<StatusEffect>();

    // used for weapons and ammo
    public enum AmmoType
    {
        NINEMILL,
        NATOFIVEFIVESIX,
        FIVEMILL,
        TENMILL,
        ENERGYCELL,
        TWELVEGAUGE,
        THREEZEROEIGHT,
        ROCKET,
        NOT_APPLICABLE,
        FORTYFOURMAGNUM,
        FIFTYCALIBER,
        PLASMA_CELL,
        FLARE,
        ARROW,
        CRYO_CELL,
        TWENTYTWOCALIBER,
        FUEL_CANISTER,
        BUZZSAW
    }

    public GameObject sceneItem;    // represents the item laying in the world

    public string ItemName { get => itemName; set => itemName = value; }
    public int ItemID { get => itemID; set => itemID = value; }
    public int Value { get => value; set => this.value = value; }
    public float Weight { get => weight; set => weight = value; }
    public string Description { get => description; set => description = value; }
    public ItemType Type { get => type; set => type = value; }
    public Sprite Sprite { get => sprite; set => sprite = value; }
    public int DropXThreshold { get => dropXThreshold; set => dropXThreshold = value; }
    public bool EquippedMain { get => equippedMain; set => equippedMain = value; }
    public bool EquippedOff { get => equippedOff; set => equippedOff = value; }
    public bool Equipped { get => equipped; set => equipped = value; }
    public int HeldMax { get => heldMax; set => heldMax = value; }
    public int StoredMax { get => storedMax; set => storedMax = value; }
    public bool MarkedForTrade { get => markedForTrade; set => markedForTrade = value; }
    public int NumberMarkedForTrade { get => numberMarkedForTrade; set => numberMarkedForTrade = value; }
    public bool RequiresConsumableAnimation { get => requiresConsumableAnimation; set => requiresConsumableAnimation = value; }
    public RoomManager.RewardCategory RewardCategory { get => rewardCategory; set => rewardCategory = value; }
    public int NumberToReward { get => numberToReward; set => numberToReward = value; }
    public ItemRarity Rarity { get => rarity; set => rarity = value; }
    public int QuickEquippedIndex { get => quickEquippedIndex; set => quickEquippedIndex = value; }
    public int QuickAidIndex { get => quickAidIndex; set => quickAidIndex = value; }
    public bool CopiesAllowed { get => copiesAllowed; set => copiesAllowed = value; }
    public List<StatusEffect> OnEquipStatusEffects { get => onEquipStatusEffects; set => onEquipStatusEffects = value; }
    public List<StatusEffect> OnUseStatusEffects { get => onUseStatusEffects; set => onUseStatusEffects = value; }

    public override string ToString()
    {
        return "Name: " + ItemName + "\n" + "ID: " + ItemID.ToString() + "\n" + "Value: " + Value.ToString() + "\n" + "Weight: " + Weight.ToString() + "\n" + "Description: " + Description + "\n";
    }

    public static string AmmoTypeToString(AmmoType ammoType)
    {
        return ammoType switch
        {
            AmmoType.NINEMILL => "9mm",
            AmmoType.NATOFIVEFIVESIX => "5.56mm",
            AmmoType.FIVEMILL => "5mm",
            AmmoType.TENMILL => "10mm",
            AmmoType.ENERGYCELL => "E-Cell",
            AmmoType.TWELVEGAUGE => "12 Gauge",
            AmmoType.THREEZEROEIGHT => ".308",
            AmmoType.ROCKET => "Rocket",
            AmmoType.NOT_APPLICABLE => "N/A",
            AmmoType.FORTYFOURMAGNUM => ".44",
            AmmoType.FIFTYCALIBER => ".50",
            AmmoType.PLASMA_CELL => "P-Cell",
            AmmoType.FLARE => "Flare",
            AmmoType.ARROW => "Arrow",
            AmmoType.CRYO_CELL => "C-Cell",
            AmmoType.TWENTYTWOCALIBER => ".22",
            AmmoType.FUEL_CANISTER => "Fuel",
            AmmoType.BUZZSAW => "Sawblade",
            _ => "N/A",
        };
    }
}
