using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Item/Weapon/RangedWeapon")]
public class RangedWeapon : Weapon
{
    [Header("Type")]
    [SerializeField] bool isThrowingWeapon = false;

    [Header("Range")]
    [SerializeField] float effectiveRange = 0f; // how long until the weapon experiences damage dropoff
    [SerializeField] float maxRange = 0f;       // how long until the projectile disappears

    [Header("Ammo and Reloading")]
    [SerializeField] int clipSize = 0;
    [SerializeField] int ammoInClip = 0;
    [SerializeField] float reloadTime = 0f;
    [SerializeField] bool isAutomatic = false;
    [SerializeField] AmmoType ammunitionType;
    [SerializeField] float chargeTime = 0f;
    [SerializeField] float projectileSpeed = 0f;
    [SerializeField] int ammoUsedPerShot = 1;
    [SerializeField] int projectilesPerShot = 1;
    [SerializeField] float timeBetweenProjectilesInShot = 0f;
    [SerializeField] float warmupTime = 0f;
    [SerializeField] float spread = 0f;

    [Header("Audio")]
    [SerializeField] AudioClip shotAudio;
    [SerializeField] AudioClip shotLoopAudio;

    public enum RangedWeaponType
    {
        PISTOL,
        RIFLE,
        SHOTGUN,
        TECH,
        REVOLVER,
        BOLTACTION,
        BALLISTIC,
        HEAVY,
        SMG,
        EXPLOSIVE,
        SNIPER,
        THERMAL,
        BOW,
        THROWING
    }
    [SerializeField] List<RangedWeaponType> rangedWeaponTypes = new List<RangedWeaponType>();

    public float EffectiveRange { get => effectiveRange; set => effectiveRange = value; }
    public float MaxRange { get => maxRange; set => maxRange = value; }
    public int ClipSize { get => clipSize; set => clipSize = value; }
    public float ReloadTime { get => reloadTime; set => reloadTime = value; }
    public bool IsAutomatic { get => isAutomatic; set => isAutomatic = value; }
    public AmmoType AmmunitionType { get => ammunitionType; set => ammunitionType = value; }
    public float ChargeTime { get => chargeTime; set => chargeTime = value; }
    public float ProjectileSpeed { get => projectileSpeed; set => projectileSpeed = value; }
    public int AmmoUsedPerShot { get => ammoUsedPerShot; set => ammoUsedPerShot = value; }
    public int AmmoInClip { get => ammoInClip; set => ammoInClip = value; }
    public List<RangedWeaponType> RangedWeaponTypes { get => rangedWeaponTypes; set => rangedWeaponTypes = value; }
    public int ProjectilesPerShot { get => projectilesPerShot; set => projectilesPerShot = value; }
    public float WarmupTime { get => warmupTime; set => warmupTime = value; }
    public float Spread { get => spread; set => spread = value; }
    public bool IsThrowingWeapon { get => isThrowingWeapon; set => isThrowingWeapon = value; }
    public float TimeBetweenProjectilesInShot { get => timeBetweenProjectilesInShot; set => timeBetweenProjectilesInShot = value; }
    public AudioClip ShotAudio { get => shotAudio; set => shotAudio = value; }
    public AudioClip ShotLoopAudio { get => shotLoopAudio; set => shotLoopAudio = value; }

    public float TotalDamagePerSecond
    {
        get
        {
            return ClipSize * GetTotalDamage() / (ReloadTime + ClipSize / AttackRate);
        }
    }

    public override string ToString()
    {
        return base.ToString() + "\n" + "Effective Range: " + effectiveRange.ToString() + "\n" + "Max Range: " + maxRange.ToString() + "\n" + "Clip Size: " + clipSize.ToString() + "\n" + "Reload Time: " + reloadTime.ToString() + "\n" + "Automatic: " + isAutomatic.ToString() + "\n" + "AmmoType: " + ammunitionType.ToString()
            + "\n" + "Charge Time: " + chargeTime.ToString();
    }

    public string RangedWeaponTypesToString()
    {
        string returnString = "";
        
        for (int i = 0; i < rangedWeaponTypes.Count; i++)
        {
            if (i == rangedWeaponTypes.Count - 1)
            {
                returnString += rangedWeaponTypes[i].ToString();
            }
            else
            {
                returnString += rangedWeaponTypes[i].ToString() + ", ";
            }
        }

        return returnString;
    }
}
