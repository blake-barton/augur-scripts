using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ItemDatabase : MonoBehaviour
{
    public List<Item> itemList = new List<Item>();
    public List<Spell> spellList = new List<Spell>();
    public List<Location> locationList = new List<Location>();
    public List<Augmentation> augmentationList = new List<Augmentation>();

    [Header("Enemy Lists")]
    public List<GameObject> coalitionMilitary = new List<GameObject>();
    public List<GameObject> sewerCreatures = new List<GameObject>();
    public List<GameObject> psychoknights = new List<GameObject>();
    public List<GameObject> undead = new List<GameObject>();
    public List<GameObject> craterMutants = new List<GameObject>();
    public List<GameObject> badlandsCreatures = new();
    public List<GameObject> sparkraiders = new();
    
    public List<GameObject> GetListOfAllEnemies()
    {
        List<GameObject> enemyList = new List<GameObject>();

        enemyList.AddRange(coalitionMilitary);
        enemyList.AddRange(sewerCreatures);
        enemyList.AddRange(psychoknights);
        enemyList.AddRange(undead);
        enemyList.AddRange(craterMutants);
        enemyList.AddRange(badlandsCreatures);
        enemyList.AddRange(sparkraiders);

        return enemyList;
    }
}
