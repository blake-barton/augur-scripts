using System.Collections.Generic;

[System.Serializable]
public class PlayerPreset
{
    public int id;
    public string name;

    public int strength = 0;
    public int perception = 0;
    public int endurance = 0;
    public int intelligence = 0;
    public int agility = 0;
    public int aberrance = 0;

    public List<int> proficiencies = new List<int>();

    public PlayerPreset(string _name, int _strength, int _perception, int _endurance, int _intelligence, int _agility, int _aberrance, List<int> _proficiencies)
    {
        id = SaveSystem.GetNextAvailablePresetID();

        name = _name;

        strength = _strength;
        perception = _perception;
        endurance = _endurance;
        intelligence = _intelligence;
        agility = _agility;
        aberrance = _aberrance;

        foreach (int proficiency in _proficiencies)
        {
            proficiencies.Add(proficiency);
        }
    }
}
