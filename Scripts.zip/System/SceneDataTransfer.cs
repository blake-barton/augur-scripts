using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Scene Data Transfer Object")]
public class SceneDataTransfer : ScriptableObject
{
    public bool written = false;

    [Header("Player Attributes")]
    public int pointsRemaining;
    public int strength;
    public int perception;
    public int endurance;
    public int intelligence;
    public int agility;
    public int aberrance;
}
