using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MusicPlayer : MonoBehaviour
{
    // config
    [SerializeField] AudioClip[] tracks;
    [SerializeField] Transform target;

    // tracks enum (MUST UPDATE THIS AS NEW TRACKS ARE ADDED)
    public enum TrackEnumerator : int
    {
        MAIN_MENU,
        UNSTABLE_ENERGY,
        CHEMICAL_CONSPIRACY,
        THE_ENTERTAINER,
        SPEAKEASY_STRIDE,
        BATTLE_ON_THE_EDGE_OF_A_DREAM,
        THE_REAPER,
        RAILWAY_REDEMPTION,
        DESCENT,
        GIANT_SPIDER_EMERGES,
        VIRTUAL_OBSERVATORY
    }
    [SerializeField] TrackEnumerator track;
    [SerializeField] bool playTrackOnAwake = false;

    // components
    [SerializeField] AudioSource audioSource;

    private void Start()
    {
        if (playTrackOnAwake)
        {
            PlayMusicOnLoop();
        }
    }

    void Update()
    {
        // follow player so music stays centered
        if (target)
        {
            transform.position = target.position;
        }
    }

    // called by classes that need to change the music
    public void ChangeTrack(int trackNumber)
    {
        audioSource.loop = true;
        audioSource.clip = tracks[trackNumber];
        audioSource.Play();
    }

    public void MultiplyPitch(float pitchMultiplier)
    {
        audioSource.pitch *= pitchMultiplier;
    }

    public void PlayMusicOnLoop()
    {
        ChangeTrack((int)track);
    }

    public void StopMusic()
    {
        audioSource.Stop();
    }

    // getters
    public float GetPitch()
    {
        return audioSource.pitch;
    }

    // setters
    public void SetPitch(float newPitch)
    {
        audioSource.pitch = newPitch;
    }

    public void PlayOneShot(AudioClip clip, float volume)
    {
        audioSource.PlayOneShot(clip, volume);
    }
}