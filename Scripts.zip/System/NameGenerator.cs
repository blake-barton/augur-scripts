using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;

public class NameGenerator
{
    public static string adjectivesFilePath = Application.streamingAssetsPath + "/TextFiles/" + "Adjectives.txt";
    public static string nounsFilePath = Application.streamingAssetsPath + "/TextFiles/" + "Nouns.txt";

    public static string GenerateQuestName()
    {
        List<string> adjectives = new List<string>(File.ReadAllLines(adjectivesFilePath));
        List<string> nouns = new List<string>(File.ReadAllLines(nounsFilePath));

        int randomAdjectiveIndex = Random.Range(0, adjectives.Count);
        int randomNounIndex = Random.Range(0, nouns.Count);

        return adjectives[randomAdjectiveIndex] + " " + nouns[randomNounIndex];
    }
}
