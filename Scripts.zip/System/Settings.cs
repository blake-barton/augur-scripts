using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Settings
{
    public static float masterVolume = 1f;
    public static float musicVolume = 1f;
    public static float effectsVolume = 1f;
    public static float uiVolume = 1f;
}