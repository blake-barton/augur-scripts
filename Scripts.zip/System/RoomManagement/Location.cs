using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Location")]
public class Location : ScriptableObject
{
    [SerializeField] string locationName;
    [SerializeField] int locationID;
    [SerializeField] List<Room> rooms = new List<Room>();

    [Header("Difficulty")]
    [SerializeField] int maxNumberOfVeryEasyRooms;
    [SerializeField] int maxNumberOfEasyRooms;
    [SerializeField] int maxNumberOfMediumRooms;
    [SerializeField] int maxNumberOfHardRooms;

    [Header("Boss Room")]
    [SerializeField] Room bossRoom;

    public List<Room> Rooms { get => rooms; }
    public int RoomCount { get => rooms.Count; }
    public int MaxRoomsInLocation { get => maxNumberOfVeryEasyRooms + maxNumberOfEasyRooms + maxNumberOfMediumRooms + maxNumberOfHardRooms; }
    public string LocationName { get => locationName; set => locationName = value; }
    public int LocationID { get => locationID; set => locationID = value; }
    public int MaxNumberOfVeryEasyRooms { get => maxNumberOfVeryEasyRooms; set => maxNumberOfVeryEasyRooms = value; }
    public int MaxNumberOfEasyRooms { get => maxNumberOfEasyRooms; set => maxNumberOfEasyRooms = value; }
    public int MaxNumberOfMediumRooms { get => maxNumberOfMediumRooms; set => maxNumberOfMediumRooms = value; }
    public int MaxNumberOfHardRooms { get => maxNumberOfHardRooms; set => maxNumberOfHardRooms = value; }
    public Room BossRoom { get => bossRoom; set => bossRoom = value; }
}
