using System;
using System.Linq;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using Pathfinding;

public class RoomManager : MonoBehaviour
{
    [Header("Room Info")]
    [SerializeField] Location location;
    [SerializeField] Room currentRoom;
    [SerializeField] bool countRoomInVisitedScenes = true;
    [SerializeField] List<int> visitedRoomIdsInLocation = new List<int>();
    [SerializeField] bool isCombatScene = true;
    [SerializeField] List<Enemy.EnemyType> enemyTypes = new List<Enemy.EnemyType>();

    [Header("Difficulty Tracking")]
    [SerializeField] int veryEasyRoomsVisited;
    [SerializeField] int easyRoomsVisited;
    [SerializeField] int mediumRoomsVisited;
    [SerializeField] int hardRoomsVisited;
    [SerializeField] bool nextRoomIsBossRoom = false;

    [Header("Reward Item Spawning")]
    [SerializeField] bool roomHasRewardChest = true;
    [SerializeField] GameObject rewardChest;
    [SerializeField] List<int> rewardItemIDs = new List<int>();
    [SerializeField] float minDistanceFromPlayer = 1f;
    [SerializeField] float maxDistanceFromPlayer = 3f;
    [SerializeField] int rewardItemIDIfNoRewards = 38;
    GameObject instantiatedRewardChest;

    [Header("Rarity Reward Chances")]
    [SerializeField] [Range(0, 100)] int commonRewardChance = 70;
    [SerializeField] [Range(0, 100)] int uncommonRewardChance = 20;
    [SerializeField] [Range(0, 100)] int rareRewardChance = 8;
    [SerializeField] [Range(0, 100)] int epicRewardChance = 2;

    [Header("Reward Selection Menu")]
    [SerializeField] GameObject rewardSelectionMenu;
    GameObject instantiatedRewardSelectionMenu;

    [Header("Wave Spawning")]
    [SerializeField] GameObject enemySpawnerObject;
    [SerializeField] int maxEnemies = 10;
    [SerializeField] int currentEnemies = 0;
    [SerializeField] [Range(0, 1)] float newWaveSpawnThreshold = .1f;
    [SerializeField] List<Wave> waves = new List<Wave>();
    [SerializeField] int currentWave = -1;
    [SerializeField] [Range(0, 5)] float minTimeBetweenWaves = 0f;
    [SerializeField] [Range(0, 5)] float maxTimeBetweenWaves = 4f;
    [SerializeField] [Range(0, 5)] float minTimeBetweenSpawners = 0f;
    [SerializeField] [Range(0, 5)] float maxTimeBetweenSpawners = 2f;
    [SerializeField] int spawnersFinished = 0;
    [SerializeField] int enemiesAddedThisWave = 0;
    [SerializeField] bool waveSpawning = false;

    [Header("Spawning Boundaries")]
    [SerializeField] float gridXMin;
    [SerializeField] float gridXMax;
    [SerializeField] float gridYMin;
    [SerializeField] float gridYMax;

    [Header("Wave Counts")]
    [SerializeField] int veryEasyWaveCount = 2;
    [SerializeField] int easyWaveCount = 3;
    [SerializeField] int mediumWaveCount = 4;
    [SerializeField] int hardWaveCount = 5;

    [Header("Entrance Doors")]
    [SerializeField] bool hasEntranceDoor = true;
    [SerializeField] Animator entranceDoorAnimator;
    public float entranceTime = 5f;
    [SerializeField] AudioClip doorCloseClip;
    [SerializeField] [Range(0, 1)] float doorCloseVolume = .5f;

    [Header("Exit Doors")]
    [SerializeField] List<GameObject> exitDoors = new List<GameObject>();
    [SerializeField] AudioClip doorOpenClip;
    [SerializeField] [Range(0, 1)] float doorOpenVolume = .5f;

    [Header("Player Entrance")]
    [SerializeField] Vector2 enterDirection = new Vector2(0, -1);

    [Header("Music")]
    [SerializeField] bool hasMusic = true;
    [SerializeField] MusicPlayer.TrackEnumerator musicTrack;

    [Header("Reward Category Sprites")]
    [SerializeField] Sprite pistol;
    [SerializeField] Sprite rifle;
    [SerializeField] Sprite heavyWeapon;
    [SerializeField] Sprite bludgeoning;
    [SerializeField] Sprite blade;
    [SerializeField] Sprite polearm;
    [SerializeField] Sprite throwing;
    [SerializeField] Sprite explosive;
    [SerializeField] Sprite enkiism;
    [SerializeField] Sprite erebancy;
    [SerializeField] Sprite gaianism;
    [SerializeField] Sprite hermeticism;
    [SerializeField] Sprite reshephism;
    [SerializeField] Sprite iktomancy;
    [SerializeField] Sprite consumable;
    [SerializeField] Sprite focusImplant;
    [SerializeField] Sprite augmentationPoint;
    [SerializeField] Sprite currencyHoard;
    [SerializeField] Sprite ammoHoard;
    [SerializeField] Sprite outfit;
    [SerializeField] Sprite store;

    [Header("Ammo Drop Counts")]
    [SerializeField] int fiveMillDropCount = 500;
    [SerializeField] int nineMillDropCount = 150;
    [SerializeField] int twelveGaugeDropCount = 120;
    [SerializeField] int threeZeroEightDropCount = 100;
    [SerializeField] int fiveFiveSixDropCount = 250;
    [SerializeField] int EnergyCellDropCount = 180;
    [SerializeField] int rocketDropCount = 40;
    [SerializeField] int fortyFourCalDropCount = 80;
    [SerializeField] int fiftyCalDropCount = 80;
    [SerializeField] int plasmaCellDropCount = 180;
    [SerializeField] int flareDropCount = 60;
    [SerializeField] int arrowDropCount = 80;
    [SerializeField] int cryoCellDropCount = 120;
    [SerializeField] int twentyTwoCalDropCount = 200;
    [SerializeField] int fuelCanisterDropCount = 300;
    [SerializeField] int buzzsawBladeDropCount = 80;

    [Header("Ammo Scene Items")]
    [SerializeField] GameObject fiveMillSceneItem;
    [SerializeField] GameObject nineMillSceneItem;
    [SerializeField] GameObject twelveGaugeSceneItem;
    [SerializeField] GameObject threeZeroEightSceneItem;
    [SerializeField] GameObject fiveFiveSixSceneItem;
    [SerializeField] GameObject energyCellSceneItem;
    [SerializeField] GameObject rocketSceneItem;
    [SerializeField] GameObject fortyFourCalSceneItem;
    [SerializeField] GameObject fiftyCalSceneItem;
    [SerializeField] GameObject plasmaCellSceneItem;
    [SerializeField] GameObject flareSceneItem;
    [SerializeField] GameObject arrowSceneItem;
    [SerializeField] GameObject cryoCellSceneItem;
    [SerializeField] GameObject twentyTwoCalSceneItem;
    [SerializeField] GameObject fuelCanisterSceneItem;
    [SerializeField] GameObject buzzsawBladeSceneItem;

    [Header("Audio")]
    [SerializeField] AudioClip roomClearedSound;
    [SerializeField] [Range(0, 1)] float roomClearedSoundVolume = 0.5f;

    [Header("Cached References")]
    [SerializeField] ItemDatabase itemDatabase;
    [SerializeField] Player player;
    [SerializeField] Canvas gameCanvas;
    [SerializeField] MusicPlayer musicPlayer;
    [SerializeField] AudioSource uiSounds;
    [SerializeField] AudioSource ambientSound;

    public enum RoomDifficulty
    {
        NOT_APPLICABLE,
        VERY_EASY,
        EASY,
        MEDIUM,
        HARD
    }
    RoomDifficulty difficulty;

    PlayerMovement playerMovement;
    Inventory playerInventory;

    public enum RewardCategory
    {
        NOT_REWARD,
        PISTOL,
        RIFLE,
        HEAVY_WEAPON,
        BLUDGEONING,
        BLADE,
        POLEARM,
        THROWING,
        EXPLOSIVE,
        ENKIISM,
        EREBANCY,
        GAIANISM,
        HERMETICISM,
        RESHEPHISM,
        IKTOMANCY,
        CONSUMABLE,
        FOCUS_IMPLANT,
        AUGMENTATION_POINT,
        CURRENCY_HOARD,
        AMMO_HOARD,
        OUTFIT
    }

    private void Awake()
    {
        playerMovement = player.GetComponent<PlayerMovement>();
        playerInventory = player.GetComponent<Inventory>();
    }

    private void Start()
    {
        if (hasEntranceDoor)
        {
            StartCoroutine(CloseEntranceDoor());
            playerMovement.ForceMovement(enterDirection, entranceTime);
        }

        if (hasMusic)
        {
            musicPlayer.ChangeTrack((int)musicTrack);
        }

        // setup exit doors if there are no enemies
        if (!isCombatScene && exitDoors.Count > 0)
        {
            OpenExitDoors();
        }
    }

    public int MaxEnemies { get => maxEnemies; set => maxEnemies = value; }
    public float PercentOfEnemiesAlive { get => (float)currentEnemies / maxEnemies; }
    public float NewWaveSpawnThreshold { get => newWaveSpawnThreshold; set => newWaveSpawnThreshold = value; }
    public Location Location { get => location; }
    public List<int> VisitedRoomIdsInLocation { get => visitedRoomIdsInLocation; }
    public List<int> RewardItemIDs { get => rewardItemIDs; set => rewardItemIDs = value; }
    public bool RoomHasRewardChest { get => roomHasRewardChest; set => roomHasRewardChest = value; }
    public int VeryEasyRoomsVisited { get => veryEasyRoomsVisited; set => veryEasyRoomsVisited = value; }
    public int EasyRoomsVisited { get => easyRoomsVisited; set => easyRoomsVisited = value; }
    public int MediumRoomsVisited { get => mediumRoomsVisited; set => mediumRoomsVisited = value; }
    public int HardRoomsVisited { get => hardRoomsVisited; set => hardRoomsVisited = value; }
    public int SpawnersFinished {
        get => spawnersFinished;
        set
        {
            spawnersFinished = value;
            if (spawnersFinished >= enemiesAddedThisWave)
            {
                waveSpawning = false;
            }
        }
    }

    /// <summary>
    /// Return true if there is more than one current enemy or a wave is currently spawning.
    /// </summary>
    /// <returns></returns>
    public bool InCombat()
    {
        return (currentEnemies > 0) || waveSpawning;
    }

    void GenerateWaves()
    {
        int numWaves = 0;

        switch (difficulty)
        {
            case RoomDifficulty.VERY_EASY:
                numWaves = veryEasyWaveCount;
                break;
            case RoomDifficulty.EASY:
                numWaves = easyWaveCount;
                break;
            case RoomDifficulty.MEDIUM:
                numWaves = mediumWaveCount;
                break;
            case RoomDifficulty.HARD:
                numWaves = hardWaveCount;
                break;
            default:
                break;
        }

        for (int i = 0; i < numWaves; i++)
        {
            waves.Add(new Wave(difficulty, itemDatabase, enemyTypes));
        }
    }

    public void SetDifficultyOfRoomsVisited(int veryEasy, int easy, int medium, int hard)
    {
        if (currentRoom)
        {
            if (!currentRoom.IsStartRoom)
            {
                VeryEasyRoomsVisited = veryEasy;
                EasyRoomsVisited = easy;
                MediumRoomsVisited = medium;
                HardRoomsVisited = hard;
            }
        }
    }

    private void VisitRoomOperations()
    {
        // add to visited rooms
        visitedRoomIdsInLocation.Add(currentRoom.RoomID);

        // combat scenes
        if (isCombatScene)
        {
            // increment difficulty counter
            if (veryEasyRoomsVisited < location.MaxNumberOfVeryEasyRooms)
            {
                veryEasyRoomsVisited++;
                difficulty = RoomDifficulty.VERY_EASY;
            }
            else if (easyRoomsVisited < location.MaxNumberOfEasyRooms)
            {
                easyRoomsVisited++;
                difficulty = RoomDifficulty.EASY;
            }
            else if (mediumRoomsVisited < location.MaxNumberOfMediumRooms)
            {
                mediumRoomsVisited++;
                difficulty = RoomDifficulty.MEDIUM;
            }
            else if (hardRoomsVisited < location.MaxNumberOfHardRooms)
            {
                hardRoomsVisited++;
                difficulty = RoomDifficulty.HARD;
            }
            
            // check if the next room is going to be a boss room
            if (hardRoomsVisited >= location.MaxNumberOfHardRooms)
            {
                nextRoomIsBossRoom = true;
            }

            GenerateWaves();
        }
    }

    // deep copy previously visited scenes
    public void SetVisitedRoomsInLocation(List<int> loadedRoomList)
    {
        // only load in previous rooms if this isn't a new location
        if (currentRoom)
        {
            if (!currentRoom.IsStartRoom)
            {
                foreach (int roomID in loadedRoomList)
                {
                    visitedRoomIdsInLocation.Add(roomID);
                }

                // add current room
                if (countRoomInVisitedScenes)
                {
                    VisitRoomOperations();
                }
            }
        }
    }

    private Room GetUnvisitedRoomInCurrentLocation()
    {
        // get a list of unvisited rooms in the current location (Location.Rooms - visitedRooms)
        List<Room> unvisitedRooms = new List<Room>();
        foreach (Room room in location.Rooms)
        {
            if (!visitedRoomIdsInLocation.Contains(room.RoomID))
            {
                unvisitedRooms.Add(room);
            }
        }

        // if the current room is a store, do not pull another store
        if (currentRoom)
        {
            if (currentRoom.IsStore)
            {
                unvisitedRooms = unvisitedRooms.Where(r => !r.IsStore).ToList();
            }
        }

        // pick a random room from the list. Else return null
        if (unvisitedRooms.Count > 0)
        {
            return unvisitedRooms[UnityEngine.Random.Range(0, unvisitedRooms.Count)];
        }
        else
        {
            return null;
        }
    }

    public Item GetItemFromDatabase(int itemID)
    {
        return itemDatabase.itemList[itemID];
    }

    public void ShowRewardSelectionMenu()
    {
        // spawn menu
        instantiatedRewardSelectionMenu = Instantiate(rewardSelectionMenu, gameCanvas.transform);
    }

    public void SubmitRewardSelection(int itemID)
    {
        // spawn reward
        SpawnRewardItem(itemID);

        // reenable player movement
        player.IsBusy = false;
        player.Character.Incapacitated = false;

        playerMovement.PlayDustTrail();

        // clear screen
        Destroy(instantiatedRewardSelectionMenu);
    }

    private void SpawnRewardItems()
    {
        foreach (int id in rewardItemIDs)
        {
            SpawnRewardItem(id);
        }
    }

    public void SpawnRewardItem(int id)
    {
        // instantiate the item from the database
        Item item = Instantiate(itemDatabase.itemList[id]);

        Vector3 spawnPoint = new Vector3();

        if (instantiatedRewardChest)
        {
            spawnPoint = instantiatedRewardChest.transform.position;
        }
        else
        {
            spawnPoint = GetClosestWalkableNodeCoordinatesToPoint(player.transform.position);
        }

        // spawn ammo with item if needed
        if (item.Type == Item.ItemType.RANGEDWEAPON)
        {
            SpawnAmmoForRangedWeapon(item, spawnPoint);
        }

        // instantiate a scene item at the reward chest
        GameObject droppedItem = Instantiate(item.sceneItem, spawnPoint, transform.rotation);
        droppedItem.GetComponent<SceneItem>().quantity = item.NumberToReward;

        // destroy chest
        if (instantiatedRewardChest)
        {
            instantiatedRewardChest.transform.GetChild(0).GetComponent<RewardChest>().Exit();
        }
    }

    public void SpawnItemNearPlayer(Item item, int quantity = 1)
    {
        // get a vector with random direction and magnitude between distance min and max
        Vector2 randomVector = UtilMath.RandomVector2(360f, 0f, UnityEngine.Random.Range(minDistanceFromPlayer, maxDistanceFromPlayer));

        // get a world point from the player and vector
        Vector3 point = playerMovement.transform.position + (Vector3)randomVector;

        // find closest walkable node to world point
        GraphNode node = AstarPath.active.GetNearest(point, NNConstraint.Default).node;

        // get the world position of said node
        Vector3 nodePosition = (Vector3)node.position;

        // spawn ammo with item if needed
        if (item.Type == Item.ItemType.RANGEDWEAPON)
        {
            SpawnAmmoForRangedWeapon(item, nodePosition);
        }

        // instantiate a scene item at the closest walkable tile to the player
        GameObject droppedItem = Instantiate(item.sceneItem, nodePosition, transform.rotation);
        droppedItem.GetComponent<SceneItem>().quantity = quantity;
    }

    private void SpawnAmmoForRangedWeapon(Item item, Vector3 position)
    {
        RangedWeapon rangedWeapon = (RangedWeapon)item;
        GameObject instantiatedAmmoSceneItem;

        switch (rangedWeapon.AmmunitionType)
        {
            case Item.AmmoType.NINEMILL:
                instantiatedAmmoSceneItem = Instantiate(nineMillSceneItem, position, Quaternion.identity);
                instantiatedAmmoSceneItem.GetComponent<SceneItem>().quantity = nineMillDropCount;
                break;
            case Item.AmmoType.FIVEMILL:
                instantiatedAmmoSceneItem = Instantiate(fiveMillSceneItem, position, Quaternion.identity);
                instantiatedAmmoSceneItem.GetComponent<SceneItem>().quantity = fiveMillDropCount;
                break;
            case Item.AmmoType.TWELVEGAUGE:
                instantiatedAmmoSceneItem = Instantiate(twelveGaugeSceneItem, position, Quaternion.identity);
                instantiatedAmmoSceneItem.GetComponent<SceneItem>().quantity = twelveGaugeDropCount;
                break;
            case Item.AmmoType.THREEZEROEIGHT:
                instantiatedAmmoSceneItem = Instantiate(threeZeroEightSceneItem, position, Quaternion.identity);
                instantiatedAmmoSceneItem.GetComponent<SceneItem>().quantity = threeZeroEightDropCount;
                break;
            case Item.AmmoType.NATOFIVEFIVESIX:
                instantiatedAmmoSceneItem = Instantiate(fiveFiveSixSceneItem, position, Quaternion.identity);
                instantiatedAmmoSceneItem.GetComponent<SceneItem>().quantity = fiveFiveSixDropCount;
                break;
            case Item.AmmoType.ENERGYCELL:
                instantiatedAmmoSceneItem = Instantiate(energyCellSceneItem, position, Quaternion.identity);
                instantiatedAmmoSceneItem.GetComponent<SceneItem>().quantity = EnergyCellDropCount;
                break;
            case Item.AmmoType.ROCKET:
                instantiatedAmmoSceneItem = Instantiate(rocketSceneItem, position, Quaternion.identity);
                instantiatedAmmoSceneItem.GetComponent<SceneItem>().quantity = rocketDropCount;
                break;
            case Item.AmmoType.TENMILL:
                break;
            case Item.AmmoType.NOT_APPLICABLE:
                break;
            case Item.AmmoType.FORTYFOURMAGNUM:
                instantiatedAmmoSceneItem = Instantiate(fortyFourCalSceneItem, position, Quaternion.identity);
                instantiatedAmmoSceneItem.GetComponent<SceneItem>().quantity = fortyFourCalDropCount;
                break;
            case Item.AmmoType.FIFTYCALIBER:
                instantiatedAmmoSceneItem = Instantiate(fiftyCalSceneItem, position, Quaternion.identity);
                instantiatedAmmoSceneItem.GetComponent<SceneItem>().quantity = fiftyCalDropCount;
                break;
            case Item.AmmoType.PLASMA_CELL:
                instantiatedAmmoSceneItem = Instantiate(plasmaCellSceneItem, position, Quaternion.identity);
                instantiatedAmmoSceneItem.GetComponent<SceneItem>().quantity = plasmaCellDropCount;
                break;
            case Item.AmmoType.FLARE:
                instantiatedAmmoSceneItem = Instantiate(flareSceneItem, position, Quaternion.identity);
                instantiatedAmmoSceneItem.GetComponent<SceneItem>().quantity = flareDropCount;
                break;
            case Item.AmmoType.ARROW:
                instantiatedAmmoSceneItem = Instantiate(arrowSceneItem, position, Quaternion.identity);
                instantiatedAmmoSceneItem.GetComponent<SceneItem>().quantity = arrowDropCount;
                break;
            case Item.AmmoType.CRYO_CELL:
                instantiatedAmmoSceneItem = Instantiate(cryoCellSceneItem, position, Quaternion.identity);
                instantiatedAmmoSceneItem.GetComponent<SceneItem>().quantity = cryoCellDropCount;
                break;
            case Item.AmmoType.TWENTYTWOCALIBER:
                instantiatedAmmoSceneItem = Instantiate(twentyTwoCalSceneItem, position, Quaternion.identity);
                instantiatedAmmoSceneItem.GetComponent<SceneItem>().quantity = twentyTwoCalDropCount;
                break;
            case Item.AmmoType.FUEL_CANISTER:
                instantiatedAmmoSceneItem = Instantiate(fuelCanisterSceneItem, position, Quaternion.identity);
                instantiatedAmmoSceneItem.GetComponent<SceneItem>().quantity = fuelCanisterDropCount;
                break;
            case Item.AmmoType.BUZZSAW:
                instantiatedAmmoSceneItem = Instantiate(buzzsawBladeSceneItem, position, Quaternion.identity);
                instantiatedAmmoSceneItem.GetComponent<SceneItem>().quantity = buzzsawBladeDropCount;
                break;
            default:
                break;
        }
    }

    public void SpawnRewardChest()
    {
        // get a vector with random direction and magnitude between distance min and max
        Vector2 randomVector = UtilMath.RandomVector2(360f, 0f, UnityEngine.Random.Range(minDistanceFromPlayer, maxDistanceFromPlayer));

        // get a world point from the player and vector
        Vector3 point = playerMovement.transform.position + (Vector3)randomVector;

        // find closest walkable node to world point
        GraphNode node = AstarPath.active.GetNearest(point, NNConstraint.Default).node;

        // get the world position of said node
        Vector3 nodePosition = (Vector3)node.position;

        // instantiate a scene item at the closest walkable tile to the player
        instantiatedRewardChest = Instantiate(rewardChest, nodePosition, transform.rotation);
    }

    private RewardCategory GenerateRewardCategoryForDoor()
    {
        // pick reward category at random
        int categoryCount = Enum.GetNames(typeof(RewardCategory)).Length;

        // 0 denotes an item that is not a reward, so it is excluded.
        return (RewardCategory)UnityEngine.Random.Range(1, categoryCount);
    }

    private List<int> GenerateRewardItemIDsForDoor(RewardCategory rewardCategory)
    {
        List<int> rewardIDs = new List<int>();
        List<Item> commonItems = new List<Item>();
        List<Item> uncommonItems = new List<Item>();
        List<Item> rareItems = new List<Item>();
        List<Item> epicItems = new List<Item>();

        // get a list of all player items
        var playerItems = playerInventory.GetInventoryAsListOfItems();

        // get a list of all items within the database that has the picked category type = categoryItems
        var categoryItems = itemDatabase.itemList.FindAll(s => s.RewardCategory.Equals(rewardCategory));

        // exclude the player's items from the category's items
        var availableItems = categoryItems.Except(playerItems).ToList();

        // split available items into three lists of rarity
        foreach (Item item in availableItems)
        {
            if (item.Rarity.Equals(Item.ItemRarity.COMMON))
            {
                commonItems.Add(item);
            }
            else if (item.Rarity.Equals(Item.ItemRarity.UNCOMMON))
            {
                uncommonItems.Add(item);
            }
            else if (item.Rarity.Equals(Item.ItemRarity.RARE))
            {
                rareItems.Add(item);
            }
            else if (item.Rarity.Equals(Item.ItemRarity.EPIC))
            {
                epicItems.Add(item);
            }
        }

        // pick 3 items from rarity lists (or fewer if there aren't enough)
        int numChoices;
        if (availableItems.Count >= 3)
        {
            numChoices = 3;
        }
        else
        {
            numChoices = availableItems.Count;
        }

        int choicesAdded = 0;
        int idPick;
        while (choicesAdded < numChoices)
        {
            // roll for what rarity list to select from
            int roll = UnityEngine.Random.Range(1, 101);

            if (roll <= epicRewardChance && epicItems.Count > 0)
            {
                // pop a random ID from the epic list
                int indexPick = UnityEngine.Random.Range(0, epicItems.Count);
                idPick = epicItems[indexPick].ItemID;
                rewardIDs.Add(idPick);
                epicItems.RemoveAt(indexPick);
                choicesAdded++;
            }
            else if (roll <= rareRewardChance && rareItems.Count > 0)
            {
                // pop a random ID from the rare list
                int indexPick = UnityEngine.Random.Range(0, rareItems.Count);
                idPick = rareItems[indexPick].ItemID;
                rewardIDs.Add(idPick);
                rareItems.RemoveAt(indexPick);
                choicesAdded++;
            }
            else if (roll <= uncommonRewardChance && uncommonItems.Count > 0)
            {
                // pop a random ID from the rare list
                int indexPick = UnityEngine.Random.Range(0, uncommonItems.Count);
                idPick = uncommonItems[indexPick].ItemID;
                rewardIDs.Add(idPick);
                uncommonItems.RemoveAt(indexPick);
                choicesAdded++;
            }
            else if (commonItems.Count > 0)
            {
                // pop a random ID from the common list
                int indexPick = UnityEngine.Random.Range(0, commonItems.Count);
                idPick = commonItems[indexPick].ItemID;
                rewardIDs.Add(idPick);
                commonItems.RemoveAt(indexPick);
                choicesAdded++;
            }
            else
            {
                // nothing pulled, retry
                continue;
            }
        }

        return rewardIDs;
    }

    private Sprite GetSpriteForGivenCategory(RewardCategory category)
    {
        return category switch
        {
            RewardCategory.PISTOL => pistol,
            RewardCategory.RIFLE => rifle,
            RewardCategory.HEAVY_WEAPON => heavyWeapon,
            RewardCategory.BLUDGEONING => bludgeoning,
            RewardCategory.BLADE => blade,
            RewardCategory.POLEARM => polearm,
            RewardCategory.THROWING => throwing,
            RewardCategory.EXPLOSIVE => explosive,
            RewardCategory.ENKIISM => enkiism,
            RewardCategory.EREBANCY => erebancy,
            RewardCategory.GAIANISM => gaianism,
            RewardCategory.HERMETICISM => hermeticism,
            RewardCategory.RESHEPHISM => reshephism,
            RewardCategory.IKTOMANCY => iktomancy,
            RewardCategory.CONSUMABLE => consumable,
            RewardCategory.FOCUS_IMPLANT => focusImplant,
            RewardCategory.AUGMENTATION_POINT => augmentationPoint,
            RewardCategory.CURRENCY_HOARD => currencyHoard,
            RewardCategory.AMMO_HOARD => ammoHoard,
            RewardCategory.OUTFIT => outfit,
            _ => null,
        };
    }

    public void IncrementCurrentEnemies() { currentEnemies++; }

    public void DecrementCurrentEnemies() 
    {
        currentEnemies--;

        if (PercentOfEnemiesAlive < NewWaveSpawnThreshold && (currentWave + 1 < waves.Count) && !waveSpawning)
        {
            // number of enemies alive below threshold. spawn new wave
            StartCoroutine(SpawnNewWave());
        }
        else if ((currentWave + 1 >= waves.Count) && currentEnemies == 0 && !waveSpawning)
        {
            EndCombat();
        }
    }

    private void EndCombat()
    {
        // no more enemies and no more waves. End level.
        musicPlayer.StopMusic();

        // play clear jingle
        if (roomClearedSound)
            musicPlayer.PlayOneShot(roomClearedSound, roomClearedSoundVolume);

        // spawn reward items OR spawn reward chest
        if (rewardItemIDs.Count > 1)
        {
            // spawn chest
            SpawnRewardChest();
        }
        else if (rewardItemIDs.Count == 1)
        {
            // if only one item, spawn without chest
            SpawnRewardItems();
        }
        else
        {
            // if no items, spawn a gossamer hoard
            rewardItemIDs.Add(rewardItemIDIfNoRewards);
            SpawnRewardItems();
        }

        // open doors
        if (exitDoors.Count > 0)
            OpenExitDoors();
    }

    IEnumerator SpawnNewWave()
    {
        waveSpawning = true;
        SpawnersFinished = 0;
        enemiesAddedThisWave = 0;

        yield return new WaitForSeconds(UnityEngine.Random.Range(minTimeBetweenWaves, maxTimeBetweenWaves));

        currentWave++;

        // spawn enemies in wave
        for (int i = 0; i < waves[currentWave].enemies.Count; i++)
        {
            // for each enemy, spawn that enemy's count
            for (int j = 0; j < waves[currentWave].counts[i]; j++)
            {
                // Instantiate an enemy spawner which will take care of the actual spawning
                StartCoroutine(InstantiateEnemySpawner(i));
            }
        }

        // set maxEnemies
        for (int i = 0; i < waves[currentWave].enemies.Count; i++)
        {
            enemiesAddedThisWave += waves[currentWave].counts[i];
        }
        maxEnemies = currentEnemies + enemiesAddedThisWave;
    }

    IEnumerator InstantiateEnemySpawner(int i)
    {
        waveSpawning = true;

        // pick a random point within the floor tilemap
        float randX = UnityEngine.Random.Range(gridXMin, gridXMax);
        float randY = UnityEngine.Random.Range(gridYMin, gridYMax);

        Vector3 randomPoint = new Vector3(randX, randY, 0);

        // find closest walkable node to world point
        GraphNode node = AstarPath.active.GetNearest(randomPoint, NNConstraint.Default).node;

        // get the world position of said node
        Vector3 nodePosition = (Vector3)node.position;

        // wait to spawn after a randomized delay
        yield return new WaitForSeconds(UnityEngine.Random.Range(minTimeBetweenSpawners, maxTimeBetweenSpawners));

        // instantiate spawner at point and assign it the current enemy
        GameObject spawner = Instantiate(enemySpawnerObject, nodePosition, Quaternion.identity);
        EnemySpawner enemySpawner = spawner.GetComponent<EnemySpawner>();
        enemySpawner.enemy = waves[currentWave].enemies[i];
        enemySpawner.roomManager = this;
    }

    IEnumerator CloseEntranceDoor()
    {
        yield return new WaitForSeconds(entranceTime);

        entranceDoorAnimator.SetTrigger("GateClose");

        uiSounds.PlayOneShot(doorCloseClip, doorCloseVolume);
    }

    private void OpenExitDoors()
    {
        int doorsOpened = 0;

        List<RewardCategory> selectedCategories = new List<RewardCategory>();

        foreach (GameObject exitDoorObject in exitDoors)
        {
            ExitDoor exitDoor = exitDoorObject.GetComponent<ExitDoor>();
            Animator exitDoorAnimator = exitDoorObject.GetComponent<Animator>();
            BoxCollider2D exitDoorCollider = exitDoorObject.GetComponent<BoxCollider2D>();

            Room unvisitedRoom = GetUnvisitedRoomInCurrentLocation();

            // set one door as the way to the boss room if the boss room is next
            if (nextRoomIsBossRoom)
            {
                exitDoor.SceneName = location.BossRoom.SceneName;

                // place icon
                Debug.Log("Boss room preview icon placed.");

                // open door
                exitDoorAnimator.SetTrigger("GateOpen");
                exitDoorCollider.enabled = true;
                doorsOpened++;

                // no more doors to open
                break;
            }
            else if (unvisitedRoom)
            {
                // assign scene to exit door
                exitDoor.SceneName = unvisitedRoom.SceneName;
            }
            else
            {
                Debug.LogError("Error: Did not get an unvisited room even though next room is not boss room.");
            }

            if (unvisitedRoom)
            {
                if (unvisitedRoom.IsStore)
                {
                    // is store, set reward category sprite manually
                    exitDoor.SetCategoryPreviewSprite(store);
                }
                else
                {
                    // not store, assign the door a reward category that hasn't already been selected
                    RewardCategory doorCategory;
                    while (true)
                    {
                        doorCategory = GenerateRewardCategoryForDoor();

                        if (selectedCategories.Contains(doorCategory))
                        {
                            continue;
                        }
                        else
                        {
                            selectedCategories.Add(doorCategory);
                            break;
                        }
                    }

                    // assign reward item IDs
                    exitDoor.RewardItemIDs = GenerateRewardItemIDsForDoor(doorCategory);

                    // spawn a reward preview above the door with the category's graphic
                    exitDoor.SetCategoryPreviewSprite(GetSpriteForGivenCategory(doorCategory));
                }

                // open door
                if (exitDoorAnimator)
                {
                    exitDoorAnimator.SetTrigger("GateOpen");
                }

                exitDoorCollider.enabled = true;
                doorsOpened++;
            }
        }

        if (doorsOpened > 0 && isCombatScene)
        {
            // play open sound
            PlayDoorOpenSound();
        }
    }

    public void PlayDoorOpenSound()
    {
        ambientSound.PlayOneShot(doorOpenClip, doorOpenVolume);
    }

    public static Vector3 GetClosestWalkableNodeCoordinatesToPoint(Vector3 worldPoint)
    {
        // find closest walkable node to world point
        GraphNode node = AstarPath.active.GetNearest(worldPoint, NNConstraint.Default).node;

        // get the world position of said node
        return (Vector3)node.position;
    }

    public Vector3 GetRandomWalkableCoordinates()
    {
        // pick a random point within the floor tilemap
        float randX = UnityEngine.Random.Range(gridXMin, gridXMax);
        float randY = UnityEngine.Random.Range(gridYMin, gridYMax);

        Vector3 randomPoint = new Vector3(randX, randY, 0);

        // find closest walkable node to world point
        GraphNode node = AstarPath.active.GetNearest(randomPoint, NNConstraint.Default).node;

        // get the world position of said node
        return (Vector3)node.position;
    }

    /* --- CHEATS --- */
    public void FinishRoomCheat()
    {
        if (isCombatScene)
        {
            EndCombat();
        }
    }

    public void TeleportToWalkableSpaceCheat()
    {
        player.transform.position = GetClosestWalkableNodeCoordinatesToPoint(player.transform.position);
    }
}
