using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Room")]
public class Room : ScriptableObject
{
    [SerializeField] int roomID;
    [SerializeField] string sceneName;
    [SerializeField] bool isStore;
    [SerializeField] bool isBossRoom;
    [SerializeField] bool isStartRoom;

    public int RoomID { get => roomID; set => roomID = value; }
    public string SceneName { get => sceneName; set => sceneName = value; }
    public bool IsStore { get => isStore; set => isStore = value; }
    public bool IsBossRoom { get => isBossRoom; set => isBossRoom = value; }
    public bool IsStartRoom { get => isStartRoom; set => isStartRoom = value; }
}