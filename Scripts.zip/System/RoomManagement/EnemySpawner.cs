using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySpawner : MonoBehaviour
{
    public GameObject enemy;
    public RoomManager roomManager;

    public void SpawnEnemy()
    {
        Instantiate(enemy, transform.position, Quaternion.identity);
    }

    public void DestroySelf()
    {
        roomManager.SpawnersFinished++;
        Destroy(gameObject);
    }
}
