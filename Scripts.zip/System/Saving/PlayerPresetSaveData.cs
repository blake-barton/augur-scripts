using System.Collections;
using System.Collections.Generic;

[System.Serializable]
public class PlayerPresetSaveData
{
    public List<PlayerPreset> playerPresets = new List<PlayerPreset>();
}
