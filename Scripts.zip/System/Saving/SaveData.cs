using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

[System.Serializable]
public class SaveData
{
    /* ----- PLAYER ----- */

    public int level;

    // attribute scores
    public int pointsRemaining;
    public int strength;
    public int perception;
    public int endurance;
    public int intelligence;
    public int agility;
    public int aberrance;

    // skills
    public int acrobatics = 0;
    public int barter = 0;
    public int blade = 0;
    public int bludgeoning = 0;
    public int enkiism = 0;
    public int erebancy = 0;
    public int explosives = 0;
    public int gaianism = 0;
    public int heavyWeapons = 0;
    public int hermeticism = 0;
    public int iktomancy = 0;
    public int pistols = 0;
    public int polearms = 0;
    public int reshephism = 0;
    public int resourcefulness = 0;
    public int rifles = 0;
    public int sleightOfHand = 0;
    public int throwing = 0;

    // proficiencies
    public bool[] proficiencies = new bool[18];

    // bars
    public float hp;
    public float mp;
    public float fp;

    // inventory
    public List<int> itemIDs = new List<int>();
    public List<int> itemQuantities = new List<int>();
    public List<bool> weaponEquippedMain = new List<bool>();
    public List<bool> weaponEquippedOff = new List<bool>();
    public List<int> ammoInClip = new List<int>();
    public List<bool> itemEquipped = new List<bool>();
    public List<int> itemQuickEquippedIndexes = new List<int>();
    public List<int> itemQuickAidIndexes = new List<int>();
    public int activeQuickAidIndex;

    // spells
    public List<int> spellIDs = new List<int>();
    public List<bool> spellEquippedMain = new List<bool>();
    public List<bool> spellEquippedOff = new List<bool>();
    public List<int> spellQuickEquippedIndexes = new List<int>();

    // money
    public int currency;

    // augmentations
    public int augmentationPoints;
    public List<int> augmentationIDs = new List<int>();

    /* ----- ROOM ----- */

    // location
    public int locationID;
    public string currentRoomName;
    public List<int> visitedRoomsInLocation = new List<int>();

    // difficulty
    public int veryEasyRoomsVisited;
    public int easyRoomsVisited;
    public int mediumRoomsVisited;
    public int hardRoomsVisited;

    // reward items
    public List<int> rewardItemIDs = new List<int>();

    /* --- QUESTS --- */
    public List<List<string>> questSaveStringLists = new List<List<string>>();

    /* --- DESTINATION --- */

    // destination door
    public string destinationDoor;

    /* --- COMPANIONS --- */
    public List<int> activeCompanionIDs = new List<int>();

    public SaveData(GameObject player, RoomManager roomManager, List<int> _rewardItemIDs, string _destinationDoor)
    {
        /* ----- PLAYER ----- */

        // attribute scores
        AttributeScores attributeScores = player.GetComponent<AttributeScores>();

        level = attributeScores.level;
        pointsRemaining = attributeScores.UnusedPoints;
        strength = attributeScores.Strength;
        perception = attributeScores.Perception;
        endurance = attributeScores.Endurance;
        intelligence = attributeScores.Intelligence;
        agility = attributeScores.Agility;
        aberrance = attributeScores.Aberrance;

        // skills
        acrobatics = attributeScores.acrobatics;
        barter = attributeScores.barter;
        blade = attributeScores.blade;
        bludgeoning = attributeScores.bludgeoning;
        enkiism = attributeScores.enkiism;
        erebancy = attributeScores.erebancy;
        explosives = attributeScores.explosives;
        gaianism = attributeScores.gaianism;
        heavyWeapons = attributeScores.heavyWeapons;
        hermeticism = attributeScores.hermeticism;
        iktomancy = attributeScores.iktomancy;
        pistols = attributeScores.pistols;
        polearms = attributeScores.polearms;
        reshephism = attributeScores.reshephism;
        resourcefulness = attributeScores.resourcefulness;
        rifles = attributeScores.rifles;
        sleightOfHand = attributeScores.sleightOfHand;
        throwing = attributeScores.throwing;

        // proficiencies
        proficiencies = attributeScores.Proficiencies;

        // bars
        hp = player.GetComponent<Health>().CurrentHealth;
        mp = player.GetComponent<Magic>().MagicPoints;
        fp = player.GetComponent<Focus>().FocusPoints;

        // inventory
        Inventory inventory = player.GetComponent<Inventory>();
        Equipment equipment = player.GetComponent<Equipment>();

        foreach (Pair<Item, int> pair in inventory.Items)
        {
            itemIDs.Add(pair.First.ItemID);
            itemQuantities.Add(pair.Second);
            weaponEquippedMain.Add(pair.First.EquippedMain);
            weaponEquippedOff.Add(pair.First.EquippedOff);

            // ammo in clip (-1 if not applicable)
            if (pair.First is RangedWeapon rangedWeapon)
            {
                if (rangedWeapon.EquippedMain)
                {
                    // if equipped, get ammo in clip from equipment
                    ammoInClip.Add(equipment.GetMainhandAmmoInClip());
                }
                else if (rangedWeapon.EquippedOff)
                {
                    ammoInClip.Add(equipment.GetOffhandAmmoInClip());
                }
                else
                {
                    // otherwise, get from data
                    ammoInClip.Add(rangedWeapon.AmmoInClip);
                }
            }
            else
            {
                ammoInClip.Add(-1);
            }

            // equipped items
            itemEquipped.Add(pair.First.Equipped);

            // quick equipped items
            itemQuickEquippedIndexes.Add(pair.First.QuickEquippedIndex);

            // quick aid items
            itemQuickAidIndexes.Add(pair.First.QuickAidIndex);
        }

        // active quick aid index
        activeQuickAidIndex = equipment.GetActiveQuickAidIndex();

        // spells
        Magic magic = player.GetComponent<Magic>();

        foreach (Spell spell in magic.SpellList)
        {
            spellIDs.Add(spell.SpellID);
            spellEquippedMain.Add(spell.EquippedMain);
            spellEquippedOff.Add(spell.EquippedOff);
            spellQuickEquippedIndexes.Add(spell.QuickEquippedIndex);
        }

        // money
        Crypto crypto = player.GetComponent<Crypto>();
        currency = crypto.CurrentCurrency;

        // augmentations
        Augmentations augmentations = player.GetComponent<Augmentations>();
        augmentationPoints = augmentations.AugmentationPoints;

        foreach (Augmentation augmentation in augmentations.AugmentationList)
        {
            augmentationIDs.Add(augmentation.AugmentationID);
        }

        /* ----- ROOM ----- */

        // location
        locationID = roomManager.Location.LocationID;

        // current scene
        currentRoomName = SceneManager.GetActiveScene().name;

        // visited scenes
        foreach (int roomID in roomManager.VisitedRoomIdsInLocation)
        {
            visitedRoomsInLocation.Add(roomID);
        }

        // difficulty
        veryEasyRoomsVisited = roomManager.VeryEasyRoomsVisited;
        easyRoomsVisited = roomManager.EasyRoomsVisited;
        mediumRoomsVisited = roomManager.MediumRoomsVisited;
        hardRoomsVisited = roomManager.HardRoomsVisited;

        // reward item IDs
        if (_rewardItemIDs != null)
        {
            foreach (int id in _rewardItemIDs)
            {
                rewardItemIDs.Add(id);
            }
        }

        /* --- QUESTS --- */
        QuestManager questManager = Object.FindObjectOfType<QuestManager>();

        if (questManager)
        {
            foreach (Quest quest in questManager.ActiveQuests)
            {
                questSaveStringLists.Add(quest.GenerateSaveStringList());
            }
        }

        /* --- DESTINATION --- */

        // destination door
        destinationDoor = _destinationDoor;

        /* --- COMPANIONS --- */

        CompanionManager companionManager = Object.FindObjectOfType<CompanionManager>();
        if (companionManager)
        {
            foreach (Companion companion in companionManager.ActiveCompanions)
            {
                activeCompanionIDs.Add(companion.CompanionID);
            }
        }
    }
}
