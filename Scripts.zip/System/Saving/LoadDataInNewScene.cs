using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LoadDataInNewScene : MonoBehaviour
{
    [SerializeField] float equipTimeDelay = 0.1f;

    Player player;
    AttributeScores attributeScores;
    Inventory inventory;
    Equipment equipment;
    Health health;
    Focus focus;
    Magic magic;
    Crypto crypto;
    Augmentations augmentations;
    RoomManager roomManager;
    QuickAidManager quickAidManager;

    ItemDatabase itemDatabase;
    QuestManager questManager;
    CompanionManager companionManager;

    private void Awake()
    {
        player = FindObjectOfType<Player>();
        attributeScores = player.GetComponent<AttributeScores>();
        inventory = player.GetComponent<Inventory>();
        equipment = player.GetComponent<Equipment>();
        health = player.GetComponent<Health>();
        focus = player.GetComponent<Focus>();
        magic = player.GetComponent<Magic>();
        crypto = player.GetComponent<Crypto>();
        augmentations = player.GetComponent<Augmentations>();
        quickAidManager = FindObjectOfType<QuickAidManager>();

        itemDatabase = FindObjectOfType<ItemDatabase>();
        roomManager = FindObjectOfType<RoomManager>();
        questManager = FindObjectOfType<QuestManager>();
        companionManager = FindObjectOfType<CompanionManager>();
    }

    // Start is called before the first frame update
    void Start()
    {
        LoadData();
    }

    void LoadData()
    {
        SaveData data = SaveSystem.LoadSave();

        /* ----- PLAYER ----- */

        // attribute scores
        attributeScores.SetAttributes(data.strength, data.perception, data.endurance, data.intelligence, data.agility, data.aberrance, data.pointsRemaining);

        // skills and level
        attributeScores.LevelUp(data.level, 0, data.acrobatics, data.barter, data.blade, data.bludgeoning, data.enkiism, data.erebancy, data.explosives, data.gaianism, data.heavyWeapons, data.hermeticism, data.iktomancy, data.pistols, data.polearms, data.reshephism, data.resourcefulness, data.rifles, data.sleightOfHand, data.throwing);

        // proficiencies
        attributeScores.Proficiencies = data.proficiencies;

        // bars
        health.SetCurrentHealth(data.hp);
        magic.SetMagicPoints(data.mp);
        focus.SetFocusPoints(data.fp);

        // inventory
        for (int i = 0; i < data.itemIDs.Count; i++)
        {
            // instantiate item
            Item item = Instantiate(itemDatabase.itemList[data.itemIDs[i]]);

            // ammo in clip
            if (item is RangedWeapon rangedWeapon)
            {
                rangedWeapon.AmmoInClip = data.ammoInClip[i];
            }

            // add to inventory
            var itemPair = inventory.AddItem(item, data.itemQuantities[i], false);

            // quick equip
            if (data.itemQuickEquippedIndexes[i] > -1)
            {
                equipment.PlaceEquippable(item, data.itemQuickEquippedIndexes[i]);
            }

            // quick aid
            if (data.itemQuickAidIndexes[i] > -1)
            {
                quickAidManager.AddItemPair(data.itemQuickAidIndexes[i], itemPair);
            }
        }

        // set active quick aid index
        quickAidManager.SetActiveKey(data.activeQuickAidIndex);

        // spells
        for (int i = 0; i < data.spellIDs.Count; i++)
        {
            Spell newSpell = magic.AddSpell(itemDatabase.spellList[data.spellIDs[i]]);

            // quick equip
            if (data.spellQuickEquippedIndexes[i] > -1)
            {
                equipment.PlaceEquippable(newSpell, data.spellQuickEquippedIndexes[i]);
            }
        }

        // currency
        crypto.AddCurrency(data.currency);

        // augmentations
        augmentations.AugmentationPoints = data.augmentationPoints;

        foreach (int id in data.augmentationIDs)
        {
            augmentations.AddAugmentation(itemDatabase.augmentationList[id]);
        }

        /* ----- ROOM ----- */

        // difficulty tracking
        roomManager.SetDifficultyOfRoomsVisited(data.veryEasyRoomsVisited, data.easyRoomsVisited, data.mediumRoomsVisited, data.hardRoomsVisited);

        // previously visited rooms in location
        roomManager.SetVisitedRoomsInLocation(data.visitedRoomsInLocation);

        // new room reward item IDs
        roomManager.RewardItemIDs = data.rewardItemIDs;

        /* --- QUESTS --- */

        questManager.LoadQuestsFromQuestSaveStringLists(data.questSaveStringLists);

        /* --- DESTINATION --- */

        // move player to correct door (if there is one)
        if (data.destinationDoor != "" && data.destinationDoor != null)
        {
            player.transform.position = GameObject.Find(data.destinationDoor).transform.position;
        }

        /* --- COMPANIONS --- */

        if (companionManager)
        {
            foreach (int id in data.activeCompanionIDs)
            {
                companionManager.SpawnCompanion(id);
            }
        }

        /* ----- EQUIP PLAYER ----- */

        // equip player
        StartCoroutine(EquipPlayer(data));
    }

    IEnumerator EquipPlayer(SaveData data)
    {
        yield return new WaitForSeconds(equipTimeDelay);

        // inventory
        for (int i = 0; i < inventory.Items.Count; i++)
        {
            Item item = inventory.Items[i].First;

            if (item.Type == Item.ItemType.RANGEDWEAPON || item.Type == Item.ItemType.MELEEWEAPON)
            {
                if (data.weaponEquippedMain[i])
                {
                    Equippable newWeapon = new Equippable(item);
                    equipment.EquipMainHandWeapon(newWeapon, false);
                }
                else if (data.weaponEquippedOff[i])
                {
                    Equippable newWeapon = new Equippable(item);
                    equipment.EquipOffHandWeapon(newWeapon, false);
                }
            }
            else if (item.Type == Item.ItemType.OUTFIT)
            {
                if (data.itemEquipped[i])
                {
                    equipment.EquipOutfit(i, false);
                }
            }
            else if (item.Type == Item.ItemType.FOCUSIMPLANT)
            {
                if (data.itemEquipped[i])
                {
                    focus.EquipImplant(i);
                }
            }
        }

        // spells
        for (int i = 0; i < magic.SpellList.Count; i++)
        {
            if (data.spellEquippedMain[i])
            {
                equipment.EquipMainHandSpell(magic.SpellList[i], false);
            }
            
            if (data.spellEquippedOff[i])
            {
                equipment.EquipOffHandSpell(magic.SpellList[i], false);
            }
        }
    }
}
