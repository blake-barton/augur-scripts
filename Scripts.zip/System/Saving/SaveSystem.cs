using UnityEngine;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Collections;
using System.Collections.Generic;
using Newtonsoft.Json;

public static class SaveSystem
{
    public static string presetsFilename = "/Presets.txt";

    public static void Save(GameObject player, RoomManager roomManager, List<int> rewardItemIDs, string doorName = "")
    {
        BinaryFormatter formatter = new BinaryFormatter();
        string path = Application.persistentDataPath + "/player.txt";
        FileStream stream = new FileStream(path, FileMode.Create);

        SaveData data = new SaveData(player, roomManager, rewardItemIDs, doorName);

        formatter.Serialize(stream, data);
        stream.Close();
    }

    public static SaveData LoadSave()
    {
        string path = Application.persistentDataPath + "/player.txt";

        if (File.Exists(path))
        {
            BinaryFormatter formatter = new BinaryFormatter();
            FileStream stream = new FileStream(path, FileMode.Open);

            SaveData data = formatter.Deserialize(stream) as SaveData;
            stream.Close();

            return data;
        }
        else
        {
            Debug.LogError("Save file not found in " + path);
            return null;
        }
    }

    public static void SavePlayerPreset(PlayerPreset preset)
    {
        // deserialize the file to an object
        PlayerPresetSaveData playerPresetSaveData = LoadPlayerPresets();

        string path = Application.persistentDataPath + presetsFilename;

        BinaryFormatter formatter = new BinaryFormatter();
        FileStream stream = new FileStream(path, FileMode.Create);

        // if data is empty, initialize
        if (playerPresetSaveData == null)
        {
            playerPresetSaveData = new PlayerPresetSaveData();
        }

        // append new preset
        playerPresetSaveData.playerPresets.Add(preset);

        // write to file
        formatter.Serialize(stream, playerPresetSaveData);
        stream.Close();
    }

    public static PlayerPresetSaveData LoadPlayerPresets()
    {
        string path = Application.persistentDataPath + presetsFilename;

        if (File.Exists(path))
        {
            BinaryFormatter formatter = new BinaryFormatter();
            FileStream stream = new FileStream(path, FileMode.OpenOrCreate);

            if (stream.Length == 0)
            {
                Debug.Log("Empty presets file.");
                stream.Close();

                return null;
            }

            PlayerPresetSaveData data = formatter.Deserialize(stream) as PlayerPresetSaveData;
            stream.Close();

            return data;
        }
        else
        {
            Debug.Log("Save file not found in " + path);
            return null;
        }
    }

    public static int GetNextAvailablePresetID()
    {
        PlayerPresetSaveData playerPresetSaveData = LoadPlayerPresets();

        if (playerPresetSaveData == null)
        {
            return 0;
        }

        int maxID = -1;

        foreach (PlayerPreset preset in playerPresetSaveData.playerPresets)
        {
            if (preset.id > maxID)
            {
                maxID = preset.id;
            }
        }

        return maxID + 1;
    }
}
