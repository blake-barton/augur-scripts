using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DebugCommand : DebugCommandBase
{
    Action command;

    public DebugCommand(string id, string description, string format, Action _command) : base (id, description, format)
    {
        command = _command;
    }

    public void Invoke()
    {
        command.Invoke();
    }
}
