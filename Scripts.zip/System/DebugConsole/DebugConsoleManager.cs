using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DebugConsoleManager : MonoBehaviour
{
    [Header("References")]
    [SerializeField] RoomManager roomManager;
    [SerializeField] SceneLoader sceneLoader;

    [Header("State")]
    [SerializeField] bool showConsole;
    bool showHelp;
    string input;

    public static DebugCommand FINISH_ROOM;
    public static DebugCommand HELP;
    public static DebugCommand TELEPORT_WALKABLE_POINT;
    public static DebugCommand RESTART_ROOM;
    public static DebugCommand RESET_TIMESCALE;

    public static List<object> commandList;

    Vector2 scroll;

    private void Awake()
    {
        FINISH_ROOM = new DebugCommand("finish_room", "Immediately spawn room reward chest and open doors.", "finish_room", () =>
        {
            roomManager.FinishRoomCheat();
        });

        HELP = new DebugCommand("help", "Show a list of available commands.", "help", () =>
        {
            showHelp = true;
        });

        TELEPORT_WALKABLE_POINT = new DebugCommand("tp_walkable", "Teleport player to nearest walkable space.", "tp_walkable", () =>
        {
            roomManager.TeleportToWalkableSpaceCheat();
        });

        RESTART_ROOM = new DebugCommand("restart_room", "Restart the current room.", "restart_room", () =>
        {
            sceneLoader.ReloadCurrentSceneWithoutSaving();
        });

        RESET_TIMESCALE = new DebugCommand("reset_timescale", "Resets Time.timeScale to 1.", "reset_timescale", () =>
        {
            Time.timeScale = 1f;
        });

        commandList = new List<object>
        {
            FINISH_ROOM,
            HELP,
            TELEPORT_WALKABLE_POINT,
            RESTART_ROOM,
            RESET_TIMESCALE
        };
    }

    private void Update()
    {
        // open console
        if (Input.GetKeyDown(KeyCode.BackQuote))
        {
            showConsole = !showConsole;
        }

        // handle input
        if (showConsole && Input.GetKeyDown(KeyCode.Return))
        {
            HandleInput();
            input = "";
        }
    }

    private void OnGUI()
    {
        if (!showConsole) { return; }

        float y = 0;

        if (showHelp)
        {
            GUI.Box(new Rect(0, y, Screen.width, 100), "");

            // create scroll view
            Rect viewport = new Rect(0, 0, Screen.width - 30, 20 * commandList.Count);
            scroll = GUI.BeginScrollView(new Rect(0, y + 5f, Screen.width, 90), scroll, viewport);
            
            // print commands
            for (int i = 0; i < commandList.Count; i++)
            {
                DebugCommandBase command = commandList[i] as DebugCommandBase;

                string label = $"{command.CommandFormat} - {command.CommandDescription}";

                Rect labelRect = new Rect(5, 20 * i, viewport.width - 100, 20);

                GUI.Label(labelRect, label);
            }

            GUI.EndScrollView();

            y += 100;
        }

        GUI.Box(new Rect(9, y, Screen.width, 30), "");
        GUI.backgroundColor = new Color(0, 0, 0, 0);

        input = GUI.TextField(new Rect(10f, y + 5f, Screen.width - 20f, 20f), input);
    }

    private void HandleInput()
    {
        for (int i = 0; i < commandList.Count; i++)
        {
            DebugCommandBase commandBase = commandList[i] as DebugCommandBase;

            // invoke command if the input string contains the command id
            if (input.Contains(commandBase.CommandID))
            {
                if (commandList[i] as DebugCommand != null)
                {
                    (commandList[i] as DebugCommand).Invoke();
                }
            }
        }
    }
}
