using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DebugCommandBase
{
    string commandID;
    string commandDescription;
    string commandFormat;

    public string CommandID { get => commandID; }
    public string CommandDescription { get => commandDescription; }
    public string CommandFormat { get => commandFormat; }

    public DebugCommandBase(string id, string description, string format)
    {
        commandID = id;
        commandDescription = description;
        commandFormat = format;
    }
}