using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

// use SceneManagement for changing between scenes
public class SceneLoader : MonoBehaviour
{
    public Animator loadingAnimator;
    public float transitionTime = 1f;

    [SerializeField] RoomManager roomManager;
    [SerializeField] Player player;

    public void LoadNextScene()
    {
        ClearMessageSubscribers();

        int currentSceneIndex = SceneManager.GetActiveScene().buildIndex;
        SceneManager.LoadScene(currentSceneIndex + 1);
    }

    public void LoadNextSceneAsync()
    {
        ClearMessageSubscribers();

        int nextSceneIndex = SceneManager.GetActiveScene().buildIndex + 1;

        StartCoroutine(PlaySceneTransition(nextSceneIndex));
    }

    public void LoadFirstScene()
    {
        ClearMessageSubscribers();

        SceneManager.LoadScene(0);
    }

    public void LoadPreviousScene()
    {
        ClearMessageSubscribers();

        int currentSceneIndex = SceneManager.GetActiveScene().buildIndex;
        SceneManager.LoadScene(currentSceneIndex - 1);
    }

    public void QuitGame()
    {
        Application.Quit();
    }

    public void LoadSceneByName(string scene, List<int> rewardItemIDs = null, string doorName = "")
    {
        ClearMessageSubscribers();

        // save data
        SaveSystem.Save(player.gameObject, roomManager, rewardItemIDs, doorName);

        StartCoroutine(PlaySceneTransition(scene));
    }

    public void LoadSceneByNameAsyncWithoutSaving(string scene)
    {
        ClearMessageSubscribers();

        StartCoroutine(PlaySceneTransition(scene));
    }

    IEnumerator PlaySceneTransition(string scene)
    {
        loadingAnimator.SetTrigger("StartCrossfade");

        yield return new WaitForSeconds(transitionTime);

        AsyncOperation operation = SceneManager.LoadSceneAsync(scene);
    }

    IEnumerator PlaySceneTransition(int sceneIndex)
    {
        loadingAnimator.SetTrigger("StartCrossfade");

        yield return new WaitForSeconds(transitionTime);

        AsyncOperation operation = SceneManager.LoadSceneAsync(sceneIndex);
    }

    public void ReloadCurrentSceneWithoutSaving()
    {
        ClearMessageSubscribers();

        StartCoroutine(PlaySceneTransition(SceneManager.GetActiveScene().buildIndex));
    }

    void ClearMessageSubscribers()
    {
        CombatSystemMessenger.Instance.ClearMessageSubscribers();
    }
}