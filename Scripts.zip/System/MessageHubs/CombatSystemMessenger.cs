using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyKilledMessage
{
    Equippable equippable;
    string enemyName;

    public Equippable Equippable { get => equippable; }
    public string EnemyName { get => enemyName; }

    public EnemyKilledMessage()
    {

    }

    public EnemyKilledMessage(Equippable _equippable, string _enemyName)
    {
        equippable = _equippable;
        enemyName = _enemyName;
    }
}

public class CombatSystemMessenger
{
    private static CombatSystemMessenger instance;
    public static CombatSystemMessenger Instance
    {
        get
        {
            if (instance == null)
            {
                instance = new CombatSystemMessenger();
            }

            return instance;
        }
        private set
        {
            instance = value;
        }
    }

    public delegate void EnemyKilledMessageDelegate(EnemyKilledMessage message);

    public event EnemyKilledMessageDelegate EnemyKilledEvent;

    public void SendEnemyKilledMessage(EnemyKilledMessage message)
    {
        EnemyKilledEvent?.Invoke(message);
    }

    public void ClearMessageSubscribers()
    {
        EnemyKilledEvent = null;
    }
}
