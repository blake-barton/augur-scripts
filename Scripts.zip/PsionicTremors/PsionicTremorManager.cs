using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PsionicTremorManager : MonoBehaviour
{
    [SerializeField] int chanceForTremor = 20;

    private void Start()
    {
        RollForTremor();
    }

    void RollForTremor()
    {
        if (UtilMath.PercentileRoll(chanceForTremor))
        {
            Debug.Log("Psionic Tremor!");
        }
    }
}
