using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RewardChestAudio : MonoBehaviour
{
    [SerializeField] AudioSource audioSource;

    [Header("Audio")]
    [SerializeField] List<AudioClip> fallAudioClips = new List<AudioClip>();
    [SerializeField] [Range(0, 1)] float fallAudioVolume = 1f;
    [SerializeField] List<AudioClip> idleAudioClips = new List<AudioClip>();
    [SerializeField] [Range(0, 1)] float idleAudioVolume = 1f;
    [SerializeField] List<AudioClip> openAudioClips = new List<AudioClip>();
    [SerializeField] [Range(0, 1)] float openAudioVolume = 1f;
    [SerializeField] List<AudioClip> exitAudioClips = new List<AudioClip>();
    [SerializeField] [Range(0, 1)] float exitAudioVolume = 1f;

    public void PlayFallAudio()
    {
        AudioUtility.PlayRandomSound(audioSource, fallAudioClips, fallAudioVolume);
    }

    public void PlayIdleAudio()
    {
        AudioUtility.PlayRandomSound(audioSource, idleAudioClips, idleAudioVolume);
    }

    public void PlayOpenAudio()
    {
        AudioUtility.PlayRandomSound(audioSource, openAudioClips, openAudioVolume);
    }

    public void PlayExitAudio()
    {
        AudioUtility.PlayRandomSound(audioSource, exitAudioClips, exitAudioVolume);
    }
}
