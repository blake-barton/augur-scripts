using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioMaterialScript : MonoBehaviour
{
    public enum AudioMaterial
    {
        Wood,
        Metal,
        Flesh,
        Stone,
        Cloth
    }
    [SerializeField] AudioMaterial audioMaterial;
    [SerializeField] [Range(0, 1)] float volume = 1f;

    [Header("Sounds")]
    [SerializeField] AudioClip[] woodSounds;
    [SerializeField] AudioClip[] metalSounds;
    [SerializeField] AudioClip[] fleshSounds;
    [SerializeField] AudioClip[] stoneSounds;
    [SerializeField] AudioClip[] clothSounds;

    public void PlayImpactSound(Collision2D collision)
    {
        switch (audioMaterial)
        {
            case AudioMaterial.Wood:
                PlayRandomSound(woodSounds, volume, collision);
                break;
            case AudioMaterial.Metal:
                PlayRandomSound(metalSounds, volume, collision);
                break;
            case AudioMaterial.Flesh:
                PlayRandomSound(fleshSounds, volume, collision);
                break;
            case AudioMaterial.Stone:
                PlayRandomSound(stoneSounds, volume, collision);
                break;
            case AudioMaterial.Cloth:
                PlayRandomSound(clothSounds, volume, collision);
                break;
            default:
                break;
        }
    }

    public void PlayImpactSound(Collider2D collision)
    {
        switch (audioMaterial)
        {
            case AudioMaterial.Wood:
                PlayRandomSound(woodSounds, volume, collision);
                break;
            case AudioMaterial.Metal:
                PlayRandomSound(metalSounds, volume, collision);
                break;
            case AudioMaterial.Flesh:
                PlayRandomSound(fleshSounds, volume, collision);
                break;
            case AudioMaterial.Stone:
                PlayRandomSound(stoneSounds, volume, collision);
                break;
            case AudioMaterial.Cloth:
                PlayRandomSound(clothSounds, volume, collision);
                break;
            default:
                break;
        }
    }

    private void PlayRandomSound(AudioClip[] clips, float volume, Collision2D collision)
    {
        int randomIndex = Random.Range(0, clips.Length);
        AudioSource.PlayClipAtPoint(clips[randomIndex], collision.GetContact(0).point, volume);
    }

    private void PlayRandomSound(AudioClip[] clips, float volume, Collider2D collision)
    {
        int randomIndex = Random.Range(0, clips.Length);
        AudioSource.PlayClipAtPoint(clips[randomIndex], collision.ClosestPoint(transform.position), volume);
    }
}
