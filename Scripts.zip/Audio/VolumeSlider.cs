using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Audio;
using TMPro;

public class VolumeSlider : MonoBehaviour
{
    [SerializeField] SettingsMenu settingsMenu;
    [SerializeField] AudioMixer mixer;
    [SerializeField] string volumeName;
    [SerializeField] TextMeshProUGUI volumeLabel;

    // cached references
    Slider slider;

    private void Awake()
    {
        slider = GetComponent<Slider>();
        slider.onValueChanged.AddListener(delegate
        {
            UpdateValueOnChange(slider.value);
        });
    }

    public void UpdateValueOnChange(float value)
    {
        if (mixer)
        {
            mixer.SetFloat(volumeName, Mathf.Log(value) * 20f);
        }

        if (volumeLabel)
        {
            volumeLabel.text = Mathf.Round(value * 100f).ToString() + "%";
        }

        // there are now unsaved changes
        settingsMenu.ChangesSaved = false;
    }
}