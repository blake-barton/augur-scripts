using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyController : MonoBehaviour
{
    protected Enemy enemy;
    protected Animator animator;
    protected Health health;
    protected EnemyMovement movement;
    protected Poise poise;

    private void Awake()
    {
        enemy = GetComponent<Enemy>();
        animator = GetComponent<Animator>();
        health = GetComponent<Health>();
        movement = GetComponent<EnemyMovement>();
        poise = GetComponent<Poise>();
    }

    public virtual void Die() {}
}