using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class AIRangedAttack : MonoBehaviour
{
    public enum AttackState
    {
        WAITING,
        ATTACKING,
    }

    public enum AttackType
    {
        PROJECTILE,
        LASER
    }

    [Header("Enemy")]
    [SerializeField] Enemy enemy;
    [SerializeField] EnemyFireProjectile fireProjectile;
    [SerializeField] AIFireLaser fireLaser;
    [SerializeField] LineOfSight lineOfSight;

    [Header("Equipped Weapon Attacks")]
    [SerializeField] float fullAutoBurstTime = 1f;

    [Header("Attack Telegraph")]
    [SerializeField] FlashOnHit gunColorFlash;
    [SerializeField] Animator telegraphAnimator;
    [SerializeField] string animatedTelegraphString = "AnimIsCharging";
    [SerializeField] float timeToTelegraphShot = 0.6f;

    [Header("Enemy Animation")]
    [SerializeField] Animator animator;                     // enemy animation, not weapon

    [Header("State")]
    [SerializeField] AttackState state;

    [Header("Events")]
    public UnityEvent firedSingleShot;

    public AttackState State { get => state; set => state = value; }

    // Update is called once per frame
    void Update()
    {
        // animation of enemy, not weapon
        if (animator && enemy.Health.Alive && lineOfSight.Target)
        {
            Animate();
        }
    }

    public bool FireSingleShot(AttackType attackType)
    {
        if (!enemy.Character.Incapacitated)
        {
            StartCoroutine(SingleShot(attackType));

            return true;
        }

        return false;
    }

    IEnumerator SingleShot(AttackType attackType)
    {
        // Attacking state
        State = AttackState.ATTACKING;

        // telegraph shot
        if (gunColorFlash)
        {
            if (!gunColorFlash.IsFlashing)
            {
                gunColorFlash.TriggerFlashContinous();
            }
        }
        else if (telegraphAnimator)
        {
            telegraphAnimator.SetBool(animatedTelegraphString, true);
        }

        yield return new WaitForSeconds(timeToTelegraphShot);

        // stop telegraphing
        if (gunColorFlash)
        {
            gunColorFlash.StopFlashContinuous();
        }
        else if (telegraphAnimator)
        {
            telegraphAnimator.SetBool(animatedTelegraphString, false);
        }

        // fire
        if (!enemy.Character.Incapacitated)
        {
            switch (attackType)
            {
                case AttackType.PROJECTILE:
                    fireProjectile.TryFireSingleShot();
                    break;
                case AttackType.LASER:
                    fireLaser.TryFireSingleShot();
                    break;
                default:
                    break;
            }

            // Event
            firedSingleShot.Invoke();
        }

        // Done
        State = AttackState.WAITING;
    }

    public bool FireFullAuto(AttackType attackType)
    {
        if (!enemy.Character.Incapacitated)
        {
            StartCoroutine(TelegraphFullAuto(attackType));

            return true;
        }

        return false;
    }

    IEnumerator TelegraphFullAuto(AttackType attackType)
    {
        // Attacking state
        State = AttackState.ATTACKING;

        // telegraph shot
        if (gunColorFlash)
        {
            if (!gunColorFlash.IsFlashing)
            {
                gunColorFlash.TriggerFlashContinous();
            }
        }

        yield return new WaitForSeconds(timeToTelegraphShot);

        // stop telegraphing
        if (gunColorFlash)
        {
            gunColorFlash.StopFlashContinuous();
        }

        // fire
        if (!enemy.Character.Incapacitated)
        {
            StartCoroutine(FullAuto(attackType));
        }
        else
        {
            // Waiting state
            State = AttackState.WAITING;
        }
    }

    IEnumerator FullAuto(AttackType attackType)
    {
        // Start firing
        switch (attackType)
        {
            case AttackType.PROJECTILE:
                fireProjectile.TriggerSpawnProjectileFullAuto();
                break;
            case AttackType.LASER:
                fireLaser.TriggerFireFullAuto();
                break;
            default:
                break;
        }

        if (animator)
        {
            animator.SetBool("AnimIsFiring", true);
        }

        // continue firing unless enemy is knocked down or killed
        for (float timer = fullAutoBurstTime; timer >= 0; timer -= Time.deltaTime)
        {
            if (enemy.Character.Incapacitated)
            {
                // Waiting state
                State = AttackState.WAITING;

                StopFiringFullAuto(attackType);
                yield break;
            }
            yield return null;
        }

        // Stop firing
        StopFiringFullAuto(attackType);

        if (animator)
        {
            animator.SetBool("AnimIsFiring", false);
        }

        // Waiting state
        State = AttackState.WAITING;
    }

    private void StopFiringFullAuto(AttackType attackType)
    {
        switch (attackType)
        {
            case AttackType.PROJECTILE:
                fireProjectile.StopSpawningFullAuto();
                break;
            case AttackType.LASER:
                fireLaser.StopFiringFullAuto();
                break;
            default:
                break;
        }
    }

    public void StopFiring()
    {
        StopAllCoroutines();

        State = AttackState.WAITING;
    }

    void Animate()
    {
        animator.SetFloat("AnimLookX", lineOfSight.GetDirectionToTarget().x);
        animator.SetFloat("AnimLookY", lineOfSight.GetDirectionToTarget().y);
    }
}
