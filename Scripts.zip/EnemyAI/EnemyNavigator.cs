using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pathfinding;

public class EnemyNavigator : MonoBehaviour
{
    [SerializeField] NavigationModes navigationMode;

    [Header("Enemy")]
    [SerializeField] Enemy enemy;
    [SerializeField] EnemyMovement movement;
    [SerializeField] LineOfSight lineOfSight;

    [Header("Animation")]
    [SerializeField] Animator animator;

    [Header("Pathfinding")]
    [SerializeField] float distanceToDestination;
    [SerializeField] float minIdleDistance = 1.5f;

    [Header("Ranged Pathfinding")]
    [SerializeField] float minDistanceFromTarget = 3f;
    [SerializeField] float maxDistanceFromTarget = 12f;
    [SerializeField] float moveCounter;
    [SerializeField] float minTimeBetweenDestinationChange = 5f;
    [SerializeField] float maxTimeBetweenDestinationChange = 10f;
    
    GameObject rangedDestination;   // destination for enemies that stay at range
    Transform player;

    public NavigationModes NavigationMode { 
        get => navigationMode;
        set
        {
            navigationMode = value;
            SwitchNavigationMode();
        }
    }

    public enum NavigationModes
    {
        SeekPlayer,
        StayBetweenRanges
    }

    private void Awake()
    {
        player = FindObjectOfType<Player>().transform;

        // set line of sight target to player
        lineOfSight.Target = player;
    }

    private void Start()
    {
        SwitchNavigationMode();
    }

    // Update is called once per frame
    void Update()
    {
        if (navigationMode == NavigationModes.StayBetweenRanges)
        {
            FindNewDestination();
        }
    }

    private void SwitchNavigationMode()
    {
        switch (navigationMode)
        {
            case NavigationModes.SeekPlayer:
                // seek player
                movement.Destination = player;
                InvokeRepeating(nameof(GetDistanceToDestinationSeeker), 0f, .5f);
                break;
            case NavigationModes.StayBetweenRanges:
                // stay at range of the player
                rangedDestination = new GameObject();
                rangedDestination.transform.position = lineOfSight.Target.transform.position;
                movement.Destination = rangedDestination.transform;
                InvokeRepeating(nameof(GetDistanceToDestinationRanged), 0f, .5f);
                break;
        }
    }

    // find random walkable destination that is between min and max distance and set it in the movement script
    private void FindNewDestination()
    {
        moveCounter -= Time.deltaTime;
        if (moveCounter <= 0f)
        {
            // get a vector with random direction and magnitude between distance min and max
            Vector2 randomVector = UtilMath.RandomVector2(360f, 0f, Random.Range(minDistanceFromTarget, maxDistanceFromTarget));

            // get a world point from the target and vector
            Vector3 point = lineOfSight.Target.position + (Vector3)randomVector;

            // find closest walkable node to world point
            GraphNode node = AstarPath.active.GetNearest(point, NNConstraint.Default).node;

            // get the world position of said node
            Vector3 nodePosition = (Vector3)node.position;

            // set destination's position to that
            rangedDestination.transform.position = nodePosition;

            // set the destination of the movement script to this script's destination
            movement.Destination = rangedDestination.transform;

            // reset counter
            moveCounter = Random.Range(minTimeBetweenDestinationChange, maxTimeBetweenDestinationChange);
        }
    }

    private void GetDistanceToDestinationRanged()
    {
        distanceToDestination = Vector2.Distance(transform.position, rangedDestination.transform.position);

        // go to idle
        if (distanceToDestination <= minIdleDistance)
        {
            animator.SetBool("AnimInRange", true);
            movement.Speed = 0;
        }
        else
        {
            animator.SetBool("AnimInRange", false);

            // let them move to the new point if they aren't knocked down
            if (!enemy.Character.Incapacitated)
            {
                movement.Speed = movement.OriginalSpeed;
            }
        }
    }

    private void GetDistanceToDestinationSeeker()
    {
        distanceToDestination = Vector2.Distance(transform.position, lineOfSight.Target.position);

        // go to idle
        if (distanceToDestination <= minIdleDistance)
        {
            animator.SetBool("AnimInRange", true);
        }
        else
        {
            animator.SetBool("AnimInRange", false);
        }
    }
}
