using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class AIMeleeAttack : MonoBehaviour
{
    public enum AttackState
    {
        WAITING,
        ATTACKING,
    }

    enum AttackDirection
    {
        Movement,
        LineOfSight
    }

    [Header("Required Components")]
    [SerializeField] Enemy enemy;
    [SerializeField] EnemyMovement movement;
    [SerializeField] Animator animator;
    [SerializeField] LineOfSight lineOfSight;
    [SerializeField] Rigidbody2D rb;

    [Header("Attack Telegraph")]
    [SerializeField] string animatedTelegraphString = "AnimReadySwing";
    [SerializeField] float timeToTelegraphAttack = 0.6f;

    [Header("Attack")]
    [SerializeField] GameObject slashPrefab;
    [SerializeField] float attackDelay = 0.4f;
    [SerializeField] float attackLungeMagnitude = 2f;
    [SerializeField] float attackRangeMultiplier = 1.5f;
    [SerializeField] float attackMovementSpeedMultiplier = .1f;     // for slowing down the actor on attack
    [SerializeField] AttackDirection attackDirectionType = AttackDirection.Movement;

    [Header("Damage")]
    [SerializeField] List<float> damages = new();
    [SerializeField] List<DamageEffects.DamageType> damageTypes = new();
    [SerializeField] float forceDamage;
    [SerializeField] float bleedBuildup;
    [SerializeField] float statusEffectDamagePercentage = 1f;

    [Header("Animation")]
    [SerializeField] string attackAnimationState = "Attack";

    [Header("Audio")]
    [SerializeField] AudioSource audioSource;
    [SerializeField] List<AudioClip> swingSounds = new();
    [SerializeField] [Range(0, 1)] float swingVolume = 1;
    [SerializeField] List<AudioClip> swingGrunts = new();
    [SerializeField] [Range(0, 1)] float gruntVolume = 1;

    [Header("State")]
    [SerializeField] AttackState state;

    [Header("Events")]
    public UnityEvent attacked;

    // Instantiated objects
    GameObject spawnedSlash;

    public AttackState State { get => state; set => state = value; }

    // Update is called once per frame
    void Update()
    {
        // animation of enemy, not weapon
        if (animator && enemy.Health.Alive && lineOfSight.Target)
        {
            Animate();
        }
    }

    public bool TryMeleeAttackWithTelegraph()
    {
        if (!enemy.Character.Incapacitated)
        {
            StartCoroutine(TelegraphAttack());

            return true;
        }

        return false;
    }

    public bool TryMeleeAttackWithoutTelegraph()
    {
        if (!enemy.Character.Incapacitated)
        {
            StartCoroutine(Attack());

            return true;
        }

        return false;
    }

    IEnumerator TelegraphAttack()
    {
        // Attacking state
        State = AttackState.ATTACKING;

        // Telegraph attack
        if (animator)
        {
            animator.SetBool(animatedTelegraphString, true);
        }

        yield return new WaitForSeconds(timeToTelegraphAttack);

        // Stop telegraphing
        if (animator)
        {
            animator.SetBool(animatedTelegraphString, false);
        }

        StartCoroutine(Attack());
    }

    IEnumerator Attack()
    {
        if (!enemy.Character.Incapacitated)
        {
            // Play attack animation
            if (animator)
            {
                animator.Play(attackAnimationState, -1, 0.0f);
            }

            // Wait to spawn slash
            yield return new WaitForSeconds(attackDelay);

            // Attack
            if (!enemy.Character.Incapacitated)
            {
                // Spawn slash
                SpawnSlash();

                // Event
                attacked.Invoke();
            }
        }
        else
        {
            yield return null;
        }

        // Done
        State = AttackState.WAITING;
    }

    public void SpawnSlash()
    {
        // give a little push so that the drained appears to lunge
        rb.AddForce(attackLungeMagnitude * movement.MoveDirection.normalized, ForceMode2D.Impulse);

        // spawn slash, adding move direction to the position so that the lunge actually has an effect
        if (attackDirectionType == AttackDirection.Movement)
        {
            spawnedSlash = Instantiate(slashPrefab, transform.position + attackRangeMultiplier * (Vector3)movement.MoveDirection.normalized, transform.rotation);
        }
        else if (attackDirectionType == AttackDirection.LineOfSight)
        {
            spawnedSlash = Instantiate(slashPrefab, transform.position + attackRangeMultiplier * (Vector3)lineOfSight.GetDirectionToTarget(), transform.rotation);
        }
        else
        {
            Debug.LogError("Bad attack direction type.");
        }

        // direction
        spawnedSlash.GetComponent<EnemyMeleeSlash>().InitializeSlash(movement.MoveDirection, gameObject);

        // add damage to slash
        DamageDealer damageDealer = spawnedSlash.GetComponent<DamageDealer>();
        damageDealer.CopyDamageList(damages);
        damageDealer.CopyDamageTypeList(damageTypes);

        // status effects
        damageDealer.SetStatusEffectDamagePercentage(statusEffectDamagePercentage);
        damageDealer.ForceDamage = forceDamage;
        damageDealer.BleedBuildup = bleedBuildup;

        // sound
        AudioUtility.PlayRandomSound(audioSource, swingGrunts, gruntVolume);
        AudioUtility.PlayRandomSound(audioSource, swingSounds, swingVolume);
    }

    public void StopAttacking()
    {
        StopAllCoroutines();

        State = AttackState.WAITING;
    }

    void Animate()
    {
        animator.SetFloat("AnimLookX", lineOfSight.GetDirectionToTarget().x);
        animator.SetFloat("AnimLookY", lineOfSight.GetDirectionToTarget().y);
    }
}
