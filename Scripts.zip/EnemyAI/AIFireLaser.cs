using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AIFireLaser : MonoBehaviour
{
    [Header("Laser")]
    [SerializeField] float fireDuration = .2f;
    [SerializeField] LineRenderer lineRenderer;
    [SerializeField] Transform firePoint;
    [SerializeField] LayerMask layersToCollideWith;
    [SerializeField] bool penetrateEnemies = false;     // does the laser continue until it hits a wall?

    [Header("Impact Effects")]
    [SerializeField] GameObject actorImpactEffect;
    [SerializeField] GameObject actorCritImpactEffect;
    [SerializeField] [Range(0, 31)] int enemyLayer = 9;
    [SerializeField] [Range(0, 31)] int playerLayer = 6;
    [SerializeField] GameObject wallImpactEffect;
    [SerializeField] [Range(0, 31)] int wallLayer = 10;

    [Header("Audio")]
    [SerializeField] AudioSource audioSource;
    [SerializeField] AudioClip shotAudio;
    [SerializeField] [Range(0, 1)] float shotVolume = 1f;

    [Header("Animation")]
    [SerializeField] Animator animator;

    [Header("Cached References")]
    [SerializeField] LineOfSight lineOfSight;

    // Calculated
    Vector2 fireDirection = new Vector2();
    Vector2 hitPoint = new Vector2();

    // State
    bool laserEnabled = false;
    bool colliderHit = false;

    // cache
    GameObject owner;
    Character ownerCharacter;
    EnemyEquippedRangedWeapon equippedWeapon;
    RangedWeapon rangedWeapon;
    DamageDealer damageDealer;
    MuzzleFlashLight muzzleFlashLight;

    // coroutines
    Coroutine fullAutoCoroutine;

    public bool LaserEnabled { get => laserEnabled; set => laserEnabled = value; }
    public bool ColliderHit { get => colliderHit; set => colliderHit = value; }

    private void Awake()
    {
        owner = transform.root.gameObject;
        ownerCharacter = owner.GetComponent<Character>();
        damageDealer = GetComponent<DamageDealer>();
        equippedWeapon = GetComponent<EnemyEquippedRangedWeapon>();
        muzzleFlashLight = GetComponent<MuzzleFlashLight>();
    }

    // Start is called before the first frame update
    void Start()
    {
        rangedWeapon = (RangedWeapon)equippedWeapon.rangedWeapon;

        CopyDamageListsToDamageDealer();
    }

    // Update is called once per frame
    void Update()
    {
        if (LaserEnabled)
        {
            FireLaser();
        }
    }

    public void CopyDamageListsToDamageDealer()
    {
        damageDealer.CopyDamageList(rangedWeapon.Damages);
        damageDealer.CopyDamageTypeList(rangedWeapon.DamageTypes);

        // status effects
        damageDealer.SetStatusEffectDamagePercentage(rangedWeapon.StatusEffectDamagePercentage);
    }

    Vector2 RotateRandomly(Vector2 aPoint)
    {
        float angle = Random.Range(-rangedWeapon.Spread, rangedWeapon.Spread);

        float rad = angle * Mathf.Deg2Rad;
        float s = Mathf.Sin(rad);
        float c = Mathf.Cos(rad);
        return new Vector2(
            aPoint.x * c - aPoint.y * s,
            aPoint.y * c + aPoint.x * s
        );
    }

    void FireLaser()
    {
        // if hits something
        if (ColliderHit)
        {
            // draw the laser
            DrawRay(firePoint.position, hitPoint);
        }
        else
        {
            // draw a ray as far as the weapon allows (ideally very far)
            DrawRay(firePoint.position, fireDirection * rangedWeapon.MaxRange);
        }
    }

    void DrawRay(Vector2 startPos, Vector2 endPos)
    {
        lineRenderer.positionCount = 2;
        lineRenderer.SetPosition(0, startPos);
        lineRenderer.SetPosition(1, endPos);
    }

    public void TryFireSingleShot()
    {
        // TODO: Multiple lasers at the same time
        FireSingleShot();
    }

    public void TriggerFireFullAuto()
    {
        fullAutoCoroutine = StartCoroutine(FireFullAuto());
    }

    public void StopFiringFullAuto()
    {
        if (!(fullAutoCoroutine is null))
        {
            StopCoroutine(fullAutoCoroutine);
            LaserEnabled = false;

            // animation
            if (animator)
            {
                animator.SetBool("AnimIsFiring", false);
            }
        }
    }

    private void FireSingleShot()
    {
        // animate charge
        if (animator)
        {
            animator.SetBool("AnimIsCharging", false);
        }

        // animate
        if (animator && !rangedWeapon.IsAutomatic)
        {
            animator.Play("Fire", -1, 0.0f);
        }

        StartCoroutine(TriggerFiring());
    }

    IEnumerator TriggerFiring()
    {
        // Wait for a moment to warm up
        if (rangedWeapon.WarmupTime > 0)
        {
            yield return new WaitForSeconds(rangedWeapon.WarmupTime);
        }

        // play sound
        if (audioSource)
        {
            audioSource.Stop(); // stop charge audio
            audioSource.PlayOneShot(shotAudio, shotVolume);
        }

        // muzzle flash
        if (muzzleFlashLight)
        {
            muzzleFlashLight.TriggerMuzzleFlash();
        }

        LaserEnabled = true;

        // Calculate direction
        fireDirection = (lineOfSight.Target.position - firePoint.position).normalized;

        if (rangedWeapon.Spread > 0)
        {
            fireDirection = RotateRandomly(fireDirection);
        }

        // cast a ray towards the mouse
        RaycastHit2D[] hits = Physics2D.RaycastAll(transform.position, fireDirection, Mathf.Infinity, layerMask: layersToCollideWith);

        // if hit something
        if (hits.Length > 0)
        {
            for (int i = 0; i < hits.Length; i++)
            {
                var hit = hits[i];

                // deal damage
                damageDealer.CauseLaserDamage(hit.collider, owner, rangedWeapon);

                // spawn impact effect
                SpawnImpactEffect(hit);

                // break on first hit if not penetrating or break if this is a wall
                if (!penetrateEnemies || (hit.collider.gameObject.layer == wallLayer))
                {
                    // enable line renderer
                    ColliderHit = true;

                    // track where the collision occurred
                    hitPoint = hit.point;

                    break;
                }
                else if (penetrateEnemies && i == hits.Length - 1)
                {
                    // penetrating and hitting last collider, enable laser
                    // enable line renderer
                    ColliderHit = true;

                    // track where the collision occurred
                    hitPoint = hit.point;
                }
            }
        }
        else
        {
            damageDealer.ClearLists();
            CopyDamageListsToDamageDealer();
            ColliderHit = false;
        }

        yield return new WaitForSeconds(fireDuration);

        LaserEnabled = false;
        ColliderHit = false;

        lineRenderer.positionCount = 0;
    }

    IEnumerator FireFullAuto()
    {
        // wait for a moment to warm up
        if (rangedWeapon.WarmupTime > 0)
        {
            yield return new WaitForSeconds(rangedWeapon.WarmupTime);
        }

        // check that there's enough ammo in the clip
        LaserEnabled = true;

        // animation
        if (animator)
        {
            animator.SetBool("AnimIsFiring", true);
        }

        while (true)
        {
            FireSingleShot();

            yield return new WaitForSeconds(1 / rangedWeapon.AttackRate);
        }
    }

    private void SpawnImpactEffect(RaycastHit2D hit)
    {
        if ((hit.collider.gameObject.layer == enemyLayer || hit.collider.gameObject.layer == playerLayer) && actorImpactEffect)
        {
            // hit enemy/player
            if (damageDealer.CritSuccess)
            {
                Instantiate(actorCritImpactEffect, hit.point, Quaternion.identity);
            }
            else
            {
                Instantiate(actorImpactEffect, hit.point, Quaternion.identity);
            }
        }
        else if ((hit.collider.gameObject.layer == wallLayer) && wallImpactEffect)
        {
            // hit wall
            Vector2 n = hit.normal.normalized;

            float angle = Mathf.Atan2(n.y, n.x) * Mathf.Rad2Deg - 90f;

            var newObject = Instantiate(wallImpactEffect, hit.point, Quaternion.identity);
            newObject.transform.rotation = Quaternion.AngleAxis(angle, Vector3.forward);
        }
    }
}
