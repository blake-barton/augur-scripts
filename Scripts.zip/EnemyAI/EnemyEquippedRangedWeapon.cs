using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyEquippedRangedWeapon : MonoBehaviour
{
    [SerializeField] RangedWeapon rangedWeaponTemplate;
    public RangedWeapon rangedWeapon;

    [Header("Rotation")]
    [SerializeField] float spriteRotationalOffset = 0f;
    [SerializeField] float radius = 0.5f;
    public Transform pivot;
    [SerializeField] bool flipped;
    [SerializeField] float minFlipThreshold = 90f;
    [SerializeField] float maxFlipThreshold = 270f;

    [Header("Config")]
    [SerializeField] bool enableSpriteFlip = true;

    // cached references
    [SerializeField] Enemy enemy;
    [SerializeField] LineOfSight lineOfSight;
    SpriteRenderer spriteRenderer;
    Transform target;               // what are we rotating around

    Vector3 lowPoint = new Vector3(100, -20, 0);

    // Start is called before the first frame update
    private void Awake()
    {
        rangedWeapon = Instantiate(rangedWeaponTemplate);
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    // Start is called before the first frame update
    void Start()
    {
        transform.Rotate(0, 0, spriteRotationalOffset);

        // rotation
        target = transform.parent;
        pivot = new GameObject().transform;
        pivot.parent = transform.parent;
        pivot.name = "Enemy Weapon";
        transform.parent = pivot;
    }

    // Update is called once per frame
    private void Update()
    {
        if (!enemy.Character.Incapacitated && lineOfSight.Target)
        {
            RotateAroundOwnerTowardsTarget();
        }
        else if (!enemy.Character.Incapacitated && !lineOfSight.Target)
        {
            AimDown();
        }

        FlipSprite();
    }

    void RotateAroundOwnerTowardsTarget()
    {
        Vector3 v3Pos = Camera.main.WorldToScreenPoint(lineOfSight.Target.position) - Camera.main.WorldToScreenPoint(target.position);
        float angle = Mathf.Atan2(v3Pos.y, v3Pos.x) * Mathf.Rad2Deg;

        v3Pos = Quaternion.AngleAxis(angle, Vector3.forward) * (Vector3.right * radius);
        transform.position = target.position + v3Pos;

        pivot.SetPositionAndRotation(target.position, Quaternion.AngleAxis(angle, Vector3.forward));
    }

    void AimDown()
    {
        Vector3 v3Pos = Camera.main.WorldToScreenPoint(lowPoint) - Camera.main.WorldToScreenPoint(target.position);
        float angle = Mathf.Atan2(v3Pos.y, v3Pos.x) * Mathf.Rad2Deg;

        v3Pos = Quaternion.AngleAxis(angle, Vector3.forward) * (Vector3.right * radius);
        transform.position = target.position + v3Pos;

        pivot.SetPositionAndRotation(target.position, Quaternion.AngleAxis(angle, Vector3.forward));
    }

    void FlipSprite()
    {
        if (enableSpriteFlip)
        {
            if (pivot.transform.localEulerAngles.z > minFlipThreshold && pivot.transform.localEulerAngles.z < maxFlipThreshold)
            {
                if (!flipped)
                {
                    transform.Rotate(0, 0, spriteRotationalOffset * -2);
                }

                spriteRenderer.flipY = true;
                flipped = true;
            }
            else
            {
                if (flipped)
                {
                    transform.Rotate(0, 0, spriteRotationalOffset * 2);
                }

                spriteRenderer.flipY = false;
                flipped = false;
            }
        }
    }
}