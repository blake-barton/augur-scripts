using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyEquipment : MonoBehaviour
{
    [Header("Equipped Weapons")]
    [SerializeField] GameObject mainhandWeapon;
    [SerializeField] GameObject offhandWeapon;

    [Header("Hands")]
    [SerializeField] GameObject mainhand;
    [SerializeField] GameObject offhand;

    public GameObject MainHandWeapon { get => mainhandWeapon; set => mainhandWeapon = value; }
    public GameObject OffhandWeapon { get => offhandWeapon; set => offhandWeapon = value; }
    public GameObject Mainhand { get => mainhand; set => mainhand = value; }
    public GameObject Offhand { get => offhand; set => offhand = value; }

    public void UnhideEquipped()
    {
        if (Mainhand)
        {
            Mainhand.SetActive(true);
        }

        if (Offhand)
        {
            Offhand.SetActive(true);
        }

        SpriteRenderer mainhandWeaponSpriteRenderer = null;
        SpriteRenderer offhandWeaponSpriteRenderer = null;

        if (MainHandWeapon)
        {
            mainhandWeaponSpriteRenderer = MainHandWeapon.GetComponent<SpriteRenderer>();
        }
        if (OffhandWeapon)
        {
            offhandWeaponSpriteRenderer = OffhandWeapon.GetComponent<SpriteRenderer>();
        }

        // hide equipped items
        if (MainHandWeapon && mainhandWeaponSpriteRenderer)
        {
            mainhandWeaponSpriteRenderer.enabled = true;
        }
        if (OffhandWeapon && offhandWeaponSpriteRenderer)
        {
            offhandWeaponSpriteRenderer.enabled = true;
        }
    }

    public void HideEquipped()
    {
        // hide hands
        if (Mainhand)
        {
            Mainhand.SetActive(false);
        }

        if (Offhand)
        {
            Offhand.SetActive(false);
        }

        // hide equipped items
        SpriteRenderer mainhandWeaponSpriteRenderer = null;
        SpriteRenderer offhandWeaponSpriteRenderer = null;

        if (MainHandWeapon)
        {
            mainhandWeaponSpriteRenderer = MainHandWeapon.GetComponent<SpriteRenderer>();
        }
        if (OffhandWeapon)
        {
            offhandWeaponSpriteRenderer = OffhandWeapon.GetComponent<SpriteRenderer>();
        }

        if (MainHandWeapon && mainhandWeaponSpriteRenderer)
        {
            mainhandWeaponSpriteRenderer.enabled = false;
        }
        if (OffhandWeapon && offhandWeaponSpriteRenderer)
        {
            offhandWeaponSpriteRenderer.enabled = false;
        }
    }

    public bool HasWeapons()
    {
        return MainHandWeapon || OffhandWeapon;
    }
}
