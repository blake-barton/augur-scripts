using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TurretController : MonoBehaviour
{
    [Header("Enemy")]
    [SerializeField] Enemy enemy;
    [SerializeField] Health health;
    [SerializeField] Animator animator;
}
