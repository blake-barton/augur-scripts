using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pathfinding;

public class GruntController : MonoBehaviour
{   
    [Header("Enemy")]
    [SerializeField] Enemy enemy;
    [SerializeField] EnemyMovement movement;
    [SerializeField] Health health;
    [SerializeField] LineOfSight lineOfSight;

    [Header("Animation")]
    [SerializeField] Animator animator;

    [Header("Hands")]
    [SerializeField] GameObject mainHandSocket;
    [SerializeField] GameObject offHandSocket;

    [Header("Pathfinding")]
    [SerializeField] float minDistanceFromTarget = 3f;
    [SerializeField] float maxDistanceFromTarget = 12f;
    [SerializeField] float moveCounter;
    [SerializeField] float minTimeBetweenDestinationChange = 5f;
    [SerializeField] float maxTimeBetweenDestinationChange = 10f;
    [SerializeField] float distanceToDestination;
    [SerializeField] float minIdleDistance = 1.5f;
    GameObject destination;

    private void Awake()
    {
        Transform player = FindObjectOfType<Player>().transform;

        // set line of sight target to player
        lineOfSight.Target = player;

        // initially move towards the target
        destination = new GameObject();
        destination.transform.position = lineOfSight.Target.transform.position;
        movement.Destination = destination.transform;
    }

    private void Start()
    {
        InvokeRepeating(nameof(GetDistanceToDestination), 0f, .5f);
    }

    // Update is called once per frame
    void Update()
    {
        FindNewDestination();
    }

    // find random walkable destination that is between min and max distance and set it in the movement script
    private void FindNewDestination()
    {
        moveCounter -= Time.deltaTime;
        if (moveCounter <= 0f)
        {
            // get a vector with random direction and magnitude between distance min and max
            Vector2 randomVector = UtilMath.RandomVector2(360f, 0f, UnityEngine.Random.Range(minDistanceFromTarget, maxDistanceFromTarget));

            // get a world point from the target and vector
            Vector3 point = lineOfSight.Target.position + (Vector3)randomVector;

            // find closest walkable node to world point
            GraphNode node = AstarPath.active.GetNearest(point, NNConstraint.Default).node;

            // get the world position of said node
            Vector3 nodePosition = (Vector3)node.position;

            // set destination's position to that
            destination.transform.position = nodePosition;

            // set the destination of the movement script to this script's destination
            movement.Destination = destination.transform;

            // reset counter
            moveCounter = UnityEngine.Random.Range(minTimeBetweenDestinationChange, maxTimeBetweenDestinationChange);
        }
    }

    private void GetDistanceToDestination()
    {
        distanceToDestination = Vector2.Distance(transform.position, destination.transform.position);

        // go to idle
        if (distanceToDestination <= minIdleDistance)
        {
            animator.SetBool("AnimInRange", true);
            movement.Speed = 0;
        }
        else
        {
            animator.SetBool("AnimInRange", false);

            // let them move to the new point if they aren't knocked down
            if (!enemy.Character.Incapacitated)
            {
                movement.Speed = movement.OriginalSpeed;
            }
        }
    }
}
