using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SkeletonController : EnemyController
{
    [SerializeField] bool firstDeath = false;
    [SerializeField] bool finalDeath = false;
    [SerializeField] float respawnTime = 6f;
    [SerializeField] GameObject soulParticles;

    GameObject instantiatedSoulParticles;

    public void TriggerFakeDeath()
    {
        if (!firstDeath)
        {
            StartCoroutine(FakeDeath());
        }
    }

    IEnumerator FakeDeath()
    {
        // fake death has happened
        firstDeath = true;

        // set incapacitated
        enemy.Character.Incapacitated = true;

        // cannot be moved
        gameObject.layer = enemy.KnockedDownLayer;

        // stop movement
        movement.FreezeMovement();

        // freeze poise regen
        poise.FreezePoiseRegen();

        // stop from standing up
        poise.StopAllCoroutines();

        // make sure we don't immediately transition back
        animator.SetBool("AnimStandingUp", false);
        animator.SetBool("AnimKnockedDown", false);

        // trigger death
        animator.SetTrigger("AnimDie");

        // instantiate soul particles
        instantiatedSoulParticles = Instantiate(soulParticles, transform.position, Quaternion.identity, transform);

        yield return new WaitForSeconds(respawnTime);

        // back alive
        firstDeath = false;

        // get rid of particles
        Destroy(instantiatedSoulParticles);

        // play standup animation
        animator.SetBool("AnimStandingUp", true);

        // back to life
        health.IncreaseHealthByFractionOfMax(1);
    }

    // called by health event
    public void FinalDeath()
    {
        if (firstDeath && !finalDeath)
        {
            finalDeath = true;
            Destroy(instantiatedSoulParticles);
            enemy.DeathOperations();
        }
    }

    public override void Die()
    {
        animator.SetTrigger("FinalDeath");
    }
}
