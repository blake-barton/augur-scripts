using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SlimeController : EnemyController
{
    [SerializeField] GameObject enemyToSpawn;
    [SerializeField] int numberToSpawn;

    public override void Die()
    {
        // spawn slimes
        for (int i = 0; i < numberToSpawn; i++)
        {
            Instantiate(enemyToSpawn, transform.position, Quaternion.identity);
        }
    }
}
