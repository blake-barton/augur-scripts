using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pathfinding;

public class DrainedController : MonoBehaviour
{
    [Header("Enemy")]
    [SerializeField] Enemy enemy;
    [SerializeField] EnemyMovement movement;
    [SerializeField] LineOfSight lineOfSight;
    [SerializeField] Rigidbody2D rb;
    [SerializeField] Health health;

    [Header("Attacking")]
    [SerializeField] GameObject slash;
    [SerializeField] float attackCounter;                         // when this hits 0, the enemy shoots
    [SerializeField] float minTimeBetweenAttacks = 1.5f;
    [SerializeField] float maxTimeBetweenAttacks = 3f;
    [SerializeField] float attackSpeedMultiplier = .1f;
    [SerializeField] float attackTime = 1f;
    [SerializeField] float minimumAttackDistance = 2f;
    [SerializeField] float distanceToTarget;
    [SerializeField] float attackJumpMagnitude = 2f;
    [SerializeField] float attackRangeMultiplier = 1.5f;

    [Header("Damage")]
    [SerializeField] List<float> damages = new List<float>();
    [SerializeField] List<DamageEffects.DamageType> damageTypes = new List<DamageEffects.DamageType>();
    [SerializeField] float forceDamage;
    [SerializeField] float bleedBuildup;

    [Header("Status Effect Damage")]
    [SerializeField] float statusEffectDamagePercentage = .1f;

    [Header("Animation")]
    [SerializeField] Animator animator;

    [Header("Sound")]
    [SerializeField] AudioSource audioSource;
    [SerializeField] AudioClip[] swingEffects;
    [SerializeField] [Range(0, 1)] float swingVolume;
    [SerializeField] AudioClip[] swingGrunts;
    [SerializeField] [Range(0, 1)] float gruntVolume;

    // util
    GameObject spawnedSlash;

    private void Awake()
    {
        Transform player = FindObjectOfType<Player>().transform;

        // set movement destination to player
        movement.Destination = player;

        // set line of sight target to player
        lineOfSight.Target = player;
    }

    private void Start()
    {
        InvokeRepeating(nameof(GetDistanceToTarget), 0f, .5f);
    }

    // Update is called once per frame
    void Update()
    {
        CountDownAndAttack();
    }

    private void CountDownAndAttack()
    {
        if (lineOfSight.TargetVisible && !enemy.Character.Incapacitated)
        {
            attackCounter -= Time.deltaTime;  // shot counter decreases by time between frames
            if (attackCounter <= 0f && distanceToTarget <= minimumAttackDistance)
            {
                // fire
                animator.SetTrigger("AnimAttack");

                // reset shot counter
                attackCounter = UnityEngine.Random.Range(minTimeBetweenAttacks, maxTimeBetweenAttacks);

                StartCoroutine(Attack());
            }
        }
    }

    IEnumerator Attack()
    {
        // slow speed
        float previousSpeed = movement.Speed;
        movement.Speed *= attackSpeedMultiplier;

        yield return new WaitForSeconds(attackTime);

        movement.Speed = previousSpeed;
    }

    // called via animation event
    public void SpawnSlash(AnimationEvent animEvent)
    {
        if (animEvent.animatorClipInfo.weight > 0.5f)
        {
            // give a little push so that the drained appears to lunge
            rb.AddForce(attackJumpMagnitude * movement.MoveDirection.normalized, ForceMode2D.Impulse);

            // spawn slash, adding move direction to the position so that the lunge actually has an effect
            spawnedSlash = Instantiate(slash, transform.position + attackRangeMultiplier * (Vector3)movement.MoveDirection.normalized, transform.rotation);

            // direction
            spawnedSlash.GetComponent<EnemyMeleeSlash>().InitializeSlash(movement.MoveDirection, gameObject);

            // add damage to slash
            DamageDealer damageDealer = spawnedSlash.GetComponent<DamageDealer>();
            damageDealer.CopyDamageList(damages);
            damageDealer.CopyDamageTypeList(damageTypes);

            // status effects
            damageDealer.SetStatusEffectDamagePercentage(statusEffectDamagePercentage);
            damageDealer.ForceDamage = forceDamage;
            damageDealer.BleedBuildup = bleedBuildup;

            // sound
            PlayRandomSound(swingGrunts, gruntVolume);
            PlayRandomSound(swingEffects, swingVolume);
        }
    }

    private void GetDistanceToTarget()
    {
        distanceToTarget = Vector2.Distance(transform.position, lineOfSight.Target.position);

        // go to idle
        if (distanceToTarget <= minimumAttackDistance)
        {
            animator.SetBool("AnimInRange", true);
        }
        else
        {
            animator.SetBool("AnimInRange", false);
        }
    }

    private void PlayRandomSound(AudioClip[] clips, float volume)
    {
        int randomIndex = Random.Range(0, clips.Length);
        audioSource.PlayOneShot(clips[randomIndex], volume);
    }
}
