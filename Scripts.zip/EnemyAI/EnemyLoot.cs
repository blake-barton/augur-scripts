using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyLoot : MonoBehaviour
{
    [SerializeField] List<LootDrop> lootDrops = new List<LootDrop>();
    [SerializeField] GameObject gossamerDrop;
    [SerializeField] int gossamerAmount = 0;

    AttributeScores playerAttributes;

    [System.Serializable]
    public struct LootDrop
    {
        public GameObject drop;
        public int minQuantity;
        public int maxQuantity;
        [Range(0, 100)] public int dropChance;
    }

    private void Awake()
    {
        Player player = FindObjectOfType<Player>();
        if (player)
        {
            playerAttributes = player.GetComponent<AttributeScores>();
        }
    }

    public void DropLoot()
    {
        if (gossamerDrop)
        {
            GameObject droppedGossamer = Instantiate(gossamerDrop, transform.position, Quaternion.identity);
            droppedGossamer.GetComponent<GossamerDrop>().gossamerAmount = gossamerAmount;
        }

        for (int i = 0; i < lootDrops.Count; i++)
        {
            // roll to see if this item is dropped
            if (RollForDrop(lootDrops[i].dropChance))
            {
                // instantiate a scene item with this item's quantity
                GameObject droppedSceneItem = Instantiate(lootDrops[i].drop, transform.position, transform.rotation);

                SceneItem sceneItem = droppedSceneItem.GetComponent<SceneItem>();

                if (sceneItem)
                {
                    // drop random quantity of item
                    int dropQuantity = Random.Range(lootDrops[i].minQuantity, lootDrops[i].maxQuantity + 1);
                    sceneItem.quantity = dropQuantity;
                }
            }
        }
    }

    private bool RollForDrop(int percentage)
    {
        int roll = Random.Range(1, 101);

        // improve odds of drop based on item discovery
        if (playerAttributes)
        {
            roll -= (playerAttributes.itemDiscovery - playerAttributes.itemDiscoveryBase) / 10;
        }

        // ex: a percentage of 100 will always succeed, a 0 will always fail
        if (roll <= percentage)
        {
            return true;
        }

        return false;
    }
}
