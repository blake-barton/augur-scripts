using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyMeleeSlash : MonoBehaviour
{
    [Header("Shield Detection")]
    [SerializeField] LayerMask shieldLayerMask;
    [SerializeField] float shieldCheckRadius = 0.5f;

    [Header("Impact Effects")]
    [SerializeField] List<GameObject> actorImpactEffects = new List<GameObject>();

    // Assigned at runtime
    private GameObject attacker;
    private Vector2 direction;

    // state
    bool isColliding = false;

    // cached references
    DamageDealer damageDealer;

    void Awake()
    {
        damageDealer = GetComponent<DamageDealer>();
    }

    private void Start()
    {
        float angle = Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
        transform.Rotate(0, 0, angle);
    }

    private void Update()
    {
        isColliding = false;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        // deal damage if not already colliding
        if (isColliding) return;
        isColliding = true;

        // Impact effect
        GameObject impactEffectToSpawn = GetRandomImpactEffect();

        // check for shield
        var hit = Physics2D.OverlapCircle(transform.position, shieldCheckRadius, shieldLayerMask);

        Shield shield = null;

        if (hit)
        {
            shield = hit.gameObject.GetComponent<Shield>();
        }

        // blocked by shield
        if (shield)
        {
            // Shield blocks damage
            shield.Block(damageDealer);

            // Impact effect spawns on shield
            Instantiate(impactEffectToSpawn, shield.gameObject.transform.position, Quaternion.identity);

            // Destroy slash
            Destroy(gameObject);
            return;                     // just in case
        }

        // Spawn impact effect
        Instantiate(impactEffectToSpawn, collision.gameObject.transform.position, Quaternion.identity);

        // Deal damage
        damageDealer.CauseMeleeDamage(collision, attacker, null);
    }

    public void InitializeSlash(Vector2 _direction, GameObject _attacker)
    {
        direction = _direction;
        attacker = _attacker;
    }

    public void DespawnSlash()
    {
        Destroy(gameObject);
    }

    GameObject GetRandomImpactEffect()
    {
        int rand = Random.Range(0, actorImpactEffects.Count);
        return actorImpactEffects[rand];
    }
}
