using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class ActionTrigger
{
    [SerializeField] string triggerName;
    [SerializeField] List<Requirements> requirements = new List<Requirements>();

    public List<Requirements> RequirementList { get => requirements; set => requirements = value; }
    public string TriggerName { get => triggerName; set => triggerName = value; }

    public enum Requirements
    {
        targetVisible,
        targetInRange,
        targetBeyondRange
    }
}
