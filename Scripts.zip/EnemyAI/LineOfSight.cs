using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LineOfSight : MonoBehaviour
{
    [SerializeField] LayerMask layersToCollide;
    [SerializeField] LayerMask frenziedLayersToCollide;
    [SerializeField] LayerMask playerAllyLayersToCollide;
    [SerializeField] Transform target = null;

    [Header("Debug")]
    [SerializeField] bool drawDebugLine = false;

    [Header("State")]
    [SerializeField] bool targetVisible;

    Character character;
    Health targetHealth;

    public bool TargetVisible { get => targetVisible; set => targetVisible = value; }
    public Transform Target
    {
        get => target;
        set
        {
            target = value;

            if (target)
            {
                // Cache target health
                targetHealth = target.GetComponent<Health>();
            }
        }
    }

    private void Awake()
    {
        character = GetComponent<Character>();
    }

    private void FixedUpdate()
    {
        // cast a ray towards the target
        if (Target)
        {
            RaycastHit2D hit = Physics2D.Raycast(transform.position, (Target.position - transform.position).normalized, Mathf.Infinity, GetFactionLayerMask());

            // if hits something
            if (hit.collider != null)
            {
                if (hit.collider.gameObject.layer == Target.gameObject.layer)
                {
                    TargetVisible = true;
                }
                else
                {
                    TargetVisible = false;
                }
            }
        }
    }

    public Vector2 GetDirectionToTarget()
    {
        return (Target.position - transform.position).normalized;
    }

    public float GetDistanceToTarget()
    {
        return Vector2.Distance(transform.position, Target.position);
    }

    public bool CheckIfTransformIsVisible(Transform targetTransform)
    {
        RaycastHit2D hit = Physics2D.Raycast(transform.position, (targetTransform.position - transform.position).normalized, Mathf.Infinity, GetFactionLayerMask());

        return hit.collider;
    }

    public bool IsTargetAlive()
    {
        if (Target && targetHealth)
        {
            // Dead creatures might have their health disabled
            if (!targetHealth.enabled)
            {
                return false;
            }

            return targetHealth.Alive;
        }

        return false;
    }

    public void ClearTarget()
    {
        Target = null;
        targetHealth = null;
        targetVisible = false;
    }

    private void OnDrawGizmos()
    {
        if (drawDebugLine)
        {
            if (TargetVisible)
            {
                Gizmos.color = Color.blue;
            }
            else
            {
                Gizmos.color = Color.red;
            }

            Gizmos.DrawRay(transform.position, Target.position - transform.position);
        }
    }

    LayerMask GetFactionLayerMask()
    {
        if (character)
        {
            return character.CharacterFaction switch
            {
                Character.Faction.Player => playerAllyLayersToCollide,
                Character.Faction.Enemy => layersToCollide,
                Character.Faction.Frenzied => frenziedLayersToCollide,
                _ => layersToCollide,
            };
        }

        return layersToCollide;
    }
}
