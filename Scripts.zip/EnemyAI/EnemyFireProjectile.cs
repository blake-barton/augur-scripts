using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyFireProjectile : MonoBehaviour
{
    [Header("Projectile")]
    [SerializeField] GameObject projectile;
    [SerializeField] GameObject frenziedProjectile;
    [SerializeField] GameObject playerProjectile;
    [SerializeField] Vector3 projectileOffset = new Vector3(0, 0, 0);

    [Header("Audio")]
    [SerializeField] AudioSource audioSource;
    [SerializeField] AudioClip shotAudio;
    [SerializeField] [Range(0, 1)] float shotVolume;
    [SerializeField] AudioClip fireLoopAudio;           // for automatic weapon
    [SerializeField] [Range(0, 1)] float fireLoopAudioVolume = 1f;
    [SerializeField] AudioClip warmupAudio;
    [SerializeField] [Range(0, 1)] float warmupAudioVolume = 1f;

    [Header("Animation")]
    [SerializeField] Animator animator;

    [Header("State")]
    [SerializeField] bool isFiring = false;

    // cache
    GameObject owner;
    EnemyEquippedRangedWeapon equippedWeapon;
    RangedWeapon rangedWeapon;
    MuzzleFlashLight muzzleFlashLight;
    Character ownerCharacter;

    // coroutines
    Coroutine firingCoroutine;

    public GameObject Projectile { get => projectile; set => projectile = value; }
    public bool IsFiring { get => isFiring; set => isFiring = value; }

    private void Awake()
    {
        owner = transform.root.gameObject;
        ownerCharacter = owner.GetComponent<Character>();
        equippedWeapon = GetComponent<EnemyEquippedRangedWeapon>();
        muzzleFlashLight = GetComponent<MuzzleFlashLight>();
    }

    private void Start()
    {
        rangedWeapon = equippedWeapon.rangedWeapon;
    }

    float GetRandomizedDirection()
    {
        return Random.Range(-rangedWeapon.Spread, rangedWeapon.Spread);
    }

    public void TryFireSingleShot()
    {
        StartCoroutine(FireSingleShot());
    }

    IEnumerator FireSingleShot()
    {
        // animate
        if (animator && !rangedWeapon.IsAutomatic)
        {
            animator.Play("Fire", -1, 0.0f);
        }

        // Wait to warm up
        yield return new WaitForSeconds(rangedWeapon.WarmupTime);

        // play sound
        AudioUtility.PlaySound(audioSource, shotAudio, shotVolume);

        // muzzle flash
        if (muzzleFlashLight)
        {
            muzzleFlashLight.TriggerMuzzleFlash();
        }

        // Spawn as many projectiles as the weapon specifies
        for (int i = 0; i < rangedWeapon.ProjectilesPerShot; i++)
        {
            SpawnProjectile();
        }
    }

    private void SpawnProjectile()
    {
        GameObject firedProjectile = Instantiate(GetFactionProjectile(), transform.position + projectileOffset, equippedWeapon.pivot.rotation);

        // add spread to projectile
        firedProjectile.transform.Rotate(0, 0, GetRandomizedDirection());

        SetProjectileAttributes(firedProjectile);
    }

    private void SetProjectileAttributes(GameObject firedProjectile)
    {
        float zAngle = firedProjectile.transform.rotation.eulerAngles.z * (Mathf.PI / 180f);
        float xComponent = Mathf.Cos(zAngle);
        float yComponent = Mathf.Sin(zAngle);
        Vector2 pivotDirection = new Vector2(xComponent, yComponent);

        firedProjectile.GetComponent<ProjectileStandard>().SetAttributes(owner, transform, rangedWeapon, pivotDirection);
    }

    public void TriggerSpawnProjectileFullAuto()
    {
        firingCoroutine = StartCoroutine(SpawnProjectileFullAuto());
    }

    public void StopSpawningFullAuto()
    {
        if (!(firingCoroutine is null))
        {
            StopCoroutine(firingCoroutine);
            IsFiring = false;

            // animation
            if (animator)
            {
                animator.SetBool("AnimIsFiring", false);
            }

            // Only play last shot audio for automatic weapons
            if (rangedWeapon.IsAutomatic)
            {
                AudioUtility.StopLoopingAudio(audioSource);

                // play last shot
                AudioUtility.PlaySound(audioSource, shotAudio, shotVolume);
            }
        }
    }

    IEnumerator SpawnProjectileFullAuto()
    {
        isFiring = true;

        // wait for a moment to warm up
        if (rangedWeapon.WarmupTime > 0)
        {
            // animation
            if (animator)
            {
                animator.SetBool("AnimIsCharging", true);
            }

            // play warmup audio
            AudioUtility.PlaySound(audioSource, warmupAudio, warmupAudioVolume);

            yield return new WaitForSeconds(rangedWeapon.WarmupTime);
        }

        // loop sound
        AudioUtility.LoopAudio(audioSource, fireLoopAudio, fireLoopAudioVolume);

        // animation
        if (animator)
        {
            animator.SetBool("AnimIsFiring", true);
        }

        while (true)
        {
            // play single fire sound if not set up for automatic fire
            if (!rangedWeapon.IsAutomatic)
            {
                AudioUtility.PlaySound(audioSource, shotAudio, shotVolume);
            }

            // muzzle flash
            if (muzzleFlashLight)
            {
                muzzleFlashLight.TriggerMuzzleFlash();
            }

            // animate single fire if not set up for automatic fire
            if (animator && !rangedWeapon.IsAutomatic)
            {
                animator.Play("Fire", -1, 0.0f);
            }

            // Spawn as many projectiles as the weapon specifies
            for (int i = 0; i < rangedWeapon.ProjectilesPerShot; i++)
            {
                SpawnProjectile();
            }

            yield return new WaitForSeconds(1 / rangedWeapon.AttackRate);
        }
    }

    GameObject GetFactionProjectile()
    {
        if (ownerCharacter)
        {
            return ownerCharacter.CharacterFaction switch
            {
                Character.Faction.Player => playerProjectile,
                Character.Faction.Enemy => projectile,
                Character.Faction.Frenzied => frenziedProjectile,
                _ => projectile,
            };
        }

        return projectile;
    }
}