using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyEquippedSpell : MonoBehaviour
{
    public Spell spell;
    public GameObject owner;
    [SerializeField] LineOfSight lineOfSight;

    [Header("Rotation")]
    public bool isMainHand = false;
    [SerializeField] float radius = 0.5f;
    public Transform pivot;

    [SerializeField] Enemy enemy;
    Transform target;

    Vector3 lowPoint = new Vector3(100, -20, 0);

    // Start is called before the first frame update
    void Start()
    {
        // rotation
        target = transform.parent;
        pivot = new GameObject().transform;
        pivot.parent = transform.parent;
        pivot.name = "Enemy spell";
        transform.parent = pivot;
    }

    // Update is called once per frame
    void Update()
    {
        if (!enemy.Character.Incapacitated && lineOfSight.Target)
        {
            RotateAroundOwnerTowardsTarget();
        }
        else if (!enemy.Character.Incapacitated && !lineOfSight.Target)
        {
            AimDown();
        }
    }

    void RotateAroundOwnerTowardsTarget()
    {
        Vector3 v3Pos = Camera.main.WorldToScreenPoint(lineOfSight.Target.position) - Camera.main.WorldToScreenPoint(target.position);
        float angle = Mathf.Atan2(v3Pos.y, v3Pos.x) * Mathf.Rad2Deg;

        v3Pos = Quaternion.AngleAxis(angle, Vector3.forward) * (Vector3.right * radius);
        transform.position = target.position + v3Pos;

        pivot.SetPositionAndRotation(target.position, Quaternion.AngleAxis(angle, Vector3.forward));
    }

    void AimDown()
    {
        Vector3 v3Pos = Camera.main.WorldToScreenPoint(lowPoint) - Camera.main.WorldToScreenPoint(target.position);
        float angle = Mathf.Atan2(v3Pos.y, v3Pos.x) * Mathf.Rad2Deg;

        v3Pos = Quaternion.AngleAxis(angle, Vector3.forward) * (Vector3.right * radius);
        transform.position = target.position + v3Pos;

        pivot.SetPositionAndRotation(target.position, Quaternion.AngleAxis(angle, Vector3.forward));
    }
}
