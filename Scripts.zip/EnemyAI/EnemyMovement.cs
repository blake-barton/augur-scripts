using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pathfinding;

public class EnemyMovement : MonoBehaviour
{
    [SerializeField] Enemy enemy;
    [SerializeField] EnemyEquipment equipment;
    [SerializeField] Seeker seeker;
    [SerializeField] Rigidbody2D rb;

    [Header("Movement")]
    [SerializeField] float speed = 5f;
    [SerializeField] float originalSpeed = 5f;
    [SerializeField] float nextWaypointDistance = 3f;     // how close the enemy gets to the waypoint before going to the next one
    [SerializeField] Vector2 moveDirection;

    [Header("Knockdown")]
    [SerializeField] Poise poise;

    [Header("Animation")]
    [SerializeField] Animator animator;

    [Header("State")]
    [SerializeField] bool hit = false;
    [SerializeField] bool forceStopped = false;

    [Header("View Only")]
    [SerializeField] Transform destination;

    // pathfinding
    Path path;
    int currentWaypoint = 0;
    bool reachedEndOfPath;

    public bool Hit { get => hit; set => hit = value; }
    public float Speed { get => speed; set => speed = value; }
    public float OriginalSpeed { get => originalSpeed; set => originalSpeed = value; }
    public float NextWaypointDistance { get => nextWaypointDistance; set => nextWaypointDistance = value; }
    public Vector2 MoveDirection { get => moveDirection; set => moveDirection = value; }
    public Transform Destination { get => destination; set => destination = value; }

    // Start is called before the first frame update
    void Start()
    {
        InvokeRepeating(nameof(UpdatePath), 0f, .5f);
    }

    void UpdatePath()
    {
        if (seeker.IsDone())
        {
            seeker.StartPath(rb.position, Destination.position, OnPathComplete);
        }
    }

    void OnPathComplete(Path p)
    {
        // get new path if no errors raised
        if (!p.error)
        {
            path = p;
            currentWaypoint = 0;
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (animator && enemy.Health.Alive)
        {
            Animate();
        }
    }

    private void FixedUpdate()
    {
        if (!enemy.Flying && !enemy.Character.Incapacitated && !Hit && !forceStopped)
        {
            Move();
        }
    }

    private void Move()
    {
        if (path == null)
            return;

        if (currentWaypoint >= path.vectorPath.Count)
        {
            // end of path reached
            reachedEndOfPath = true;
            return;
        }
        else
        {
            reachedEndOfPath = false;
        }

        // get direction to next waypoint
        MoveDirection = ((Vector2)path.vectorPath[currentWaypoint] - rb.position).normalized;

        // move
        rb.velocity = new Vector2(MoveDirection.x * Speed, MoveDirection.y * Speed);

        // get distance to next waypoint
        float distance = Vector2.Distance(rb.position, path.vectorPath[currentWaypoint]);

        if (distance < NextWaypointDistance)
        {
            currentWaypoint++;
        }
    }

    // called during standup animation
    public void StandUp()
    {
        if (enemy.Character.Incapacitated)
        {
            // no longer incapacitated
            enemy.Character.Incapacitated = false;

            // reset layer
            gameObject.layer = enemy.Character.GetLayerByOwnFaction();

            // restart regen
            poise.StartPoiseRegen();

            // reset speed
            Speed = OriginalSpeed;

            // max out poise
            poise.RefillPoiseToMax();

            // done standing
            animator.SetBool("AnimStandingUp", false);

            // show items
            if (equipment)
            {
                equipment.UnhideEquipped();
            }
        }
    }

    public void ResetSpeed()
    {
        Speed = OriginalSpeed;
    }

    public void FreezeMovement()
    {
        MoveDirection = Vector2.zero;
        rb.velocity = Vector2.zero;
    }
    
    // Disables movement using boolean switch
    public void DisableMovement()
    {
        forceStopped = true;

        FreezeMovement();                           // velocity to zero
    }

    public void EnableMovement()
    {
        forceStopped = false;
    }

    private void Animate()
    {
        float destinationDifferenceX = 0;
        float destinationDifferenceY = 0;

        if (Destination)
        {
            destinationDifferenceX = Destination.position.x - transform.position.x;
            destinationDifferenceY = Destination.position.y - transform.position.y;
        }

        // these magic strings coincide with the parameter's in the players animation controller
        animator.SetFloat("AnimMoveX", destinationDifferenceX);
        animator.SetFloat("AnimMoveY", destinationDifferenceY);
        animator.SetFloat("AnimMoveMagnitude", MoveDirection.magnitude);
    }
}
