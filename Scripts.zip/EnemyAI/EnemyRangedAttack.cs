using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyRangedAttack : MonoBehaviour
{
    // equipped weapons are like a player's gun. Animated attacks are baked completely into the enemy's animation.
    public enum RangedAttackType
    {
        EQUIPPED_WEAPON,
        ANIMATED
    }

    [Header("Enemy")]
    [SerializeField] Enemy enemy;
    [SerializeField] EnemyFireProjectile fireProjectile;
    [SerializeField] LineOfSight lineOfSight;

    [Header("Attacking")]
    [SerializeField] RangedAttackType attackType;
    [SerializeField] RangedWeapon enemyRangedWeapon;
    [SerializeField] float attackCounter;                         // when this hits 0, the enemy attacks
    [SerializeField] float minTimeBetweenAttacks = 0.2f;
    [SerializeField] float maxTimeBetweenAttacks = 3f;
    [SerializeField] float attackCounterFailsafeTime = -6f;

    [Header("Equipped Weapon Attacks")]
    [SerializeField] float fullAutoBurstTime = 2f;
    [SerializeField] bool automaticFire = false;

    [Header("Attack Selection")]
    [SerializeField] AttackTriggers attackTriggers;

    [Header("Attack Telegraph")]
    [SerializeField] FlashOnHit gunColorFlash;
    [SerializeField] float timeToTelegraphShot;

    [Header("Enemy Animation")]
    [SerializeField] Animator animator;                     // enemy animation, not weapon

    [Header("State")]
    [SerializeField] bool attacking = false;

    private void Awake()
    {
        Transform player = FindObjectOfType<Player>().transform;

        // set line of sight target to player
        lineOfSight.Target = player;

        // randomize initial shot counter
        attackCounter = Random.Range(minTimeBetweenAttacks, maxTimeBetweenAttacks);
    }

    // Update is called once per frame
    void Update()
    {
        if (attackType == RangedAttackType.EQUIPPED_WEAPON)
        {
            if (automaticFire)
            {
                CountDownAndFireFullAuto();
            }
            else
            {
                CountDownAndShoot();
            }
        }
        else if (attackType == RangedAttackType.ANIMATED)
        {
            CountDownAndAttackAnimated();
        }

        // animation of enemy, not weapon
        if (animator && enemy.Health.Alive)
        {
            Animate();
        }
    }

    private void CountDownAndAttackAnimated()
    {
        if (!enemy.Character.Incapacitated)
        {
            attackCounter -= Time.deltaTime;  // shot counter decreases by time between frames

            if (attackCounter <= 0f && !attacking)
            {
                attacking = true;

                // get the animation trigger to set
                string trigger = attackTriggers.GetTriggerString();

                // trigger attack animation if no empty string
                if (!trigger.Equals(""))
                {
                    animator.Play(trigger, -1, 0.0f);
                }
                else
                {
                    // failed to attack
                    attacking = false;
                }
            }

            // failsafe in case the AI gets stuck attacking
            if (attackCounter <= attackCounterFailsafeTime && attacking)
            {
                // reset shot counter
                attackCounter = UnityEngine.Random.Range(minTimeBetweenAttacks, maxTimeBetweenAttacks);

                attacking = false;
            }
        }
    }

    // called via animation
    public void FireAnimatedAttack(AnimationEvent animEvent)
    {
        if (animEvent.animatorClipInfo.weight > 0.5f)
        {
            // fire
            fireProjectile.TryFireSingleShot();

            // reset shot counter
            attackCounter = UnityEngine.Random.Range(minTimeBetweenAttacks, maxTimeBetweenAttacks);

            // no longer attacking
            attacking = false;
        }
    }

    private void CountDownAndShoot()
    {
        if (lineOfSight.TargetVisible && !enemy.Character.Incapacitated && (lineOfSight.GetDistanceToTarget() <= enemyRangedWeapon.MaxRange))
        {
            attackCounter -= Time.deltaTime;  // shot counter decreases by time between frames

            if (attackCounter <= 0f)
            {
                // stop telegraphing
                if (gunColorFlash)
                    gunColorFlash.StopFlashContinuous();

                // fire
                fireProjectile.TryFireSingleShot();

                // reset shot counter
                attackCounter = UnityEngine.Random.Range(minTimeBetweenAttacks, maxTimeBetweenAttacks);
            }
            else if (attackCounter <= timeToTelegraphShot)
            {
                // telegraph shot
                if (gunColorFlash)
                {
                    if (!gunColorFlash.IsFlashing)
                    {
                        gunColorFlash.TriggerFlashContinous();
                    }
                }
            }
        }
    }

    private void CountDownAndFireFullAuto()
    {
        if (lineOfSight.TargetVisible && !enemy.Character.Incapacitated && (lineOfSight.GetDistanceToTarget() <= enemyRangedWeapon.MaxRange))
        {
            attackCounter -= Time.deltaTime;  // shot counter decreases by time between frames

            if (attackCounter <= 0f)
            {
                // stop telegraphing
                if (gunColorFlash)
                    gunColorFlash.StopFlashContinuous();

                // fire
                StartCoroutine(FireFullAuto());

                // reset shot counter
                attackCounter = UnityEngine.Random.Range(minTimeBetweenAttacks, maxTimeBetweenAttacks) + fullAutoBurstTime;
            }
            else if (attackCounter <= timeToTelegraphShot)
            {
                // telegraph shot
                if (gunColorFlash)
                {
                    if (!gunColorFlash.IsFlashing)
                    {
                        gunColorFlash.TriggerFlashContinous();
                    }
                }
            }
        }
    }

    IEnumerator FireFullAuto()
    {
        fireProjectile.TriggerSpawnProjectileFullAuto();

        if (animator)
        {
            animator.SetBool("AnimIsFiring", true);
        }
        
        // continue firing unless enemy is knocked down or killed
        for (float timer = fullAutoBurstTime; timer >= 0; timer -= Time.deltaTime)
        {
            if (enemy.Character.Incapacitated)
            {
                fireProjectile.StopSpawningFullAuto();
                yield break;
            }
            yield return null;
        }

        fireProjectile.StopSpawningFullAuto();

        if (animator)
        {
            animator.SetBool("AnimIsFiring", false);
        }
    }

    void Animate()
    {
        animator.SetFloat("AnimLookX", lineOfSight.GetDirectionToTarget().x);
        animator.SetFloat("AnimLookY", lineOfSight.GetDirectionToTarget().y);
    }
}
