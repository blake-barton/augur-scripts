using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    public enum EnemyType
    {
        COALITION_MILITARY,
        SEWER_CREATURE,
        PSYCHOKNIGHT,
        UNDEAD,
        CRATER_MUTANT,
        BADLANDS_CREATURE,
        SPARKRAIDER
    }

    [Header("Enemy Classification")]
    [SerializeField] string enemyName;
    [SerializeField] EnemyType type;
    [SerializeField] RoomManager.RoomDifficulty enemyDifficulty;
    [SerializeField] bool isBoss;
    [SerializeField] bool isMiniBoss;

    [Header("Death")]
    [SerializeField] float timeToDestroy = 10f;
    [SerializeField] bool endStatusEffectsOnDeath = false;
    [SerializeField] bool destroyShadowOnDeath = false;
    [SerializeField] bool animateDeath = true;
    [SerializeField] List<AudioClip> deathSounds = new List<AudioClip>();
    [SerializeField] [Range(0, 1)] float deathSoundVolume = 0.5f;
    [SerializeField] string deathAnimState = "Die";

    [Header("Cached references")]
    [SerializeField] EnemyController controller;
    [SerializeField] Health health;
    [SerializeField] EnemyLoot enemyLoot;
    [SerializeField] Animator animator;
    [SerializeField] EnemyMovement movement;
    [SerializeField] StatusEffects statusEffects;
    [SerializeField] Rigidbody2D rb2d;
    [SerializeField] AudioSource audioSource;
    [SerializeField] EnemyEquipment equipment;
    [SerializeField] Character character;

    [Header("Layers")]
    [SerializeField] GameObject wallCollider;
    [SerializeField] [Range(0, 32)] int wallAndWaterCollisionLayer = 13;
    [SerializeField] [Range(0, 32)] int playerLayer = 6;
    [SerializeField] [Range(0, 32)] int noWaterCollisionLayer = 6;
    [SerializeField] [Range(0, 32)] int enemyLayer = 9;
    [SerializeField] [Range(0, 32)] int frenzyLayer = 24;
    [SerializeField] [Range(0, 32)] int corpseLayer = 19;
    [SerializeField] [Range(0, 32)] int knockedDownLayer = 21;

    [Header("Shadow")]
    [SerializeField] GameObject shadow;

    [Header("State")]
    [SerializeField] bool flying = false;

    RoomManager roomManager;
    Companion companion;    // Just here to make sure we don't add companions to the enemies counter

    public bool Flying 
    {
        get { return flying; }
        set
        {
            if (value == flying)
                return;

            flying = value;

            // if flying, change the wallCollider's layer to one which does not collide with water
            if (flying)
            {
                wallCollider.layer = NoWaterCollisionLayer;
            }
            else
            {
                wallCollider.layer = WallAndWaterCollisionLayer;
            }
        }
    }

    public EnemyType Type { get => type; set => type = value; }
    public bool IsBoss { get => isBoss; set => isBoss = value; }
    public bool IsMiniBoss { get => isMiniBoss; set => isMiniBoss = value; }
    public RoomManager.RoomDifficulty EnemyDifficulty { get => enemyDifficulty; set => enemyDifficulty = value; }
    public int CorpseLayer { get => corpseLayer; set => corpseLayer = value; }
    public int WallAndWaterCollisionLayer { get => wallAndWaterCollisionLayer; set => wallAndWaterCollisionLayer = value; }
    public int NoWaterCollisionLayer { get => noWaterCollisionLayer; set => noWaterCollisionLayer = value; }
    public int EnemyLayer { get => enemyLayer; set => enemyLayer = value; }
    public int KnockedDownLayer { get => knockedDownLayer; set => knockedDownLayer = value; }
    public string EnemyName { get => enemyName; set => enemyName = value; }
    public Health Health { get => health; set => health = value; }
    public Character Character { get => character; set => character = value; }
    public int PlayerLayer { get => playerLayer; set => playerLayer = value; }
    public int FrenzyLayer { get => frenzyLayer; set => frenzyLayer = value; }

    private void Awake()
    {
        companion = GetComponent<Companion>();
        roomManager = FindObjectOfType<RoomManager>();

        if (!companion)
        {
            roomManager.IncrementCurrentEnemies();
        }
    }

    public void DeathOperations()
    {
        if (equipment)
        {
            // hide hands
            equipment.HideEquipped();
        }

        // stop effects (if toggled)
        if (endStatusEffectsOnDeath && statusEffects)
        {
            statusEffects.CureAllStatusEffects();    
        }

        if (Health)
        {
            Health.enabled = false;
        }

        // destroy shadow (if toggled)
        if (destroyShadowOnDeath && shadow)
        {
            shadow.SetActive(false);
        }

        // drop loot
        if (enemyLoot)
        {
            DropLootOnDeath();
        }

        // controller death functions
        if (controller)
        {
            controller.Die();
        }

        // talk to room manager
        if (!companion)
        {
            roomManager.DecrementCurrentEnemies();
        }

        // sound
        if (deathSounds.Count > 0 && audioSource)
        {
            PlayRandomDeathSound();
        }

        // animate
        if (animateDeath && animator)
        {
            animator.Play(deathAnimState, -1, 0.0f);
        }

        // set state
        Character.Incapacitated = true;

        // make corpse
        gameObject.layer = CorpseLayer;

        if (movement)
        {
            // freeze movement
            movement.DisableMovement();
        }

        // stop colliding with other enemies
        wallCollider.SetActive(false);

        Destroy(gameObject, timeToDestroy);
    }

    void PitDeath()
    {
        // set state
        Health.Alive = false;
        Character.Incapacitated = true;

        // talk to room manager
        if (!companion)
        {
            roomManager.DecrementCurrentEnemies();
        }

        // sound
        if (deathSounds.Count > 0 && audioSource)
        {
            PlayRandomDeathSound();
        }

        Destroy(gameObject);
    }

    void DropLootOnDeath()
    {
        enemyLoot.DropLoot();
    }

    public void HandlePitfall()
    {
        PitDeath();
    }

    private void PlayRandomDeathSound()
    {
        int randomIndex = Random.Range(0, deathSounds.Count);
        audioSource.PlayOneShot(deathSounds[randomIndex], deathSoundVolume);
    }
}
