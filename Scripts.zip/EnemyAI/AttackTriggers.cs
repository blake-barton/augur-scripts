using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class AttackTriggers : MonoBehaviour
{
    [SerializeField] List<ActionTrigger> triggers = new List<ActionTrigger>();

    [Header("IsTargetInRange")]
    [SerializeField] float maxRange;

    [Header("IsTargetBeyondRange")]
    [SerializeField] float minRange;

    // cached references
    LineOfSight lineOfSight;

    private void Awake()
    {
        lineOfSight = GetComponent<LineOfSight>();
    }

    public string GetTriggerString()
    {
        List<ActionTrigger> potentialTriggers = new List<ActionTrigger>();

        foreach (ActionTrigger trigger in triggers)
        {
            bool allRequirementsSatisfied = true;
            foreach (ActionTrigger.Requirements requirement in trigger.RequirementList)
            {
                // if the requirement is not met, break and do not add this trigger to the list of potentials
                if (!CheckRequirement(requirement))
                {
                    allRequirementsSatisfied = false;
                    break;
                }
            }

            // add if all requirements met
            if (allRequirementsSatisfied)
            {
                potentialTriggers.Add(trigger);
            }
        }

        // use the weights of each trigger in the list to decide which one gets selected
        if (potentialTriggers.Count > 0)
        {
            return SelectTriggerFromPotentialList(potentialTriggers).TriggerName;
        }

        return "";
    }

    ActionTrigger SelectTriggerFromPotentialList(List<ActionTrigger> potentialTriggers)
    {
        // randomly choose one of the options
        return potentialTriggers[UnityEngine.Random.Range(0, potentialTriggers.Count)];
    }

    bool CheckRequirement(ActionTrigger.Requirements requirement)
    {
        return requirement switch
        {
            ActionTrigger.Requirements.targetVisible => IsTargetVisible(),
            ActionTrigger.Requirements.targetInRange => IsTargetInRange(),
            ActionTrigger.Requirements.targetBeyondRange => IsTargetBeyondRange(),
            _ => false,
        };
    }

    bool IsTargetVisible()
    {
        return GetComponent<LineOfSight>().TargetVisible;
    }

    bool IsTargetInRange()
    {
        return lineOfSight.GetDistanceToTarget() <= maxRange;
    }

    bool IsTargetBeyondRange()
    {
        return lineOfSight.GetDistanceToTarget() > minRange;
    }
}
