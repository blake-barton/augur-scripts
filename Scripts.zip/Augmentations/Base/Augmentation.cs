using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class Augmentation : ScriptableObject
{
    [System.Serializable]
    public struct AttributeRequirement
    {
        public AttributeScores.Attributes attribute;
        public int requirement;
    }

    [System.Serializable]
    public struct SkillRequirement
    {
        public AttributeScores.Skills skill;
        public int requirement;
    }

    [SerializeField] string augmentationName;
    [SerializeField] int augmentationID;
    [SerializeField] int levelRequirement = 1;
    [SerializeField] int augmentationPointCost = 1;
    [SerializeField] List<AttributeRequirement> attributeRequirements;
    [SerializeField] List<SkillRequirement> skillRequirements;

    [TextArea(5, 10)]
    [SerializeField] string description = "";

    public string AugmentationName { get => augmentationName; set => augmentationName = value; }
    public int AugmentationID { get => augmentationID; set => augmentationID = value; }
    public int LevelRequirement { get => levelRequirement; set => levelRequirement = value; }
    public int AugmentationPointCost { get => augmentationPointCost; set => augmentationPointCost = value; }
    public List<AttributeRequirement> AttributeRequirements { get => attributeRequirements; }
    public List<SkillRequirement> SkillRequirements { get => skillRequirements; }
    public string Description { get => description; set => description = value; }

    public abstract void Equip(Augmentations augmentationList);
    public abstract void Unequip(Augmentations augmentationList);
}
