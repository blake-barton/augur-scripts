using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Augmentations/Attribute Score Augmentation")]
public class AttributeScoreAugmentation : Augmentation
{
    [Header("Attribute Score Augmentation")]
    [SerializeField] float statBoost;
    [SerializeField] Stat boostedStat;

    enum Stat
    {
        CritDamageMultiplier,
        CritChance
    }

    public override void Equip(Augmentations augmentationList)
    {
        AttributeScores attributeScores = augmentationList.GetComponent<AttributeScores>();

        switch (boostedStat)
        {
            case Stat.CritDamageMultiplier:
                attributeScores.critDamageMultiplier += statBoost;
                break;
            case Stat.CritChance:
                attributeScores.critChance += (int)statBoost;
                break;
            default:
                break;
        }
    }

    public override void Unequip(Augmentations augmentationList)
    {
        throw new System.NotImplementedException();
    }
}
