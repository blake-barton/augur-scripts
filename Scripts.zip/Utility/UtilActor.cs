using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UtilActor : MonoBehaviour
{
    public static void FreezeMovement(GameObject actor)
    {
        PlayerMovement playerMovement = actor.GetComponent<PlayerMovement>();
        EnemyMovement enemyMovement = actor.GetComponent<EnemyMovement>();

        if (playerMovement)
        {
            playerMovement.FreezeMovement();
        }
        else if (enemyMovement)
        {
            enemyMovement.FreezeMovement();
        }
        else
        {
            Debug.LogError("Passed in an actor with no movement script.");
        }
    }

    public static void SetHit(GameObject actor, bool hit)
    {
        PlayerMovement playerMovement = actor.GetComponent<PlayerMovement>();
        EnemyMovement enemyMovement = actor.GetComponent<EnemyMovement>();

        if (playerMovement)
        {
            // tbd
        }
        else if (enemyMovement)
        {
            enemyMovement.Hit = hit;
        }
        else
        {
            Debug.LogError("Passed in an actor with no movement script.");
        }
    }

    public static void SetIncapacitated(GameObject actor, bool incapacitated)
    {
        Character character = actor.GetComponent<Character>();

        if (character)
        {
            character.Incapacitated = incapacitated;
        }
        else
        {
            Debug.LogError("Passed in an actor with no character script.");
        }
    }

    public static bool IsIncapacitated(GameObject actor)
    {
        Character character = actor.GetComponent<Character>();

        if (character)
        {
            return character.Incapacitated;
        }
        else
        {
            Debug.LogError("Passed in an actor with no character script.");
            return false;
        }
    }

    public static bool IsAlive(GameObject actor)
    {
        Health health = actor.GetComponent<Health>();

        if (health)
        {
            return health.Alive;
        }
        else
        {
            Debug.LogError("Passed in an actor with no health script.");
            return false;
        }
    }
}
