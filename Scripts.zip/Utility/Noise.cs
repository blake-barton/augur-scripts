using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class Noise
{
    /*
        scale: number that determines at what distance to view the noisemap.
        octaves: the number of levels of detail you want you perlin noise to have.
        lacunarity: number that determines how much detail is added or removed at each octave (adjusts frequency AKA more wild).
        persistence: number that determines how much each octave contributes to the overall shape (adjusts amplitude AKA more quiet).
    */
    public static float[,] GenerateNoiseMap(int mapWidth, int mapHeight, float scale, int octaves, float persistance, float lacunarity, float randomOffsetX = 0, float randomOffsetY = 0, Range range = null)
    {
        float[,] noiseMap = new float[mapWidth, mapHeight];

        // avoid division by 0
        if (scale <= 0)
        {
            scale = 0.0001f;
        }

        float maxNoiseHeight = float.MinValue;
        float minNoiseHeight = float.MaxValue;

        for (int y = 0; y < mapHeight; y++)
        {
            for (int x = 0; x < mapWidth; x++)
            {
                float amplitude = 1;
                float frequency = 1;
                float noiseHeight = 0;

                for (int i = 0; i < octaves; i++)
                {
                    float sampleX = x / scale * frequency;
                    float sampleY = y / scale * frequency;

                    float perlinValue = Mathf.PerlinNoise(sampleX + randomOffsetX, sampleY + randomOffsetY) * 2 - 1;    // places in the range (-1, 1) so that noise map can decrease
                    noiseHeight += perlinValue * amplitude;

                    amplitude *= persistance;   // persistance is 0..1 so amplitude decreases each octave
                    frequency *= lacunarity;    // frequency (wildness) increases each octave (lacunarity > 1)  
                }

                // track min and max for normalization later
                if (noiseHeight > maxNoiseHeight)
                {
                    maxNoiseHeight = noiseHeight;
                }
                else if (noiseHeight < minNoiseHeight)
                {
                    minNoiseHeight = noiseHeight;
                }

                noiseMap[x, y] = noiseHeight;
            }
        }

        // normalize noise height back to 0..1
        for (int y = 0; y < mapHeight; y++)
        {
            for (int x = 0; x < mapWidth; x++)
            {
                noiseMap[x, y] = Mathf.InverseLerp(minNoiseHeight, maxNoiseHeight, noiseMap[x, y]);
            }
        }

        // interpolate to range if given
        if (range != null)
        {
            for (int y = 0; y < mapHeight; y++)
            {
                for (int x = 0; x < mapWidth; x++)
                {
                    noiseMap[x, y] = Mathf.RoundToInt(Mathf.Lerp(range.min, range.max, noiseMap[x, y]));
                }
            }
        }

        return noiseMap;
    }
}
