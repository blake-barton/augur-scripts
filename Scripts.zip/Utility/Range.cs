using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class Range
{
    public float min;
    public float max;

    public Range(float min, float max)
    {
        this.min = min;
        this.max = max;
    }

    // Returns whether the given value fits in the range
    public bool ValueInRange(float value)
    {
        return min <= value && value <= max;
    }

    // Return a random value within the range
    public float GetRandomValueInRange()
    {
        return Random.Range(min, max);
    }
}
