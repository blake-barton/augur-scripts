using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OnHoverSpriteSwap : MonoBehaviour
{
    [SerializeField] Sprite unhoveredSprite;
    [SerializeField] Sprite hoveredSprite;
    [SerializeField] SpriteRenderer spriteRenderer;

    private void OnMouseOver()
    {
        spriteRenderer.sprite = hoveredSprite;
    }

    private void OnMouseExit()
    {
        spriteRenderer.sprite = unhoveredSprite;
    }
}
