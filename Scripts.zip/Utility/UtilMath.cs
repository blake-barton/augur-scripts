using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UtilMath
{
    public static float RoundUp(float value)
    {
        if (value % 0.5f == 0)
            return Mathf.Ceil(value);
        else
            return Mathf.Floor(value);
    }

    // takes angles in degrees
    public static Vector2 RandomVector2(float angle, float angleMin, float magnitude = 1f)
    {
        angle *= Mathf.Deg2Rad;
        angleMin *= Mathf.Deg2Rad;
        float random = Random.value * angle + angleMin;
        return new Vector2(Mathf.Cos(random), Mathf.Sin(random)) * magnitude;
    }

    public static bool Roll(int diceCount, int diceSides, int dc)
    {
        int total = 0;

        for (int i = 0; i < diceCount; i++)
        {
            total += Random.Range(1, diceSides);
        }

        if (total >= dc)
        {
            return true;
        }

        return false;
    }

    public static bool PercentileRoll(int chance)
    {
        int roll = Random.Range(1, 101);

        if (roll <= chance)
        {
            return true;
        }

        return false;
    }

    public static bool PercentileRoll(float chance)
    {
        float roll = Random.Range(0, 100);

        if (roll <= chance)
        {
            return true;
        }

        return false;
    }
}
