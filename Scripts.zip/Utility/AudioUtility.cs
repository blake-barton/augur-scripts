using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AudioUtility : MonoBehaviour
{
    public static void PlayRandomSound(AudioSource audioSource, List<AudioClip> clips, float volume)
    {
        if (clips.Count > 0 && audioSource)
        {
            int randomIndex = Random.Range(0, clips.Count);
            audioSource.PlayOneShot(clips[randomIndex], volume);
        }
    }

    public static void PlayRandomSound(AudioSource audioSource, AudioClip[] clips, float volume)
    {
        if (clips.Length > 0 && audioSource)
        {
            int randomIndex = Random.Range(0, clips.Length);
            audioSource.PlayOneShot(clips[randomIndex], volume);
        }
    }

    public static void PlaySound(AudioSource audioSource, AudioClip clip, float volume)
    {
        if (audioSource && clip)
        {
            // play sound
            audioSource.PlayOneShot(clip, volume);
        }
    }

    public static void LoopAudio(AudioSource audioSource, AudioClip clip, float volume = 1f)
    {
        if (audioSource && clip)
        {
            audioSource.clip = clip;
            audioSource.loop = true;
            audioSource.volume = volume;
            audioSource.Play();
        }
    }

    public static void StopLoopingAudio(AudioSource audioSource)
    {
        audioSource.Stop();
        audioSource.loop = false;
    }
}
