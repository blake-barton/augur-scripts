using System.Collections;
using System.Linq;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class Wave
{
    // these arrays must have the same length
    public List<GameObject> enemies = new List<GameObject>();
    public List<int> counts = new List<int>();

    // enemy counts by difficulty
    int veryEasyEnemyCount;
    int easyEnemyCount;
    int mediumEnemyCount;
    int hardEnemyCount;

    // matrix indices
    const int VeryEasy = 0;
    const int Easy = 1;
    const int Medium = 2;
    const int Hard = 3;

    // difficulty matrices (enemies are columns and rooms are rows)
    readonly int[,] difficultyMatrixMinimums = new int[4, 4] 
    {
       {1, 0, 0, 0},   /*  initializers for row indexed by 0 */
       {2, 3, 0, 0},   /*  initializers for row indexed by 1 */
       {0, 1, 1, 0},  /*  initializers for row indexed by 2 */
       {0, 2, 1, 1}   /*  initializers for row indexed by 3 */
    };

    readonly int[,] difficultyMatrixMaximums = new int[4, 4]
    {
        {4, 2, 0, 0},   /*  initializers for row indexed by 0 */
        {4, 5, 1, 0},   /*  initializers for row indexed by 1 */
        {3, 4, 4, 1},  /*  initializers for row indexed by 2 */
        {4, 4, 3, 3}   /*  initializers for row indexed by 3 */
    };

    public Wave(RoomManager.RoomDifficulty difficulty, ItemDatabase database, List<Enemy.EnemyType> enemyTypes)
    {
        int room = GetRoomIndex(difficulty);

        // given the difficulty, randomly select the amounts of enemies that will be spawned for each difficulty
        veryEasyEnemyCount = Random.Range(difficultyMatrixMinimums[room, VeryEasy], difficultyMatrixMaximums[room, VeryEasy]);
        easyEnemyCount = Random.Range(difficultyMatrixMinimums[room, Easy], difficultyMatrixMaximums[room, Easy]);
        mediumEnemyCount = Random.Range(difficultyMatrixMinimums[room, Medium], difficultyMatrixMaximums[room, Medium]);
        hardEnemyCount = Random.Range(difficultyMatrixMinimums[room, Hard], difficultyMatrixMaximums[room, Hard]);

        // pick a random assortment of enemies for each difficulty
        List<GameObject> listToDrawFrom = GetEnemyListToDrawFrom(database, enemyTypes);

        // very easy
        List<GameObject> veryEasyList = listToDrawFrom.Where(g => g.GetComponent<Enemy>().EnemyDifficulty.Equals(RoomManager.RoomDifficulty.VERY_EASY)).ToList();
        if (veryEasyList.Count > 0)
        {
            for (int i = 0; i < veryEasyEnemyCount; i++)
            {
                // pick a random index and add the enemy at that index
                GameObject enemyGameObjectToAdd = veryEasyList[Random.Range(0, veryEasyList.Count)];

                // if the enemy is already in the enemies list, increase its count
                if (enemies.Contains(enemyGameObjectToAdd))
                {
                    int enemyIndex = enemies.IndexOf(enemyGameObjectToAdd);
                    counts[enemyIndex]++;
                }
                else
                {
                    // if not in the list, add it and an element for its count
                    enemies.Add(enemyGameObjectToAdd);
                    counts.Add(1);
                }
            }
        }

        // easy
        List<GameObject> easyList = listToDrawFrom.Where(g => g.GetComponent<Enemy>().EnemyDifficulty.Equals(RoomManager.RoomDifficulty.EASY)).ToList();
        if (easyList.Count > 0)
        {
            for (int i = 0; i < easyEnemyCount; i++)
            {
                // pick a random index and add the enemy at that index
                GameObject enemyGameObjectToAdd = easyList[Random.Range(0, easyList.Count)];

                // if the enemy is already in the enemies list, increase its count
                if (enemies.Contains(enemyGameObjectToAdd))
                {
                    int enemyIndex = enemies.IndexOf(enemyGameObjectToAdd);
                    counts[enemyIndex]++;
                }
                else
                {
                    // if not in the list, add it and an element for its count
                    enemies.Add(enemyGameObjectToAdd);
                    counts.Add(1);
                }
            }
        }

        // medium
        List<GameObject> mediumList = listToDrawFrom.Where(g => g.GetComponent<Enemy>().EnemyDifficulty.Equals(RoomManager.RoomDifficulty.MEDIUM)).ToList();
        if (mediumList.Count > 0)
        {
            for (int i = 0; i < mediumEnemyCount; i++)
            {
                // pick a random index and add the enemy at that index
                GameObject enemyGameObjectToAdd = mediumList[Random.Range(0, mediumList.Count)];

                // if the enemy is already in the enemies list, increase its count
                if (enemies.Contains(enemyGameObjectToAdd))
                {
                    int enemyIndex = enemies.IndexOf(enemyGameObjectToAdd);
                    counts[enemyIndex]++;
                }
                else
                {
                    // if not in the list, add it and an element for its count
                    enemies.Add(enemyGameObjectToAdd);
                    counts.Add(1);
                }
            }
        }

        // hard
        List<GameObject> hardList = listToDrawFrom.Where(g => g.GetComponent<Enemy>().EnemyDifficulty.Equals(RoomManager.RoomDifficulty.HARD)).ToList();
        if (hardList.Count > 0)
        {
            for (int i = 0; i < hardEnemyCount; i++)
            {
                // pick a random index and add the enemy at that index
                GameObject enemyGameObjectToAdd = hardList[Random.Range(0, hardList.Count)];

                // if the enemy is already in the enemies list, increase its count
                if (enemies.Contains(enemyGameObjectToAdd))
                {
                    int enemyIndex = enemies.IndexOf(enemyGameObjectToAdd);
                    counts[enemyIndex]++;
                }
                else
                {
                    // if not in the list, add it and an element for its count
                    enemies.Add(enemyGameObjectToAdd);
                    counts.Add(1);
                }
            }
        }
    }

    int GetRoomIndex(RoomManager.RoomDifficulty difficulty)
    {
        return difficulty switch
        {
            RoomManager.RoomDifficulty.VERY_EASY => VeryEasy,
            RoomManager.RoomDifficulty.EASY => Easy,
            RoomManager.RoomDifficulty.MEDIUM => Medium,
            RoomManager.RoomDifficulty.HARD => Hard,
            _ => -1,
        };
    }

    List<GameObject> GetEnemyListToDrawFrom(ItemDatabase database, List<Enemy.EnemyType> enemyTypes)
    {
        List<GameObject> combinedEnemiesList = new List<GameObject>();

        foreach (Enemy.EnemyType enemyType in enemyTypes)
        {
            switch (enemyType)
            {
                case Enemy.EnemyType.COALITION_MILITARY:
                    combinedEnemiesList.AddRange(database.coalitionMilitary);
                    break;
                case Enemy.EnemyType.SEWER_CREATURE:
                    combinedEnemiesList.AddRange(database.sewerCreatures);
                    break;
                case Enemy.EnemyType.PSYCHOKNIGHT:
                    combinedEnemiesList.AddRange(database.psychoknights);
                    break;
                case Enemy.EnemyType.UNDEAD:
                    combinedEnemiesList.AddRange(database.undead);
                    break;
                case Enemy.EnemyType.CRATER_MUTANT:
                    combinedEnemiesList.AddRange(database.craterMutants);
                    break;
                case Enemy.EnemyType.BADLANDS_CREATURE:
                    combinedEnemiesList.AddRange(database.badlandsCreatures);
                    break;
                case Enemy.EnemyType.SPARKRAIDER:
                    combinedEnemiesList.AddRange(database.sparkraiders);
                    break;
            }
        }

        return combinedEnemiesList;
    }
}
