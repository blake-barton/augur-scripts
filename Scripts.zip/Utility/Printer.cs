using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class Printer
{
    public static void Print2DArray<T>(T[,] matrix)
    {
        string debugStatement = "";

        for (int i = 0; i < matrix.GetLength(1); i++)
        {
            for (int j = 0; j < matrix.GetLength(0); j++)
            {
                debugStatement += (matrix[i, j] + "\t");
            }
            debugStatement += "\n";
        }

        Debug.Log(debugStatement);
    }

    public static void PrintStringHashSet(HashSet<string> hashSet)
    {
        string debugStatement = "";

        foreach (string element in hashSet)
        {
            debugStatement += element + ", ";
        }

        Debug.Log(debugStatement);
    }

    public static void PrintStringList(List<string> list)
    {
        string debugStatement = "";

        foreach (string element in list)
        {
            debugStatement += element + ", ";
        }

        Debug.Log(debugStatement);
    }

    public static void PrintStringAsAscii(string s)
    {
        string debugStatement = "";

        foreach (char c in s)
        {
            debugStatement += System.Convert.ToInt32(c) + ", ";
        }

        Debug.Log(debugStatement);
    }
}
