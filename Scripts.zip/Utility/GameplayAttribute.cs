using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class GameplayAttribute
{
    [SerializeField] float baseValue = 0f;
    [SerializeField] float multiplier = 1f;     // multiplicative
    [SerializeField] float modifier = 0f;       // additive (after multiplication)

    public float BaseValue { get => baseValue; set => baseValue = value; }
    public float Multiplier { get => multiplier; set => multiplier = value; }
    public float Modifier { get => modifier; set => modifier = value; }

    public GameplayAttribute()
    {
        baseValue = 0f;
        multiplier = 1f;
        modifier = 0f;
    }

    public GameplayAttribute(float _baseValue, float _multiplier, float _modifier)
    {
        baseValue = _baseValue;
        multiplier = _multiplier;
        modifier = _modifier;
    }

    public void Copy(GameplayAttribute other)
    {
        baseValue = other.BaseValue;
        multiplier = other.Multiplier;
        modifier = other.Modifier;
    }

    public float GetCurrentValue(bool allowNegatives = true)
    {
        if (allowNegatives)
        {
            return BaseValue * Multiplier + Modifier;
        }
        else
        {
            return Mathf.Max(BaseValue * Multiplier + Modifier, 0f);
        }
    }

    public override string ToString()
    {
        return GetCurrentValue().ToString();
    }
}
