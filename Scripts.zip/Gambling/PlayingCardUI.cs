using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayingCardUI : MonoBehaviour
{
    [Header("Config")]
    [SerializeField] PlayingCard playingCard;
    [SerializeField] Sprite cardBack;

    [Header("Required Components")]
    [SerializeField] Image cardImage;
    [SerializeField] Animator animator;

    public PlayingCard PlayingCard
    { 
        get => playingCard;
        set
        {
            playingCard = value;

            if (playingCard.FaceUp)
            {
                cardImage.sprite = playingCard.Sprite;
            }
            else
            {
                cardImage.sprite = cardBack;
            }
        }
    }

    /// <summary>
    /// This triggers the animation. Call this within code.
    /// </summary>
    public void TriggerCardFlip()
    {
        if (!playingCard.FaceUp)
        {
            animator.SetBool("AnimFlipped", true);
        }
        else
        {
            animator.SetBool("AnimFlipped", false);
        }
    }

    /// <summary>
    /// This is called from the child.
    /// </summary>
    public void FlipCard()
    {
        if (playingCard.FaceUp)
        {
            playingCard.FaceUp = false;
            cardImage.sprite = cardBack;
        }
        else
        {
            playingCard.FaceUp = true;
            cardImage.sprite = playingCard.Sprite;
        }
    }
}
