using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class BlackjackMenu : UIPanel
{
    [Header("UI Elements")]
    [SerializeField] RectTransform dealerHand;
    [SerializeField] RectTransform playerHand;
    [SerializeField] RectTransform playerSplitHand;
    [SerializeField] RectTransform dealButtons;
    [SerializeField] RectTransform gameplayButtons;
    [SerializeField] GameObject statusMessage;
    [SerializeField] GameObject playerPokerChip;
    [SerializeField] GameObject splitPokerChip;
    [SerializeField] GameObject splitBetLabel;
    [SerializeField] Animator dealtCardAnimator;

    [Header("Text")]
    [SerializeField] TextMeshProUGUI betTextMesh;
    [SerializeField] TextMeshProUGUI currencyTextMesh;
    [SerializeField] TextMeshProUGUI earningsTextMesh;
    [SerializeField] TextMeshProUGUI splitBetTextMesh;

    [Header("Prefabs")]
    [SerializeField] GameObject playingCardPrefab;

    [Header("Config")]
    [SerializeField] float statusMessageTime;

    // Coroutines
    Coroutine statusMessageCoroutine;

    BlackjackManager blackjackManager;
    TextMeshProUGUI statusMessageTextMesh;

    private void Awake()
    {
        blackjackManager = FindObjectOfType<BlackjackManager>();
        statusMessageTextMesh = statusMessage.GetComponent<TextMeshProUGUI>();
    }

    public void DisplayDealButtons()
    {
        dealButtons.gameObject.SetActive(true);
        gameplayButtons.gameObject.SetActive(false);
    }

    public void DisplayGameplayButtons()
    {
        dealButtons.gameObject.SetActive(false);
        gameplayButtons.gameObject.SetActive(true);
    }

    public void PrintStatusMessage(string message)
    {
        if (statusMessageCoroutine != null)
        {
            StopCoroutine(statusMessageCoroutine);
        }
        
        statusMessageCoroutine = StartCoroutine(DisplayStatusMessage(message));
    }

    IEnumerator DisplayStatusMessage(string message)
    {
        statusMessageTextMesh.text = message;

        yield return new WaitForSeconds(statusMessageTime);

        statusMessageTextMesh.text = "";
    }

    public void ClearStatusMessage()
    {
        if (statusMessageCoroutine != null)
        {
            StopCoroutine(statusMessageCoroutine);
        }

        statusMessageTextMesh.text = "";
    }

    /// <summary>
    /// Begin a new hand. Called by button.
    /// </summary>
    public void Deal()
    {
        // Deal new cards
        blackjackManager.Deal();
    }

    /// <summary>
    /// End the hand. Called by button.
    /// </summary>
    public void Stay()
    {
        blackjackManager.Stay();
    }

    /// <summary>
    /// Called by button.
    /// </summary>
    public void DoubleDown()
    {
        blackjackManager.DoubleDown();
    }
    public void Split()
    {
        blackjackManager.Split();
    }

    public void SwitchHand()
    {
        blackjackManager.SwitchHands();
    }

    public void DisplayPlayerChip()
    {
        playerPokerChip.SetActive(true);
        splitPokerChip.SetActive(false);
    }

    public void DisplaySplitChip()
    {
        playerPokerChip.SetActive(false);
        splitPokerChip.SetActive(true);
    }

    public void HideSplitChips()
    {
        playerPokerChip.SetActive(false);
        splitPokerChip.SetActive(false);
    }

    public void Surrender()
    {
        blackjackManager.Surrender();
    }

    public void DrawDealerCard(PlayingCard playingCard)
    {
        FakeDeal();

        GameObject newCard = Instantiate(playingCardPrefab, dealerHand);
        newCard.GetComponent<PlayingCardUI>().PlayingCard = playingCard;
    }

    public void DrawPlayerCard(PlayingCard playingCard)
    {
        FakeDeal();

        GameObject newCard = Instantiate(playingCardPrefab, playerHand);
        newCard.GetComponent<PlayingCardUI>().PlayingCard = playingCard;
    }

    public void DrawPlayerSplitCard(PlayingCard playingCard)
    {
        FakeDeal();

        GameObject newCard = Instantiate(playingCardPrefab, playerSplitHand);
        newCard.GetComponent<PlayingCardUI>().PlayingCard = playingCard;
    }

    /// <summary>
    /// Deal a card to the player. Called by button press.
    /// </summary>
    public void Hit()
    {
        blackjackManager.Hit();
    }

    /// <summary>
    /// Set the current bet directly. Called by button press.
    /// </summary>
    public void SetBet(int value)
    {
        blackjackManager.SetBet(value);
    }

    /// <summary>
    /// Add or subtract value from the current bet. Called by button press.
    /// </summary>
    public void AdjustBet(int value)
    {
        blackjackManager.AdjustBet(value);
    }

    /// <summary>
    /// Bet all currency. Called by button press.
    /// </summary>
    public void AllIn()
    {
        blackjackManager.AllIn();
    }

    public void SetBetText(int value)
    {
        betTextMesh.text = value.ToString();
    }

    public void SetCurrencyText(int value)
    {
        currencyTextMesh.text = value.ToString();
    }

    public void SetEarningsText(int value)
    {
        earningsTextMesh.text = value.ToString();

        // Todo: Color
    }

    public void DisplaySplitBetText()
    {
        splitBetLabel.SetActive(true);
        splitBetTextMesh.gameObject.SetActive(true);
    }

    public void HideSplitBetText()
    {
        splitBetLabel.SetActive(false);
        splitBetTextMesh.gameObject.SetActive(false);
    }

    public void SetSplitBetText(int value)
    {
        splitBetTextMesh.text = value.ToString();
    }

    public void FlipDealerCard(int index)
    {
        if (index >= 0 && index < dealerHand.childCount)
        {
            dealerHand.GetChild(0).GetComponent<PlayingCardUI>().TriggerCardFlip();
        }
        else
        {
            Debug.LogError("Invalid card index.");
        }
    }

    void FakeDeal()
    {
        dealtCardAnimator.SetTrigger("AnimDeal");
    }

    public void RemoveCardFromPlayerDeck(int index)
    {
        Destroy(playerHand.GetChild(index).gameObject);
    }

    public void ClearCards()
    {
        foreach (RectTransform child in dealerHand)
        {
            Destroy(child.gameObject);
        }

        foreach (RectTransform child in playerHand)
        {
            Destroy(child.gameObject);
        }

        foreach (RectTransform child in playerSplitHand)
        {
            Destroy(child.gameObject);
        }
    }

    public void ExitGame()
    {
        blackjackManager.ExitGame();
    }
}
