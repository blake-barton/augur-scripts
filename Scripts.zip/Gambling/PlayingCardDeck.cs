using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Gambling/Deck")]
public class PlayingCardDeck : ScriptableObject
{
    [SerializeField] List<PlayingCard> cards = new();

    readonly List<PlayingCard> deck = new();

    /// <summary>
    /// Create a new unshuffled deck.
    /// </summary>
    public void CreateDeck()
    {
        foreach (PlayingCard card in cards)
        {
            deck.Add(Instantiate(card));
        }
    }

    /// <summary>
    /// Shuffle the deck of cards
    /// </summary>
    public void Shuffle()
    {
        // https://en.wikipedia.org/wiki/Fisher%E2%80%93Yates_shuffle
        for (int n = deck.Count - 1; n > 0; --n)
        {
            int k = Random.Range(0, n + 1);
            PlayingCard temp = deck[n];
            deck[n] = deck[k];
            deck[k] = temp;
        }
    }

    /// <summary>
    /// Remove the top card (index 0) from the deck.
    /// </summary>
    public PlayingCard DrawTopCard()
    {
        if (deck.Count > 0)
        {
            PlayingCard topCard = deck[0];

            deck.RemoveAt(0);

            return topCard;
        }

        return null;
    }

    /// <summary>
    /// Add card to deck. It will be the last one drawn.
    /// </summary>
    public void AddCardToBottomOfDeck(PlayingCard card)
    {
        deck.Add(card);
    }

    /// <summary>
    /// Add card to deck. It will be the next one drawn.
    /// </summary>
    public void AddCardToTopOfDeck(PlayingCard card)
    {
        deck.Insert(0, card);
    }

    /// <summary>
    /// Clear the deck and add all cards back in order.
    /// </summary>
    public void ResetDeck()
    {
        deck.Clear();
        CreateDeck();
    }
}
