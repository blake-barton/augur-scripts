using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BlackjackManager : MonoBehaviour
{
    [Header("UI")]
    [SerializeField] GameObject blackjackMenuPrefab;

    [Header("Cards")]
    [SerializeField] PlayingCardDeck deckPrefab;

    [Header("Game Config")]
    [SerializeField] int minimumBet = 200;
    [SerializeField] float timeBetweenDealerFlips = 0.5f;
    [SerializeField] float timeBetweenGames = 1f;

    [Header("Game Status")]
    [SerializeField] bool playingHand = false;
    [SerializeField] bool revealingDealerCards = false;
    [SerializeField] bool doubledDown = false;
    [SerializeField] bool splitting = false;
    [SerializeField] bool hittingSplitHand = false;
    [SerializeField] bool bustedSplitHand = false;
    [SerializeField] bool bustedMainHand = false;
    [SerializeField] bool doubledDownMainHand = false;
    [SerializeField] int currentBet = 200;
    [SerializeField] int earnings = 0;
    [SerializeField] int splitBet = 0;

    [Header("Audio")]
    [SerializeField] List<AudioClip> cardSounds = new();
    [SerializeField] [Range(0, 1)] float cardSoundVolume = 1f;
    [SerializeField] List<AudioClip> winSounds = new();
    [SerializeField] [Range(0, 1)] float winSoundVolume = 1f;

    [Header("State")]
    [SerializeField] bool inMenu = false;
    [SerializeField] UIPanel currentPanel;

    [Header("Cached References")]
    [SerializeField] CameraTarget cameraTarget;
    [SerializeField] Transform dealerNPC;
    [SerializeField] AudioSource audioSource;

    // Instantiated Objects
    GameObject instantiatedBlackjackMenu;
    PlayingCardDeck playingDeck;

    // Cache
    Player player;
    Crypto playerCurrency;
    Canvas canvas;
    BlackjackMenu blackjackUI;

    // Game variables
    List<PlayingCard> dealerCards = new();
    List<PlayingCard> playerCards = new();
    List<PlayingCard> playerSplitCards = new();

    private void Awake()
    {
        player = FindObjectOfType<Player>();
        playerCurrency = player.GetComponent<Crypto>();
        canvas = GameObject.FindGameObjectWithTag("GameCanvas").GetComponent<Canvas>();
    }

    public void SpawnBlackjackMenu()
    {
        instantiatedBlackjackMenu = Instantiate(blackjackMenuPrefab, canvas.transform);
        blackjackUI = instantiatedBlackjackMenu.GetComponent<BlackjackMenu>();

        inMenu = true;

        // freeze player
        player.IsBusy = true;
        player.Character.Incapacitated = true;
        player.GetComponent<PlayerMovement>().FreezeMovement();

        StartCoroutine(LockCameraToDealer());

        StartGame();
    }

    IEnumerator LockCameraToDealer()
    {
        yield return new WaitForSeconds(.1f);

        // move camera to Dealer
        cameraTarget.LockToTransform(dealerNPC);
    }

    void StartGame()
    {
        // Create deck
        if (!playingDeck)
        {
            playingDeck = Instantiate(deckPrefab);
            playingDeck.CreateDeck();
            playingDeck.Shuffle();
        }
        else
        {
            playingDeck.ResetDeck();
            playingDeck.Shuffle();
        }

        // Set starting money values
        blackjackUI.SetBetText(currentBet);
        blackjackUI.SetCurrencyText(playerCurrency.CurrentCurrency);
        blackjackUI.SetEarningsText(earnings);
    }

    public void ExitGame()
    {
        if (inMenu)
        {
            Destroy(instantiatedBlackjackMenu);

            inMenu = false;

            player.IsBusy = false;
            player.Character.Incapacitated = false;

            // enable mouse look
            cameraTarget.EnableMouseLook();
        }
    }

    void ResetGame()
    {
        // Half current bet if doubled down
        if (doubledDown)
        {
            currentBet /= 2;
            blackjackUI.SetBetText(currentBet);
            doubledDown = false;
        }

        // Clear split
        splitting = false;
        hittingSplitHand = false;
        bustedMainHand = false;
        bustedSplitHand = false;
        doubledDownMainHand = false;
        splitBet = 0;
        blackjackUI.SetSplitBetText(splitBet);
        blackjackUI.HideSplitBetText();
        blackjackUI.HideSplitChips();

        // New deck
        playingDeck.ResetDeck();
        playingDeck.Shuffle();

        // Clear hands
        playerCards.Clear();
        dealerCards.Clear();
        playerSplitCards.Clear();

        // UI
        blackjackUI.ClearCards();
        blackjackUI.DisplayDealButtons();

        // No longer playing hand
        playingHand = false;
    }

    public void Deal()
    {
        if (!playingHand)
        {
            blackjackUI.ClearStatusMessage();

            if (playerCurrency.CurrentCurrency - currentBet >= 0)
            {
                // We're playing now
                playingHand = true;

                // Show gameplay buttons
                blackjackUI.DisplayGameplayButtons();

                // Subtract currency
                playerCurrency.SubtractCurrency(currentBet);
                earnings -= currentBet;
                blackjackUI.SetCurrencyText(playerCurrency.CurrentCurrency);    // UI
                blackjackUI.SetEarningsText(earnings);

                // Player -> Dealer -> Player -> Dealer
                DrawPlayerCard();
                DrawDealerCard(false);
                DrawPlayerCard();
                DrawDealerCard(true);

                // Check blackjacks immediately
                bool blackjack = CheckBlackjack(playerCards) || CheckBlackjack(dealerCards);
                if (blackjack)
                {
                    // Immediately stay. If the dealer also has blackjack the player breaks even. Otherwise pay out 3:2.
                    Stay(true);
                }
            }
            else
            {
                blackjackUI.PrintStatusMessage("Not enough money to wager that amount.");
            }
        }
    }

    /// <summary>
    /// Draw a card for the player. Calculate player's new score and check if they bust. Return false busted.
    /// </summary>
    public bool Hit()
    {
        if (!revealingDealerCards)
        {
            if (hittingSplitHand)
            {
                if (!bustedSplitHand)
                {
                    DrawPlayerSplitCard();

                    // Check if player split hand busts
                    if (CheckBust(playerSplitCards))
                    {
                        // Bust normally if not splitting
                        if (!splitting)
                        {
                            Debug.LogError("Splitting = false even though we're acting on the split hand.");
                            return false;
                        }
                        else
                        {
                            bustedSplitHand = true;

                            blackjackUI.PrintStatusMessage("Busted your split hand!");

                            SwitchHands();

                            if (bustedMainHand && bustedSplitHand)
                            {
                                StartCoroutine(PlayerBust());
                            }

                            return false;
                        }
                    }
                }
                else
                {
                    blackjackUI.PrintStatusMessage("You already busted your split hand.");
                }
            }
            else
            {
                if (!bustedMainHand)
                {
                    // Early out if already doubled down main hand
                    if (doubledDownMainHand)
                    {
                        blackjackUI.PrintStatusMessage("Your main hand is doubled down.");
                        return true;
                    }

                    // Draw new card
                    DrawPlayerCard();

                    // Check if player busts
                    if (CheckBust(playerCards))
                    {
                        // Bust normally if not splitting
                        if (!splitting)
                        {
                            StartCoroutine(PlayerBust());
                            return false;
                        }
                        else
                        {
                            blackjackUI.PrintStatusMessage("Busted your main hand!");

                            bustedMainHand = true;

                            // Switch to split hand
                            SwitchHands();

                            if (bustedMainHand && bustedSplitHand)
                            {
                                StartCoroutine(PlayerBust());
                            }

                            return false;
                        }
                    }
                }
                else
                {
                    blackjackUI.PrintStatusMessage("You already busted your main hand.");
                }
            }

            return true;
        }

        return true;
    }

    /// <summary>
    /// End hand. Dealer flips and draws until staying at 17.
    /// </summary>
    public void Stay(bool blackjack = false)
    {
        if (!revealingDealerCards)
        {
            StartCoroutine(DealerTurn(blackjack));
        }
    }

    /// <summary>
    /// Double wager. Hit once. Dealer immediately reveals.
    /// </summary>
    public void DoubleDown()
    {
        if (!revealingDealerCards)
        {
            // Check that the player hasn't already hit
            if (playerCards.Count > 2)
            {
                blackjackUI.PrintStatusMessage("You can only double down on your starting hand.");
                return;
            }

            // Check that player has enough money to double down
            if (currentBet > playerCurrency.CurrentCurrency)
            {
                blackjackUI.PrintStatusMessage("Not enough gossamer to double down.");
                return;
            }

            doubledDown = true; // for decreasing the bet after the hand

            // Double bet
            playerCurrency.SubtractCurrency(currentBet);
            earnings -= currentBet;
            currentBet += currentBet;
            blackjackUI.SetBetText(currentBet);
            blackjackUI.SetCurrencyText(playerCurrency.CurrentCurrency);
            blackjackUI.SetEarningsText(earnings);

            // Hit once if did not bust
            if (Hit())
            {
                // Stay if not splitting or we are splitting and we already busted the split hand
                if (!splitting || (splitting && bustedSplitHand))
                {
                    Stay();
                }
                else
                {
                    doubledDownMainHand = true;
                }
            }
        }
    }

    /// <summary>
    /// Split on any starting pair except Queen:King. Start two hands.
    /// </summary>
    public void Split()
    {
        if (!revealingDealerCards)
        {
            // Check that the player only has two cards
            if (playerCards.Count > 2)
            {
                blackjackUI.PrintStatusMessage("You can only split on your starting hand.");
                return;
            }

            // Check that the cards are the same
            if (GetCardValue(playerCards[0], false) != GetCardValue(playerCards[1], false))
            {
                blackjackUI.PrintStatusMessage("You can only split cards with the same value.");
                return;
            }

            // Check that the cards aren't king and queen
            if ((playerCards[0].Value == PlayingCard.CardValue.King && playerCards[1].Value == PlayingCard.CardValue.Queen) || (playerCards[1].Value == PlayingCard.CardValue.King && playerCards[0].Value == PlayingCard.CardValue.Queen))
            {
                blackjackUI.PrintStatusMessage("You cannot split on King:Queen.");
                return;
            }

            // Check not already splitting
            if (splitting)
            {
                blackjackUI.PrintStatusMessage("You\'ve already split your hand.");
                return;
            }

            // Check that player has enough money to split
            if (currentBet > playerCurrency.CurrentCurrency)
            {
                blackjackUI.PrintStatusMessage("Not enough gossamer to split.");
                return;
            }

            // Split mode
            splitting = true;

            // Turn on player poker chip
            blackjackUI.DisplayPlayerChip();

            // Add split bet
            playerCurrency.SubtractCurrency(currentBet);
            earnings -= currentBet;
            splitBet = currentBet;
            blackjackUI.DisplaySplitBetText();
            blackjackUI.SetSplitBetText(splitBet);
            blackjackUI.SetCurrencyText(playerCurrency.CurrentCurrency);
            blackjackUI.SetEarningsText(earnings);

            // Move second card to split hand
            blackjackUI.DrawPlayerSplitCard(playerCards[1]);    // Add split card in UI
            blackjackUI.RemoveCardFromPlayerDeck(1);            // Remove player card in UI
            playerSplitCards.Add(playerCards[1]);               // Add split card in list
            playerCards.RemoveAt(1);                            // Remove player card in list

            // Hit on the player card and split card
            Hit();
            SwitchHands();
            Hit();
            SwitchHands();
        }
    }

    public void SwitchHands()
    {
        if (hittingSplitHand)
        {
            hittingSplitHand = false;

            // Show player chip
            blackjackUI.DisplayPlayerChip();
        }
        else
        {
            hittingSplitHand = true;

            // Show split chip
            blackjackUI.DisplaySplitChip();
        }
    }

    /// <summary>
    /// Instantly lose, retrieving half of your bet back.
    /// </summary>
    public void Surrender()
    {
        if (!revealingDealerCards)
        {
            StartCoroutine(PlayerSurrender());
        }
    }

    IEnumerator PlayerSurrender()
    {
        revealingDealerCards = true;

        // Give the player HALF their money back
        playerCurrency.AddCurrency(currentBet / 2);
        earnings += currentBet / 2;
        blackjackUI.SetCurrencyText(playerCurrency.CurrentCurrency);
        blackjackUI.SetEarningsText(earnings);

        blackjackUI.PrintStatusMessage("Surrendered. Retrieve half of your bet.");

        yield return new WaitForSeconds(timeBetweenGames);

        ResetGame();

        revealingDealerCards = false;
    }

    IEnumerator PlayerBust()
    {
        revealingDealerCards = true;

        blackjackUI.PrintStatusMessage("You\'ve gone bust!");

        yield return new WaitForSeconds(timeBetweenGames);

        ResetGame();

        revealingDealerCards = false;
    }

    IEnumerator DealerTurn(bool blackjack = false)
    {
        revealingDealerCards = true;

        // Flip first card
        blackjackUI.FlipDealerCard(0);

        // Audio
        AudioUtility.PlayRandomSound(audioSource, cardSounds, cardSoundVolume);

        // Add up new value
        int dealerValue = GetHandValue(dealerCards);

        // Wait to draw
        yield return new WaitForSeconds(timeBetweenDealerFlips);

        // If someone has a blackjack, compare and pay
        if (blackjack)
        {
            ResolveWinner(dealerValue, playerCards, blackjack);

            yield return new WaitForSeconds(timeBetweenGames);

            // Prepare a new hand
            ResetGame();

            revealingDealerCards = false;

            // Exit early
            yield break;
        }

        while (dealerValue < 17)
        {
            // Draw new card
            DrawDealerCard(true);

            // Add up new value
            dealerValue = GetHandValue(dealerCards);

            // Wait to flip next card
            yield return new WaitForSeconds(timeBetweenDealerFlips);
        }

        // Resolve
        if (splitting)
        {
            // If split, resolve the hands that aren't busted
            if (!bustedMainHand)
            {
                blackjackUI.DisplayPlayerChip();

                ResolveWinner(dealerValue, playerCards);

                yield return new WaitForSeconds(timeBetweenGames);
            }
            if (!bustedSplitHand)
            {
                blackjackUI.DisplaySplitChip();
                ResolveWinner(dealerValue, playerSplitCards);
            }
        }
        else
        {
            ResolveWinner(dealerValue, playerCards);
        }

        yield return new WaitForSeconds(timeBetweenGames);

        // Prepare a new hand
        ResetGame();

        revealingDealerCards = false;
    }

    private void ResolveWinner(int dealerValue, List<PlayingCard> playerHand, bool blackjack = false)
    {
        int playerValue = GetHandValue(playerHand);

        // Resolve blackjacks
        if (dealerValue == 21 && playerValue != 21 && blackjack)
        {
            // Player doesn't get anything back
            blackjackUI.PrintStatusMessage("Dealer blackjack! You lose!");
        }
        else if (playerValue == 21 && dealerValue != 21 && blackjack)
        {
            // Blackjack! 3:2 payout
            int payout = (currentBet * 3) / 2;

            playerCurrency.AddCurrency(currentBet + payout);
            earnings += currentBet + payout;
            blackjackUI.SetCurrencyText(playerCurrency.CurrentCurrency);
            blackjackUI.SetEarningsText(earnings);

            blackjackUI.PrintStatusMessage("Blackjack! You win " + payout + " gossamer.");

            // Audio
            AudioUtility.PlayRandomSound(audioSource, winSounds, winSoundVolume);
        }
        else if (playerValue == 21 && dealerValue == 21 && blackjack)
        {
            // Two blackjacks! Push.
            playerCurrency.AddCurrency(currentBet);
            earnings += currentBet;
            blackjackUI.SetCurrencyText(playerCurrency.CurrentCurrency);
            blackjackUI.SetEarningsText(earnings);

            blackjackUI.PrintStatusMessage("Two blackjacks! Push.");
        }
        else if (dealerValue > 21)
        {
            // Give the player their money back and then again for winning
            playerCurrency.AddCurrency(currentBet * 2);
            earnings += (currentBet * 2);
            blackjackUI.SetCurrencyText(playerCurrency.CurrentCurrency);
            blackjackUI.SetEarningsText(earnings);

            blackjackUI.PrintStatusMessage("Dealer busts! You win " + currentBet + " gossamer.");

            // Audio
            AudioUtility.PlayRandomSound(audioSource, winSounds, winSoundVolume);
        }
        else if (playerValue > dealerValue)
        {
            // Give the player their money back and then again for winning
            playerCurrency.AddCurrency(currentBet * 2);
            earnings += (currentBet * 2);
            blackjackUI.SetCurrencyText(playerCurrency.CurrentCurrency);
            blackjackUI.SetEarningsText(earnings);

            blackjackUI.PrintStatusMessage("You beat the dealer! You win " + currentBet + " gossamer.");

            // Audio
            AudioUtility.PlayRandomSound(audioSource, winSounds, winSoundVolume);
        }
        else if (playerValue == dealerValue)
        {
            // Give the player their money back
            playerCurrency.AddCurrency(currentBet);
            earnings += currentBet;
            blackjackUI.SetCurrencyText(playerCurrency.CurrentCurrency);
            blackjackUI.SetEarningsText(earnings);

            blackjackUI.PrintStatusMessage("Push. Get your money back.");
        }
        else if (playerValue < dealerValue)
        {
            // Player doesn't get anything back
            blackjackUI.PrintStatusMessage("You lose!");
        }
    }

    /// <summary>
    /// Return true if first two cards are an ace and a 10 value card.
    /// </summary>
    /// <param name="hand"></param>
    /// <returns></returns>
    private bool CheckBlackjack(List<PlayingCard> hand)
    {
        if (hand.Count != 2)
        {
            Debug.LogError("Can only check blackjack on the first hand.");
            return false;
        }

        // XOR ace
        if ((hand[0].Value == PlayingCard.CardValue.Ace) ^ (hand[1].Value == PlayingCard.CardValue.Ace))
        {
            // XOR other card is a 10
            if ((GetCardValue(hand[0], true) == 10) ^ (GetCardValue(hand[1], true) == 10))
            {
                return true;
            }
        }

        return false;
    }

    /// <summary>
    /// Returns true on bust.
    /// </summary>
    private bool CheckBust(List<PlayingCard> hand)
    {
        return GetHandValue(hand) > 21;
    }

    private int GetHandValue(List<PlayingCard> hand)
    {
        int value = 0;
        bool aceFound = false;  // A hand can have at most 1 ace, because 11 + 11 busts at 22.

        // Add up the value of the non-aces and add the number of aces (aces = 1)
        foreach (PlayingCard card in hand)
        {
            // Check for ace
            if (card.Value == PlayingCard.CardValue.Ace)
            {
                aceFound = true;
            }

            value += GetCardValue(card, false);
        }

        // Convert an ace to 11 if it doesn't bust the hand
        if (aceFound && value + 10 <= 21)
        {
            value += 10;
        }

        return value;
    }

    private int GetCardValue(PlayingCard card, bool highAce)
    {
        switch (card.Value)
        {
            case PlayingCard.CardValue.One:
                return 1;
            case PlayingCard.CardValue.Two:
                return 2;
            case PlayingCard.CardValue.Three:
                return 3;
            case PlayingCard.CardValue.Four:
                return 4;
            case PlayingCard.CardValue.Five:
                return 5;
            case PlayingCard.CardValue.Six:
                return 6;
            case PlayingCard.CardValue.Seven:
                return 7;
            case PlayingCard.CardValue.Eight:
                return 8;
            case PlayingCard.CardValue.Nine:
                return 9;
            case PlayingCard.CardValue.Ten:
                return 10;
            case PlayingCard.CardValue.Jack:
                return 10;
            case PlayingCard.CardValue.Queen:
                return 10;
            case PlayingCard.CardValue.King:
                return 10;
            case PlayingCard.CardValue.Ace:
                if (highAce)
                {
                    return 11;
                }
                return 1;
            default:
                Debug.LogError("Impossible card value!");
                return -1;
        }
    }

    /// <summary>
    /// Set the current bet directly
    /// </summary>
    public void SetBet(int value)
    {
        if (value < minimumBet)
        {
            blackjackUI.PrintStatusMessage("Minimum bet: " + minimumBet);
            return;
        }
  
        currentBet = value;

        // UI
        blackjackUI.SetBetText(currentBet);
    }

    /// <summary>
    /// Add or subtract value from the current bet
    /// </summary>
    public void AdjustBet(int value)
    {
        SetBet(currentBet + value);
    }

    /// <summary>
    /// Add or subtract value from the current bet
    /// </summary>
    public void AllIn()
    {
        SetBet(playerCurrency.CurrentCurrency);
    }

    void DrawDealerCard(bool faceUp)
    {
        // Audio
        AudioUtility.PlayRandomSound(audioSource, cardSounds, cardSoundVolume);

        // Draw new card
        PlayingCard drawnCard = playingDeck.DrawTopCard();
        drawnCard.FaceUp = faceUp;

        dealerCards.Add(drawnCard);

        // Add to UI
        blackjackUI.DrawDealerCard(drawnCard);
    }

    void DrawPlayerCard()
    {
        // Audio
        AudioUtility.PlayRandomSound(audioSource, cardSounds, cardSoundVolume);

        // Draw new card
        PlayingCard drawnCard = playingDeck.DrawTopCard();
        drawnCard.FaceUp = true;

        playerCards.Add(drawnCard);

        // Add to UI
        blackjackUI.DrawPlayerCard(drawnCard);
    }

    void DrawPlayerSplitCard()
    {
        // Audio
        AudioUtility.PlayRandomSound(audioSource, cardSounds, cardSoundVolume);

        // Draw new card
        PlayingCard drawnCard = playingDeck.DrawTopCard();
        drawnCard.FaceUp = true;

        playerSplitCards.Add(drawnCard);

        // Add to UI
        blackjackUI.DrawPlayerSplitCard(drawnCard);
    }
}
