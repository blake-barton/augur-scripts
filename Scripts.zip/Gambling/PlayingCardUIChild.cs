using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayingCardUIChild : MonoBehaviour
{
    PlayingCardUI playingCardUI;

    private void Awake()
    {
        playingCardUI = transform.parent.GetComponent<PlayingCardUI>();
    }

    /// <summary>
    /// This is called from animation. DO NOT call within code.
    /// </summary>
    public void FlipCard()
    {
        playingCardUI.FlipCard();
    }
}
