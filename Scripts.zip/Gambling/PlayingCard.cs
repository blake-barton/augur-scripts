using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Gambling/Playing Card")]
public class PlayingCard : ScriptableObject
{
    public enum CardValue
    {
        One,
        Two,
        Three,
        Four,
        Five,
        Six,
        Seven,
        Eight,
        Nine,
        Ten,
        Jack,
        Queen,
        King,
        Ace
    }

    public enum CardSuit
    {
        Hearts,
        Diamonds,
        Clubs,
        Spades
    }

    [SerializeField] CardValue value;
    [SerializeField] CardSuit suit;
    [SerializeField] Sprite sprite;

    [Header("State")]
    [SerializeField] bool faceUp = false;

    public CardSuit Suit { get => suit; set => suit = value; }
    public CardValue Value { get => value; set => this.value = value; }
    public Sprite Sprite { get => sprite; set => sprite = value; }
    public bool FaceUp { get => faceUp; set => faceUp = value; }

    public static bool operator ==(PlayingCard left, PlayingCard right)
    {
        // If both are null, or both are same instance, return true.
        if (ReferenceEquals(left, right))
        {
            return true;
        }

        // If one is null, but not both, return false.
        if ((left is null) || (right is null))
        {
            return false;
        }

        // Return true if the fields match:
        return left.Equals(right);
    }

    public static bool operator !=(PlayingCard left, PlayingCard right)
    {
        return !(left == right);
    }

    /// <summary>
    /// Returns the card as a single string
    /// </summary>
    /// <returns></returns>
    public string CardName()
    {
        return value.ToString() + " of " + suit.ToString();
    }
}
