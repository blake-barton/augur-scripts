using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

public class LightMapsInit : MonoBehaviour
{
    [SerializeField] [Range(0, 10)] int darknessLevel;

    [Header("Tilemaps")]
    [SerializeField] Tilemap darkMap;
    [SerializeField] Tilemap blurredMap;
    [SerializeField] Tilemap backgroundMap;

    [Header("Lighting Tiles")]
    [SerializeField] Tile dark100Tile;
    [SerializeField] Tile dark90Tile;
    [SerializeField] Tile dark80Tile;
    [SerializeField] Tile dark70Tile;
    [SerializeField] Tile dark60Tile;
    [SerializeField] Tile dark50Tile;
    [SerializeField] Tile dark40Tile;
    [SerializeField] Tile dark30Tile;
    [SerializeField] Tile dark20Tile;
    [SerializeField] Tile dark10Tile;
    [SerializeField] Tile dark05Tile;

    Tile darkTile;
    Tile blurredTile;

    bool generateMaps = true;

    // Start is called before the first frame update
    void Start()
    {
        InitTilemaps();
    }

    void InitTilemaps()
    {
        // set light maps equal to the size of the background map (the largest tilemap in the scene)
        darkMap.origin = blurredMap.origin = backgroundMap.origin;
        darkMap.size = blurredMap.size = backgroundMap.size;

        // select dark tiles based on darknessLevel
        SelectDarkAndBlurredTiles();

        if (generateMaps)
        {
            // loop through the light maps to assign each tile
            foreach (Vector3Int position in darkMap.cellBounds.allPositionsWithin)
            {
                darkMap.SetTile(position, darkTile);
            }

            // loop through the light maps to assign each tile
            foreach (Vector3Int position in blurredMap.cellBounds.allPositionsWithin)
            {
                blurredMap.SetTile(position, blurredTile);
            }
        }
    }

    void SelectDarkAndBlurredTiles()
    {
        switch (darknessLevel)
        {
            case 10:
                darkTile = dark100Tile;
                blurredTile = dark30Tile;
                break;
            case 9:
                darkTile = dark90Tile;
                blurredTile = dark30Tile;
                break;
            case 8:
                darkTile = dark80Tile;
                blurredTile = dark30Tile;
                break;
            case 7:
                darkTile = dark70Tile;
                blurredTile = dark30Tile;
                break;
            case 6:
                darkTile = dark60Tile;
                blurredTile = dark20Tile;
                break;
            case 5:
                darkTile = dark50Tile;
                blurredTile = dark20Tile;
                break;
            case 4:
                darkTile = dark40Tile;
                blurredTile = dark10Tile;
                break;
            case 3:
                darkTile = dark30Tile;
                blurredTile = dark05Tile;
                break;
            case 2:
                darkTile = dark20Tile;
                blurredTile = dark05Tile;
                break;
            case 1:
                darkTile = dark10Tile;
                blurredTile = dark05Tile;
                break;
            case 0:
                generateMaps = false;
                enabled = false;
                break;
        }
    }
}
