using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LightMask : MonoBehaviour
{
    [SerializeField] bool flickerEnabled = true;
    [SerializeField] [Range(0f, 1f)] float flickerTime;     // how often light size is changed
    [SerializeField] [Range(0f, 1f)] float lightSizeDelta;

    float timer = 0;

    // states
    bool sizeIncreased = false;

    // Update is called once per frame
    void Update()
    {
        Flicker();
    }

    private void Flicker()
    {
        if (flickerEnabled)
        {
            timer += Time.deltaTime;

            if (timer > flickerTime)
            {
                if (sizeIncreased)
                    transform.localScale = new Vector3(transform.localScale.x + lightSizeDelta, transform.localScale.y + lightSizeDelta, transform.localScale.z);
                else
                    transform.localScale = new Vector3(transform.localScale.x - lightSizeDelta, transform.localScale.y - lightSizeDelta, transform.localScale.z);

                timer = 0;
                sizeIncreased = !sizeIncreased;
            }
        }
    }
}
