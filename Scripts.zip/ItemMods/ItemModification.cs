using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class ItemModification : ScriptableObject
{
    [SerializeField] string modName;
    [SerializeField] string modDescription;
    [SerializeField] Sprite modSprite;

    public abstract void AttachMod(Item item);
    public abstract void DetachMod(Item item);
    public abstract void OnItemEquipped(Item item, Equipment equipment);
    public abstract void OnItemUnequipped(Item item, Equipment equipment);
}
