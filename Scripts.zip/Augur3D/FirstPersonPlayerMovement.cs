using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FirstPersonPlayerMovement : MonoBehaviour
{
    [SerializeField] float speed = 12f;

    [Header("Gravity")]
    [SerializeField] float gravity = -9.81f;
    [SerializeField] float groundDistance = .4f;
    [SerializeField] LayerMask groundMask;

    [Header("State")]
    [SerializeField] bool isGrounded = false;

    [Header("Cached References")]
    [SerializeField] CharacterController controller;
    [SerializeField] Transform groundCheck;

    Vector3 velocity;

    // Update is called once per frame
    void Update()
    {
        isGrounded = Physics.CheckSphere(groundCheck.position, groundDistance, groundMask);

        if (isGrounded && velocity.y < 0)
        {
            velocity.y = -2f;
        }

        float x = Input.GetAxis("Horizontal");
        float z = Input.GetAxis("Vertical");        // where "vertical" really means forward

        // move in the direction the player is facing
        Vector3 move = transform.right * x + transform.forward * z;

        controller.Move(speed * Time.deltaTime * move);

        velocity.y += gravity * Time.deltaTime;

        controller.Move(velocity * Time.deltaTime);
    }
}
