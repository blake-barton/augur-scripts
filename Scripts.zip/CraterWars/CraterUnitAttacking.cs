using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CraterUnitAttacking : MonoBehaviour
{
    [Header("Weapon")]
    [SerializeField] RangedWeapon weaponStats;
    [SerializeField] GameObject projectile;
    [SerializeField] Vector3 projectileOffset = new Vector2();
    [SerializeField] Orbiter orbiter;

    [Header("Ammo")]
    [SerializeField] int ammoInMagazine;
    [SerializeField] GameObject reloadingWidget;

    [Header("State")]
    [SerializeField] bool permittedToEngage = false;
    [SerializeField] bool canSearchForNewTargets = false;
    [SerializeField] bool searchingForNewTargets = false;
    [SerializeField] bool isFiring = false;
    [SerializeField] bool isReloading = false;

    [Header("Audio")]
    [SerializeField] AudioClip shotAudio;
    [SerializeField] [Range(0, 1)] float shotAudioVolume = 1f;

    // coroutines
    Coroutine firingCoroutine;

    // timers
    float reloadTimer;

    // cache
    CraterUnit thisUnit;
    LineOfSight lineOfSight;
    AudioSource audioSource;

    public bool PermittedToEngage 
    {
        get => permittedToEngage; 
        set
        {
            permittedToEngage = value;

            // clear target when receiving new orders
            lineOfSight.Target = null;
        }
    }
    public bool CanSearchForNewTargets { get => canSearchForNewTargets; set => canSearchForNewTargets = value; }
    public bool SearchingForNewTargets { get => searchingForNewTargets; set => searchingForNewTargets = value; }
    public RangedWeapon WeaponStats { get => weaponStats; set => weaponStats = value; }

    private void Awake()
    {
        thisUnit = GetComponent<CraterUnit>();
        lineOfSight = GetComponent<LineOfSight>();
        audioSource = GetComponent<AudioSource>();

        // init ammo
        ammoInMagazine = WeaponStats.ClipSize;
    }

    // Update is called once per frame
    void Update()
    {
        // reload weapon
        if (WeaponStats && reloadTimer > 0)
        {
            reloadTimer -= Time.deltaTime;
        }
        else if (WeaponStats && reloadTimer <= 0 && isReloading)
        {
            // no longer reloading
            isReloading = false;

            reloadingWidget.SetActive(false);
        }

        // try to fire
        if (PermittedToEngage && WeaponStats && lineOfSight.Target)
        {
            // have a target and can fire
            StartFiring();
        }
        else if (PermittedToEngage && WeaponStats && !lineOfSight.Target && CanSearchForNewTargets && !SearchingForNewTargets)
        {
            // can fire but no target. Search for nearest target.
            SearchingForNewTargets = true;
            InvokeRepeating(nameof(SearchForNearestEnemy), 0f, 1f);
        }
    }

    void SearchForNearestEnemy()
    {
        // Iterate through the visible enemies in aggro range. Find the one that is closest.
        float minDistance = float.MaxValue;
        CraterUnit closestVisibleEnemy = null;

        if (thisUnit.UnitFaction == CraterUnit.Faction.PlayerFaction)
        {
            foreach (CraterUnit unit in CraterAIUnitCommander.CraterUnits)
            {
                // narrow down results to those in aggro range
                float distanceToCandidate = Vector2.Distance(transform.position, unit.transform.position);
                if (distanceToCandidate <= thisUnit.SightRange && distanceToCandidate < minDistance)
                {
                    // check visibility
                    if (lineOfSight.CheckIfTransformIsVisible(unit.transform))
                    {
                        minDistance = distanceToCandidate;
                        closestVisibleEnemy = unit;
                    }
                }
            }
        }
        else
        {
            foreach (CraterUnit unit in CraterUnitCommander.Instance.availableUnits)
            {
                // narrow down results to those in aggro range
                float distanceToCandidate = Vector2.Distance(transform.position, unit.transform.position);
                if (distanceToCandidate <= thisUnit.SightRange && distanceToCandidate < minDistance)
                {
                    // check visibility
                    if (lineOfSight.CheckIfTransformIsVisible(unit.transform))
                    {
                        minDistance = distanceToCandidate;
                        closestVisibleEnemy = unit;
                    }
                }
            }
        }

        if (closestVisibleEnemy)
        {
            lineOfSight.Target = closestVisibleEnemy.transform;
        }
    }

    public void StopSearchingForNearestEnemy()
    {
        CancelInvoke();
        SearchingForNewTargets = false;
    }

    void StartFiring()
    {
        if (reloadTimer <= 0 && (lineOfSight.GetDistanceToTarget() <= WeaponStats.MaxRange) && lineOfSight.TargetVisible && ammoInMagazine > 0 && !isFiring)
        {
            firingCoroutine = StartCoroutine(SpawnProjectileFullAuto());
        }
    }

    void SpawnProjectile()
    {
        GameObject firedProjectile = Instantiate(projectile, transform.position + projectileOffset, orbiter.GetPivotRotation());

        // add spread to projectile and set attributes
        firedProjectile.transform.Rotate(0, 0, GetRandomizedProjectileSpread());
        SetProjectileAttributes(firedProjectile);
    }

    public void StopSpawningFullAuto()
    {
        if (!(firingCoroutine is null))
        {
            StopCoroutine(firingCoroutine);
            isFiring = false;
        }
    }

    IEnumerator SpawnProjectileFullAuto()
    {
        // check that there's enough ammo in the clip
        if (ammoInMagazine - WeaponStats.AmmoUsedPerShot >= 0)
        {
            isFiring = true;

            while (true)
            {
                for (int i = 0; i < WeaponStats.ProjectilesPerShot; i++)
                {
                    SpawnProjectile();
                }

                // decrease ammo count
                ammoInMagazine -= WeaponStats.AmmoUsedPerShot;

                // play sound
                if (audioSource)
                {
                    audioSource.PlayOneShot(shotAudio, shotAudioVolume);
                }

                // break if ammo goes below or equal to 0
                if (ammoInMagazine <= 0)
                {
                    ReloadWeapon();

                    yield break;
                }

                yield return new WaitForSeconds(1 / WeaponStats.AttackRate);
            }
        }
        else
        {
            ReloadWeapon();

            yield break;
        }
    }

    void ReloadWeapon()
    {
        // out of ammo
        isFiring = false;

        // "reload"
        reloadTimer = WeaponStats.ReloadTime;
        ammoInMagazine = WeaponStats.ClipSize;

        // show widget
        reloadingWidget.SetActive(true);

        isReloading = true;
    }

    float GetRandomizedProjectileSpread()
    {
        return Random.Range(-WeaponStats.Spread, WeaponStats.Spread);
    }

    private void SetProjectileAttributes(GameObject firedProjectile)
    {
        float zAngle = firedProjectile.transform.rotation.eulerAngles.z * (Mathf.PI / 180f);
        float xComponent = Mathf.Cos(zAngle);
        float yComponent = Mathf.Sin(zAngle);
        Vector2 pivotDirection = new Vector2(xComponent, yComponent);

        firedProjectile.GetComponent<ProjectileStandard>().SetAttributes(gameObject, transform, WeaponStats, pivotDirection);
    }
}
