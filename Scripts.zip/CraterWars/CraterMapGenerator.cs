using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

public class CraterMapGenerator : MonoBehaviour
{
    [Header("Tile Map")]
    [SerializeField] Grid grid;
    [SerializeField] Tilemap groundTilemap;
    [SerializeField] Tilemap obstacleTilemap;
    [SerializeField] Tilemap pitTilemap;
    [SerializeField] Tilemap darkTilemap;
    [SerializeField] Tilemap dimTilemap;
    [SerializeField] Tile groundTile;
    [SerializeField] RuleTile obstacleTile;
    [SerializeField] Tile pitTile;
    [SerializeField] Tile darkTile;
    [SerializeField] Tile dimTile;

    [Header("Map")]
    [SerializeField] int mapWidth;
    [SerializeField] int mapHeight;

    [Header("Terrain")]
    [SerializeField] Range pitHeightRange;
    [SerializeField] Range groundHeightRange;
    [SerializeField] Range obstacleHeightRange;

    [Header("Noise")]
    [SerializeField] int seed;
    [SerializeField] float noiseScale;
    [SerializeField] int octaves;
    [SerializeField] [Range(0, 1)] float persistance;
    [SerializeField] float lacunarity;

    [Header("Editor")]
    public bool autoUpdate;

    float[,] heightMap;

    // terrain maps
    bool[,] groundMap;
    bool[,] pitMap;
    bool[,] obstacleMap;

    public bool[,] GroundMap { get => groundMap; }
    public bool[,] PitMap { get => pitMap; }
    public bool[,] ObstacleMap { get => obstacleMap; }
    public int MapWidth { get => mapWidth; set => mapWidth = value; }
    public int MapHeight { get => mapHeight; set => mapHeight = value; }

    public void GenerateMap()
    {
        // initialize maps
        heightMap = new float[MapWidth, MapHeight];
        groundMap = new bool[MapWidth, MapHeight];
        pitMap = new bool[MapWidth, MapHeight];
        obstacleMap = new bool[MapWidth, MapHeight];

        // seed random offsets
        Random.InitState(seed);
        float randomOffsetX = Random.value;
        float randomOffsetY = Random.value;

        heightMap = Noise.GenerateNoiseMap(MapWidth, MapHeight, noiseScale, octaves, persistance, lacunarity, randomOffsetX, randomOffsetY);

        // generate
        for (int y = 0; y < MapHeight; y++)
        {
            for (int x = 0; x < MapWidth; x++)
            {
                float height = heightMap[x, y];

                // fill dark and dim maps
                AddTile(darkTilemap, x, y, darkTile);
                AddTile(dimTilemap, x, y, dimTile);

                if (pitHeightRange.ValueInRange(height))
                {
                    AddTile(pitTilemap , x, y, pitTile);
                    pitMap[x, y] = true;
                }
                else if (groundHeightRange.ValueInRange(height))
                {
                    AddTile(groundTilemap, x, y, groundTile);
                    groundMap[x, y] = true;
                }
                else
                {
                    AddTile(obstacleTilemap, x, y, obstacleTile);
                    obstacleMap[x, y] = true;
                }
            }
        }
    }

    void AddTile(Tilemap tilemap, int x, int y, Tile tile)
    {
        tilemap.SetTile(new Vector3Int(x, y, 0), tile);
    }

    void AddTile(Tilemap tilemap, int x, int y, RuleTile tile)
    {
        tilemap.SetTile(new Vector3Int(x, y, 0), tile);
    }

    public void RandomizeSeed()
    {
        seed = Random.Range(int.MinValue, int.MaxValue);
    }
}
