using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CraterWarsResource : MonoBehaviour
{
    [SerializeField] CraterWarsResourceManager.Resource resource;
    [SerializeField] int resourceAmount;
    [SerializeField] GameObject harvestedObject;

    CraterWarsResourceManager resourceManager;

    private void Awake()
    {
        resourceManager = FindObjectOfType<CraterWarsResourceManager>();
    }

    // called by event
    public void HarvestResource()
    {
        // increase resources
        resourceManager.AddResourceToStock(resource, resourceAmount);

        // spawn ghost
        Instantiate(harvestedObject, transform.position, Quaternion.identity);

        // destroy
        Destroy(gameObject);
    }
}
