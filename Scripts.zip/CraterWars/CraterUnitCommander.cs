using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CraterUnitCommander
{
    private static CraterUnitCommander instance;
    public static CraterUnitCommander Instance
    {
        get
        {
            if (instance == null)
            {
                instance = new CraterUnitCommander();
            }

            return instance;
        }
        private set
        {
            instance = value;
        }
    }

    public List<CraterUnit> availableUnits = new List<CraterUnit>();
    public HashSet<CraterUnit> selectedUnits = new HashSet<CraterUnit>();

    // base
    public CraterWarsBase selectedBase;

    private CraterUnitCommander() {}

    public void Select(CraterUnit unit)
    {
        selectedUnits.Add(unit);
        unit.OnSelected();
    }

    public void Deselect(CraterUnit unit)
    {
        selectedUnits.Remove(unit);
        unit.OnDeselected();
    }

    public void DeselectAll()
    {
        foreach (CraterUnit unit in selectedUnits)
        {
            unit.OnDeselected();
        }

        selectedUnits.Clear();
    }

    public bool IsSelected(CraterUnit unit)
    {
        return selectedUnits.Contains(unit);
    }

    public void RemoveUnit(CraterUnit unit)
    {
        if (selectedUnits.Contains(unit))
        {
            selectedUnits.Remove(unit);
        }

        availableUnits.Remove(unit);
    }
}
