using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Cinemachine;
using Pathfinding;

public class CraterWarsInputHandler : MonoBehaviour
{
    [Header("Camera")]
    [SerializeField] CinemachineVirtualCamera virtualCamera;
    [SerializeField] float cameraSpeed;
    [SerializeField] float cameraZoomSpeed;
    [SerializeField] float maxZoom = 5;
    [SerializeField] float minZoom = 20;
    [SerializeField] float sensitivity = 1;
    float cameraZoom;

    [Header("Map Boundaries")]
    [SerializeField] float xMin;
    [SerializeField] float xMax;
    [SerializeField] float yMin;
    [SerializeField] float yMax;

    [Header("Selection Box")]
    [SerializeField] RectTransform selectionBox;
    [SerializeField] LayerMask unitLayers;
    [SerializeField] LayerMask floorLayers;
    [SerializeField] float dragDelay = 0.1f;

    [Header("Unit States")]
    [SerializeField] TravelState travelState;
    [SerializeField] AttackState attackState;

    [Header("Action Layers")]
    [SerializeField] LayerMask actionLayers;    // things that can be right clicked on
    const int enemyLayer = 17;

    [Header("Prefabs")]
    [SerializeField] GameObject waypointMarker;
    [SerializeField] GameObject invalidWaypointMarker;

    [Header("Crater Wars Components")]
    [SerializeField] CraterWarsUi guiComponent;

    private float mouseDownTime;    // for delaying the drag box from spawning if just performing a simple click
    Vector2 startMousePosition;

    private void Start()
    {
        cameraZoom = virtualCamera.m_Lens.OrthographicSize;
    }

    private void Update()
    {
        CameraPan();
        CameraZoom();
        HandleSelectionInputs();
        HandleActionInputs();
    }

    void CameraPan()
    {
        float xMovement = Input.GetAxisRaw("Horizontal") * cameraSpeed;
        float yMovement = Input.GetAxisRaw("Vertical") * cameraSpeed;

        // multiply by delta time so speed is not tied to frame rate.
        xMovement *= Time.deltaTime;
        yMovement *= Time.deltaTime;

        // move camera
        virtualCamera.transform.Translate(xMovement, yMovement, 0);

        // clamp movement to viewport
        Vector3 clampedPosition = virtualCamera.transform.position;
        clampedPosition.x = Mathf.Clamp(clampedPosition.x, xMin, xMax);
        clampedPosition.y = Mathf.Clamp(clampedPosition.y, yMin, yMax);
        virtualCamera.transform.position = clampedPosition;
    }

    void CameraZoom()
    {
        cameraZoom -= Input.mouseScrollDelta.y * sensitivity;
        cameraZoom = Mathf.Clamp(cameraZoom, maxZoom, minZoom);
        float newSize = Mathf.MoveTowards(virtualCamera.m_Lens.OrthographicSize, cameraZoom, cameraZoomSpeed * Time.deltaTime);
        virtualCamera.m_Lens.OrthographicSize = newSize;
    }

    void HandleActionInputs()
    {
        if (Input.GetMouseButtonUp(1) && CraterUnitCommander.Instance.selectedUnits.Count > 0)
        {
            RaycastHit2D hit = Physics2D.GetRayIntersection(Camera.main.ScreenPointToRay(Input.mousePosition), actionLayers);

            int rankWidth = Mathf.RoundToInt(Mathf.Sqrt(CraterUnitCommander.Instance.selectedUnits.Count)); // for forming up ranks at destination
            int currentUnit = 0;

            foreach (CraterUnit unit in CraterUnitCommander.Instance.selectedUnits)
            {
                if (hit)
                {
                    int rootLayer = hit.collider.transform.root.gameObject.layer;

                    // targeting something
                    switch (rootLayer)
                    {
                        case enemyLayer:
                            unit.GetComponent<BaseStateMachine>().ChangeState(attackState);
                            unit.GetComponent<LineOfSight>().Target = hit.collider.transform.root;
                            break;
                    }
                }
                else
                {
                    // calculate where in the rank this unit will look for a position
                    int xIncrease = currentUnit % rankWidth;
                    int yIncrease = currentUnit / rankWidth;

                    // get world point for unit destination
                    Vector3 destinationWorldPosition = new Vector3(Camera.main.ScreenToWorldPoint(Input.mousePosition).x + xIncrease, Camera.main.ScreenToWorldPoint(Input.mousePosition).y + yIncrease, 0);

                    // check viability
                    if (currentUnit == 0)
                    {
                        GraphNode start = AstarPath.active.GetNearest(unit.transform.position, NNConstraint.Default).node;
                        GraphNode target = AstarPath.active.GetNearest(destinationWorldPosition, NNConstraint.Default).node;

                        // cancel travel and instantiate invalid icon if no path possible
                        if (!PathUtilities.IsPathPossible(start, target))
                        {
                            GameObject invalidMarker = Instantiate(invalidWaypointMarker, destinationWorldPosition, Quaternion.identity);
                            Destroy(invalidMarker, 1f);
                            break;
                        }

                        // good target, instantiate a waypoint for the squad
                        Instantiate(waypointMarker, destinationWorldPosition, Quaternion.identity);
                    }

                    // find closest walkable node to world point that isn't already in the list of filled nodes
                    GraphNode node = AstarPath.active.GetNearest(destinationWorldPosition, NNConstraint.Default).node;

                    // change state and set destination
                    unit.GetComponent<BaseStateMachine>().ChangeState(travelState);
                    unit.GetComponent<CraterUnitMovement>().Destination = (Vector3)node.position;
                }

                currentUnit++;
            }
        }
    }

    void HandleSelectionInputs()
    {
        if (Input.GetMouseButtonDown(0))
        {
            // reset box and show
            selectionBox.sizeDelta = Vector2.zero;
            selectionBox.gameObject.SetActive(true);
            startMousePosition = Input.mousePosition;
            mouseDownTime = Time.time;
        }
        else if (Input.GetMouseButton(0) && mouseDownTime + dragDelay < Time.time)
        {
            // mouse held, increase size of box
            ResizeSelectionBox();
        }
        else if (Input.GetMouseButtonUp(0))
        {
            // mouse released, get rid of box
            selectionBox.sizeDelta = Vector2.zero;
            selectionBox.gameObject.SetActive(false);

            // cast ray from camera
            RaycastHit2D hit = Physics2D.GetRayIntersection(Camera.main.ScreenPointToRay(Input.mousePosition), unitLayers);

            // selecting a unit on click
            if (hit && hit.collider.transform.root.TryGetComponent(out CraterUnit unit))
            {
                // must be in the player faction
                if (unit.UnitFaction == CraterUnit.Faction.PlayerFaction)
                {
                    // add to selection if there are already units selected
                    if (Input.GetKey(KeyCode.LeftShift) || Input.GetKey(KeyCode.RightShift))
                    {
                        if (CraterUnitCommander.Instance.IsSelected(unit))
                        {
                            // deselect if already selected
                            CraterUnitCommander.Instance.Deselect(unit);
                        }
                        else
                        {
                            // select if not
                            CraterUnitCommander.Instance.Select(unit);
                        }
                    }
                    else
                    {
                        // only select this one unit
                        CraterUnitCommander.Instance.DeselectAll();
                        CraterUnitCommander.Instance.Select(unit);
                    }
                }
            }
            else if (hit && hit.collider.transform.root.TryGetComponent(out CraterWarsBase fob))
            {
                if (fob.Faction == CraterUnit.Faction.PlayerFaction)
                {
                    fob.ShowBaseGUI();
                }
            }
            else if (mouseDownTime + dragDelay > Time.time)
            {
                // clicked nothing
                CraterUnitCommander.Instance.DeselectAll();
                guiComponent.ClearGUI();
            }


            mouseDownTime = 0;
        }
    }

    void ResizeSelectionBox()
    {
        float width = Input.mousePosition.x - startMousePosition.x;
        float height = Input.mousePosition.y - startMousePosition.y;

        selectionBox.anchoredPosition = startMousePosition + new Vector2(width / 2, height / 2);
        selectionBox.sizeDelta = new Vector2(Mathf.Abs(width), Mathf.Abs(height));

        Bounds bounds = new Bounds(selectionBox.anchoredPosition, selectionBox.sizeDelta);

        for (int i = 0; i < CraterUnitCommander.Instance.availableUnits.Count; i++)
        {
            if (UnitIsInSelectionBox(Camera.main.WorldToScreenPoint(CraterUnitCommander.Instance.availableUnits[i].transform.position), bounds))
            {
                CraterUnitCommander.Instance.Select(CraterUnitCommander.Instance.availableUnits[i]);
            }
            else
            {
                CraterUnitCommander.Instance.Deselect(CraterUnitCommander.Instance.availableUnits[i]);
            }
        }
    }

    bool UnitIsInSelectionBox(Vector3 position, Bounds bounds)
    {
        return position.x > bounds.min.x && position.x < bounds.max.x 
            && position.y > bounds.min.y && position.y < bounds.max.y;
    }
}
