using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "FSM/States/Travel")]
public class TravelState : State
{
    public override void EnterState(BaseStateMachine stateMachine)
    {
        // movement
        stateMachine.GetComponent<CraterUnitMovement>().EnableMovement();

        // combat
        stateMachine.GetComponent<CraterUnitAttacking>().PermittedToEngage = true;
        stateMachine.GetComponent<CraterUnitAttacking>().CanSearchForNewTargets = true;
        stateMachine.GetComponent<CraterUnitSpriteFlip>().Behavior = CraterUnitSpriteFlip.FlipBehavior.Velocity;
    }

    public override void ExitState(BaseStateMachine stateMachine)
    {
        stateMachine.GetComponent<CraterUnitMovement>().DisableMovement();
    }
}
