using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "FSM/States/Attack")]
public class AttackState : State
{
    public override void EnterState(BaseStateMachine stateMachine)
    {
        stateMachine.GetComponent<CraterUnitAttacking>().PermittedToEngage = true;
        stateMachine.GetComponent<CraterUnitAttacking>().CanSearchForNewTargets = false;    // should only focus on a single targeted enemy
        stateMachine.GetComponent<CraterUnitAttacking>().StopSearchingForNearestEnemy();
        stateMachine.GetComponent<CraterUnitSpriteFlip>().Behavior = CraterUnitSpriteFlip.FlipBehavior.Orbiter;
    }

    public override void ExitState(BaseStateMachine stateMachine)
    {
        stateMachine.GetComponent<CraterUnitAttacking>().PermittedToEngage = true;
    }
}
