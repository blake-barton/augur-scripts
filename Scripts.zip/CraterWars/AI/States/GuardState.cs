using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "FSM/States/Guard")]
public class GuardState : State
{
    public override void EnterState(BaseStateMachine stateMachine)
    {
        stateMachine.GetComponent<CraterUnitAttacking>().PermittedToEngage = true;
        stateMachine.GetComponent<CraterUnitAttacking>().CanSearchForNewTargets = true;
        stateMachine.GetComponent<CraterUnitSpriteFlip>().Behavior = CraterUnitSpriteFlip.FlipBehavior.Orbiter;
    }

    public override void ExitState(BaseStateMachine stateMachine)
    {
    }
}
