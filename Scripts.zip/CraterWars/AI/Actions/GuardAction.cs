using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "FSM/Actions/Guard")]
public class GuardAction : FSMAction
{
    public override void UpdateAction(BaseStateMachine stateMachine)
    {
        // stand in place and fire on enemies
    }
}
