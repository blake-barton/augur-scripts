using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "FSM/Actions/Travel")]
public class TravelAction : FSMAction
{
    public override void UpdateAction(BaseStateMachine stateMachine)
    {

    }
}
