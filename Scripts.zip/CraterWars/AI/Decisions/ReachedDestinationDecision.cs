using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "FSM/Decisions/Reached Destination")]
public class ReachedDestinationDecision : Decision
{
    public override bool Decide(BaseStateMachine stateMachine)
    {
        // check if unit has reached destination
        return stateMachine.GetComponent<CraterUnitMovement>().ReachedDestination;
    }
}
