using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CraterAIUnitCommander : MonoBehaviour
{
    static HashSet<CraterUnit> craterUnits = new HashSet<CraterUnit>();

    public static HashSet<CraterUnit> CraterUnits { get => craterUnits; }

    public static bool AddUnit(CraterUnit unit)
    {
        return CraterUnits.Add(unit);
    }

    public static void RemoveUnit(CraterUnit unit)
    {
        CraterUnits.Remove(unit);
    }
}
