using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using TMPro;

public class CraterWarsUnitCardClickable : MonoBehaviour, IPointerClickHandler
{
    [SerializeField] GameObject unit;

    [Header("UI Elements")]
    [SerializeField] Image unitImage;
    [SerializeField] TextMeshProUGUI unitName;
    [SerializeField] TextMeshProUGUI unitHP;
    [SerializeField] TextMeshProUGUI unitDT;
    [SerializeField] TextMeshProUGUI unitSpeed;
    [SerializeField] TextMeshProUGUI unitDamage;
    [SerializeField] TextMeshProUGUI unitDPS;
    [SerializeField] TextMeshProUGUI unitReloadTime;
    [SerializeField] TextMeshProUGUI unitDescription;

    CraterWarsResourceManager resourceManager;

    void Awake()
    {
        if (unit)
        {
            resourceManager = FindObjectOfType<CraterWarsResourceManager>();

            CraterUnit craterUnit = unit.GetComponent<CraterUnit>();

            unitImage.sprite = craterUnit.DeselectedSprite;
            unitName.text = unit.name;
            unitHP.text = unit.GetComponent<Health>().MaxHealth.ToString();
            unitDT.text = unit.GetComponent<DamageThresholds>().PiercingDT.GetCurrentValue().ToString();
            unitSpeed.text = unit.GetComponent<CraterUnitMovement>().Speed.ToString();

            RangedWeapon unitWeaponStats = unit.GetComponent<CraterUnitAttacking>().WeaponStats;
            unitDamage.text = unitWeaponStats.GetTotalDamage().ToString();
            unitDPS.text = unitWeaponStats.TotalDamagePerSecond.ToString();
            unitReloadTime.text = unitWeaponStats.ReloadTime.ToString();

            unitDescription.text = craterUnit.Description;
        }
    }

    public void OnPointerClick(PointerEventData eventData)
    {
        // queue unit for construction if possible
        if (unit)
        {
            // space in ranks
            if (!resourceManager.IsUnitCountFull())
            {
                CraterUnitCommander.Instance.selectedBase.QueueUnitForConstruction(unit);
            }
        }
    }
}
