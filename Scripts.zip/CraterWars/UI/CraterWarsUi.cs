using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class CraterWarsUi : MonoBehaviour
{
    [SerializeField] TextMeshProUGUI currentUnitsTextMesh;
    [SerializeField] GameObject unitCards;

    [Header("State")]
    [SerializeField] bool showingUnitCards = false;

    Animator unitCardsAnimator;

    private void Awake()
    {
        unitCardsAnimator = unitCards.GetComponent<Animator>();
    }

    public void SetCurrentUnitsText(int currentUnits, int maxUnits)
    {
        currentUnitsTextMesh.text = currentUnits.ToString() + "/" + maxUnits.ToString();
    }

    public void ShowUnitCards()
    {
        if (!showingUnitCards)
        {
            showingUnitCards = true;
            unitCardsAnimator.SetTrigger("AnimRise");
        }
    }

    public void HideUnitCards()
    {
        if (showingUnitCards)
        {
            showingUnitCards = false;
            unitCardsAnimator.SetTrigger("AnimFall");
        }
    }

    // Get everything off the screen
    public void ClearGUI()
    {
        if (showingUnitCards)
            HideUnitCards();
    }
}
