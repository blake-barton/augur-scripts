using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CraterUnitSpriteFlip : MonoBehaviour
{
    [SerializeField] Orbiter orbiter;
    [SerializeField] SpriteRenderer spriteRenderer;
    [SerializeField] CraterUnitMovement unitMovement;
    [SerializeField] float minFlipThreshold = 90f;
    [SerializeField] float maxFlipThreshold = 270f;
    
    public enum FlipBehavior
    {
        Orbiter,
        Velocity
    }
    [SerializeField] FlipBehavior behavior;

    Transform orbiterPivot;

    public FlipBehavior Behavior { get => behavior; set => behavior = value; }

    // Start is called before the first frame update
    void Start()
    {
        orbiterPivot = orbiter.transform.parent;
    }

    // Update is called once per frame
    void Update()
    {
        switch (Behavior)
        {
            case FlipBehavior.Orbiter:
                FlipSpriteUsingOrbiter();
                break;
            case FlipBehavior.Velocity:
                FlipSpriteUsingWaypoint();
                break;
            default:
                break;
        }
    }

    void FlipSpriteUsingOrbiter()
    {
        if (orbiterPivot.localEulerAngles.z > minFlipThreshold && orbiterPivot.localEulerAngles.z < maxFlipThreshold && !spriteRenderer.flipX)
        {
            spriteRenderer.flipX = true;
        }
        else if (orbiterPivot.localEulerAngles.z <= minFlipThreshold && orbiterPivot.localEulerAngles.z >= maxFlipThreshold && spriteRenderer.flipX)
        {
            spriteRenderer.flipX = false;
        }
    }

    void FlipSpriteUsingWaypoint()
    {
        float destinationDifference = transform.position.x - unitMovement.Destination.x;

        if (destinationDifference > 0 && !spriteRenderer.flipX)
        {
            spriteRenderer.flipX = true;
        }
        else if (destinationDifference <= 0 && spriteRenderer.flipX)
        {
            spriteRenderer.flipX = false;
        }
    }
}
