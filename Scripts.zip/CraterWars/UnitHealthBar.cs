using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UnitHealthBar : MonoBehaviour
{
    [Header("Properties")]
    [SerializeField] float backgroundWidth;
    [SerializeField] float backgroundHeight = 5f;

    [Header("Positioning")]
    [SerializeField] Vector2 positionOffset = new Vector2();

    [Header("Bars")]
    [SerializeField] RectTransform handleSlideArea;
    [SerializeField] RectTransform background;
    [SerializeField] Image fill;

    [Header("Colors")]
    [SerializeField] Color fullHealthColor;
    [SerializeField] Color damagedColor;
    [SerializeField] Color severeDamageColor;

    [Header("Cached References")]
    [SerializeField] RectTransform sliderTransform;
    [SerializeField] Slider slider;

    Transform owner;

    // Start is called before the first frame update
    void Start()
    {
        FormatBar();
    }

    // Update is called once per frame
    void Update()
    {
        LockToOwner();
    }

    // handles the size of the background and slider
    public void FormatBar()
    {
        // size background
        background.sizeDelta = new Vector2(backgroundWidth, backgroundHeight);

        // size slider
        sliderTransform.sizeDelta = new Vector2(backgroundWidth, backgroundHeight * 2);
    }

    private void LockToOwner()
    {
        // lock position to player if player exists
        if (owner)
        {
            transform.position = Camera.main.WorldToScreenPoint((Vector2)owner.transform.position + positionOffset);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    public void SetParameters(Transform _owner, float maxHealth, float currentHealth)
    {
        owner = _owner;

        // set slider values based on health
        slider.minValue = 0f;
        slider.maxValue = maxHealth;

        slider.value = currentHealth;
    }

    public void SetFullHealthColor()
    {
        fill.color = fullHealthColor;
    }

    public void SetDamagedColor()
    {
        fill.color = damagedColor;
    }
    public void SetSeverelyDamagedColor()
    {
        fill.color = severeDamageColor;
    }
}
