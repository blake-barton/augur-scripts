using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pathfinding;

public class CraterUnitMovement : MonoBehaviour
{
    [Header("Movement")]
    [SerializeField] Rigidbody2D rb;
    [SerializeField] float speed = 5f;

    [Header("Pathfinding")]
    [SerializeField] Seeker seeker;
    [SerializeField] float nextWaypointDistance = 3f;     // how close the enemy gets to the waypoint before going to the next one
    [SerializeField] float minReachedDestinationDistance = 0.1f;

    [Header("State")]
    [SerializeField] bool movementEnabled = false;
    [SerializeField] bool reachedDestination = false;

    [Header("Animation")]
    [SerializeField] Animator animator;

    // pathfinding
    Path path;
    int currentWaypoint = 0;
    bool reachedEndOfPath;
    Vector2 destination;
    Vector2 moveDirection;

    public Vector2 Destination { get => destination; set => destination = value; }
    public bool ReachedDestination { get => reachedDestination; set => reachedDestination = value; }
    public float Speed { get => speed; set => speed = value; }

    // Start is called before the first frame update
    public void EnableMovement()
    {
        InvokeRepeating(nameof(UpdatePath), 0f, .5f);
        movementEnabled = true;
        rb.bodyType = RigidbodyType2D.Dynamic;

        if (animator)
        {
            animator.enabled = true;
        }

        reachedDestination = false;
    }

    public void DisableMovement()
    {
        CancelInvoke();
        movementEnabled = false;
        if (animator)
        {
            animator.enabled = false;
        }

        rb.velocity = Vector2.zero;
        rb.bodyType = RigidbodyType2D.Kinematic;
    }

    void UpdatePath()
    {
        if (seeker.IsDone())
        {
            seeker.StartPath(rb.position, Destination, OnPathComplete);
        }
    }

    void OnPathComplete(Path p)
    {
        // get new path if no errors raised
        if (!p.error)
        {
            path = p;
            currentWaypoint = 0;
        }
    }

    private void FixedUpdate()
    {
        // if not dead and movement enabled
        if (movementEnabled)
        {
            Move();
        }
    }

    private void Move()
    {
        if (path == null)
            return;

        if (currentWaypoint >= path.vectorPath.Count)
        {
            // end of path reached
            reachedEndOfPath = true;
            return;
        }
        else
        {
            reachedEndOfPath = false;
        }

        // get direction to next waypoint
        moveDirection = ((Vector2)path.vectorPath[currentWaypoint] - rb.position).normalized;

        // move
        rb.velocity = new Vector2(moveDirection.x * Speed, moveDirection.y * Speed);

        // get distance to next waypoint
        float distance = Vector2.Distance(rb.position, path.vectorPath[currentWaypoint]);

        // check if we've reached the destination
        float distanceToDestination = Vector2.Distance(transform.position, Destination);
        if (distanceToDestination <= minReachedDestinationDistance)
        {
            ReachedDestination = true;
        }
        else
        {
            ReachedDestination = false;
        }

        if (distance < nextWaypointDistance)
        {
            currentWaypoint++;
        }
    }
}
