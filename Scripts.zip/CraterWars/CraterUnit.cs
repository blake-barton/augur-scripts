using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CraterUnit : MonoBehaviour
{
    [SerializeField] Faction faction;
    [SerializeField] float sightRange = 8f;

    [TextArea(5, 10)]
    [SerializeField] string description = "";

    [Header("Sprite")]
    [SerializeField] Sprite deselectedSprite;
    [SerializeField] Sprite selectedSprite;
    [SerializeField] SpriteRenderer spriteRenderer;

    [Header("Death")]
    [SerializeField] List<GameObject> ghostObjects;

    CraterWarsResourceManager resourceManager;

    public Faction UnitFaction { get => faction; set => faction = value; }
    public float SightRange { get => sightRange; set => sightRange = value; }
    public string Description { get => description; set => description = value; }
    public Sprite DeselectedSprite { get => deselectedSprite; set => deselectedSprite = value; }

    public enum Faction
    {
        PlayerFaction,
        Crater
    }

    private void Awake()
    {
        if (faction == Faction.PlayerFaction)
        {
            CraterUnitCommander.Instance.availableUnits.Add(this);
        }
        else
        {
            CraterAIUnitCommander.AddUnit(this);
        }

        resourceManager = FindObjectOfType<CraterWarsResourceManager>();
    }

    public void OnSelected()
    {
        spriteRenderer.sprite = selectedSprite;
    }

    public void OnDeselected()
    {
        spriteRenderer.sprite = DeselectedSprite;
    }

    // called via event
    public void Die()
    {
        // instantiate a random ghost
        Instantiate(ghostObjects[Random.Range(0, ghostObjects.Count)], transform.position, Quaternion.identity);

        // remove self from unit commander
        if (faction == Faction.PlayerFaction)
        {
            CraterUnitCommander.Instance.RemoveUnit(this);
            resourceManager.RemoveUnitFromCount();
        }
        else
        {
            CraterAIUnitCommander.RemoveUnit(this);
        }

        Destroy(gameObject);
    }
}
