using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CraterWarsResourceManager : MonoBehaviour
{
    [Header("Units")]
    [SerializeField] int unitCount = 0;
    [SerializeField] int maxUnits = 10;

    [Header("Resource Counts")]
    [SerializeField] int celestiumCount = 0;

    [Header("Resource Maximums")]
    [SerializeField] int maxCelestium = 999;

    [Header("Components")]
    [SerializeField] CraterWarsUi guiComponenent;

    public enum Resource
    {
        Celestium
    }

    private void Start()
    {
        guiComponenent.SetCurrentUnitsText(unitCount, maxUnits);
    }

    public void AddResourceToStock(Resource resource, int count)
    {
        switch (resource)
        {
            case Resource.Celestium:
                celestiumCount += count;
                break;
            default:
                break;
        }
    }

    public void AddUnitToCount()
    {
        if (unitCount + 1 <= maxUnits)
        {
            unitCount++;
        }

        guiComponenent.SetCurrentUnitsText(unitCount, maxUnits);
    }

    public void RemoveUnitFromCount()
    {
        if (unitCount - 1 >= 0)
        {
            unitCount--;
        }

        guiComponenent.SetCurrentUnitsText(unitCount, maxUnits);
    }

    public bool IsUnitCountFull()
    {
        return unitCount == maxUnits;
    }
}
