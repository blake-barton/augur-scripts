using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CraterWarsBase : MonoBehaviour
{
    [SerializeField] CraterUnit.Faction faction;
    [SerializeField] bool constructingUnits = false;
    [SerializeField] float unitConstructionTime = 5f;
    [SerializeField] Vector2 unitSpawnOffset = new Vector2();

    [Header("Visuals")]
    [SerializeField] GameObject unitConstructionWidget;
    [SerializeField] GameObject explosionPrefab;

    // cached components
    CraterWarsUi guiComponent;
    CraterWarsResourceManager resourceManager;

    // Queue for units to be constructed
    Queue<GameObject> unitConstructionQueue = new Queue<GameObject>();

    public CraterUnit.Faction Faction { get => faction; set => faction = value; }

    private void Awake()
    {
        guiComponent = FindObjectOfType<CraterWarsUi>();
        resourceManager = FindObjectOfType<CraterWarsResourceManager>();
    }

    public void QueueUnitForConstruction(GameObject unitObject)
    {
        // increase unit count
        resourceManager.AddUnitToCount();

        // add unit to queue
        unitConstructionQueue.Enqueue(unitObject);

        // start constructing units if not already
        if (!constructingUnits)
        {
            StartCoroutine(ConstructUnits());
        }
    }

    // construct all of the units currently in the queue
    IEnumerator ConstructUnits()
    {
        constructingUnits = true;
        
        // vfx
        if (unitConstructionWidget)
        {
            unitConstructionWidget.SetActive(true);
        }

        while (unitConstructionQueue.Count > 0)
        {
            // wait for this unit to be built
            yield return new WaitForSeconds(unitConstructionTime);

            // instantiate unit
            Instantiate(unitConstructionQueue.Dequeue(), (Vector2)transform.position + unitSpawnOffset, Quaternion.identity);
        }

        constructingUnits = false;

        // vfx
        if (unitConstructionWidget)
        {
            unitConstructionWidget.SetActive(false);
        }
    }

    public void Explode()
    {
        // Instantiate explosion prefab
        Instantiate(explosionPrefab, transform.position, Quaternion.identity);

        // Remove from list of structures

        // Destroy
        Destroy(gameObject);
    }

    public void ShowBaseGUI()
    {
        // set this base as selected
        CraterUnitCommander.Instance.selectedBase = this;

        // show cards
        guiComponent.ShowUnitCards();
    }
}
