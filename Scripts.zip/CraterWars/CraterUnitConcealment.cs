using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CraterUnitConcealment : MonoBehaviour
{
    [SerializeField] SpriteRenderer spriteRenderer;
    [SerializeField] Health health;

    [Header("State")]
    [SerializeField] bool isHidden = true;

    // Start is called before the first frame update
    void Start()
    {
        HideSelf();

        InvokeRepeating(nameof(RevealIfInEnemyUnitSightRange), 0f, 1f);
    }

    void RevealIfInEnemyUnitSightRange()
    {
        foreach (CraterUnit unit in CraterUnitCommander.Instance.availableUnits)
        {
            if (Vector2.Distance(transform.position, unit.transform.position) <= unit.SightRange)
            {
                // reveal self
                if (isHidden)
                {
                    RevealSelf();
                }

                // no need to keep searching
                break;
            }
            else
            {
                // hide self
                if (!isHidden)
                {
                    HideSelf();
                }
            }
        }
    }

    void RevealSelf()
    {
        isHidden = false;

        spriteRenderer.enabled = true;
        health.ShowHealthBar();
    }

    void HideSelf()
    {
        isHidden = true;

        spriteRenderer.enabled = false;
        health.HideHealthBar();
    }
}
