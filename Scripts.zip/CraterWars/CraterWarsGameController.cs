using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Cinemachine;

public class CraterWarsGameController : MonoBehaviour
{
    [SerializeField] GameObject forwardOperatingBase;
    [SerializeField] CraterMapGenerator mapGenerator;
    [SerializeField] Grid grid;
    [SerializeField] CinemachineVirtualCamera virtualCamera;

    private void Start()
    {
        mapGenerator.GenerateMap();

        List<Vector3Int> groundTiles = new List<Vector3Int>();

        // get a list of ground tiles
        for (int y = 0; y < mapGenerator.MapHeight; y++)
        {
            for (int x = 0; x < mapGenerator.MapWidth; x++)
            {
                if (mapGenerator.GroundMap[x, y])
                {
                    groundTiles.Add(new Vector3Int(x, y, 0));
                }
            }
        }

        // get random starting ground tile
        Vector3 worldCoordinateStart = grid.GetCellCenterWorld(groundTiles[Random.Range(0, groundTiles.Count)]);

        // spawn the first base at a random ground tile
        GameObject instantiatedBase = Instantiate(forwardOperatingBase, worldCoordinateStart, Quaternion.identity);

        // move camera to base
        virtualCamera.transform.position = new Vector3(instantiatedBase.transform.position.x, instantiatedBase.transform.position.y, virtualCamera.transform.position.z);

        // Recalculate all graphs
        AstarPath.active.Scan();
    }
}
