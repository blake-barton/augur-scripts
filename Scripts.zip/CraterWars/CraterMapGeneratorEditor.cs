using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class CraterMapGeneratorEditor
{
    //public override void OnInspectorGUI()
    //{
    //    CraterMapGenerator mapGenerator = (CraterMapGenerator)target;

    //    if (DrawDefaultInspector())
    //    {
    //        if (mapGenerator.autoUpdate)
    //        {
    //            mapGenerator.GenerateMap();
    //        }
    //    }

    //    if (GUILayout.Button("Generate"))
    //    {
    //        mapGenerator.GenerateMap();
    //    }

    //    if (GUILayout.Button("Randomize Seed"))
    //    {
    //        mapGenerator.RandomizeSeed();
    //    }
    //}
}
