using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class TradingPanel : MonoBehaviour
{
    public int currentCategory = -1;

    [Header("Grid")]
    [SerializeField] GameObject itemSlotTemplate;
    [SerializeField] GameObject itemGrid;

    [Header("Text")]
    [SerializeField] TextMeshProUGUI categoryTitleText;
    [SerializeField] TextMeshProUGUI itemNameTitleText;

    // cached references
    public List<Pair<Item, int>> itemList;

    public enum InventoryOwner
    {
        PLAYER,
        NPC
    }
    public InventoryOwner owner;

    // Start is called before the first frame update
    void Start()
    {
        LoadPlayerInventoryIntoGrid();        // -1 starts with all items displayed
        categoryTitleText.text = "All Items";
        itemNameTitleText.text = "";
    }

    void LoadPlayerInventoryIntoGrid()
    {
        foreach (Pair<Item, int> pair in itemList)
        {
            // insert the slot into the grid
            GameObject newSlot = Instantiate(itemSlotTemplate, itemGrid.transform);

            // fill the slot with data
            FillItemSlotTemplate(newSlot, pair);
        }

        // choose which category to start with
        if (currentCategory > -1)
        {
            ToggleInventoryCategory(currentCategory);
        }
        else
        {
            ShowAllInventoryCategories();
        }
    }

    void FillItemSlotTemplate(GameObject newSlot, Pair<Item, int> pair)
    {
        InventoryClickable clickable = newSlot.GetComponent<InventoryClickable>();
        Image itemImage = newSlot.transform.GetChild(0).GetComponent<Image>();

        clickable.ItemPair = pair;

        clickable.owner = owner;

        clickable.SlotType = InventoryClickable.ClickableType.TRADING_SLOT;

        clickable.itemType = pair.First.Type;
        clickable.itemName = pair.First.ItemName;
        clickable.ItemCount = pair.Second;
        clickable.UpdateCountPanelText();
        itemImage.sprite = pair.First.Sprite;

        // equip panels
        clickable.EquippedMain = pair.First.EquippedMain;
        clickable.EquippedOff = pair.First.EquippedOff;
        clickable.ItemEquipped = pair.First.Equipped;
        clickable.MarkedForTrade = pair.First.MarkedForTrade;
        clickable.NumberMarkedForTrade = pair.First.NumberMarkedForTrade;
        clickable.UpdateEquipPanels();
    }

    // Disable all item panels that are not of the given type
    // NOTE: BECAUSE ENUMS ARE NOT SUPPORTED THIS IS PASSED AN INTEGER ARGUMENT, MEANING THAT IF THE ENUM IN Item.cs IS EVER CHANGED THE BUTTONS WILL NEED TO BE CHANGED
    public void ToggleInventoryCategory(int type)
    {
        foreach (RectTransform child in itemGrid.transform)
        {
            if ((int)child.gameObject.GetComponent<InventoryClickable>().itemType != type)
            {
                child.gameObject.SetActive(false);
            }
            else
            {
                child.gameObject.SetActive(true);
            }
        }

        switch (type)
        {
            case (int)Item.ItemType.RANGEDWEAPON:
                categoryTitleText.text = "Ranged Weapons";
                break;
            case (int)Item.ItemType.MELEEWEAPON:
                categoryTitleText.text = "Melee Weapons";
                break;
            case (int)Item.ItemType.OUTFIT:
                categoryTitleText.text = "Outfits";
                break;
            case (int)Item.ItemType.AID:
                categoryTitleText.text = "Aid";
                break;
            case (int)Item.ItemType.MISC:
                categoryTitleText.text = "Miscellaneous";
                break;
            case (int)Item.ItemType.AMMO:
                categoryTitleText.text = "Ammunition";
                break;
            case (int)Item.ItemType.AUGMENTATION:
                categoryTitleText.text = "Augmentations";
                break;
            case (int)Item.ItemType.FOCUSIMPLANT:
                categoryTitleText.text = "Focus Implants";
                break;
        }

        SetItemNameTitleText("");
        currentCategory = type;
    }

    public void ShowAllInventoryCategories()
    {
        foreach (RectTransform child in itemGrid.transform)
        {
            child.gameObject.SetActive(true);
        }

        categoryTitleText.text = "All Items";
        currentCategory = -1;
    }

    public void SetItemNameTitleText(string itemName)
    {
        itemNameTitleText.text = itemName;
    }

    public void DestroySlotAtIndex(int slotIndex)
    {
        Destroy(itemGrid.transform.GetChild(slotIndex).gameObject);
    }

    public void UpdateSlotCountAtIndex(int slotIndex, int quantity)
    {
        InventoryClickable clickable = itemGrid.transform.GetChild(slotIndex).GetComponent<InventoryClickable>();
        clickable.ItemCount -= quantity;
        clickable.UpdateCountPanelText();
    }

    public void ReloadGrid()
    {
        foreach (RectTransform child in itemGrid.transform)
        {
            Destroy(child.gameObject);
        }

        LoadPlayerInventoryIntoGrid();
    }
}
