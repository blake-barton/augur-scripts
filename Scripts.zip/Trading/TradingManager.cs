using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class TradingManager : MonoBehaviour
{
    [Header("Objects")]
    [SerializeField] GameObject tradingMenu;
    [SerializeField] DialogueManager dialogueManager;

    [Header("Panels")]
    [SerializeField] GameObject tradingPanel;

    [Header("Info Panels")]
    [SerializeField] GameObject testItemPanel;
    [SerializeField] GameObject spellInfoPanel;
    [SerializeField] GameObject rangedWeaponPanel;
    [SerializeField] GameObject meleeWeaponPanel;
    [SerializeField] GameObject outfitPanel;
    [SerializeField] GameObject ammoPanel;
    [SerializeField] GameObject itemPanel;
    [SerializeField] GameObject descriptionPanel;

    [Header("Areas")]
    [SerializeField] Transform panelsArea;

    [Header("Grids")]
    [SerializeField] Transform panelsGrid;

    [Header("Popups")]
    [SerializeField] GameObject selectXAmountPanel;
    [SerializeField] GameObject completeTradingPanel;
    [SerializeField] GameObject endTradingPanel;
    [SerializeField] GameObject statusMessageTemplate;

    [Header("NPC Inventory")]
    public NPCInventory npcInventory;
    public Crypto npcCrypto;

    [Header("Crypto Displays")]
    [SerializeField] TextMeshProUGUI playerCryptoText;
    [SerializeField] TextMeshProUGUI npcCryptoText;
    [SerializeField] TextMeshProUGUI currentValueText;

    [Header("Cost Display")]
    [SerializeField] int cost = 0;
    [SerializeField] TextMeshProUGUI costText;
    [SerializeField] GameObject leftArrow;
    [SerializeField] GameObject rightArrow;

    [Header("State")]
    [SerializeField] bool isTrading = false;
    [SerializeField] bool descriptionMode = false;
    public int playerCategory = -1;
    public int npcCategory = -1;

    GameObject spawnedCompleteTradingPanel;
    GameObject spawnedEndTradingPanel;

    Player player;
    Inventory playerInventory;
    Crypto playerCrypto;
    AttributeScores playerAttributes;
    TradingPanel playerTrading;
    TradingPanel npcTrading;

    public bool IsTrading { get => isTrading; set => isTrading = value; }

    private void Awake()
    {
        player = FindObjectOfType<Player>();
        playerInventory = player.GetComponent<Inventory>();
        playerCrypto = player.GetComponent<Crypto>();
        playerAttributes = player.GetComponent<AttributeScores>();

        costText.text = "0g";
        leftArrow.SetActive(false);
        rightArrow.SetActive(false);
    }

    private void Start()
    {
        tradingMenu.SetActive(false);
    }

    private void Update()
    {
        OpenCompleteTransactionPanel();
        OpenEndTradingPanel();
    }

    public void ShowTradingMenu()
    {
        IsTrading = true;

        dialogueManager.HideDialogue();
        tradingMenu.SetActive(true);

        // instantiate the trading panel for the player
        GameObject playerInventoryPanel = Instantiate(tradingPanel, panelsGrid);
        playerTrading = playerInventoryPanel.GetComponent<TradingPanel>();
        playerTrading.currentCategory = playerCategory;
        playerTrading.itemList = playerInventory.Items;
        playerTrading.owner = TradingPanel.InventoryOwner.PLAYER;

        // instantiate an empty info panel
        Instantiate(testItemPanel, panelsGrid);

        // instantiate the trading panel for the NPC
        GameObject npcInventoryPanel = Instantiate(tradingPanel, panelsGrid);
        npcTrading = npcInventoryPanel.GetComponent<TradingPanel>();
        npcTrading.currentCategory = npcCategory;
        npcTrading.itemList = npcInventory.itemPairs;
        npcTrading.owner = TradingPanel.InventoryOwner.NPC;

        SetTraderCryptoValues();
        SortNPCListByNameAscending();
    }

    private void DestroyPanels()
    {
        foreach (RectTransform child in panelsGrid.transform)
        {
            Destroy(child.gameObject);
        }
    }

    private void ReloadTradingMenu()
    {
        // store categories
        playerCategory = playerTrading.currentCategory;
        npcCategory = npcTrading.currentCategory;

        DestroyPanels();

        // instantiate the trading panel for the player
        GameObject playerInventoryPanel = Instantiate(tradingPanel, panelsGrid);
        playerTrading = playerInventoryPanel.GetComponent<TradingPanel>();
        playerTrading = playerInventoryPanel.GetComponent<TradingPanel>();
        playerTrading.itemList = playerInventory.Items;
        playerTrading.owner = TradingPanel.InventoryOwner.PLAYER;

        // instantiate an empty info panel
        Instantiate(testItemPanel, panelsGrid);

        // instantiate the trading panel for the NPC
        GameObject npcInventoryPanel = Instantiate(tradingPanel, panelsGrid);
        npcTrading = npcInventoryPanel.GetComponent<TradingPanel>();
        npcTrading.currentCategory = npcCategory;
        npcTrading.itemList = npcInventory.itemPairs;
        npcTrading.owner = TradingPanel.InventoryOwner.NPC;
    }

    public void LoadItemInfoPanel(Pair<Item, int> itemPair)
    {
        if (descriptionMode)
        {
            var panel = Instantiate(descriptionPanel, panelsGrid);
            panel.transform.SetSiblingIndex(1);

            panel.GetComponent<DescriptionPanel>().SetItemPanelText(itemPair.First);
        }
        else
        {
            switch (itemPair.First.Type)
            {
                case Item.ItemType.RANGEDWEAPON:
                    // load ranged weapon panel
                    var rangedInfoPanel = Instantiate(rangedWeaponPanel, panelsGrid);
                    rangedInfoPanel.transform.SetSiblingIndex(1);

                    // load data into panel
                    rangedInfoPanel.GetComponent<RangedWeaponPanel>().SetPanelText(itemPair.First);

                    break;
                case Item.ItemType.MELEEWEAPON:
                    // load melee weapon panel
                    var meleeInfoPanel = Instantiate(meleeWeaponPanel, panelsGrid);
                    meleeInfoPanel.transform.SetSiblingIndex(1);

                    // load data into panel
                    meleeInfoPanel.GetComponent<MeleeWeaponPanel>().SetPanelText(itemPair.First);
                    break;
                case Item.ItemType.OUTFIT:
                    // load outfit panel
                    var outfitInfoPanel = Instantiate(outfitPanel, panelsGrid);
                    outfitInfoPanel.transform.SetSiblingIndex(1);

                    // load data into panel
                    outfitInfoPanel.GetComponent<OutfitPanel>().SetPanelInfo(itemPair.First);
                    break;
                case Item.ItemType.AMMO:
                    var ammoInfoPanel = Instantiate(ammoPanel, panelsGrid);
                    ammoInfoPanel.transform.SetSiblingIndex(1);

                    // load data into panel
                    ammoInfoPanel.GetComponent<AmmoPanel>().SetPanelText(itemPair.First, itemPair.Second);
                    break;
                default:
                    // load item panel
                    var itemInfoPanel = Instantiate(itemPanel, panelsGrid);
                    itemInfoPanel.transform.SetSiblingIndex(1);

                    // load data into panel
                    itemInfoPanel.GetComponent<MiscPanel>().SetPanelText(itemPair.First, itemPair.Second);
                    break;
            }
        }
    }

    public void ReloadInfoPanel(Pair<Item, int> itemPair)
    {
        // clear current item info
        DestroyInfoPanel();

        // load an info panel with this item's data
        LoadItemInfoPanel(itemPair);
    }

    public void DestroyInfoPanel()
    {
        // The info panel will always be the second child
        if (panelsGrid.transform.childCount >= 3)
        {
            Destroy(panelsGrid.transform.GetChild(1).gameObject);
        }
    }

    public void ToggleDescriptionPanel(Pair<Item, int> itemPair)
    {
        DestroyInfoPanel();

        if (descriptionMode)
        {
            // showing description. Delete description panel and spawn info panel
            descriptionMode = false;
            LoadItemInfoPanel(itemPair);
        }
        else
        {
            // Not showing description. Set description mode and spawn description panel.
            descriptionMode = true;
            LoadItemInfoPanel(itemPair);
        }
    }

    // returns true if item slot is deleted
    public void MoveItem(TradingPanel.InventoryOwner owner, Pair<Item, int> itemPair, int quantity)
    {
        Pair<Item, int> newPair = new Pair<Item, int>(Instantiate(itemPair.First), quantity);
        newPair.First.MarkedForTrade = false;
        newPair.First.NumberMarkedForTrade = 0;

        // move the item to the other inventory
        if (owner == TradingPanel.InventoryOwner.PLAYER)
        {
            // sell
            playerInventory.RemoveItem(itemPair, quantity);
            AddNPCItem(newPair.First, newPair.Second);
        }
        else
        {
            // buy -- add to player inventory
            RemoveNPCItem(itemPair, quantity);
            playerInventory.AddItem(newPair.First, newPair.Second);
        }
    }

    public void AdjustTransactionCost(TradingPanel.InventoryOwner owner, Pair<Item, int> itemPair, int quantity)
    {
        /* NEGATIVE COST = PLAYER GETTING MONEY | POSITIVE = NPC GETS MONEY */

        int tradeValue;

        // adjust current cost of transaction by value of item * quantity
        if (owner == TradingPanel.InventoryOwner.PLAYER)
        {
            tradeValue = (int)Mathf.Round(itemPair.First.Value * playerAttributes.sellMultiplier);

            // sell
            cost -= tradeValue * quantity;
        }
        else
        {
            tradeValue = (int)Mathf.Round(itemPair.First.Value * playerAttributes.buyMultiplier);

            // buy
            cost += tradeValue * quantity;
        }

        DisplayCostArrowsAndTransactionCost();
    }

    private void SetTraderCryptoValues()
    {
        playerCryptoText.text = playerCrypto.CurrentCurrency.ToString() + "g";
        npcCryptoText.text = npcCrypto.CurrentCurrency.ToString() + "g";
        currentValueText.text = "";
    }

    public void SetCurrentCryptoValue(int val, TradingPanel.InventoryOwner owner)
    {
        if (owner == TradingPanel.InventoryOwner.PLAYER)
        {
            // sale
            currentValueText.text = Mathf.Round(val * playerAttributes.sellMultiplier).ToString() + "g";
        }
        else
        {
            // buy
            currentValueText.text = Mathf.Round(val * playerAttributes.buyMultiplier).ToString() + "g";
        }
    }

    private void DisplayCostArrowsAndTransactionCost()
    {
        if (cost < 0)
        {
            // player get money
            rightArrow.SetActive(false);
            leftArrow.SetActive(true);
        }
        else if (cost > 0)
        {
            // npc get money
            rightArrow.SetActive(true);
            leftArrow.SetActive(false);
        }
        else
        {
            rightArrow.SetActive(false);
            leftArrow.SetActive(false);
        }

        costText.text = Mathf.Abs(cost).ToString() + "g";
    }

    public void LoadTestInfoPanel()
    {
        var testPanel = Instantiate(testItemPanel, panelsGrid);                 // eventually want this to depend on the first item in the inventory
        testPanel.transform.SetSiblingIndex(1);
    }

    public void LoadSelectXPopup(TradingPanel.InventoryOwner owner, TradingManager tradingManager, Inventory playerInventory, InventoryClickable clickable, Pair<Item, int> itemPair)
    {
        var selectX = Instantiate(selectXAmountPanel, panelsArea);
        selectX.GetComponent<SelectXPanel>().SetSliderLimits(0, itemPair.Second);
        var selectXTradeBehavior = selectX.GetComponent<SelectXTradeBehavior>();
        selectXTradeBehavior.owner = owner;
        selectXTradeBehavior.tradingManager = tradingManager;
        selectXTradeBehavior.playerInventory = playerInventory;
        selectXTradeBehavior.clickable = clickable;
        selectXTradeBehavior.itemPair = itemPair;
    }

    public void SetPlayerPanelItemTitle(string title)
    {
        playerTrading.SetItemNameTitleText(title);
    }

    public void SetNPCPanelItemTitle(string title)
    {
        npcTrading.SetItemNameTitleText(title);
    }

    private void SortNPCListByNameAscending()
    {
        npcInventory.itemPairs.Sort((x, y) => x.First.ItemName.CompareTo(y.First.ItemName));
    }

    public void AddNPCItem(Item item, int quantity = 1)
    {
        // add the item if it isn't in the inventory
        bool itemExists = false;

        // search list to see if item already exists
        foreach (Pair<Item, int> pair in npcInventory.itemPairs)
        {
            if (item.ItemID == pair.First.ItemID)
            {
                itemExists = true;

                // increase existing item quantity
                pair.Second += quantity;
            }
        }

        // make a new item, quantity pair
        if (!itemExists)
        {
            Pair<Item, int> newPair = new Pair<Item, int>(item, quantity);

            npcInventory.itemPairs.Add(newPair);
        }

        SortNPCListByNameAscending();
    }

    public bool RemoveNPCItem(Pair<Item, int> itemPair, int quantity = 1)
    {
        bool stillInInventory = true;

        // decrease the quantity of the item
        itemPair.Second -= quantity;

        // remove the item from the list if its quantity drops below 0
        if (itemPair.Second <= 0)
        {
            npcInventory.itemPairs.Remove(itemPair);
            stillInInventory = false;
        }

        return stillInInventory;
    }

    void OpenCompleteTransactionPanel()
    {
        if (Input.GetKeyDown(KeyCode.X) && !spawnedCompleteTradingPanel && !spawnedEndTradingPanel && IsTrading)
        {
            spawnedCompleteTradingPanel = Instantiate(completeTradingPanel, panelsArea);
        }
    }

    void OpenEndTradingPanel()
    {
        if (Input.GetKeyDown(KeyCode.Tab) && !spawnedCompleteTradingPanel && !spawnedEndTradingPanel && IsTrading)
        {
            spawnedEndTradingPanel = Instantiate(endTradingPanel, panelsArea);
        }
    }

    public void CompleteTransaction()
    {
        bool completed;

        if (cost > 0)
        {
            if (playerCrypto.CurrentCurrency - cost >= 0)
            {
                playerCrypto.SubtractCurrency(cost);
                npcCrypto.AddCurrency(cost);
                completed = true;
            }
            else
            {
                // spawn message stating that player cannot afford transaction
                var message = Instantiate(statusMessageTemplate, panelsArea);
                message.GetComponent<MenuStatusPanel>().SetStatusMessage("You cannot afford this transaction.");
                completed = false;
            }
        }
        else
        {
            int profit = Mathf.Abs(cost);
            
            if (npcCrypto.CurrentCurrency - profit >= 0)
            {
                npcCrypto.SubtractCurrency(profit);
                playerCrypto.AddCurrency(profit);
                completed = true;
            }
            else
            {
                // spawn message stating that player cannot afford transaction
                var message = Instantiate(statusMessageTemplate, panelsArea);
                message.GetComponent<MenuStatusPanel>().SetStatusMessage("Trader cannot afford this transaction.");
                completed = false;
            }
        }

        if (completed)
        {
            // move npc items marked for trade to player side
            for (int i = npcInventory.itemPairs.Count - 1; i > -1; i--)
            {
                if (npcInventory.itemPairs[i].First.MarkedForTrade)
                {
                    MoveItem(TradingPanel.InventoryOwner.NPC, npcInventory.itemPairs[i], npcInventory.itemPairs[i].First.NumberMarkedForTrade);
                }
            }

            // move player items marked for trade to npc side
            for (int i = playerInventory.Items.Count - 1; i > -1; i--)
            {
                if (playerInventory.Items[i].First.MarkedForTrade)
                {
                    MoveItem(TradingPanel.InventoryOwner.PLAYER, playerInventory.Items[i], playerInventory.Items[i].First.NumberMarkedForTrade);
                }
            }

            UnmarkItemsForTrade();

            // reset cost
            cost = 0;
            DisplayCostArrowsAndTransactionCost();

            // reset categories
            playerCategory = -1;
            npcCategory = -1;

            // reload panels
            ReloadTradingMenu();
            DisplayCostArrowsAndTransactionCost();
            SetTraderCryptoValues();
        }
    }

    public void CloseTrading()
    {
        UnmarkItemsForTrade();

        // reset cost
        cost = 0;
        DisplayCostArrowsAndTransactionCost();

        // reset categories
        playerCategory = -1;
        npcCategory = -1;

        // disable trading menu
        DestroyPanels();
        tradingMenu.SetActive(false);
        dialogueManager.UnhideDialogue();

        IsTrading = false;
    }

    private void UnmarkItemsForTrade()
    {
        // unmark all npc items for trade
        for (int i = 0; i < npcInventory.itemPairs.Count; i++)
        {
            npcInventory.itemPairs[i].First.MarkedForTrade = false;
            npcInventory.itemPairs[i].First.NumberMarkedForTrade = 0;
        }

        // unmark all player items for trade
        for (int i = 0; i < playerInventory.Items.Count; i++)
        {
            playerInventory.Items[i].First.MarkedForTrade = false;
            playerInventory.Items[i].First.NumberMarkedForTrade = 0;
        }
    }
}
