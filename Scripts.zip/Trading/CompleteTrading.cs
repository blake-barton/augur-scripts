using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CompleteTrading : MonoBehaviour
{
    TradingManager tradingManager;

    private void Awake()
    {
        tradingManager = FindObjectOfType<TradingManager>();
    }

    public void CompleteTransaction()
    {
        tradingManager.CompleteTransaction();
        Destroy(gameObject);
    }

    public void CloseTrading()
    {
        tradingManager.CloseTrading();
        Destroy(gameObject);
    }
}
