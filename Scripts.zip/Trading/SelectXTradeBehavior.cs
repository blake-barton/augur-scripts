using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SelectXTradeBehavior : MonoBehaviour
{
    [SerializeField] Slider slider;

    public TradingPanel.InventoryOwner owner;
    public TradingManager tradingManager;
    public Inventory playerInventory;
    public InventoryClickable clickable;
    public Pair<Item, int> itemPair;

    public void RemoveItems()
    {
        int previousNumMarkedForTrade = clickable.NumberMarkedForTrade;
        int numMarkedForTrade = (int)slider.value;

        if (numMarkedForTrade == 0)
        {
            // unmark all for trade
            itemPair.First.MarkedForTrade = false;
            itemPair.First.NumberMarkedForTrade = 0;

            clickable.MarkedForTrade = false;
            clickable.NumberMarkedForTrade = 0;
        }
        else
        {
            // mark the selected amount for trade
            itemPair.First.MarkedForTrade = true;
            itemPair.First.NumberMarkedForTrade = numMarkedForTrade;

            clickable.MarkedForTrade = true;
            clickable.NumberMarkedForTrade = numMarkedForTrade;
        }

        // update trade marker
        clickable.UpdateEquipPanels();

        // adjust transaction cost
        tradingManager.AdjustTransactionCost(owner, itemPair, numMarkedForTrade - previousNumMarkedForTrade);

        // destroy the select x popup panel
        Destroy(gameObject);
    }
}