using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BaseStateMachine : MonoBehaviour
{
    [SerializeField] private BaseState initialState;

    private BaseState currentState;
    private Dictionary<Type, Component> cachedComponents;
    private void Awake()
    {
        currentState = initialState;
        cachedComponents = new Dictionary<Type, Component>();
    }

    private void Start()
    {
        currentState.EnterState(this);
    }

    public BaseState CurrentState { get => currentState; }

    private void Update()
    {
        CurrentState.UpdateStateLogic(this);
    }

    public void ChangeState(BaseState state)
    {
        currentState.ExitState(this);
        state.EnterState(this);
        currentState = state;
    }

    public new T GetComponent<T>() where T : Component
    {
        if (cachedComponents.ContainsKey(typeof(T)))
            return cachedComponents[typeof(T)] as T;

        var component = base.GetComponent<T>();
        if (component != null)
        {
            cachedComponents.Add(typeof(T), component);
        }
        return component;
    }
}
