using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using AIBehaviorTree;

public class TaskShootAtTarget : BTNode
{
    AIRangedAttack rangedAttack;
    AIRangedAttack.AttackType attackType;

    public TaskShootAtTarget(BehaviorTree _behaviorTree, AIRangedAttack _rangedAttack, AIRangedAttack.AttackType _attackType) : base(_behaviorTree) 
    {
        rangedAttack = _rangedAttack;
        attackType = _attackType;
    }

    public override NodeState Evaluate()
    {
        switch (rangedAttack.State)
        {
            case AIRangedAttack.AttackState.WAITING:    // Fire. Return running if initiated successfully, failure otherwise.
                if (rangedAttack.FireSingleShot(attackType))
                {
                    state = NodeState.RUNNING;
                    return NodeState.RUNNING;
                }

                state = NodeState.FAILURE;
                return NodeState.FAILURE; 
            case AIRangedAttack.AttackState.ATTACKING:  // Still attacking
                state = NodeState.RUNNING;
                return NodeState.RUNNING;
            default:
                state = NodeState.FAILURE;
                return NodeState.FAILURE;
        }
    }
}