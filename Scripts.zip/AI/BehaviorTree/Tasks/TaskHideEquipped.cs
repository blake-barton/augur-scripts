using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using AIBehaviorTree;

public class TaskHideEquipped : BTNode
{
    EnemyEquipment enemyEquipment;

    public TaskHideEquipped(BehaviorTree _behaviorTree, EnemyEquipment _enemyEquipment) : base(_behaviorTree)
    {
        enemyEquipment = _enemyEquipment;
    }

    public override NodeState Evaluate()
    {
        // Hide
        enemyEquipment.HideEquipped();

        // Can't fail
        state = NodeState.SUCCESS;
        return NodeState.SUCCESS;
    }
}