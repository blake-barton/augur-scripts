using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using AIBehaviorTree;

public class TaskMeleeAttackTarget : BTNode
{
    readonly AIMeleeAttack meleeAttack;
    readonly bool telegraph;

    public TaskMeleeAttackTarget(BehaviorTree _behaviorTree, AIMeleeAttack _meleeAttack, bool _telegraph) : base(_behaviorTree)
    {
        meleeAttack = _meleeAttack;
    }

    public override NodeState Evaluate()
    {
        switch (meleeAttack.State)
        {
            case AIMeleeAttack.AttackState.WAITING:    // Fire. Return running if initiated successfully, failure otherwise.
                if (telegraph)
                {
                    if (meleeAttack.TryMeleeAttackWithTelegraph())
                    {
                        state = NodeState.RUNNING;
                        return NodeState.RUNNING;
                    }
                }
                else
                {
                    if (meleeAttack.TryMeleeAttackWithoutTelegraph())
                    {
                        state = NodeState.RUNNING;
                        return NodeState.RUNNING;
                    }
                }

                state = NodeState.FAILURE;
                return NodeState.FAILURE;
            case AIMeleeAttack.AttackState.ATTACKING:  // Still attacking
                state = NodeState.RUNNING;
                return NodeState.RUNNING;
            default:
                state = NodeState.FAILURE;
                return NodeState.FAILURE;
        }
    }
}