using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pathfinding;
using AIBehaviorTree;

public class TaskFollow : BTNode
{
    [Header("Enemy")]
    [SerializeField] Transform transform;
    [SerializeField] Enemy enemy;
    [SerializeField] EnemyMovement movement;

    [Header("Animation")]
    [SerializeField] Animator animator;

    [Header("Pathfinding")]
    [SerializeField] float minIdleDistance = 1.5f;

    // Target
    float distanceToDestination;
    readonly float distanceFromFollowTarget;   // Try to stay this far from the follow target
    readonly string followTargetTag;   // Used to find the target to follow
    GameObject followTarget;

    public TaskFollow(BehaviorTree _behaviorTree, Transform _transform, Enemy _enemy, EnemyMovement _enemyMovement, Animator _animator, float _distanceFromTarget, string _followTargetTag) : base(_behaviorTree)
    {
        transform = _transform;
        enemy = _enemy;
        movement = _enemyMovement;
        animator = _animator;

        distanceFromFollowTarget = _distanceFromTarget;
        followTargetTag = _followTargetTag;

        // Initial destination is self until follow target is found
        movement.Destination = transform;
    }

    // Update is called once per frame
    public override NodeState Evaluate()
    {
        // Find target if there isn't one
        if (!followTarget)
        {
            if (!FindFollowTarget())
            {
                // If we failed to find a target, return failed state.
                state = NodeState.FAILURE;
                return NodeState.FAILURE;
            }
        }

        // Only move if target has moved far enough away from this unit
        if (Vector2.Distance(followTarget.transform.position, transform.position) > distanceFromFollowTarget)
        {
            if (movement.Destination != followTarget.transform)
            {
                // Move towards the follow target
                movement.Destination = followTarget.transform;
            }
        }
        else
        {
            // In range of target. Stop moving.
            if (movement.Destination != transform)
            {
                movement.Destination = transform;
            }
        }

        IdleIfAtDestination();

        state = NodeState.RUNNING;
        return NodeState.RUNNING;
    }

    private GameObject FindFollowTarget()
    {
        followTarget = GameObject.FindWithTag(followTargetTag);

        return followTarget;
    }

    private void IdleIfAtDestination()
    {
        distanceToDestination = Vector2.Distance(transform.position, movement.Destination.position);

        // go to idle
        if (distanceToDestination <= minIdleDistance)
        {
            animator.SetBool("AnimInRange", true);
            movement.Speed = 0;
        }
        else
        {
            animator.SetBool("AnimInRange", false);

            // let them move to the new point if they aren't knocked down
            if (!enemy.Character.Incapacitated)
            {
                movement.Speed = movement.OriginalSpeed;
            }
        }
    }
}
