using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using AIBehaviorTree;

public class TaskStopMoving : BTNode
{
    EnemyMovement enemyMovement;

    public TaskStopMoving(BehaviorTree _behaviorTree, EnemyMovement _enemyMovement) : base(_behaviorTree)
    {
        enemyMovement = _enemyMovement;
    }

    public override NodeState Evaluate()
    {
        // Move destination to self
        enemyMovement.DisableMovement();

        // Can't fail
        state = NodeState.SUCCESS;
        return NodeState.SUCCESS;
    }
}