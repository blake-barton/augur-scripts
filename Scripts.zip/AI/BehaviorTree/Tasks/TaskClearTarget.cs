using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using AIBehaviorTree;

public class TaskClearTarget : BTNode
{
    LineOfSight lineOfSight;

    public TaskClearTarget(BehaviorTree _behaviorTree, LineOfSight _lineOfSight) : base(_behaviorTree)
    {
        lineOfSight = _lineOfSight;
    }

    public override NodeState Evaluate()
    {
        lineOfSight.ClearTarget();
        state = NodeState.SUCCESS;
        return NodeState.SUCCESS;
    }
}
