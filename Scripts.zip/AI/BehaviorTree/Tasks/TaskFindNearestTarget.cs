using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using AIBehaviorTree;

public class TaskFindNearestTarget : BTNode
{
    Transform transform;
    Character character;
    LineOfSight lineOfSight;

    public TaskFindNearestTarget(BehaviorTree _behaviorTree, Transform _transform, Character _character, LineOfSight _lineOfSight) : base(_behaviorTree)
    {
        transform = _transform;
        character = _character;
        lineOfSight = _lineOfSight;
    }

    public override NodeState Evaluate()
    {
        // Find all characters in range. Select the closest character that does not belong to this character's faction. Return SUCCESS if found. FAILURE otherwise.
        var characters = Object.FindObjectsOfType<Character>();
        float minDistance = float.MaxValue;
        Character closestVisibleCharacter = null;

        foreach (Character candidate in characters)
        {
            // Ignore self
            if (character == candidate)
            {
                continue;
            }

            // Ignore characters of the same faction
            if (character.CharacterFaction == candidate.CharacterFaction)
            {
                continue;
            }

            // Ignore dead people
            if (!candidate.CharacterHealth.enabled || (candidate.CharacterHealth.enabled && !candidate.CharacterHealth.Alive))
            {
                continue;
            }

            // Check distance
            float distanceToCandidate = Vector2.Distance(transform.position, candidate.transform.position);
            if (distanceToCandidate <= character.SightRange && distanceToCandidate < minDistance)
            {
                // Check visibility
                if (lineOfSight.CheckIfTransformIsVisible(candidate.transform))
                {
                    minDistance = distanceToCandidate;
                    closestVisibleCharacter = candidate;
                }
            }
        }

        // Done searching. Set target (if found).
        if (closestVisibleCharacter)
        {
            lineOfSight.Target = closestVisibleCharacter.transform;

            state = NodeState.SUCCESS;
            return NodeState.SUCCESS;
        }

        // No target found.
        state = NodeState.FAILURE;
        return NodeState.FAILURE;
    }
}