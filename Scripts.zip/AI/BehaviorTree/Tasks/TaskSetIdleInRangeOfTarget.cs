using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pathfinding;
using AIBehaviorTree;

public class TaskSetIdleInRangeOfTarget : BTNode
{
    [Header("Enemy")]
    [SerializeField] Transform transform;
    [SerializeField] LineOfSight lineOfSight;

    [Header("Animation")]
    [SerializeField] Animator animator;

    [Header("Pathfinding")]
    [SerializeField] float minIdleDistance = 1.5f;

    float distanceToDestination;

    public TaskSetIdleInRangeOfTarget(BehaviorTree _behaviorTree, Transform _transform, LineOfSight _lineOfSight, Animator _animator, float _minIdleDistance) : base(_behaviorTree)
    {
        transform = _transform;
        lineOfSight = _lineOfSight;
        animator = _animator;

        minIdleDistance = _minIdleDistance;
    }

    // Update is called once per frame
    public override NodeState Evaluate()
    {
        GetDistanceToDestination();

        state = NodeState.RUNNING;
        return NodeState.RUNNING;
    }

    private void GetDistanceToDestination()
    {
        distanceToDestination = Vector2.Distance(transform.position, lineOfSight.Target.position);

        // go to idle
        if (distanceToDestination <= minIdleDistance)
        {
            animator.SetBool("AnimInRange", true);
        }
        else
        {
            animator.SetBool("AnimInRange", false);
        }
    }
}