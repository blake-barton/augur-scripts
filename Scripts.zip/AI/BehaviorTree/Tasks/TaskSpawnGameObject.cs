using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using AIBehaviorTree;

public class TaskSpawnGameObject : BTNode
{
    public TaskSpawnGameObject(BehaviorTree _behaviorTree) : base(_behaviorTree)
    {
    }

    public override NodeState Evaluate()
    {
        state = NodeState.FAILURE;
        return NodeState.FAILURE;
    }
}