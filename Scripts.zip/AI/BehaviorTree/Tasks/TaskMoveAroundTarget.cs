using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pathfinding;
using AIBehaviorTree;

public class TaskMoveAroundTarget : BTNode
{
    [Header("Enemy")]
    [SerializeField] Transform transform;
    [SerializeField] Enemy enemy;
    [SerializeField] EnemyMovement movement;
    [SerializeField] LineOfSight lineOfSight;

    [Header("Animation")]
    [SerializeField] Animator animator;

    [Header("Pathfinding")]
    [SerializeField] Range distanceFromTarget;
    [SerializeField] Range timeBetweenDestinationChange;
    [SerializeField] float minIdleDistance = 1.5f;

    float moveCounter;
    GameObject destination;
    float distanceToDestination;

    public TaskMoveAroundTarget(BehaviorTree _behaviorTree, Transform _transform, Enemy _enemy, EnemyMovement _enemyMovement, LineOfSight _lineOfSight, Animator _animator, Range _distanceFromTarget, Range _timeBetweenDestinationChange) : base(_behaviorTree) 
    {
        transform = _transform;
        enemy = _enemy;
        movement = _enemyMovement;
        lineOfSight = _lineOfSight;
        animator = _animator;

        distanceFromTarget = _distanceFromTarget;
        timeBetweenDestinationChange = _timeBetweenDestinationChange;

        // initially move towards the target
        destination = new GameObject();
        movement.Destination = destination.transform;
    }

    // Update is called once per frame
    public override NodeState Evaluate()
    {
        GetDistanceToDestination();
        FindNewDestination();

        state = NodeState.RUNNING;
        return NodeState.RUNNING;
    }

    // find random walkable destination that is between min and max distance and set it in the movement script
    private void FindNewDestination()
    {
        moveCounter -= Time.deltaTime;
        if (moveCounter <= 0f)
        {
            // get a vector with random direction and magnitude between distance min and max
            Vector2 randomVector = UtilMath.RandomVector2(360f, 0f, distanceFromTarget.GetRandomValueInRange());

            // get a world point from the target and vector
            Vector3 point = lineOfSight.Target.position + (Vector3)randomVector;

            // find closest walkable node to world point
            GraphNode node = AstarPath.active.GetNearest(point, NNConstraint.Default).node;

            // get the world position of said node
            Vector3 nodePosition = (Vector3)node.position;

            // set destination's position to that
            destination.transform.position = nodePosition;

            // set the destination of the movement script to this script's destination
            movement.Destination = destination.transform;

            // reset counter
            moveCounter = timeBetweenDestinationChange.GetRandomValueInRange();
        }
    }

    private void GetDistanceToDestination()
    {
        distanceToDestination = Vector2.Distance(transform.position, destination.transform.position);

        // go to idle
        if (distanceToDestination <= minIdleDistance)
        {
            animator.SetBool("AnimInRange", true);
            movement.Speed = 0;
        }
        else
        {
            animator.SetBool("AnimInRange", false);

            // let them move to the new point if they aren't knocked down
            if (!enemy.Character.Incapacitated)
            {
                movement.Speed = movement.OriginalSpeed;
            }
        }
    }
}