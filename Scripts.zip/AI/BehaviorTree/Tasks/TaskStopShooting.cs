using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using AIBehaviorTree;

public class TaskStopShooting : BTNode
{
    AIRangedAttack rangedAttack;

    public TaskStopShooting(BehaviorTree _behaviorTree, AIRangedAttack _rangedAttack) : base(_behaviorTree)
    {
        rangedAttack = _rangedAttack;
    }

    public override NodeState Evaluate()
    {
        // Stopping coroutines should stop anything firing
        rangedAttack.StopFiring();

        state = NodeState.SUCCESS;
        return NodeState.SUCCESS;
    }
}