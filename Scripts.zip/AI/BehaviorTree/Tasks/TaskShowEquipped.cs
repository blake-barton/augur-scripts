using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using AIBehaviorTree;

public class TaskShowEquipped : BTNode
{
    EnemyEquipment enemyEquipment;

    public TaskShowEquipped(BehaviorTree _behaviorTree, EnemyEquipment _enemyEquipment) : base(_behaviorTree)
    {
        enemyEquipment = _enemyEquipment;
    }

    public override NodeState Evaluate()
    {
        // Hide
        enemyEquipment.UnhideEquipped();

        // Can't fail
        state = NodeState.SUCCESS;
        return NodeState.SUCCESS;
    }
}