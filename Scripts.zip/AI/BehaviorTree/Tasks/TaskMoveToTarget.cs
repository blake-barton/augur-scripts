using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Pathfinding;
using AIBehaviorTree;

public class TaskMoveToTarget : BTNode
{
    [Header("Enemy")]
    [SerializeField] EnemyMovement movement;
    [SerializeField] LineOfSight lineOfSight;

    public TaskMoveToTarget(BehaviorTree _behaviorTree, EnemyMovement _enemyMovement, LineOfSight _lineOfSight) : base(_behaviorTree)
    {
        movement = _enemyMovement;
        lineOfSight = _lineOfSight;
    }

    // Update is called once per frame
    public override NodeState Evaluate()
    {
        // move towards the target
        movement.Destination = lineOfSight.Target;

        state = NodeState.RUNNING;
        return NodeState.RUNNING;
    }
}