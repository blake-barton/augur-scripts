using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using AIBehaviorTree;

public class TaskPlayAnimation : BTNode
{
    Animator animator;
    string animState;

    public TaskPlayAnimation(BehaviorTree _behaviorTree, Animator _animator, string _animState) : base(_behaviorTree) 
    {
        animator = _animator;
        animState = _animState;
    }

    public override NodeState Evaluate()
    {
        // Check if we're already performing this animation
        if (animator.GetCurrentAnimatorStateInfo(0).IsName(animState))
        {
            state = NodeState.RUNNING;
            return NodeState.RUNNING;
        } 

        // Play anim
        animator.Play(animState, -1, 0.0f);

        behaviorTree.StopTicking();

        // Return running
        state = NodeState.SUCCESS;
        return NodeState.SUCCESS;
    }
}