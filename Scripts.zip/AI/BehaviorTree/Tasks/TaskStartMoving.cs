using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using AIBehaviorTree;

public class TaskStartMoving : BTNode
{
    readonly EnemyMovement enemyMovement;

    public TaskStartMoving(BehaviorTree _behaviorTree, EnemyMovement _enemyMovement) : base(_behaviorTree)
    {
        enemyMovement = _enemyMovement;
    }

    public override NodeState Evaluate()
    {
        // Move destination to self
        enemyMovement.EnableMovement();

        // Can't fail
        state = NodeState.SUCCESS;
        return NodeState.SUCCESS;
    }
}