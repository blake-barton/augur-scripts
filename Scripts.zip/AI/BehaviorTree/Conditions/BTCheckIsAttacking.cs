using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using AIBehaviorTree;

public class BTCheckIsAttacking : BTNode
{
    readonly AIMeleeAttack meleeAttack = null;
    readonly AIRangedAttack rangedAttack = null;

    public BTCheckIsAttacking(BehaviorTree _behaviorTree, AIRangedAttack _rangedAttack) : base(_behaviorTree)
    {
        rangedAttack = _rangedAttack;
    }

    public BTCheckIsAttacking(BehaviorTree _behaviorTree, AIMeleeAttack _meleeAttack) : base(_behaviorTree)
    {
        meleeAttack = _meleeAttack;
    }

    public BTCheckIsAttacking(BehaviorTree _behaviorTree, AIRangedAttack _rangedAttack, AIMeleeAttack _meleeAttack) : base(_behaviorTree)
    {
        rangedAttack = _rangedAttack;
        meleeAttack = _meleeAttack;
    }

    public override NodeState Evaluate()
    {
        // Return success if either ranged attack or melee attack is attacking, false otherwise
        if (meleeAttack)
        {
            if (meleeAttack.State == AIMeleeAttack.AttackState.ATTACKING)
            {
                state = NodeState.SUCCESS;
                return NodeState.SUCCESS;
            }
        }
        else if (rangedAttack)
        {
            if (rangedAttack.State == AIRangedAttack.AttackState.ATTACKING)
            {
                state = NodeState.SUCCESS;
                return NodeState.SUCCESS;
            }
        }

        state = NodeState.FAILURE;
        return NodeState.FAILURE;
    }
}
