using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace AIBehaviorTree
{
    // Don't hook children up to this. Returns as successful if timer is up, failure otherwise.
    public class BTCooldown : BTNode
    {
        [SerializeField] Range cooldownRange;

        float timer;

        public BTCooldown(BehaviorTree _behaviorTree, Range _cooldownRange) : base(_behaviorTree)
        {
            cooldownRange = _cooldownRange;
            timer = cooldownRange.GetRandomValueInRange();
        }

        public override NodeState Evaluate()
        {
            timer -= Time.deltaTime;

            if (timer <= 0f)
            {
                // Time's up. Reset timer and return successful.
                timer = cooldownRange.GetRandomValueInRange();

                state = NodeState.SUCCESS;
                return NodeState.SUCCESS;
            }

            // Timer not up. Return failure.
            state = NodeState.FAILURE;
            return NodeState.FAILURE;
        }
    }
}
