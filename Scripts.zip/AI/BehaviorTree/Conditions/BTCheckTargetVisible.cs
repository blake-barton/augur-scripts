using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using AIBehaviorTree;

public class BTCheckTargetVisible : BTNode
{
    LineOfSight lineOfSight;

    public BTCheckTargetVisible(BehaviorTree _behaviorTree, LineOfSight _lineOfSight) : base(_behaviorTree)
    {
        lineOfSight = _lineOfSight;
    }

    public override NodeState Evaluate()
    {
        // Check for target.
        if (lineOfSight.Target)
        {
            // Return success if target visible
            if (lineOfSight.TargetVisible)
            {
                state = NodeState.SUCCESS;
                return NodeState.SUCCESS;
            }
            else
            {
                state = NodeState.FAILURE;
                return NodeState.FAILURE;
            }
        }

        // No target
        state = NodeState.FAILURE;
        return NodeState.FAILURE;
    }
}