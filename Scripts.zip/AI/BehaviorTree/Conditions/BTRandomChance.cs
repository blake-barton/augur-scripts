using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace AIBehaviorTree
{
    // Don't hook children up to this. Returns as successful if the roll passes.
    public class BTRandomChance : BTNode
    {
        float chance;

        public BTRandomChance(BehaviorTree _behaviorTree, float _chance) : base(_behaviorTree)
        {
            chance = _chance;
        }

        public override NodeState Evaluate()
        {
            if (UtilMath.PercentileRoll(chance))
            {
                state = NodeState.SUCCESS;
                return NodeState.SUCCESS;
            }

            state = NodeState.FAILURE;
            return NodeState.FAILURE;
        }
    }
}
