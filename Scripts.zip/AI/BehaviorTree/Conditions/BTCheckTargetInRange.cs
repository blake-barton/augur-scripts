using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using AIBehaviorTree;

public class BTCheckTargetInRange : BTNode
{
    LineOfSight lineOfSight;
    float range;

    public BTCheckTargetInRange(BehaviorTree _behaviorTree, LineOfSight _lineOfSight, float _range) : base(_behaviorTree)
    {
        lineOfSight = _lineOfSight;
        range = _range;
    }

    public override NodeState Evaluate()
    {
        // Check if target exists
        if (lineOfSight.Target)
        {
            // If distance to target is less than or equal to the inputted range, return successful.
            if (lineOfSight.GetDistanceToTarget() <= range)
            {
                state = NodeState.SUCCESS;
                return NodeState.SUCCESS;
            }
            else
            {
                state = NodeState.FAILURE;
                return NodeState.FAILURE;
            }
        }

        // No target
        state = NodeState.FAILURE;
        return NodeState.FAILURE;
    }
}