using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using AIBehaviorTree;

public class BTCheckHasTarget : BTNode
{
    LineOfSight lineOfSight;

    public BTCheckHasTarget(BehaviorTree _behaviorTree, LineOfSight _lineOfSight) : base(_behaviorTree)
    {
        lineOfSight = _lineOfSight;
    }

    public override NodeState Evaluate()
    {
        // Return success if line of sight has target. Failure otherwise.
        if (lineOfSight.Target)
        {
            state = NodeState.SUCCESS;
            return NodeState.SUCCESS;
        }
        else
        {
            state = NodeState.FAILURE;
            return NodeState.FAILURE;
        }
    }
}
