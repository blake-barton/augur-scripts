using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using AIBehaviorTree;

public class BTCheckTargetAlive : BTNode
{
    LineOfSight lineOfSight;

    public BTCheckTargetAlive(BehaviorTree _behaviorTree, LineOfSight _lineOfSight) : base(_behaviorTree)
    {
        lineOfSight = _lineOfSight;
    }

    public override NodeState Evaluate()
    {
        // Return success if target alive
        if (lineOfSight.IsTargetAlive())
        {
            state = NodeState.SUCCESS;
            return NodeState.SUCCESS;
        }
        else
        {
            state = NodeState.FAILURE;
            return NodeState.FAILURE;
        }
    }
}
