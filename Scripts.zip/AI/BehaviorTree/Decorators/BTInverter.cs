using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using AIBehaviorTree;

public class BTInverter : BTNode
{
    /// <summary>
    /// Tick the child once and return SUCCESS if the child failed or FAILURE if the child succeeded. If the child returns RUNNING, this node returns RUNNING too. Only use this node with a single child.
    /// </summary>
    public BTInverter(BehaviorTree _behaviorTree, List<BTNode> _children) : base(_behaviorTree, _children) {}

    public override NodeState Evaluate()
    {
        if (children.Count == 1)
        {
            switch (children[0].Evaluate())
            {
                case NodeState.FAILURE:
                    state = NodeState.SUCCESS;
                    return state;
                case NodeState.SUCCESS:
                    state = NodeState.FAILURE;
                    return state;
                case NodeState.RUNNING:
                    state = NodeState.RUNNING;
                    return state;
                default:
                    state = NodeState.FAILURE;
                    return state;
            }
        }

        Debug.LogError("Error: Used inverter decorator with a bad child count (should be 1): " + children.Count);
        state = NodeState.FAILURE;
        return state;
    }
}
