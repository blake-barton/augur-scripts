using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace AIBehaviorTree
{
    public enum NodeState
    {
        RUNNING,
        SUCCESS,
        FAILURE
    }

    public class BTNode
    {
        protected NodeState state;

        protected BehaviorTree behaviorTree;
        public BTNode parent;
        protected List<BTNode> children = new List<BTNode>();

        // Shared data -> object can be of any type
        private Dictionary<string, object> dataContext = new Dictionary<string, object>();

        // Constructors
        public BTNode(BehaviorTree _behaviorTree)
        {
            behaviorTree = _behaviorTree;
            parent = null;
        }
        public BTNode(BehaviorTree _behaviorTree, List<BTNode> _children)
        {
            behaviorTree = _behaviorTree;

            foreach (BTNode child in _children)
            {
                Attach(child);
            }
        }

        private void Attach(BTNode node)
        {
            node.parent = this;

            children.Add(node);
        }

        public virtual NodeState Evaluate() => NodeState.FAILURE;

        public void SetData(string key, object value)
        {
            dataContext[key] = value;
        }

        // Checking if data is defined somewhere in the branch, not just this node. Search up until we find the desired key or we hit the root of the tree
        public object GetData(string key)
        {
            // Found key, return
            if (dataContext.TryGetValue(key, out object value))
            {
                return value;
            }

            // Search up
            BTNode node = parent;
            while (node != null)
            {
                value = node.GetData(key);
                if (value != null)
                {
                    return value;
                }

                node = node.parent;
            }

            // Reached root
            return null;
        }

        // Returns true if data was cleared
        public bool ClearData(string key)
        {
            // Found key, return
            if (dataContext.ContainsKey(key))
            {
                dataContext.Remove(key);
                return true;
            }

            // Search up
            BTNode node = parent;
            while (node != null)
            {
                bool cleared = node.ClearData(key);
                if (cleared)
                {
                    return true;
                }

                node = node.parent;
            }

            // Reached root
            return false;
        }
    }
}
