using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using AIBehaviorTree;

public class LylaCompanionBT : BehaviorTree
{
    [Header("Required Components")]
    [SerializeField] Character character;
    [SerializeField] Enemy enemy;
    [SerializeField] EnemyMovement enemyMovement;
    [SerializeField] Animator animator;
    [SerializeField] LineOfSight lineOfSight;
    [SerializeField] AIRangedAttack rangedAttack;

    [Header("Follow Player Movement")]
    [SerializeField] float distanceFromLeader;
    [SerializeField] string playerTag = "Player";

    [Header("Attacking")]
    [SerializeField] RangedWeapon rangedWeaponData;
    [SerializeField] Range attackCooldownRange;

    protected override BTNode SetupTree()
    {
        BTNode newRoot = new BTSequence(this, new List<BTNode>
        {
            // Follow the leader (player)
            new TaskFollow(this, transform, enemy, enemyMovement, animator, distanceFromLeader, playerTag),
            // Combat
            new BTSelector(this, new List<BTNode>
            {
                // Check that target is alive, in range, and visible, then shoot after cooldown
                new BTSequence(this, new List<BTNode>
                {
                    new BTCheckHasTarget(this, lineOfSight),
                    new BTCheckTargetAlive(this, lineOfSight),
                    new BTCheckTargetInRange(this, lineOfSight, rangedWeaponData.MaxRange),
                    new BTCheckTargetVisible(this, lineOfSight),
                    new BTCooldown(this, attackCooldownRange),
                    new TaskShootAtTarget(this, rangedAttack, AIRangedAttack.AttackType.PROJECTILE)
                }),
                // Look for target
                new TaskFindNearestTarget(this, transform, character, lineOfSight)
            }),
            // Clear target if dead
            new BTSequence(this, new List<BTNode>
            {
                new BTCheckHasTarget(this, lineOfSight),
                new BTInverter(this, new List<BTNode> { new BTCheckTargetAlive(this, lineOfSight) }),
                new TaskClearTarget(this, lineOfSight),
                new TaskFindNearestTarget(this, transform, character, lineOfSight)  // Find new target
            })
        });

        return newRoot;
    }
}
