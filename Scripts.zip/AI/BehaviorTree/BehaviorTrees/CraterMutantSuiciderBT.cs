using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using AIBehaviorTree;

public class CraterMutantSuiciderBT : BehaviorTree
{
    [Header("Required Components")]
    [SerializeField] Character character;
    [SerializeField] Enemy enemy;
    [SerializeField] EnemyMovement enemyMovement;
    [SerializeField] Animator animator;
    [SerializeField] LineOfSight lineOfSight;

    [Header("Patrol")]
    [SerializeField] Range patrolDistanceRange;
    [SerializeField] Range timeBetweenDestinationChange;

    [Header("Suicide")]
    [SerializeField] float suicideTargetRange = 1.5f;
    [SerializeField] string suicideAnimState = "Suicide";

    protected override BTNode SetupTree()
    {
        BTNode newRoot = new BTSelector(this, new List<BTNode>
        {
            // Suicide
            new BTSequence(this, new List<BTNode>
            {
                new BTCheckHasTarget(this, lineOfSight),
                new BTCheckTargetAlive(this, lineOfSight),
                new BTCheckTargetInRange(this, lineOfSight, suicideTargetRange),
                new TaskStopMoving(this, enemyMovement),
                new TaskPlayAnimation(this, animator, suicideAnimState)
            }),
            // Find target and seek
            new BTSequence(this, new List<BTNode>
            {
                new TaskFindNearestTarget(this, transform, character, lineOfSight),
                new TaskMoveToTarget(this, enemyMovement, lineOfSight),
            }),
            // Patrol
            new TaskPatrol(this, transform, enemy, enemyMovement, animator, patrolDistanceRange, timeBetweenDestinationChange)
        });

        return newRoot;
    }
}
