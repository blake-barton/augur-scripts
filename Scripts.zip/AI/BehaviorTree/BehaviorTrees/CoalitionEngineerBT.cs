using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using AIBehaviorTree;

public class CoalitionEngineerBT : BehaviorTree
{
    [Header("Required Components")]
    [SerializeField] Character character;
    [SerializeField] Enemy enemy;
    [SerializeField] EnemyMovement enemyMovement;
    [SerializeField] Animator animator;
    [SerializeField] LineOfSight lineOfSight;
    [SerializeField] AIRangedAttack rangedAttack;
    [SerializeField] EnemyEquipment enemyEquipment;

    [Header("Target Movement")]
    [SerializeField] Range distanceFromTarget;
    [SerializeField] Range timeBetweenDistanceChange;

    [Header("Patrol")]
    [SerializeField] Range patrolDistanceRange;
    [SerializeField] Range timeBetweenDestinationChange;

    [Header("Attacking")]
    [SerializeField] RangedWeapon rangedWeaponData;
    [SerializeField] Range attackCooldownRange;

    [Header("Turret Build")]
    [SerializeField] string turretBuildAnimState = "BuildTurret";
    [SerializeField] Range turretBuildCooldown;
    [SerializeField] [Range(0, 100)] float chanceToBuild = 40f;

    protected override BTNode SetupTree()
    {
        BTNode newRoot = new BTSelector(this, new List<BTNode>
        {
            new BTSequence(this, new List<BTNode>
            {
                new BTRandomChance(this, chanceToBuild),
                new BTCheckHasTarget(this, lineOfSight),
                new BTCooldown(this, turretBuildCooldown),
                new TaskStopMoving(this, enemyMovement),
                new TaskStopShooting(this, rangedAttack),
                new TaskHideEquipped(this, enemyEquipment),
                new TaskPlayAnimation(this, animator, turretBuildAnimState)
            }),
            new BTSequence(this, new List<BTNode>
            {
                new BTCheckHasTarget(this, lineOfSight),
                new BTCheckTargetAlive(this, lineOfSight),
                new TaskMoveAroundTarget(this, transform, enemy, enemyMovement, lineOfSight, animator, distanceFromTarget, timeBetweenDestinationChange),
                new BTCheckTargetInRange(this, lineOfSight, rangedWeaponData.MaxRange),
                new BTCheckTargetVisible(this, lineOfSight),
                new BTCooldown(this, attackCooldownRange),
                new TaskShootAtTarget(this, rangedAttack, AIRangedAttack.AttackType.PROJECTILE)
            }),
            new TaskFindNearestTarget(this, transform, character, lineOfSight),
            new TaskPatrol(this, transform, enemy, enemyMovement, animator, patrolDistanceRange, timeBetweenDestinationChange)
        });

        return newRoot;
    }
}
