using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using AIBehaviorTree;

public class OmnigolemBT : BehaviorTree
{
    [Header("Required Components")]
    [SerializeField] Character character;
    [SerializeField] Enemy enemy;
    [SerializeField] EnemyMovement enemyMovement;
    [SerializeField] Animator animator;
    [SerializeField] LineOfSight lineOfSight;
    [SerializeField] AIRangedAttack rangedAttack;
    [SerializeField] AIMeleeAttack meleeAttack;

    [Header("Patrol")]
    [SerializeField] Range patrolDistanceRange;
    [SerializeField] Range timeBetweenDestinationChange;

    [Header("Ranged Attack")]
    [SerializeField] RangedWeapon rangedWeaponData;
    [SerializeField] Range attackCooldownRange;

    [Header("Melee Attack")]
    [SerializeField] float meleeAttackRange = 1.5f;
    [SerializeField] Range meleeAttackCooldown;

    protected override BTNode SetupTree()
    {
        BTNode newRoot = new BTSelector(this, new List<BTNode>
        {
            // If in range, melee attack
            new BTSequence(this, new List<BTNode>
            {
                new BTInverter(this, new List<BTNode>{ new BTCheckIsAttacking(this, rangedAttack) }),  // Only go down this branch if not ranged attacking
                new TaskStartMoving(this, enemyMovement),
                new BTCooldown(this, meleeAttackCooldown),
                new BTCheckHasTarget(this, lineOfSight),
                new BTCheckTargetAlive(this, lineOfSight),
                new BTCheckTargetInRange(this, lineOfSight, meleeAttackRange),
                new BTCheckTargetVisible(this, lineOfSight),
                new TaskMeleeAttackTarget(this, meleeAttack, false)
            }),
            // Move towards target
            new BTSequence(this, new List<BTNode>
            {
                new BTInverter(this, new List<BTNode>{ new BTCheckIsAttacking(this, rangedAttack) }),  // Only go down this branch if not ranged attacking
                new TaskStartMoving(this, enemyMovement),
                new BTCheckHasTarget(this, lineOfSight),
                new BTCheckTargetAlive(this, lineOfSight),
                new TaskMoveToTarget(this, enemyMovement, lineOfSight),
            }),
            // Stop moving. Shoot.
            new BTSequence(this, new List<BTNode>
            {
                new BTCooldown(this, attackCooldownRange),
                new BTInverter(this, new List<BTNode>{ new BTCheckIsAttacking(this, rangedAttack, meleeAttack) }),  // Only go down this branch if not attacking
                new BTCheckTargetInRange(this, lineOfSight, rangedWeaponData.MaxRange),
                new BTCheckTargetVisible(this, lineOfSight),
                new TaskStopMoving(this, enemyMovement),
                new TaskShootAtTarget(this, rangedAttack, AIRangedAttack.AttackType.LASER)
            }),
            // Look for target
            new TaskFindNearestTarget(this, transform, character, lineOfSight),
            // Patrol
            new TaskPatrol(this, transform, enemy, enemyMovement, animator, patrolDistanceRange, timeBetweenDestinationChange)
        });

        return newRoot;
    }
}
