using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using AIBehaviorTree;

public class CoalitionGruntBT : BehaviorTree
{
    [Header("Required Components")]
    [SerializeField] Character character;
    [SerializeField] Enemy enemy;
    [SerializeField] EnemyMovement enemyMovement;
    [SerializeField] Animator animator;
    [SerializeField] LineOfSight lineOfSight;
    [SerializeField] AIRangedAttack rangedAttack;
    [SerializeField] EnemyEquipment enemyEquipment;

    [Header("Target Movement")]
    [SerializeField] Range distanceFromTarget;
    [SerializeField] Range timeBetweenDistanceChange;

    [Header("Patrol")]
    [SerializeField] Range patrolDistanceRange;
    [SerializeField] Range timeBetweenDestinationChange;

    [Header("Attacking")]
    [SerializeField] RangedWeapon rangedWeaponData;
    [SerializeField] Range attackCooldownRange;

    protected override BTNode SetupTree()
    {
        BTNode newRoot = new BTSelector(this, new List<BTNode>
        {
            // Move around and shoot
            new BTSequence(this, new List<BTNode>
            {
                new BTCheckHasTarget(this, lineOfSight),
                new BTCheckTargetAlive(this, lineOfSight),
                new TaskMoveAroundTarget(this, transform, enemy, enemyMovement, lineOfSight, animator, distanceFromTarget, timeBetweenDestinationChange),
                new BTCheckTargetInRange(this, lineOfSight, rangedWeaponData.MaxRange),
                new BTCheckTargetVisible(this, lineOfSight),
                new BTCooldown(this, attackCooldownRange),
                new TaskShootAtTargetFullAuto(this, rangedAttack, AIRangedAttack.AttackType.PROJECTILE)
            }),
            // Look for target
            new TaskFindNearestTarget(this, transform, character, lineOfSight),
            // Patrol
            new TaskPatrol(this, transform, enemy, enemyMovement, animator, patrolDistanceRange, timeBetweenDestinationChange)
        });

        return newRoot;
    }
}
