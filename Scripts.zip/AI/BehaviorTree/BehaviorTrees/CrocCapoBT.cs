using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using AIBehaviorTree;

public class CrocCapoBT : BehaviorTree
{
    [Header("Required Components")]
    [SerializeField] Character character;
    [SerializeField] Enemy enemy;
    [SerializeField] EnemyMovement enemyMovement;
    [SerializeField] Animator animator;
    [SerializeField] LineOfSight lineOfSight;
    [SerializeField] AIRangedAttack rangedAttack;
    [SerializeField] EnemyEquipment enemyEquipment;
    [SerializeField] AIMeleeAttack meleeAttack;

    [Header("Target Movement")]
    [SerializeField] Range distanceFromTarget;
    [SerializeField] Range timeBetweenDistanceChange;

    [Header("Patrol")]
    [SerializeField] Range patrolDistanceRange;
    [SerializeField] Range timeBetweenDestinationChange;

    [Header("Ranged Attack")]
    [SerializeField] RangedWeapon rangedWeaponData;
    [SerializeField] Range rangedAttackCooldown;

    [Header("Melee Attack")]
    [SerializeField] float meleeAttackRange = 1.5f;
    [SerializeField] Range meleeAttackCooldown;

    protected override BTNode SetupTree()
    {
        BTNode newRoot = new BTSelector(this, new List<BTNode>
        {
            // If in range, melee attack
            new BTSequence(this, new List<BTNode>
            {
                new BTCheckHasTarget(this, lineOfSight),
                new BTCheckTargetAlive(this, lineOfSight),
                new BTCooldown(this, meleeAttackCooldown),
                new BTCheckTargetInRange(this, lineOfSight, meleeAttackRange),
                new BTCheckTargetVisible(this, lineOfSight),
                new TaskHideEquipped(this, enemyEquipment),
                new TaskMeleeAttackTarget(this, meleeAttack, false)
            }),
            // Move around and shoot
            new BTSequence(this, new List<BTNode>
            {
                new BTInverter(this, new List<BTNode>{ new BTCheckIsAttacking(this, rangedAttack, meleeAttack) }),  // Only go down this branch if not attacking
                new TaskShowEquipped(this, enemyEquipment),
                new BTCheckHasTarget(this, lineOfSight),
                new BTCheckTargetAlive(this, lineOfSight),
                new TaskMoveAroundTarget(this, transform, enemy, enemyMovement, lineOfSight, animator, distanceFromTarget, timeBetweenDestinationChange),
                new BTCheckTargetInRange(this, lineOfSight, rangedWeaponData.MaxRange),
                new BTCheckTargetVisible(this, lineOfSight),
                new BTCooldown(this, rangedAttackCooldown),
                new TaskShootAtTargetFullAuto(this, rangedAttack, AIRangedAttack.AttackType.PROJECTILE)
            }),
            // Look for target
            new TaskFindNearestTarget(this, transform, character, lineOfSight),
            // Patrol
            new TaskPatrol(this, transform, enemy, enemyMovement, animator, patrolDistanceRange, timeBetweenDestinationChange)
        });

        return newRoot;
    }
}
