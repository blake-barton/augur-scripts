using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using AIBehaviorTree;

public class SmallSlimeBT : BehaviorTree
{
    [Header("Required Components")]
    [SerializeField] Character character;
    [SerializeField] Enemy enemy;
    [SerializeField] EnemyMovement enemyMovement;
    [SerializeField] Animator animator;
    [SerializeField] LineOfSight lineOfSight;

    [Header("Patrol")]
    [SerializeField] Range patrolDistanceRange;
    [SerializeField] Range timeBetweenDestinationChange;

    protected override BTNode SetupTree()
    {
        BTNode newRoot = new BTSelector(this, new List<BTNode>
        {
            // Move towards target. Attack target when in melee range
            new BTSequence(this, new List<BTNode>
            {
                new BTCheckHasTarget(this, lineOfSight),
                new BTCheckTargetAlive(this, lineOfSight),
                new TaskMoveToTarget(this, enemyMovement, lineOfSight),
            }),
            // Look for target
            new TaskFindNearestTarget(this, transform, character, lineOfSight),
            // Patrol
            new TaskPatrol(this, transform, enemy, enemyMovement, animator, patrolDistanceRange, timeBetweenDestinationChange),
        });

        return newRoot;
    }
}
