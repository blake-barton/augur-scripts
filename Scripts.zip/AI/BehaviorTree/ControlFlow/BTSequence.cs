using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace AIBehaviorTree
{
    // Acts like an AND logic gate. Only if all child nodes succeed will this one succeed.
    public class BTSequence : BTNode
    {
        public BTSequence(BehaviorTree _behaviorTree) : base(_behaviorTree) {}

        public BTSequence(BehaviorTree _behaviorTree, List<BTNode> _children) : base(_behaviorTree, _children) {}

        public override NodeState Evaluate()
        {
            bool anyChildIsRunning = false;     // if a child is running, this node is running

            foreach (BTNode node in children)
            {
                switch (node.Evaluate())
                {
                    case NodeState.FAILURE:         // if any child fails, this node fails
                        state = NodeState.FAILURE;
                        return state;
                    case NodeState.SUCCESS:
                        continue;
                    case NodeState.RUNNING:
                        anyChildIsRunning = true;
                        continue;
                    default:
                        state = NodeState.SUCCESS;
                        return state;
                }
            }

            // If a child is running, return running, otherwise this node is successful
            state = anyChildIsRunning ? NodeState.RUNNING : NodeState.SUCCESS;
            return state;
        }
    }
}
