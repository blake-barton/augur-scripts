using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace AIBehaviorTree
{
    // Acts like an OR logic gate. Only one child needs to be running or successful for this one to return.
    public class BTSelector : BTNode
    {
        public BTSelector(BehaviorTree _behaviorTree) : base(_behaviorTree) { }
        public BTSelector(BehaviorTree _behaviorTree, List<BTNode> _children) : base(_behaviorTree, _children) { }

        public override NodeState Evaluate()
        {
            foreach (BTNode node in children)
            {
                switch (node.Evaluate())
                {
                    case NodeState.FAILURE:
                        continue;
                    case NodeState.SUCCESS:
                        state = NodeState.SUCCESS;
                        return state;
                    case NodeState.RUNNING:         // if any child is running, this node is running
                        state = NodeState.RUNNING;
                        return state;
                    default:
                        continue;
                }
            }

            state = NodeState.FAILURE;
            return state;
        }
    }
}
