using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace AIBehaviorTree
{
    public abstract class BehaviorTree : MonoBehaviour
    {
        private BTNode root = null;
        private BTNode interruptingNode = null;
        private bool interrupted = false;
        private bool tickEnabled = true;

        protected void Start()
        {
            root = SetupTree();
        }

        private void Update()
        {
            if (tickEnabled)
            {
                if (interrupted && interruptingNode != null)    // Only evaluate the node that's taken over the tree
                {
                    interruptingNode.Evaluate();
                }
                else
                {
                    if (root != null)   // Evaluate the whole tree
                    {
                        root.Evaluate();
                    }
                }
            }
        }

        protected abstract BTNode SetupTree();

        public void StartTicking()
        {
            tickEnabled = true;
        }

        public void StopTicking()
        {
            tickEnabled = false;
        }
    }
}
