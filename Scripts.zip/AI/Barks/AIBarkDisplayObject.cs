using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class AIBarkDisplayObject : MonoBehaviour
{
    [SerializeField] TextMeshPro barkTextMesh;
    [SerializeField] TextMeshPro dropShadowTextMesh;

    private void Start()
    {
        ClearBark();
    }

    public void SetBark(AIBark bark)
    {
        barkTextMesh.text = bark.Text;
        barkTextMesh.color = bark.Color;

        dropShadowTextMesh.text = bark.Text;
    }

    public void ClearBark()
    {
        barkTextMesh.text = "";
        dropShadowTextMesh.text = "";
    }
}
