using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class AIBark
{
    [TextArea(3, 5)]
    [SerializeField] string text;

    [SerializeField] float displayTime = 2f;
    [SerializeField] Color color = Color.white;
    [SerializeField] [Range(0, 1)] private float chanceToDisplay = 1;

    public string Text { get => text; set => text = value; }
    public float DisplayTime { get => displayTime; set => displayTime = value; }
    public Color Color { get => color; set => color = value; }
    public float ChanceToDisplay { get => chanceToDisplay; set => chanceToDisplay = value; }
}
