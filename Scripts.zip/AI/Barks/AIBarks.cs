using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AIBarks : MonoBehaviour
{
    /* All functions in this class are meant to be called by UnityEvents set up throughout the editor. */

    [SerializeField] AIBarkData barkData;
    [SerializeField] AIBarkDisplayObject barkDisplay;

    // State
    bool displayingBark = false;

    // ------------------------------------------------------------
    /* BARKS */
    public void OnAttackBark()
    {
        DisplayBark(GetRandomBarkFromList(barkData.onAttack));
    }
    public void OnCombatStarted()
    {
        DisplayBark(GetRandomBarkFromList(barkData.onCombatStarted));
    }
    public void OnCombatEnded()
    {
        DisplayBark(GetRandomBarkFromList(barkData.onCombatEnded));
    }
    public void OnDamaged()
    {
        DisplayBark(GetRandomBarkFromList(barkData.onDamaged));
    }
    public void OnDeath()
    {
        DisplayBark(GetRandomBarkFromList(barkData.onDeath));
    }
    public void OnFoundEnemyTarget()
    {
        DisplayBark(GetRandomBarkFromList(barkData.onFoundEnemyTarget));
    }
    public void OnInteractedCombat()
    {
        DisplayBark(GetRandomBarkFromList(barkData.onInteractedCombat));
    }
    public void OnKnockedDown()
    {
        DisplayBark(GetRandomBarkFromList(barkData.onKnockedDown));
    }
    public void OnLowHealth()
    {
        DisplayBark(GetRandomBarkFromList(barkData.onLowHealth));
    }
    // ------------------------------------------------------------

    /// <summary>
    /// Start display coroutine if not already displaying bark.
    /// </summary>
    private void DisplayBark(AIBark bark)
    {
        // Random chance to display
        float roll = Random.value;

        if (roll <= bark.ChanceToDisplay)
        {
            if (!displayingBark)
            {
                StartCoroutine(DisplayBarkForTimePeriod(bark));
            }
        }
    }

    /// <summary>
    /// Force clear displayed bark.
    /// </summary>
    public void ClearBark()
    {
        StopAllCoroutines();

        barkDisplay.ClearBark();

        displayingBark = false;
    }

    /// <summary>
    /// Set the bark object's text to the given bark for the bark's display time, then clear the bark.
    /// </summary>
    IEnumerator DisplayBarkForTimePeriod(AIBark bark)
    {
        displayingBark = true;

        barkDisplay.SetBark(bark);

        yield return new WaitForSeconds(bark.DisplayTime);

        barkDisplay.ClearBark();

        displayingBark = false;
    }

    private AIBark GetRandomBarkFromList(List<AIBark> barks)
    {
        if (barks.Count > 0)
        {
            int index = Random.Range(0, barks.Count);
            return barks[index];
        }

        Debug.LogWarning("Tried to get a bark from a list with no barks.");
        return null;
    }
}
