using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "AI Barks/Default")]
public class AIBarkData : ScriptableObject
{
    public List<AIBark> onAttack = new();
    public List<AIBark> onCombatStarted = new();
    public List<AIBark> onCombatEnded = new();
    public List<AIBark> onDamaged = new();
    public List<AIBark> onDeath = new();
    public List<AIBark> onFoundEnemyTarget = new();
    public List<AIBark> onInteractedCombat = new();
    public List<AIBark> onKnockedDown = new();
    public List<AIBark> onLowHealth = new();
}
