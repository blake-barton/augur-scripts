using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TutorialManager : MonoBehaviour
{
    [SerializeField] AttributeScores playerAttributes;

    private void Start()
    {
        // level up player
        playerAttributes.SetAttributes(5, 5, 5, 5, 5, 5, 5);
    }
}
