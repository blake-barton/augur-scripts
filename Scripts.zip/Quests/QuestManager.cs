using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class QuestManager : MonoBehaviour
{
    public enum QuestObjectiveEnum
    {
        ObjectiveKillNumberOfEnemy
    }

    public enum QuestResultEnum
    {
        ResultLootDrop
    }

    [Header("Cached References")]
    [SerializeField] StatusMessageManager statusMessageManager;

    List<Quest> activeQuests = new List<Quest>();

    public List<Quest> ActiveQuests { get => activeQuests; set => activeQuests = value; }

    public void AddQuestToActiveQuests(Quest quest)
    {
        quest.State = Quest.QuestState.IN_PROGRESS;

        ActiveQuests.Add(quest);

        SortListByNameAscending();
    }

    public void MarkQuestCompleted(Quest quest)
    {
        ActiveQuests.Remove(quest);
    }

    public Quest GenerateQuest(string assignerName, string assignerQuote)
    {
        List<QuestObjectiveBase> objectives = new List<QuestObjectiveBase>();
        List<QuestResultBase> results = new List<QuestResultBase>();

        // Randomly choose a quest objective
        switch (GetRandomQuestObjective())
        {
            case QuestObjectiveEnum.ObjectiveKillNumberOfEnemy:
                objectives.Add(new ObjectiveKillNumberOfEnemy());
                break;
            default:
                break;
        }

        switch (GetRandomQuestResult())
        {
            case QuestResultEnum.ResultLootDrop:
                results.Add(new ResultLootDrop());
                break;
            default:
                break;
        }

        // Generate objective requirements
        foreach (QuestObjectiveBase objective in objectives)
        {
            objective.Generate(this);
        }

        // Generate results
        foreach (QuestResultBase result in results)
        {
            result.Generate(this);
        }

        string randomName = NameGenerator.GenerateQuestName();

        return new Quest(this, randomName, assignerQuote, assignerName, objectives, results);
    }

    public void LoadQuestsFromQuestSaveStringLists(List<List<string>> questSaveStringLists)
    {
        foreach (List<string> questSaveStringList in questSaveStringLists)
        {
            ActiveQuests.Add(new Quest(this, questSaveStringList));
        }

        SortListByNameAscending();
    }

    private QuestObjectiveEnum GetRandomQuestObjective()
    {
        // pick reward category at random
        int objectiveCount = Enum.GetNames(typeof(QuestObjectiveEnum)).Length;

        return (QuestObjectiveEnum)UnityEngine.Random.Range(0, objectiveCount);
    }

    private QuestResultEnum GetRandomQuestResult()
    {
        // pick reward category at random
        int resultCount = Enum.GetNames(typeof(QuestResultEnum)).Length;

        return (QuestResultEnum)UnityEngine.Random.Range(0, resultCount);
    }

    private void SortListByNameAscending()
    {
        activeQuests.Sort((x, y) => x.QuestName.CompareTo(y.QuestName));
    }

    public void SendStatusMessage(string message)
    {
        statusMessageManager.DisplayMessage(message);
    }
}
