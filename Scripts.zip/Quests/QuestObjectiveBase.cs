using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class QuestObjectiveBase
{
    protected bool isComplete;
    protected Quest parentQuest;

    public bool IsComplete { get => isComplete; set => isComplete = value; }
    public Quest ParentQuest { get => parentQuest; set => parentQuest = value; }

    // Check if objective completed
    public abstract bool Evaluate();
    public abstract void Generate(QuestManager questManager);
    public abstract override string ToString();
    public abstract string GetCurrentProgressAsString();
    public abstract string GenerateSaveString();
    public abstract void LoadObjectiveWithSaveStringArray(string[] splitObjectiveString);

    protected void Complete()
    {
        IsComplete = true;

        // notify owning quest that this objective is complete
        ParentQuest.NotifyObjectiveComplete();
    }
}
