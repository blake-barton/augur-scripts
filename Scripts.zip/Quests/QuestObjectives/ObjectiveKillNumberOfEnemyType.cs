using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectiveKillNumberOfEnemyType : QuestObjectiveBase
{
    public override bool Evaluate()
    {
        throw new System.NotImplementedException();
    }

    public override void Generate(QuestManager questManager)
    {
        throw new System.NotImplementedException();
    }

    public override string GenerateSaveString()
    {
        throw new System.NotImplementedException();
    }

    public override string GetCurrentProgressAsString()
    {
        throw new System.NotImplementedException();
    }

    public override void LoadObjectiveWithSaveStringArray(string[] saveStrings)
    {
        throw new System.NotImplementedException();
    }

    public override string ToString()
    {
        throw new System.NotImplementedException();
    }
}
