using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectiveKillNumberOfEnemy : QuestObjectiveBase
{
    int enemyID;
    string enemyName;
    int numToKill;
    int currentNumKilled;

    public ObjectiveKillNumberOfEnemy()
    {
        // Hook up combat system to this objectiver
        CombatSystemMessenger.Instance.EnemyKilledEvent += OnEnemyKilled;
    }

    public ObjectiveKillNumberOfEnemy(Quest _parentQuest, string[] splitObjectiveString)
    {
        ParentQuest = _parentQuest;
        LoadObjectiveWithSaveStringArray(splitObjectiveString);

        // Hook up combat system to this objectiver
        CombatSystemMessenger.Instance.EnemyKilledEvent += OnEnemyKilled;
    }

    public override bool Evaluate()
    {
        return currentNumKilled >= numToKill; 
    }

    public override void Generate(QuestManager questManager)
    {
        ChooseEnemy();
        ChooseCount();
    }

    public override string GetCurrentProgressAsString()
    {
        return "Killed " + currentNumKilled + "/" + numToKill;
    }

    public override string ToString()
    {
        return "Kill " + numToKill + " " + enemyName + "s.";
    }

    void ChooseEnemy()
    {
        ItemDatabase database = Object.FindObjectOfType<ItemDatabase>();

        var enemyList = database.GetListOfAllEnemies();

        int randomIndex = Random.Range(0, enemyList.Count);
        GameObject randomEnemy = enemyList[randomIndex];

        enemyName = randomEnemy.GetComponent<Enemy>().EnemyName;
    }

    void ChooseCount()
    {
        numToKill = Random.Range(1, 5);
    }

    public override string GenerateSaveString()
    {
        return "ObjectiveKillNumberOfEnemy|" + enemyName + "|" + numToKill + "|" + currentNumKilled;
    }

    public override void LoadObjectiveWithSaveStringArray(string[] splitObjectiveString)
    {
        // [1] -> enemyName
        enemyName = splitObjectiveString[1];

        // [2] -> numToKill
        numToKill = int.Parse(splitObjectiveString[2]);

        // [3] -> currentNumKilled
        currentNumKilled = int.Parse(splitObjectiveString[3]);
    }

    public void OnEnemyKilled(EnemyKilledMessage message)
    {
        if (message.EnemyName.Equals(enemyName) && parentQuest.State == Quest.QuestState.IN_PROGRESS)
        {
            currentNumKilled++;

            // check completion
            if (Evaluate())
            {
                Complete();
            }
        }
    }
}
