using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ResultLootDrop : QuestResultBase
{
    struct ItemQuantityPair
    {
        public int itemID;
        public string itemName;
        public int quantity;
    }

    List<ItemQuantityPair> items = new List<ItemQuantityPair>();

    public ResultLootDrop()
    {

    }

    public ResultLootDrop(string[] splitResultString)
    {
        LoadResultWithSaveStringArray(splitResultString);
    }

    public override void ExecuteResult()
    {
        foreach (ItemQuantityPair pair in items)
        {
            UnityEngine.Object.FindObjectOfType<RoomManager>().SpawnRewardItem(pair.itemID);
        }
    }

    public override void Generate(QuestManager questManager)
    {
        //int numItems = UnityEngine.Random.Range(1, 3);
        int numItems = 1;

        for (int i = 0; i < numItems; i++)
        {
            ItemQuantityPair pair = new ItemQuantityPair();

            var itemList = UnityEngine.Object.FindObjectOfType<ItemDatabase>().itemList;
            int randomIndex = UnityEngine.Random.Range(0, itemList.Count);

            pair.itemID = itemList[randomIndex].ItemID;
            pair.itemName = itemList[randomIndex].ItemName;
            pair.quantity = itemList[randomIndex].NumberToReward;

            items.Add(pair);
        }
    }

    public override string ToString()
    {
        string returnString = "";

        for (int i = 0; i < items.Count; i++)
        {
            if (i == items.Count - 1)
            {
                returnString += items[i].quantity + " " + items[i].itemName + "(s)";
            }
            else
            {
                returnString += items[i].quantity + " " + items[i].itemName + "(s), ";
            }
        }

        return returnString;
    }

    public override string GenerateSaveString()
    {
        string saveString = "ResultLootDrop|";

        foreach (ItemQuantityPair item in items)
        {
            saveString += "{" + item.itemID + "," + item.itemName + "," + item.quantity + "}|";
        }

        return saveString;
    }

    public override void LoadResultWithSaveStringArray(string[] splitResultString)
    {
        for (int i = 1; i < splitResultString.Length; i++)
        {
            string segment = splitResultString[i];

            ItemQuantityPair newItem;

            // remove braces
            segment = segment.Substring(1, segment.Length - 2);

            char[] charSeparators = new char[] { ',' };

            // split on commas
            string[] splitItemString = segment.Split(charSeparators, StringSplitOptions.RemoveEmptyEntries);

            // [0] -> itemID
            newItem.itemID = int.Parse(splitItemString[0]);

            // [1] -> itemName
            newItem.itemName = splitItemString[1];

            // [2] -> quantity
            newItem.quantity = int.Parse(splitItemString[2]);

            // add item
            items.Add(newItem);
        }
    }
}
