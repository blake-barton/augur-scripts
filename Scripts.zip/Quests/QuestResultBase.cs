using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class QuestResultBase
{
    public abstract void ExecuteResult();
    public abstract void Generate(QuestManager questManager);
    public abstract override string ToString();
    public abstract string GenerateSaveString();
    public abstract void LoadResultWithSaveStringArray(string[] splitResultString);
}
