using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class Quest
{
    public enum QuestState
    {
        PENDING,
        IN_PROGRESS,
        COMPLETED
    }

    [SerializeField] string questName;
    [SerializeField] QuestState state;
    [SerializeField] string description;
    [SerializeField] string assignerName;
    [SerializeField] List<QuestObjectiveBase> questObjectives = new List<QuestObjectiveBase>();
    [SerializeField] List<QuestResultBase> questResults = new List<QuestResultBase>();

    [Header("Manager")]
    [SerializeField] QuestManager questManager;

    public string QuestName { get => questName; set => questName = value; }
    public QuestState State { get => state; set => state = value; }
    public string Description { get => description; set => description = value; }
    public List<QuestObjectiveBase> QuestObjectives { get => questObjectives; set => questObjectives = value; }
    public List<QuestResultBase> QuestResults { get => questResults; set => questResults = value; }
    public string AssignerName { get => assignerName; set => assignerName = value; }

    public Quest(QuestManager _questManager, List<string> saveStringList)
    {
        questManager = _questManager;

        LoadQuestFromSaveStringList(saveStringList);
    }

    public Quest(QuestManager _questManager, string _questName, string _description, string _assignerName, List<QuestObjectiveBase> objectives, List<QuestResultBase> results)
    {
        questManager = _questManager;
        QuestName = _questName;
        Description = _description;
        AssignerName = _assignerName;
        QuestObjectives = objectives;
        QuestResults = results;

        State = QuestState.PENDING;

        // assign as parent
        foreach (QuestObjectiveBase objective in objectives)
        {
            objective.ParentQuest = this;
        }
    }

    public void NotifyObjectiveComplete()
    {
        // check if all objectives are complete
        foreach (QuestObjectiveBase objective in QuestObjectives)
        {
            if (!objective.IsComplete)
            {
                return;
            }
        }

        // All objectives complete. Mark ready to submit.
        State = QuestState.COMPLETED;

        // Status message
        questManager.SendStatusMessage(QuestName + " Completed!");

        // quest jingle
    }

    public void CompleteQuest()
    {
        foreach (QuestResultBase result in QuestResults)
        {
            result.ExecuteResult();
        }

        // tell manager we're done
        questManager.MarkQuestCompleted(this);
    }

    // Create a string that can be parsed in a new scene to recreate this quest
    public List<string> GenerateSaveStringList()
    {
        List<string> saveStringList = new List<string>();

        // [0] -> questName
        saveStringList.Add(QuestName);

        // [1] -> state
        saveStringList.Add(State.ToString());

        // [2] -> description
        saveStringList.Add(Description);

        // [3] -> assigner name
        saveStringList.Add(AssignerName);

        // [4] -> objectives start
        saveStringList.Add("objectives");

        foreach (QuestObjectiveBase objective in QuestObjectives)
        {
            saveStringList.Add(objective.GenerateSaveString());
        }

        // [?] -> results start
        saveStringList.Add("results");

        foreach (QuestResultBase result in QuestResults)
        {
            saveStringList.Add(result.GenerateSaveString());
        }

        // [?] -> done
        saveStringList.Add("done");

        return saveStringList;
    }

    void LoadQuestFromSaveStringList(List<string> saveStringList)
    {
        // [0] -> questName
        QuestName = saveStringList[0];

        // [1] -> state
        Enum.TryParse(saveStringList[1], out state);

        // [2] -> description
        Description = saveStringList[2];

        // [3] -> assigner name
        AssignerName = saveStringList[3];

        // Load objectives
        int i = 5;

        char[] charSeparators = new char[] { '|' };

        while (saveStringList[i] != "results")
        {
            // split the objective string into its separate parts
            string[] splitObjectiveString = saveStringList[i].Split(charSeparators, StringSplitOptions.RemoveEmptyEntries);

            LoadObjective(splitObjectiveString);

            i++;
        }

        // go to first result
        i++;

        // Load Results
        while (saveStringList[i] != "done")
        {
            // split the objective string into its separate parts
            string[] splitResultString = saveStringList[i].Split(charSeparators, StringSplitOptions.RemoveEmptyEntries);

            LoadResult(splitResultString);

            i++;
        }
    }

    void LoadObjective(string[] splitObjectiveString)
    {
        Enum.TryParse(splitObjectiveString[0], out QuestManager.QuestObjectiveEnum questObjective);

        switch (questObjective)
        {
            case QuestManager.QuestObjectiveEnum.ObjectiveKillNumberOfEnemy:
                QuestObjectives.Add(new ObjectiveKillNumberOfEnemy(this, splitObjectiveString));
                break;
        }
    }

    void LoadResult(string[] splitResultString)
    {
        Enum.TryParse(splitResultString[0], out QuestManager.QuestResultEnum questResult);

        switch (questResult)
        {
            case QuestManager.QuestResultEnum.ResultLootDrop:
                QuestResults.Add(new ResultLootDrop(splitResultString));
                break;
            default:
                break;
        }
    }
}
