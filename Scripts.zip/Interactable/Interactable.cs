using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Interactable : MonoBehaviour
{
    // this static lists holds a record of all interactables the player is currently in range of
    public static List<Interactable> interactablesInRange = new List<Interactable>();
    public static Interactable closestInteractable;

    protected static Player player;

    protected virtual void Awake()
    {
        player = FindObjectOfType<Player>();
    }

    public static void FindClosestInteractable()
    {
        // check that any other scene items also in range are not as close as this one
        float minDistance = float.MaxValue;
        closestInteractable = null;
        foreach (Interactable interactable in Interactable.interactablesInRange)
        {
            // check the positions of each interactable in range (player is within trigger collider)
            float distance = Vector2.Distance(interactable.gameObject.transform.position, player.gameObject.transform.position);
            if (distance < minDistance)
            {
                minDistance = distance;
                Interactable.closestInteractable = interactable;
            }
        }
    }

    protected virtual void OnTriggerEnter2D(Collider2D collision)
    {
        // check that the object colliding is a player
        if (collision.gameObject.CompareTag("Player"))
        {
            // add this item to the list of items in range
            Interactable.interactablesInRange.Add(this);
        }
    }

    protected void OnTriggerExit2D(Collider2D collision)
    {
        // check that the object colliding is a player
        if (collision.gameObject.CompareTag("Player"))
        {
            // remove this item from the list of items in range
            Interactable.interactablesInRange.Remove(this);
        }
    }

    public static void ClearInteractablesInRange()
    {
        interactablesInRange.Clear();
        closestInteractable = null;
    }

    public virtual void Interact() { }
}
