using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class ButtonSwitch : Interactable
{
    [SerializeField] bool isSwitch;
    [SerializeField] bool switchedOn;

    [Header("Limited Uses")]
    [SerializeField] bool hasLimitedUses;
    [SerializeField] int numUses = 1;

    [Header("Timing")]
    [SerializeField] float actionDelay = 0.5f;
    [SerializeField] float buttonPopDelay = 0.5f;

    [Header("Visuals")]
    [SerializeField] Sprite offSprite;
    [SerializeField] Sprite onSprite;
    [SerializeField] SpriteRenderer spriteRenderer;

    [Header("Audio")]
    [SerializeField] AudioSource audioSource;
    [SerializeField] AudioClip pressAudio;
    [SerializeField] [Range(0, 1)] float pressAudioVolume = 1f;

    public UnityEvent switchedOnEvent;
    public UnityEvent switchedOffEvent;

    public override void Interact()
    {
        StartCoroutine(PressButtonSwitch());
    }

    IEnumerator PressButtonSwitch()
    {
        // audio
        if (pressAudio)
        {
            AudioUtility.PlaySound(audioSource, pressAudio, pressAudioVolume);
        }

        // visuals
        if (spriteRenderer)
        {
            if (isSwitch)
            {
                if (!switchedOn)
                {
                    // switches don't pop back out
                    spriteRenderer.sprite = onSprite;
                }
                else
                {
                    // switches don't pop back out
                    spriteRenderer.sprite = onSprite;
                }
            }
            else
            {
                // buttons pop back out after a delay
                spriteRenderer.sprite = onSprite;

                yield return new WaitForSeconds(buttonPopDelay);

                spriteRenderer.sprite = offSprite;
            }
        }

        if ((hasLimitedUses && numUses > 0) || !hasLimitedUses)
        {
            yield return new WaitForSeconds(actionDelay);

            // switches can be turned on or off. Buttons only have one action.
            if (isSwitch)
            {
                if (!switchedOn)
                {
                    switchedOnEvent.Invoke();
                    switchedOn = true;
                }
                else
                {
                    switchedOffEvent.Invoke();
                    switchedOn = false;
                }
            }
            else
            {
                switchedOnEvent.Invoke();
            }

            numUses--;
        }
        else
        {
            yield return null;
        }
    }
}
