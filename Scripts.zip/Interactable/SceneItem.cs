using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// a scene item is the physical representation of an item dropped into the scene.
public class SceneItem : Interactable
{
    public Item itemTemplate;     // data from the item's serialized object
    public int quantity = 1;
    [SerializeField] AudioClip pickupSound;
    [SerializeField] [Range(0, 1)] float pickupVolume = .5f;
    [SerializeField] bool useVortexPickup = true;
    [SerializeField] float vortexSpeed = 5f;
    [SerializeField] bool movingTowardsPlayer = false;

    // This item's data (starts copied from the template)
    Item itemData;

    // cache
    Inventory inventory;
    AudioSource uiSounds;
    StatusMessageManager statusMessageManager;

    // getters/setters
    public Item ItemData { get => itemData; set => itemData = value; }
    public bool UseVortexPickup { get => useVortexPickup; set => useVortexPickup = value; }

    protected override void Awake()
    {
        base.Awake();

        itemData = Object.Instantiate(itemTemplate);
        inventory = FindObjectOfType<Player>().GetComponent<Inventory>();
        uiSounds = GameObject.FindWithTag("UISound").GetComponent<AudioSource>();
        statusMessageManager = FindObjectOfType<StatusMessageManager>();
    }

    private void Update()
    {
        if (movingTowardsPlayer)
        {
            // move closer to the player
            var step = vortexSpeed * Time.deltaTime; // calculate distance to move
            transform.position = Vector3.MoveTowards(transform.position, inventory.transform.position, step);

            // shrink item
            transform.localScale -= new Vector3(step, step, 0);

            // clamp local scale x
            if (transform.localScale.x < 0)
            {
                transform.localScale = new Vector3(0, transform.localScale.y, 0);
            }

            // clamp local scale y
            if (transform.localScale.y < 0)
            {
                transform.localScale = new Vector3(transform.localScale.x, 0, 0);
            }

            // Check if the position of the item and the player are approximately equal
            if (Vector3.Distance(transform.position, inventory.transform.position) < 0.001f)
            {
                // Add the item to the player's inventory
                if (itemData.CopiesAllowed)
                {
                    AddStacksToInventory();
                }
                else
                {
                    AddToInventory();
                }
            }
        }
    }

    public override void Interact()
    {
        // Add the item to the player's inventory
        if (itemData.CopiesAllowed)
        {
            AddStacksToInventory();
        }
        else
        {
            AddToInventory();
        }
    }

    private void AddStacksToInventory()
    {
        // Stack if copiesAllowed
        int stacks = quantity / itemData.HeldMax;
        int remainder = quantity % itemData.HeldMax;

        // Enough to start another stack
        if (remainder > 0)
        {
            stacks++;
        }

        for (int i = 0; i < stacks; i++)
        {
            int quantityToAdd;

            // Last
            if (i == stacks - 1 && remainder > 0)
            {
                quantityToAdd = remainder;
            }
            else
            {
                quantityToAdd = itemData.HeldMax;
            }

            // Add to inventory
            inventory.AddItem(ItemData, quantityToAdd);
        }

        // sound
        if (pickupSound)
        {
            uiSounds.PlayOneShot(pickupSound, pickupVolume);
        }

        // Print status message
        if (quantity > 1)
        {
            statusMessageManager.DisplayMessage("+" + quantity + " " + itemData.ItemName + "s");
        }
        else
        {
            statusMessageManager.DisplayMessage(itemData.ItemName);
        }

        // remove the item from the list of items in range
        Interactable.interactablesInRange.Remove(this);

        // remove item from scene
        Destroy(gameObject);
    }

    private void AddToInventory()
    {
        int countInInventory = inventory.GetItemCount(itemData.ItemID);

        int quantityToAdd = Mathf.Min(quantity, itemData.HeldMax - countInInventory);
        int quantityRemaining = quantity - quantityToAdd;

        if (quantityToAdd > 0) // if adding this quantity does not exceed the held max or the item doesn't exist in the inventory, add the quantity
        {
            inventory.AddItem(ItemData, quantityToAdd);

            // sound
            if (pickupSound)
            {
                uiSounds.PlayOneShot(pickupSound, pickupVolume);
            }

            if (quantity > 1)
            {
                statusMessageManager.DisplayMessage("+" + quantityToAdd + " " + itemData.ItemName + "s");
            }
            else
            {
                statusMessageManager.DisplayMessage(itemData.ItemName);
            }

            if (quantityRemaining > 0)
            {
                quantity = quantityRemaining;
            }
            else
            {
                // remove the item from the list of items in range
                Interactable.interactablesInRange.Remove(this);

                // remove item from scene
                Destroy(gameObject);
            }
        }
        else
        {
            statusMessageManager.DisplayMessage("MAXED");
        }
    }

    // Returns true if there is room in the inventory for the entire quantity
    bool CheckDoesInventoryHaveRoomForWholeStack()
    {
        if (itemData.CopiesAllowed)
        {
            return true;
        }

        int countInInventory = inventory.GetItemCount(itemData.ItemID);

        int quantityToAdd = Mathf.Min(quantity, itemData.HeldMax - countInInventory);

        if (quantity <= quantityToAdd)
        {
            return true;
        }

        return false;
    }

    protected override void OnTriggerEnter2D(Collider2D collision)
    {
        base.OnTriggerEnter2D(collision);

        if (UseVortexPickup && CheckDoesInventoryHaveRoomForWholeStack())
        {
            movingTowardsPlayer = true;
        }
    }
}
