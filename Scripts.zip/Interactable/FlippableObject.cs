using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FlippableObject : Interactable
{
    enum Direction
    {
        UP,
        DOWN,
        LEFT,
        RIGHT,
        NONE
    }

    [Header("Direction Sprites")]
    [SerializeField] Sprite baseSprite;
    [SerializeField] Sprite upSprite;
    [SerializeField] Sprite downSprite;
    [SerializeField] Sprite leftSprite;
    [SerializeField] Sprite rightSprite;

    [Header("Flipped Hitboxes")]
    [SerializeField] BoxCollider2D upBox;
    [SerializeField] BoxCollider2D downBox;
    [SerializeField] BoxCollider2D leftBox;
    [SerializeField] BoxCollider2D rightBox;

    [Header("Audio")]
    [SerializeField] AudioClip[] flipAudios;
    [SerializeField] [Range(0, 1)] float flipAudioVolume = 1f;

    [Header("Cached References")]
    [SerializeField] SpriteRenderer spriteRenderer;
    [SerializeField] Animator animator;
    [SerializeField] BoxCollider2D baseHitbox;
    [SerializeField] Rigidbody2D rb2d;
    [SerializeField] AudioSource audioSource;

    float upBoundary;
    float downBoundary;
    float leftBoundary;
    float rightBoundary;

    Direction currentDirection;

    private void Start()
    {
        animator.enabled = false;

        upBoundary = baseHitbox.bounds.extents.y + baseHitbox.offset.y;
        downBoundary = -baseHitbox.bounds.extents.y + baseHitbox.offset.y;

        leftBoundary = -baseHitbox.bounds.extents.x + baseHitbox.offset.x;
        rightBoundary = baseHitbox.bounds.extents.x + baseHitbox.offset.x;
    }

    private void Update()
    {
        DisplayDirectionalSprite();
    }

    public override void Interact()
    {
        Flip();
    }

    void DisplayDirectionalSprite()
    {
        if (interactablesInRange.Contains(this))
        {
            Vector2 direction = player.transform.position - transform.position;

            // Up
            if (direction.x >= leftBoundary && direction.x < rightBoundary && direction.y >= 0)
            {
                currentDirection = Direction.UP;
                spriteRenderer.sprite = upSprite;
            }
            // Down
            else if (direction.x > leftBoundary && direction.x <= rightBoundary && direction.y < 0)
            {
                currentDirection = Direction.DOWN;
                spriteRenderer.sprite = downSprite;
            }
            // Left
            else if (direction.y >= downBoundary && direction.y < upBoundary && direction.x < 0)
            {
                currentDirection = Direction.LEFT;
                spriteRenderer.sprite = leftSprite;
            }
            // Right
            else if (direction.y > downBoundary && direction.y <= upBoundary && direction.x > 0)
            {
                currentDirection = Direction.RIGHT;
                spriteRenderer.sprite = rightSprite;
            }
        }
        else if (currentDirection != Direction.NONE)
        {
            currentDirection = Direction.NONE;
            spriteRenderer.sprite = baseSprite;
        }
    }

    void Flip()
    {
        animator.enabled = true;

        // Kick in the opposite direction
        switch (currentDirection)
        {
            case Direction.UP:
                animator.SetTrigger("KickDown");
                downBox.enabled = true;
                rb2d.gameObject.layer = downBox.gameObject.layer;
                break;
            case Direction.DOWN:
                animator.SetTrigger("KickUp");
                upBox.enabled = true;
                rb2d.gameObject.layer = upBox.gameObject.layer;
                break;
            case Direction.LEFT:
                animator.SetTrigger("KickRight");
                rightBox.enabled = true;
                rb2d.gameObject.layer = rightBox.gameObject.layer;
                break;
            case Direction.RIGHT:
                animator.SetTrigger("KickLeft");
                leftBox.enabled = true;
                rb2d.gameObject.layer = leftBox.gameObject.layer;
                break;
            default:
                Debug.LogError("Table flip had no direction.");
                animator.SetTrigger("KickLeft");
                leftBox.enabled = true;
                rb2d.gameObject.layer = leftBox.gameObject.layer;
                break;
        }

        // Audio
        AudioUtility.PlayRandomSound(audioSource, flipAudios, flipAudioVolume);

        // Change rigidbody to dynamic (so it can be pushed)
        rb2d.bodyType = RigidbodyType2D.Dynamic;

        // Base hitbox is done
        baseHitbox.enabled = false;

        // No more interacting
        gameObject.SetActive(false);
    }
}
