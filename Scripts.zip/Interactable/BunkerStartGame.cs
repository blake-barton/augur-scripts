using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BunkerStartGame : Interactable
{
    [SerializeField] SceneLoader sceneLoader;
    [SerializeField] string sceneToLoad = "";

    public override void Interact()
    {
        sceneLoader.LoadSceneByName(sceneToLoad);
    }
}
