using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class DialogueTrigger : Interactable
{
    [SerializeField] Dialogue dialogue;

    [Header("Config")]
    [SerializeField] bool allowDialogueInCombat = false;

    [Header("Trading")]
    [SerializeField] bool trader = false;
    [SerializeField] NPCInventory inventory;
    [SerializeField] Crypto crypto;
    [SerializeField] DialogueActions dialogueActions;

    [Header("Quests")]
    [SerializeField] bool hasQuest = false;
    [SerializeField] bool canRollForQuests = true;
    [SerializeField] GameObject exclamationPoint;
    [SerializeField] int chanceToHaveQuest = 10;

    [Header("State")]
    [SerializeField] bool spokenTo = false;

    // Events
    [Header("Events")]
    public UnityEvent spokenToDuringCombat;

    // cache
    DialogueManager dialogueManager;
    QuestManager questManager;
    RoomManager roomManager;

    Quest npcQuest;

    public Dialogue Dialogue { get => dialogue; set => dialogue = value; }
    public bool Trader { get => trader; set => trader = value; }
    public bool HasQuest { get => hasQuest; set => hasQuest = value; }
    public Quest NpcQuest { get => npcQuest; set => npcQuest = value; }
    public DialogueActions DialogueActions { get => dialogueActions; set => dialogueActions = value; }

    protected override void Awake()
    {
        base.Awake();

        dialogueManager = FindObjectOfType<DialogueManager>();
        questManager = FindObjectOfType<QuestManager>();
        roomManager = FindObjectOfType<RoomManager>();
    }

    private void Start()
    {
        if (exclamationPoint)
        {
            if (canRollForQuests)
            {
                RollForQuest();

                if (HasQuest)
                {
                    exclamationPoint.SetActive(true);
                }
                else
                {
                    exclamationPoint.SetActive(false);
                }
            }
            else
            {
                exclamationPoint.SetActive(false);
            }
        }
    }

    public override void Interact()
    {
        // Early out if in combat and not allowed to speak in combat
        if (!allowDialogueInCombat && roomManager)
        {
            if (roomManager.InCombat())
            {
                spokenToDuringCombat.Invoke();
                return;
            }
        }

        dialogueManager.StartDialogue(this, spokenTo);

        if (Trader)
        {
            TradingManager tradingManager = FindObjectOfType<TradingManager>();
            tradingManager.npcInventory = inventory;
            tradingManager.npcCrypto = crypto;
        }

        spokenTo = true;
    }

    public void InvokeOnDialogueEndActions()
    {
        if (Dialogue.onDialogueEndActions.Count > 0)
        {
            DialogueActions.InvokeActions(Dialogue.onDialogueEndActions);
        }
    }

    void RollForQuest()
    {
        if (dialogue)
        {
            int roll = Random.Range(1, 101);
            if (roll <= chanceToHaveQuest)
            {
                HasQuest = true;
                NpcQuest = questManager.GenerateQuest(dialogue.npcName, "This is a quote from me, " + dialogue.npcName);

                return;
            }
        }

        HasQuest = false;
    }

    public void RemoveQuest()
    {
        HasQuest = false;
        NpcQuest = null;
        exclamationPoint.SetActive(false);
    }
}
