using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RewardChest : Interactable
{
    [SerializeField] GameObject rewardSelectionMenu;
    [SerializeField] float timeDelayBeforeMenuSpawn = 1f;
    [SerializeField] bool clicked = false;

    [Header("Cached References")]
    [SerializeField] Animator animator;

    // object references
    PlayerMovement playerMovement;
    RoomManager roomManager;

    protected override void Awake()
    {
        base.Awake();

        playerMovement = player.GetComponent<PlayerMovement>();
        roomManager = FindObjectOfType<RoomManager>();
    }

    public override void Interact()
    {
        if (!clicked)
        {
            StartCoroutine(PlayAnimationAndSpawnMenu());
        }
    }

    IEnumerator PlayAnimationAndSpawnMenu()
    {
        clicked = true;

        player.IsBusy = true;
        player.Character.Incapacitated = true;
        playerMovement.FreezeMovement();
        playerMovement.StopDustTrail();

        // play animation
        animator.Play("Open", -1, 0.0f);

        // wait for some time
        yield return new WaitForSeconds(timeDelayBeforeMenuSpawn);

        roomManager.ShowRewardSelectionMenu();
    }

    public void Exit()
    {
        // play animation
        animator.Play("Exit", -1, 0.0f);
    }
}
