using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpellTome : Usable
{
    [SerializeField] Spell spell;

    public override void Use()
    {
        Magic playerMagic = FindObjectOfType<Player>().GetComponent<Magic>();

        PlayUseSound();

        if (!playerMagic.SpellList.Exists(x => x.SpellID == spell.SpellID))
        {
            // add spell data to list
            FindObjectOfType<Player>().GetComponent<Magic>().AddSpell(spell);
        }
    }
}