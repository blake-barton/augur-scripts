using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GossamerClot : Usable
{
    [SerializeField] int levelsToAward = 10;

    public override void Use()
    {
        base.Use();

        int gossamerAmount = 0;
        for (int i = playerAttributes.level; i < playerAttributes.level + levelsToAward + 1; i++)
        {
            gossamerAmount += AttributeScores.GetLevelCost(i);
        }

        playerCrypto.AddCurrency(gossamerAmount);

        PlayUseSound();
    }
}
