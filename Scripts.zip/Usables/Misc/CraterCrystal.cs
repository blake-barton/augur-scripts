using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CraterCrystal : Usable
{
    [SerializeField] int augmentationPoints = 1;

    public override void Use()
    {
        base.Use();

        playerAugmentations.AugmentationPoints += augmentationPoints;

        PlayUseSound();
    }
}
