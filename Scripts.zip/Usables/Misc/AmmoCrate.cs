using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AmmoCrate : Usable
{
    [System.Serializable]
    public struct AmmoPair
    {
        public Ammo ammoType;
        public int quantity;
    }

    [SerializeField] List<AmmoPair> ammoPairs;

    public override void Use()
    {
        base.Use();

        foreach (AmmoPair pair in ammoPairs)
        {
            roomManager.SpawnItemNearPlayer(pair.ammoType, pair.quantity);
        }

        PlayUseSound();
    }
}
