using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MPHypo : Usable
{
    [SerializeField] [Range(0, 1)] float percentage = .3f;

    public override void Use()
    {
        base.Use();

        Magic magic = player.GetComponent<Magic>();

        magic.IncreaseMagicByFractionOfMax(percentage + playerAttributes.consumableMod / 100);

        PlayUseSound();
    }
}
