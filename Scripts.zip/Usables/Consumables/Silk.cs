using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Silk : Usable
{
    [SerializeField] [Range(0, 1)] float percentage = .3f;

    public override void Use()
    {
        base.Use();

        Focus focus = player.GetComponent<Focus>();

        focus.IncreaseFocusByFractionOfMax(percentage + playerAttributes.consumableMod / 100);

        PlayUseSound();
    }
}
