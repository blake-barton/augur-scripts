using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Medkit : Usable
{
    [SerializeField] [Range(0, 1)] float percentage = .3f;

    public override void Use()
    {
        base.Use();

        Health health = player.GetComponent<Health>();

        health.IncreaseHealthByFractionOfMax(percentage + playerAttributes.consumableMod / 100);

        PlayUseSound();
    }
}