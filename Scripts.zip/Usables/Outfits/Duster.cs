using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Duster : Usable
{
    [SerializeField] Outfit outfitData;

    public override void Use()
    {
        GetComponent<OutfitSetup>().InitializeOutfit(outfitData);

        // call any bonus functions associated with the outfit
    }
}
