using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OutfitSetup : MonoBehaviour
{
    public void InitializeOutfit(Outfit outfit)
    {
        Player player = FindObjectOfType<Player>();
        SpriteRenderer mainArm = player.GetComponent<PlayerMovement>().mainhandSpriteRenderer;
        SpriteRenderer offArm = player.GetComponent<PlayerMovement>().offhandSpriteRenderer;

        // change player's sprite to given outfit (PUT THE FIRST THREE FUNCTIONS INTO ANOTHER PARENT CLASS THAT DERIVES USABLE)
        SpriteRenderer playerRenderer = player.GetComponent<SpriteRenderer>();
        playerRenderer.sprite = outfit.WornSprite;
        mainArm.sprite = outfit.MainhandArm;
        offArm.sprite = outfit.OffhandArm;

        // change animations and whatnot
        Animator playerAnimator = player.GetComponent<Animator>();
        playerAnimator.runtimeAnimatorController = outfit.animatorController;

        // Alter resistances, immunities, etc.
        DamageEffects damageEffects = player.GetComponent<DamageEffects>();

        // remove damage effects
        InitializeNoOutfit();

        // set damage effects
        CloneList(outfit.Resistances, damageEffects.Resistances);
        CloneList(outfit.Immunities, damageEffects.Immunities);
        CloneList(outfit.Vulnerabilities, damageEffects.Vulnerabilities);
    }

    public static void InitializeNoOutfit()
    {
        Player player = FindObjectOfType<Player>();
        DamageEffects playerEffects = player.GetComponent<DamageEffects>();

        // damage effects
        playerEffects.Resistances.Clear();
        playerEffects.Immunities.Clear();
        playerEffects.Vulnerabilities.Clear();

        // clear other special functions
    }

    private void CloneList(List<DamageEffects.DamageType> oldList, List<DamageEffects.DamageType> newList) 
    {
        foreach (DamageEffects.DamageType oldType in oldList)
        {
            newList.Add(oldType);
        }
    }
}
