using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Usable : MonoBehaviour
{
    [SerializeField] Misc itemTemplate;
    [SerializeField] float usageDelayInSeconds = .5f;
    [SerializeField] protected AudioClip useSound;
    [SerializeField] [Range(0, 1)] protected float useVolume = .5f;

    protected RoomManager roomManager;
    protected Player player;
    protected AttributeScores playerAttributes;
    protected PlayerMovement playerMovement;
    protected Augmentations playerAugmentations;
    protected Crypto playerCrypto;
    protected Inventory playerInventory;

    TabMenuManager tabMenuManager;

    public virtual void Use() 
    {
        tabMenuManager = FindObjectOfType<TabMenuManager>();
        roomManager = FindObjectOfType<RoomManager>();
        player = FindObjectOfType<Player>();
        playerAttributes = player.GetComponent<AttributeScores>();
        playerMovement = player.GetComponent<PlayerMovement>();
        playerAugmentations = player.GetComponent<Augmentations>();
        playerCrypto = player.GetComponent<Crypto>();
        playerInventory = player.GetComponent<Inventory>();

        // if flagged for consumable animation, reenable play and play animation before allowing for effects
        if (itemTemplate.RequiresConsumableAnimation)
        {
            // exit menu (if in menu)
            tabMenuManager.ExitMenu();

            // freeze player
            playerMovement.FreezeMovement();

            // hide equipped and mark player as busy
            playerMovement.HideEquipped();
            player.Character.Incapacitated = true;

            // play consumable animation
            player.PlayConsumableAnimation();

            // delay consumable use
        }
    }

    protected void PlayUseSound()
    {
        if (useSound)
            GameObject.FindWithTag("UISound").GetComponent<AudioSource>().PlayOneShot(useSound, useVolume);
    }
}