using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FocusImplantEquip : Usable
{
    [SerializeField] FocusImplant focusImplant;
    [SerializeField] AudioClip activateSound;
    [SerializeField] [Range(0, 1)] float activateVolume = .5f;
    [SerializeField] AudioClip deactivateSound;
    [SerializeField] [Range(0, 1)] float deactivateVolume = .5f;

    public override void Use()
    {
        Focus focus = FindObjectOfType<Player>().GetComponent<Focus>();
        focus.focusImplant = focusImplant;
        focus.activateSound = activateSound;
        focus.activateVolume = activateVolume;
        focus.deactivateSound = deactivateSound;
        focus.deactivateVolume = deactivateVolume;
    }
}