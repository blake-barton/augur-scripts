using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class DialogueActions : MonoBehaviour
{
    public Dictionary<string, TextAdventureAction> dialogueActions;

    protected virtual void Awake()
    {
        LoadActions();
    }

    /// <summary>
    /// Creates the functions for each dialogue action
    /// </summary>
    protected abstract void LoadActions();

    /// <summary>
    /// Invoke the action that has the given key.
    /// </summary>
    public void InvokeAction(string action)
    {
        if (dialogueActions.ContainsKey(action))
        {
            dialogueActions[action].Invoke();
        }
        else
        {
            Debug.LogError("Could not find a dialogue action with key: " + action);
        }
    }

    public void InvokeActions(List<string> actions)
    {
        if (actions.Count > 0)
        {
            foreach (string action in actions)
            {
                InvokeAction(action);
            }
        }
        else
        {
            Debug.LogWarning("Passed in empty list of dialogue action strings.");
        }
    }
}
