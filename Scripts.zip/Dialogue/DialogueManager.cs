using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class DialogueManager : MonoBehaviour
{
    [Header("Objects")]
    [SerializeField] GameObject dialogueBox;
    [SerializeField] TextMeshProUGUI npcName;
    [SerializeField] TextMeshProUGUI dialogueText;
    [SerializeField] Transform responseGroup;
    [SerializeField] GameObject responseTemplate;

    [Header("Trading")]
    [SerializeField] GameObject tradingButton;

    [Header("Quests")]
    [SerializeField] GameObject questButton;

    [Header("State")]
    [SerializeField] bool displayingResponses = false;
    [SerializeField] bool firstPrompt = true;   // used so that E can be used for initiating and advanced dialogue
    [SerializeField] bool isTextScrolling = false; 

    [Header("Audio")]
    [SerializeField] AudioClip textScrollBeep;
    [SerializeField] [Range(0, 1)] float textScrollBeepVolume = 1f;

    [Header("Cached References")]
    [SerializeField] AudioSource audioSource;
    [SerializeField] HUDManager HUD;
    [SerializeField] TradingManager tradingManager;
    [SerializeField] CameraTarget cameraTarget;
    [SerializeField] QuestGuiManager questGuiManager;

    Queue<string> sentences = new Queue<string>();
    Prompt currentPrompt;
    string currentSentence;

    DialogueTrigger dialogueOwner;

    // cache
    Player player;
    PlayerMovement playerMovement;

    public DialogueTrigger DialogueOwner { get => dialogueOwner; set => dialogueOwner = value; }

    private void Awake()
    {
        player = FindObjectOfType<Player>();
        playerMovement = player.GetComponent<PlayerMovement>();
    }

    private void Start()
    {
        dialogueBox.SetActive(false);
        audioSource.clip = textScrollBeep;
        audioSource.volume = textScrollBeepVolume;
    }

    private void Update()
    {
        HandleInput();
    }

    private void HandleInput()
    {
        if (player.InDialogue)
        {
            // press E or left click to advance dialogue if not displaying responses
            if (!displayingResponses)
            {
                if (Input.GetMouseButtonDown(0) || (Input.GetKeyDown(KeyCode.E) && !firstPrompt))
                {
                    if (isTextScrolling)
                    {
                        // Text is printing out. Finish it early.
                        SkipTextScroll();
                    }
                    else
                    {
                        // Text is done printing. Go to next sentence.
                        DisplayNextSentence();
                    }
                }
            }

            // Quick exit dialogue
            if ((Input.GetKeyDown(KeyCode.Tab) || Input.GetKeyDown(KeyCode.Escape)) && !tradingManager.IsTrading && !questGuiManager.IsInQuestSelection)
            {
                // stop audio scroll
                StopAllCoroutines();
                audioSource.Stop();
                isTextScrolling = false;

                StartCoroutine(EndDialogueWithDelay());
            }
        }
    }

    public void StartDialogue(DialogueTrigger _dialogueOwner, bool spokenTo)
    {
        DialogueOwner = _dialogueOwner;

        // disable input
        player.InDialogue = true;
        player.IsBusy = true;

        // stop movement
        playerMovement.FreezeMovement();
        playerMovement.StopDustTrail();

        // hide HUD
        HUD.ToggleHUD();

        // move camera to NPC
        cameraTarget.LockToTransform(DialogueOwner.transform);

        // empty queue of old dialogue
        sentences.Clear();
        
        // show dialogue box and set name
        dialogueBox.SetActive(true);
        npcName.text = DialogueOwner.Dialogue.npcName;

        if (spokenTo && DialogueOwner.Dialogue.spokenToGreetingPrompt)
        {
            // load in spoken to prompt
            DisplayPrompt(DialogueOwner.Dialogue.spokenToGreetingPrompt);
        }
        else
        {
            // load in first prompt
            DisplayPrompt(DialogueOwner.Dialogue.greetingPrompt);
        }
    }

    public void DisplayPrompt(Prompt prompt)
    {
        ClearResponses();

        // disable trading button
        tradingButton.SetActive(false);

        // disable quest button
        questButton.SetActive(false);

        displayingResponses = false;
        currentPrompt = prompt;

        // Trigger any dialogue actions associated with this prompt
        if (currentPrompt.onPromptDisplayedDialogueActions.Count > 0 && DialogueOwner.DialogueActions)
        {
            DialogueOwner.DialogueActions.InvokeActions(currentPrompt.onPromptDisplayedDialogueActions);
        }

        // show a sentence in the prompt, then wait for player input until the next one
        foreach (string sentence in prompt.sentences)
        {
            sentences.Enqueue(sentence);
        }

        DisplayNextSentence();
    }

    public void DisplayResponses(Prompt prompt)
    {
        if (prompt.responses.Count == 0 && !prompt.useReturnPrompt)
        {
            // no responses, end dialogue
            StartCoroutine(EndDialogueWithDelay());
        }

        // clear the box of any text
        dialogueText.text = "";

        displayingResponses = true;

        // show trading button
        if (DialogueOwner.Trader)
        {
            tradingButton.SetActive(true);
        }

        // show quest button
        if (DialogueOwner.HasQuest)
        {
            questButton.SetActive(true);
        }

        foreach (Response response in prompt.responses)
        {
            // instantiate response
            GameObject responseButton = Instantiate(responseTemplate, responseGroup);

            // set response text
            responseButton.transform.GetChild(0).GetComponent<TextMeshProUGUI>().text = response.text;

            // set response and pass in dialogue actions
            ResponseClickable newClickable = responseButton.GetComponent<ResponseClickable>();
            newClickable.response = response;
            newClickable.DialogueActions = DialogueOwner.DialogueActions;
        }
    }

    public void DisplayNextSentence()
    {
        // stop audio scroll
        StopAllCoroutines();
        audioSource.Stop();
        isTextScrolling = false;

        // no longer on the first prompt
        firstPrompt = false;

        // if out of sentences, display responses
        if (sentences.Count == 0)
        {
            if (currentPrompt.useReturnPrompt)
            {
                // automatically jump to prompt
                DisplayPrompt(currentPrompt.returnPrompt);
            }
            else
            {
                DisplayResponses(currentPrompt);
            }
        }
        else
        {
            // change dialogue text
            string sentence = sentences.Dequeue();
            currentSentence = sentence;
            StartCoroutine(TypeOutText(sentence));
        }
    }

    IEnumerator TypeOutText(string text)
    {
        isTextScrolling = true;

        dialogueText.text = "";
        foreach (char letter in text.ToCharArray())
        {
            dialogueText.text += letter;
            audioSource.Play();
            yield return null;
        }

        isTextScrolling = false;
    }

    void SkipTextScroll()
    {
        // stop audio scroll
        StopAllCoroutines();
        audioSource.Stop();
        isTextScrolling = false;

        dialogueText.text = currentSentence;
    }

    public void EndDialogue()
    {
        ClearResponses();
        dialogueBox.SetActive(false);

        // Invoke any OnDialogueEnd dialogue actions
        DialogueOwner.InvokeOnDialogueEndActions();

        // enable mouse look
        cameraTarget.EnableMouseLook();

        // show HUD
        HUD.ToggleHUD();

        // enable input
        player.InDialogue = false;
        player.IsBusy = false;
        firstPrompt = true;

        // fix audiosource
        audioSource.volume = 1f;

        playerMovement.PlayDustTrail();
    }

    IEnumerator EndDialogueWithDelay()
    {
        ClearResponses();
        dialogueBox.SetActive(false);

        // show HUD
        HUD.ToggleHUD();

        // enable mouse look
        cameraTarget.EnableMouseLook();

        yield return new WaitForSeconds(.1f);

        player.InDialogue = false;
        player.IsBusy = false;
        firstPrompt = true;
    }

    private void ClearResponses()
    {
        // destroy all responses
        foreach (Transform child in responseGroup)
        {
            Destroy(child.gameObject);
        }
    }

    public void HideDialogue()
    {
        dialogueBox.SetActive(false);
    }

    public void UnhideDialogue()
    {
        dialogueBox.SetActive(true);
    }

    public void HideQuestButton()
    {
        questButton.SetActive(false);
    }
}
