using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class Response
{
    [TextArea(3, 5)]
    public string text;

    public bool goodbye = false;

    public Prompt nextPrompt;

    public List<string> dialogueActions = new();
}
