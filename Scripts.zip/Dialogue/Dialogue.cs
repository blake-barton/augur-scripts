using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Dialogue")]
public class Dialogue : ScriptableObject
{
    public string npcName;
    public Prompt greetingPrompt;
    public Prompt spokenToGreetingPrompt;

    [Header("Dialogue Actions")]
    public List<string> onDialogueEndActions = new List<string>();
}
