using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class ResponseClickable : MonoBehaviour, IPointerClickHandler, IPointerEnterHandler, IPointerExitHandler
{
    public Response response;
    DialogueActions dialogueActions;    // Added by dialogue manager on instantiation

    [Header("State")]
    [SerializeField] bool hovered = false;

    // cache
    DialogueManager dialogueManager;

    public DialogueActions DialogueActions { get => dialogueActions; set => dialogueActions = value; }

    void Awake()
    {
        dialogueManager = FindObjectOfType<DialogueManager>();
    }

    void Update()
    {
        if (hovered && Input.GetKeyDown(KeyCode.E))
        {
            HandleInput();
        }
    }

    public void OnPointerClick(PointerEventData eventData)
    {
        HandleInput();
    }

    void HandleInput()
    {
        // Call this response's dialogue actions if it has any
        if (response.dialogueActions.Count > 0 && DialogueActions)
        {
            DialogueActions.InvokeActions(response.dialogueActions);
        }

        if (response.goodbye)
        {
            dialogueManager.EndDialogue();
        }
        else
        {
            dialogueManager.DisplayPrompt(response.nextPrompt);
        }
    }

    public void OnPointerEnter(PointerEventData eventData)
    {
        hovered = true;
    }

    public void OnPointerExit(PointerEventData eventData)
    {
        hovered = false;
    }
}
