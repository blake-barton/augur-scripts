using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Prompt")]
public class Prompt : ScriptableObject
{
    [TextArea(3, 5)]
    public string[] sentences;

    public List<Response> responses = new List<Response>();
    public bool useReturnPrompt = false;
    public Prompt returnPrompt;

    [Header("Dialogue Actions")]
    public List<string> onPromptDisplayedDialogueActions = new();
}
