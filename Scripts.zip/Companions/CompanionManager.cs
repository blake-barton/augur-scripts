using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CompanionManager : MonoBehaviour
{
    [SerializeField] List<GameObject> companionPrefabs = new();

    [Header("Cached References")]
    [SerializeField] Transform companionSpawnPoint;

    List<Companion> activeCompanions = new();

    public List<Companion> ActiveCompanions { get => activeCompanions; set => activeCompanions = value; }

    public void RegisterCompanion(Companion companion)
    {
        ActiveCompanions.Add(companion);
    }

    public void UnregisterCompanion(Companion companion)
    {
        ActiveCompanions.Remove(companion);
    }

    public void SpawnCompanion(int companionID)
    {
        if (companionID >= 0)
        {
            GameObject newCompanion = companionPrefabs[companionID];

            // Instantiate at spawn point
            Instantiate(newCompanion, companionSpawnPoint.position, Quaternion.identity);
        }
        else
        {
            Debug.LogError("Invalid companion ID: " + companionID);
        }
    }
}
