using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Companion : MonoBehaviour
{
    [SerializeField] int companionID = -1;

    CompanionManager companionManager;

    public int CompanionID { get => companionID; set => companionID = value; }

    private void Awake()
    {
        companionManager = FindObjectOfType<CompanionManager>();
    }

    // Start is called before the first frame update
    void Start()
    {
        companionManager.RegisterCompanion(this);
    }

    /// <summary>
    /// Invoked by UnityEvent. Unregisters this companion from the active companions list.
    /// </summary>
    public void OnCompanionDeath()
    {
        companionManager.UnregisterCompanion(this);
    }
}
