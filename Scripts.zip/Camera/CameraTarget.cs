using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraTarget : MonoBehaviour
{
    [SerializeField] Camera mCamera;
    [SerializeField] Player player;
    [SerializeField] Transform playerTransform;
    [SerializeField] float threshold;

    [Header("Lock On")]
    [SerializeField] float moveSpeed;
    [SerializeField] Transform lockTransform;

    [Header("Gamepad")]
    [SerializeField] Transform gamepadTarget;

    [Header("State")]
    [SerializeField] bool mouseLook = true;
    [SerializeField] bool lockingToTransform = false;

    private void Update()
    {
        if (mouseLook)
        {
            if (player.IsGamepad)
            {
                // Use the gamepad orbiter
                Vector3 gamepadTargetPos = gamepadTarget.position;

                // target is where the camera is centered
                Vector3 targetPosition = (playerTransform.position + gamepadTargetPos) / 2f;

                // target cannot go beyond the threshold from the player
                targetPosition.x = Mathf.Clamp(targetPosition.x, -threshold + playerTransform.position.x, threshold + playerTransform.position.x);
                targetPosition.y = Mathf.Clamp(targetPosition.y, -threshold + playerTransform.position.y, threshold + playerTransform.position.y);

                transform.position = targetPosition;
            }
            else
            {
                // get mouse pos in world coordinates
                Vector3 mousePos = mCamera.ScreenToWorldPoint(Input.mousePosition);

                // target is where the camera is centered
                Vector3 targetPosition = (playerTransform.position + mousePos) / 2f;

                // target cannot go beyond the threshold from the player
                targetPosition.x = Mathf.Clamp(targetPosition.x, -threshold + playerTransform.position.x, threshold + playerTransform.position.x);
                targetPosition.y = Mathf.Clamp(targetPosition.y, -threshold + playerTransform.position.y, threshold + playerTransform.position.y);

                transform.position = targetPosition;
            }
        }
        else if (lockingToTransform)
        {
            float step = moveSpeed * Time.deltaTime;

            transform.position = Vector2.MoveTowards(transform.position, lockTransform.position, step);
        }
    }

    public void LockToTransform(Transform _lockTransform)
    {
        mouseLook = false;
        lockingToTransform = true;

        lockTransform = _lockTransform;
    }

    public void EnableMouseLook()
    {
        lockingToTransform = false;
        mouseLook = true;
    }
}
