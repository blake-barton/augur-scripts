using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Cinemachine;

public class ShakeBehavior : MonoBehaviour
{
    [SerializeField] float shakeTimer;
    float shakeTimerTotal;
    float startingIntensity;
    CinemachineVirtualCamera virtualCamera;
    CinemachineBasicMultiChannelPerlin noiseMaker;

    private void Awake()
    {
        virtualCamera = GetComponent<CinemachineVirtualCamera>();
        noiseMaker = virtualCamera.GetCinemachineComponent<CinemachineBasicMultiChannelPerlin>();
    }

    private void Update()
    {
        ResetCameraOverTime();
    }

    private void ResetCameraOverTime()
    {
        if (shakeTimer > 0)
        {
            shakeTimer -= Time.deltaTime;
            noiseMaker.m_AmplitudeGain = Mathf.Lerp(startingIntensity, 0f, 1 - (shakeTimer / shakeTimerTotal));
        }
    }

    public void ShakeCamera(float intensity, float time)
    {
        noiseMaker.m_AmplitudeGain = intensity;

        startingIntensity = intensity;
        shakeTimerTotal = time;
        shakeTimer = time;
    }
}
