using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    [SerializeField] Vector3 offset = new Vector3();

    //
    Camera m_camera;

    private void Start()
    {
        m_camera = Camera.main;
    }

    // Update is called once per frame
    void LateUpdate()
    {
        m_camera.transform.position = transform.position + offset;
    }
}
