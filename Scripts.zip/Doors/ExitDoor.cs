using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ExitDoor : MonoBehaviour
{
    [SerializeField] string sceneName;
    [SerializeField] string doorName;
    [SerializeField] List<int> rewardItemIDs;
    [SerializeField] SpriteRenderer categoryPreview;

    [Header("Player Movement")]
    [SerializeField] bool playAnimation = true;
    [SerializeField] bool forceMovement = false;
    [SerializeField] Vector2 exitDirection = new Vector2(0, 0);
    [SerializeField] float moveTime = 4f;

    [Header("Audio")]
    [SerializeField] AudioSource audioSource;
    [SerializeField] AudioClip doorOpenClip;
    [SerializeField] [Range(0, 1)] float doorOpenVolume = .5f;
    [SerializeField] AudioClip doorCloseClip;
    [SerializeField] [Range(0, 1)] float doorCloseVolume = .5f;

    SceneLoader sceneLoader;
    Animator animator;
    BoxCollider2D boxCollider;

    public string SceneName { get => sceneName; set => sceneName = value; }
    public List<int> RewardItemIDs { get => rewardItemIDs; set => rewardItemIDs = value; }

    private void Awake()
    {
        sceneLoader = FindObjectOfType<SceneLoader>();
        animator = GetComponent<Animator>();
        boxCollider = GetComponent<BoxCollider2D>();
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        // play player's exit animation
        Player player = collision.gameObject.GetComponent<Player>();

        if (playAnimation)
        {
            player.PlayExitRoomAnimation();
        }

        if (forceMovement)
        {
            player.GetComponent<PlayerMovement>().ForceMovement(exitDirection, moveTime);
        }

        // when the player enters this door, transition to the next scene
        sceneLoader.LoadSceneByName(sceneName, rewardItemIDs, doorName);
    }

    public void SetCategoryPreviewSprite(Sprite sprite)
    {
        categoryPreview.sprite = sprite;
    }

    public void OpenDoor()
    {
        animator.SetTrigger("GateOpen");
        boxCollider.enabled = true;

        AudioUtility.PlaySound(audioSource, doorOpenClip, doorOpenVolume);
    }

    public void CloseDoor()
    {
        animator.SetTrigger("GateClose");
        boxCollider.enabled = false;

        AudioUtility.PlaySound(audioSource, doorCloseClip, doorCloseVolume);
    }
}