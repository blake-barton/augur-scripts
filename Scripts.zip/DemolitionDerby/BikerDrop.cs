using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BikerDrop : MonoBehaviour
{
    enum DropFunction
    {
        AddHealth,
        LoadPistol,
        LoadShotgun,
        LoadMachinePistol
    }

    [SerializeField] DropFunction function;
    [SerializeField] int healthToAdd = 1;
    [SerializeField] RangedWeapon pistol;
    [SerializeField] RangedWeapon shotgun;
    [SerializeField] RangedWeapon machinePistol;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        PlayerBiker player = collision.gameObject.GetComponent<PlayerBiker>();

        if (player)
        {
            switch (function)
            {
                case DropFunction.AddHealth:
                    player.CurrentHealth += healthToAdd;
                    player.PlayHealSound();
                    break;
                case DropFunction.LoadPistol:
                    player.WeaponStats = pistol;
                    player.ShotAudio = pistol.ShotAudio;
                    player.StopSpawningFullAuto(false);
                    player.PlayWeaponEquipSound();
                    break;
                case DropFunction.LoadShotgun:
                    player.WeaponStats = shotgun;
                    player.ShotAudio = shotgun.ShotAudio;
                    player.StopSpawningFullAuto(false);
                    player.PlayWeaponEquipSound();
                    break;
                case DropFunction.LoadMachinePistol:
                    player.WeaponStats = machinePistol;
                    player.ShotAudio = machinePistol.ShotAudio;
                    player.ShotLoopAudio = machinePistol.ShotLoopAudio;
                    player.PlayWeaponEquipSound();
                    break;
            }

            Destroy(gameObject);
        }
    }
}
