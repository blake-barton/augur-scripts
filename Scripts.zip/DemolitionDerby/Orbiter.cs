using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Orbiter : MonoBehaviour
{
    public enum OrbiterType
    {
        Player,
        Enemy
    }

    [SerializeField] OrbiterType orbiterType;

    [Header("Rotation")]
    [SerializeField] float radius = 0.5f;

    [Header("Cache")]
    [SerializeField] LineOfSight lineOfSight;

    Transform target;
    Transform pivot;

    // Start is called before the first frame update
    void Awake()
    {
        // rotation
        target = transform.parent;
        pivot = new GameObject().transform;
        pivot.name = "Equipped Item";
        pivot.parent = target.transform;
        transform.parent = pivot;
    }

    // Update is called once per frame
    void Update()
    {
        switch (orbiterType)
        {
            case OrbiterType.Player:
                RotateAroundPlayer();
                break;
            case OrbiterType.Enemy:
                RotateAroundOwnerTowardsTarget();
                break;
        }
    }

    void RotateAroundPlayer()
    {
        Vector3 v3Pos = Camera.main.WorldToScreenPoint(target.position);
        v3Pos = Input.mousePosition - v3Pos;
        float angle = Mathf.Atan2(v3Pos.y, v3Pos.x) * Mathf.Rad2Deg;

        v3Pos = Quaternion.AngleAxis(angle, Vector3.forward) * (Vector3.right * radius);
        transform.position = target.position + v3Pos;

        pivot.SetPositionAndRotation(target.position, Quaternion.AngleAxis(angle, Vector3.forward));
    }

    void RotateAroundOwnerTowardsTarget()
    {
        if (lineOfSight.Target)
        {
            Vector3 v3Pos = Camera.main.WorldToScreenPoint(lineOfSight.Target.position) - Camera.main.WorldToScreenPoint(target.position);
            float angle = Mathf.Atan2(v3Pos.y, v3Pos.x) * Mathf.Rad2Deg;

            v3Pos = Quaternion.AngleAxis(angle, Vector3.forward) * (Vector3.right * radius);
            transform.position = target.position + v3Pos;

            pivot.SetPositionAndRotation(target.position, Quaternion.AngleAxis(angle, Vector3.forward));
        }
    }

    public Quaternion GetPivotRotation()
    {
        return pivot.rotation;
    }
}
