using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObstacleMovement : MonoBehaviour
{
    [SerializeField] float xSpeed = -13f;
    [SerializeField] float ySpeed = 0f;
    [SerializeField] int wallLayer = 21;

    [Header("Speed Limits")]
    [SerializeField] bool clampSpeed = false;
    [SerializeField] float xSpeedMin = -13f;
    [SerializeField] float xSpeedMax = 0f;

    [Header("Deceleration")]
    [SerializeField] float speedDecreasePerSecond;
    [SerializeField] float speedDecreaseTicksPerSecond;

    [Header("State")]
    [SerializeField] bool movementEnabled = true;

    public float XSpeed { get => xSpeed; set => xSpeed = value; }
    public float YSpeed { get => ySpeed; set => ySpeed = value; }

    // Update is called once per frame
    void Update()
    {
        if (movementEnabled)
        {
            Move();
        }
    }

    void Move()
    {
        float xMovement = XSpeed;
        float yMovement = YSpeed;

        // multiply by delta time so speed is not tied to frame rate.
        xMovement *= Time.deltaTime;
        yMovement *= Time.deltaTime;

        // move
        transform.Translate(xMovement, yMovement, 0);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.layer == wallLayer)
        {
            Destroy(gameObject);
        }
    }

    public void AddToXSpeed(float x)
    {
        XSpeed += x;

        if (clampSpeed)
        {
            XSpeed = Mathf.Clamp(XSpeed, xSpeedMin, xSpeedMax);
        }
    }

    public void TriggerSlowdown()
    {
        StartCoroutine(SlowToStop());
    }

    IEnumerator SlowToStop()
    {
        float speedDecreasePerTick = speedDecreasePerSecond / speedDecreaseTicksPerSecond;

        // loop forever
        while (true)
        {
            // still have enough focus points
            if (XSpeed <= 0)
            {
                XSpeed += speedDecreasePerTick;

                yield return new WaitForSeconds(1f / speedDecreaseTicksPerSecond);
            }
            else
            {
                XSpeed = 0;

                movementEnabled = false;

                yield break;
            }
        }
    }
}
