using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ProjectileBiker : MonoBehaviour
{
    [Header("Impact Effects")]
    [SerializeField] GameObject actorImpactEffect;
    [SerializeField] GameObject actorCritImpactEffect;
    [SerializeField] [Range(0, 31)] int enemyLayer = 9;
    [SerializeField] [Range(0, 31)] int playerLayer = 6;
    [SerializeField] GameObject wallImpactEffect;
    [SerializeField] [Range(0, 31)] int wallLayer = 10;

    float speed;
    Vector2 direction = new Vector2();
    RangedWeapon weaponStats;
    Rigidbody2D rb;

    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    private void FixedUpdate()
    {
        Travel();
    }

    void Travel()
    {
        rb.velocity = new Vector2(direction.x * speed, direction.y * speed);
    }

    public void SetAttributes(RangedWeapon rangedWeapon, Vector2 pivotDirection)
    {
        speed = rangedWeapon.ProjectileSpeed;
        weaponStats = rangedWeapon;
        direction = pivotDirection;
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        // spawn impact effect
        if ((collision.gameObject.layer == enemyLayer || collision.gameObject.layer == playerLayer) && actorImpactEffect)
        {
            Instantiate(actorImpactEffect, transform.position, Quaternion.identity);
        }
        else if ((collision.gameObject.layer == wallLayer) && wallImpactEffect)
        {
            // hit wall
            Vector2 n = collision.GetContact(0).normal.normalized;

            float angle = Mathf.Atan2(n.y, n.x) * Mathf.Rad2Deg - 90f;

            var newObject = Instantiate(wallImpactEffect, transform.position, Quaternion.identity);
            newObject.transform.rotation = Quaternion.AngleAxis(angle, Vector3.forward);
        }

        Destroy(gameObject);
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        Destroy(gameObject);
    }
}
