using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class SpriteScroller : MonoBehaviour
{
    [SerializeField] Vector2 moveSpeed;

    [Header("Finish")]
    [SerializeField] float speedDecreasePerSecond;
    [SerializeField] float speedDecreaseTicksPerSecond;

    public UnityEvent stoppedScrolling;

    Vector2 offset;
    Material material;

    private void Awake()
    {
        material = GetComponent<SpriteRenderer>().material;
    }

    // Update is called once per frame
    void Update()
    {
        offset = moveSpeed * Time.deltaTime;
        material.mainTextureOffset += offset;
    }

    public void TriggerSlowdown()
    {
        StartCoroutine(SlowToStop());
    }

    IEnumerator SlowToStop()
    {
        float speedDecreasePerTick = speedDecreasePerSecond / speedDecreaseTicksPerSecond;

        // loop forever
        while (true)
        {
            // still have enough focus points
            if (moveSpeed.x >= 0)
            {
                moveSpeed.x -= speedDecreasePerTick;

                yield return new WaitForSeconds(1f / speedDecreaseTicksPerSecond);
            }
            else
            {
                moveSpeed = Vector2.zero;
                stoppedScrolling.Invoke();

                yield break;
            }
        }
    }
}
