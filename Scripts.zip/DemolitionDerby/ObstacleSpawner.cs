using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObstacleSpawner : MonoBehaviour
{
    [SerializeField] List<Transform> spawnPoints = new List<Transform>();
    [SerializeField] List<GameObject> gameObjects = new List<GameObject>();

    [Header("Timing")]
    [SerializeField] float maxTimeToSpawn = 6f;
    [SerializeField] float minTimeToSpawn = 1f;

    [Header("Count")]
    [SerializeField] int minToSpawn = 1;
    [SerializeField] int maxToSpawn = 2;

    float timer;
    float timeToSpawn = 5f;

    public float MaxTimeToSpawn
    { 
        get => maxTimeToSpawn;
        set
        {
            maxTimeToSpawn = value;
            if (maxTimeToSpawn < minTimeToSpawn)
            {
                maxTimeToSpawn = minTimeToSpawn;
            }
        }
    }
    public float MinTimeToSpawn { get => minTimeToSpawn; set => minTimeToSpawn = value; }
    public int MinToSpawn { get => minToSpawn; set => minToSpawn = value; }
    public int MaxToSpawn { get => maxToSpawn; set => maxToSpawn = value; }

    private void Update()
    {
        timer += Time.deltaTime;

        if (timer >= timeToSpawn)
        {
            // reset timer
            timer = 0;
            timeToSpawn = Random.Range(MinTimeToSpawn, MaxTimeToSpawn);

            // spawn
            int numObstaclesToSpawn = Random.Range(MinToSpawn, MaxToSpawn);

            for (int i = 0; i < numObstaclesToSpawn; i++)
            {
                // pick a random spawn point and obstacle
                int spawnIndex = Random.Range(0, spawnPoints.Count);
                int obstacleIndex = Random.Range(0, gameObjects.Count);

                Instantiate(gameObjects[obstacleIndex], spawnPoints[spawnIndex].position, Quaternion.identity);
            }
        }
    }
}
