using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyBiker : MonoBehaviour
{
    [Header("Movement")]
    [SerializeField] float speed = 5;
    [SerializeField] float minTimeToMove = 0f;
    [SerializeField] float maxTimeToMove = 4f;
    [SerializeField] float mapSpeed = -13f;
    [SerializeField] float deathXSpeed;
    [SerializeField] float deathYSpeed;

    [Header("Weapon")]
    [SerializeField] RangedWeapon weaponStats;
    [SerializeField] GameObject projectile;
    [SerializeField] Vector3 projectileOffset = new Vector2();
    [SerializeField] Orbiter orbiter;
    [SerializeField] float minTimeToAttack = 2f;
    [SerializeField] float maxTimeToAttack = 5f;
    [SerializeField] float timeToTelegraphShot = 1f;
    [SerializeField] float fullAutoBurstTime = 2f;

    [Header("Health")]
    [SerializeField] int maxHealth = 3;
    [SerializeField] int currentHealth = 3;

    [Header("State")]
    [SerializeField] bool isAlive = true;
    [SerializeField] bool telegraphingAttack = false;

    [Header("Audio")]
    [SerializeField] AudioClip shotAudio;
    [SerializeField] [Range(0, 1)] float shotAudioVolume = 1f;
    [SerializeField] AudioClip[] deathAudioClips;
    [SerializeField] [Range(0, 1)] float deathAudioVolume = 1f;
    [SerializeField] AudioClip[] damageAudioClips;
    [SerializeField] [Range(0, 1)] float damageAudioVolume = 1f;

    // coroutines
    Coroutine firingCoroutine;

    // timers
    float moveTimer;
    float attackTimer;

    // variables
    float xMin;
    float yMin;
    float xMax;
    float yMax;
    float nextXPos;
    float nextYPos;
    Vector2 nextWayPoint;

    // cache
    Animator animator;
    Camera gameCamera;
    CapsuleCollider2D hitbox;
    FlashOnHit damageFlasher;
    LineOfSight lineOfSight;
    EnemyLoot enemyLoot;
    AudioSource audioSource;

    public int MaxHealth { get => maxHealth; set => maxHealth = value; }
    public int CurrentHealth { get => currentHealth; set => currentHealth = value; }
    public bool IsAlive { get => isAlive; set => isAlive = value; }

    private void Awake()
    {
        animator = GetComponent<Animator>();
        hitbox = GetComponent<CapsuleCollider2D>();
        damageFlasher = GetComponent<FlashOnHit>();
        lineOfSight = GetComponent<LineOfSight>();
        enemyLoot = GetComponent<EnemyLoot>();
        audioSource = GetComponent<AudioSource>();
    }

    // Start is called before the first frame update
    void Start()
    {
        gameCamera = Camera.main;
        SetUpMovementBoundaries();
        GenerateNextWayPoint();

        PlayerBiker player = FindObjectOfType<PlayerBiker>();
        if (player)
        {
            lineOfSight.Target = player.transform;
        }

        attackTimer = Random.Range(5f, 10f);  // let enemy get on screen
    }

    // Update is called once per frame
    void Update()
    {
        if (IsAlive)
        {
            Move();
            FindNextWayPoint();
            if (weaponStats && lineOfSight.Target)
            {
                CountDownAndFire();
            }
            Animate();
        }
        else
        {
            MoveAutomatically();
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        BikerDamageDealer damageDealer = collision.gameObject.GetComponent<BikerDamageDealer>();

        if (damageDealer)
        {
            TakeDamage(damageDealer);
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        BikerDamageDealer damageDealer = collision.gameObject.GetComponent<BikerDamageDealer>();

        if (damageDealer)
        {
            TakeDamage(damageDealer);
        }
    }

    private void Move()
    {
        float movementThisFrame = speed * Time.deltaTime;
        transform.position = Vector2.MoveTowards(transform.position, nextWayPoint, movementThisFrame);
    }

    private void FindNextWayPoint()
    {
        moveTimer -= Time.deltaTime;
        if (moveTimer <= 0 && (Vector2)transform.position == nextWayPoint)
        {
            GenerateNextWayPoint();
            moveTimer = Random.Range(minTimeToMove, maxTimeToMove);
        }
    }

    void MoveAutomatically()
    {
        float xMovement = deathXSpeed;
        float yMovement = deathYSpeed;

        // multiply by delta time so speed is not tied to frame rate.
        xMovement *= Time.deltaTime;
        yMovement *= Time.deltaTime;

        // move
        transform.Translate(xMovement, yMovement, 0);
    }

    void CountDownAndFire()
    {
        attackTimer -= Time.deltaTime;

        if (attackTimer <= 0 && (lineOfSight.GetDistanceToTarget() <= weaponStats.MaxRange))
        {
            telegraphingAttack = false;

            attackTimer = Random.Range(minTimeToAttack, maxTimeToAttack);   // add time to wait until next shot

            if (weaponStats.IsAutomatic)
            {
                animator.Play("FireFullAuto", -1, 0.0f);

                StartCoroutine(FireFullAuto());
            }
            else
            {
                animator.Play("Fire", -1, 0.0f);
                audioSource.PlayOneShot(shotAudio, shotAudioVolume);

                for (int i = 0; i < weaponStats.ProjectilesPerShot; i++)
                {
                    SpawnProjectile();
                }
            }
        }
        else if (attackTimer <= timeToTelegraphShot && !telegraphingAttack)
        {
            telegraphingAttack = true;

            // play gun raised animation
            animator.Play("AttackTelegraph", -1, 0.0f);
        }
    }

    void SpawnProjectile()
    {
        GameObject firedProjectile = Instantiate(projectile, transform.position + projectileOffset, orbiter.GetPivotRotation());

        // add spread to projectile and set attributes
        firedProjectile.transform.Rotate(0, 0, GetRandomizedProjectileSpread());
        SetProjectileAttributes(firedProjectile);
    }

    public void StopSpawningFullAuto()
    {
        if (!(firingCoroutine is null))
        {
            StopCoroutine(firingCoroutine);
        }
    }

    IEnumerator FireFullAuto()
    {
        firingCoroutine = StartCoroutine(SpawnProjectileFullAuto());

        // continue firing unless enemy is knocked down or killed
        for (float timer = fullAutoBurstTime; timer >= 0; timer -= Time.deltaTime)
        {
            if (!isAlive)
            {
                StopSpawningFullAuto();
                yield break;
            }
            yield return null;
        }

        StopSpawningFullAuto();

        animator.Play("AimGun", -1, 0.0f);
    }

    IEnumerator SpawnProjectileFullAuto()
    {
        while (true)
        {
            audioSource.PlayOneShot(shotAudio, shotAudioVolume);
            SpawnProjectile();

            yield return new WaitForSeconds(1 / weaponStats.AttackRate);
        }
    }

    private void GenerateNextWayPoint()
    {
        nextXPos = Random.Range(xMin, xMax);
        nextYPos = Random.Range(yMin, yMax);

        nextWayPoint = new Vector2(nextXPos, nextYPos);
    }

    private void SetUpMovementBoundaries()
    {
        xMin = gameCamera.ViewportToWorldPoint(new Vector3(0, 0, 0)).x;
        yMin = gameCamera.ViewportToWorldPoint(new Vector3(0, 0, 0)).y;

        xMax = gameCamera.ViewportToWorldPoint(new Vector3(1, 0, 0)).x;
        yMax = gameCamera.ViewportToWorldPoint(new Vector3(0, 1, 0)).y;
    }

    float GetRandomizedProjectileSpread()
    {
        return Random.Range(-weaponStats.Spread, weaponStats.Spread);
    }

    private void SetProjectileAttributes(GameObject firedProjectile)
    {
        float zAngle = firedProjectile.transform.rotation.eulerAngles.z * (Mathf.PI / 180f);
        float xComponent = Mathf.Cos(zAngle);
        float yComponent = Mathf.Sin(zAngle);
        Vector2 pivotDirection = new Vector2(xComponent, yComponent);

        firedProjectile.GetComponent<ProjectileBiker>().SetAttributes(weaponStats, pivotDirection);
    }

    void TakeDamage(BikerDamageDealer damageDealer)
    {
        if (isAlive)
        {
            CurrentHealth -= damageDealer.Damage;

            AudioUtility.PlayRandomSound(audioSource, damageAudioClips, damageAudioVolume);

            damageFlasher.TriggerFlash();

            if (CurrentHealth <= 0 && IsAlive)
            {
                Die();
            }
        }
    }

    void Die()
    {
        IsAlive = false;

        animator.Play("Die", -1, 0.0f);

        AudioUtility.PlayRandomSound(audioSource, deathAudioClips, deathAudioVolume);

        deathXSpeed = mapSpeed;
        deathYSpeed = 0;

        hitbox.enabled = false;

        if (enemyLoot)
        {
            enemyLoot.DropLoot();
        }
    }

    public void SelfDestruct()
    {
        Die();
    }

    void Animate()
    {
        if (lineOfSight.Target)
        {
            animator.SetFloat("AnimLookX", lineOfSight.GetDirectionToTarget().x);
            animator.SetFloat("AnimLookY", lineOfSight.GetDirectionToTarget().y);
        }
    }
}
