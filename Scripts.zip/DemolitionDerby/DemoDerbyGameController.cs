using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class DemoDerbyGameController : MonoBehaviour
{
    [Header("Player")]
    [SerializeField] PlayerBiker player;

    [Header("Traveling")]
    [SerializeField] float endDistance = 20000;
    [SerializeField] float currentDistance = 0;
    [SerializeField] float speed = 30;

    [Header("Spawners")]
    [SerializeField] ObstacleSpawner obstacleSpawner;
    [SerializeField] ObstacleSpawner enemySpawner;

    [Header("Difficulty")]
    [SerializeField] int mileageDifficultyIncrease = 1000;
    [SerializeField] int milesAfterIncreaseToFlipBool = 10;
    [SerializeField] float maxTimeToSpawnObstacleDecrease = .2f;
    [SerializeField] int maxObstaclesToSpawnIncrease = 1;
    [SerializeField] float maxTimeToSpawnEnemyDecrease = .2f;
    [SerializeField] int maxEnemiesToSpawnIncrease = 1;
    [SerializeField] bool difficultyIncreased = false;  // locks difficulty from increasing more than once per milestone. Unlocks after a few more meters

    [Header("UI")]
    [SerializeField] TextMeshProUGUI meterCounter;

    [Header("Audio")]
    [SerializeField] MusicPlayer musicPlayer;
    [SerializeField] AudioClip raceBeep;
    [SerializeField] [Range(0, 1)] float raceBeepVolume = 1f;
    [SerializeField] AudioClip raceStartBeep;
    [SerializeField] [Range(0, 1)] float raceStartBeepVolume = 1f;

    [Header("Start")]
    [SerializeField] bool started = false;
    [SerializeField] SpriteScroller spriteScroller;
    [SerializeField] float timeBeforeCountdown = 3f;
    [SerializeField] ObstacleMovement startLineMovement;
    [SerializeField] ObstacleMovement startingLightsMovement;
    [SerializeField] ObstacleMovement bikerObstacleMovement;
    [SerializeField] float timeAfterStartBeforeMusic = 4f;

    [Header("Finish")]
    [SerializeField] GameObject finishLine;
    [SerializeField] bool finished = false;
    [SerializeField] Transform finishLineSpawn;
    [SerializeField] SceneLoader sceneLoader;
    [SerializeField] float timeBeforeSceneTransition = 5f;
    [SerializeField] string winScene;

    [Header("Pause Menu")]
    [SerializeField] bool isPaused = false;
    [SerializeField] GameObject pauseMenu;

    float lastDifficultyIncreaseMileage;

    public float CurrentDistance
    { 
        get => currentDistance; 
        set
        {
            currentDistance = value;
            UpdateMeterCounter();
        }
    }

    public bool IsPaused { get => isPaused; set => isPaused = value; }

    private void Start()
    {
        StartCoroutine(StartCountdown());
    }

    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Tab) || Input.GetKeyDown(KeyCode.Escape))
        {
            TogglePauseMenu();
        }

        if (player.IsAlive && !finished && started)
        {
            Travel();
        }

        IncreaseDifficulty();

        if (difficultyIncreased && currentDistance >= lastDifficultyIncreaseMileage + milesAfterIncreaseToFlipBool)
        {
            difficultyIncreased = false;
        }

        Finish();
    }

    IEnumerator StartCountdown()
    {
        yield return new WaitForSeconds(timeBeforeCountdown);

        startingLightsMovement.GetComponent<Animator>().enabled = true;

        // countdown
        for (int i = 0; i < 3; i++)
        {
            AudioSource.PlayClipAtPoint(raceBeep, Camera.main.transform.position, raceBeepVolume);

            yield return new WaitForSeconds(1f);
        }

        started = true;

        AudioSource.PlayClipAtPoint(raceStartBeep, Camera.main.transform.position, raceStartBeepVolume);

        player.GetComponent<Animator>().enabled = true;

        player.MovementEnabled = true;

        spriteScroller.enabled = true;
        startLineMovement.enabled = true;
        startingLightsMovement.enabled = true;
        bikerObstacleMovement.enabled = true;

        obstacleSpawner.enabled = true;
        enemySpawner.enabled = true;

        Destroy(startLineMovement.gameObject, 8f);
        Destroy(startingLightsMovement.gameObject, 8f);
        Destroy(bikerObstacleMovement.gameObject, 8f);

        yield return new WaitForSeconds(timeAfterStartBeforeMusic);

        musicPlayer.PlayMusicOnLoop();
    }

    private void IncreaseDifficulty()
    {
        if ((int)currentDistance % mileageDifficultyIncrease == 0 && currentDistance > 1 && difficultyIncreased != true)
        {
            lastDifficultyIncreaseMileage = (int)currentDistance;

            difficultyIncreased = true;

            obstacleSpawner.MaxTimeToSpawn -= maxTimeToSpawnObstacleDecrease;
            obstacleSpawner.MaxToSpawn += maxObstaclesToSpawnIncrease;

            enemySpawner.MaxTimeToSpawn -= maxTimeToSpawnEnemyDecrease;
            enemySpawner.MaxToSpawn += maxEnemiesToSpawnIncrease;
        }
    }

    void Travel()
    {
        float metersThisFrame = speed * Time.deltaTime;
        CurrentDistance += metersThisFrame;
    }

    void UpdateMeterCounter()
    {
        meterCounter.text = ((int)CurrentDistance).ToString("d5") + "m";
    }

    void Finish()
    {
        if (currentDistance >= endDistance && !finished)
        {
            finished = true;

            GameObject instantiatedFinishLine = Instantiate(finishLine, finishLineSpawn.position, Quaternion.identity);
            instantiatedFinishLine.GetComponent<ObstacleMovement>().TriggerSlowdown();

            player.StopMovement();

            spriteScroller.TriggerSlowdown();

            musicPlayer.StopMusic();

            obstacleSpawner.enabled = false;
            enemySpawner.enabled = false;

            // destroy all enemies
            var bikerEnemies = FindObjectsOfType<EnemyBiker>();
            foreach (EnemyBiker biker in bikerEnemies)
            {
                biker.SelfDestruct();
            }

            StartCoroutine(FinishedRaceSceneTransition());
        }
    }

    IEnumerator FinishedRaceSceneTransition()
    {
        yield return new WaitForSeconds(timeBeforeSceneTransition);

        sceneLoader.LoadSceneByNameAsyncWithoutSaving(winScene);
    }

    public void TogglePauseMenu()
    {
        if (IsPaused)
        {
            pauseMenu.SetActive(false);
            IsPaused = false;

            // back to real time
            Time.timeScale = 1f;
        }
        else
        {
            pauseMenu.SetActive(true);
            IsPaused = true;

            // set timescale to 0
            Time.timeScale = 0;
        }
    }

    public void LoadSceneByName(string sceneName)
    {
        if (IsPaused)
        {
            TogglePauseMenu();
        }

        sceneLoader.LoadSceneByNameAsyncWithoutSaving(sceneName);
    }
}
