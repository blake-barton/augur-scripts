using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;
using UnityEngine.Events;

public class PlayerBiker : MonoBehaviour
{
    [Header("Movement")]
    [SerializeField] float xSpeed = 5f;
    [SerializeField] float ySpeed = 5f;
    [SerializeField] float mapSpeed = -13f;

    [Header("Weapon")]
    [SerializeField] RangedWeapon weaponStats;
    [SerializeField] int currentAmmo;
    [SerializeField] int maxAmmo;
    [SerializeField] GameObject projectile;
    [SerializeField] Vector3 projectileOffset = new Vector2();
    [SerializeField] Orbiter orbiter;

    [Header("Health")]
    [SerializeField] int maxHealth = 3;
    [SerializeField] int currentHealth = 3;

    [Header("State")]
    [SerializeField] bool isAlive = true;
    [SerializeField] bool isFiring = true;
    [SerializeField] bool movementEnabled = false;

    [Header("UI")]
    [SerializeField] TextMeshProUGUI ammoText;
    [SerializeField] Image[] healthBlocks;
    [SerializeField] Image weaponSprite;

    [Header("Audio")]
    [SerializeField] AudioSource weaponAudioSource;
    [SerializeField] AudioClip shotAudio;
    [SerializeField] AudioClip shotLoopAudio;
    [SerializeField] [Range(0, 1)] float shotAudioVolume = 1f;
    [SerializeField] AudioClip weaponEquipAudio;
    [SerializeField] [Range(0, 1)] float weaponEquipAudioVolume = 1f;
    [SerializeField] AudioClip outOfAmmoAudio;
    [SerializeField] [Range(0, 1)] float outOfAmmoAudioVolume = 1f;
    [SerializeField] AudioClip[] deathAudioClips;
    [SerializeField] [Range(0, 1)] float deathAudioVolume = 1f;
    [SerializeField] AudioClip[] damageAudioClips;
    [SerializeField] [Range(0, 1)] float damageAudioVolume = 1f;
    [SerializeField] AudioClip weaponHealAudio;
    [SerializeField] [Range(0, 1)] float weaponHealAudioVolume = 1f;

    [Header("Screen Shake")]
    [SerializeField] float shakeIntensity = 6f;
    [SerializeField] float shakeTime = .2f;

    [Header("Game Control")]
    [SerializeField] DemoDerbyGameController gameController;

    public UnityEvent playerDied;
    
    // boundaries
    float xMin;
    float xMax;
    float yMin;
    float yMax;

    // util
    float nextFireTime;

    // coroutines
    Coroutine firingCoroutine;

    // cache
    Animator animator;
    Camera gameCamera;
    CapsuleCollider2D playerCollider;
    FlashOnHit damageFlasher;
    ShakeBehavior screenShake;
    AudioSource audioSource;
    DamageImmunityFlash damageImmunityFlash;

    public int CurrentAmmo
    {   
        get => currentAmmo; 
        set
        {
            currentAmmo = value;
            SetAmmoText();
        }
    }
    public float YSpeed { get => ySpeed; set => ySpeed = value; }
    public float XSpeed { get => xSpeed; set => xSpeed = value; }
    public int MaxAmmo { get => maxAmmo; set => maxAmmo = value; }
    public int CurrentHealth
    { 
        get => currentHealth; 
        set
        {
            currentHealth = Mathf.Clamp(value, 0, maxHealth);
            UpdateHealthBar();
        }
    }

    public bool IsAlive { get => isAlive; set => isAlive = value; }
    public RangedWeapon WeaponStats 
    { 
        get => weaponStats;
        set
        {
            weaponStats = value;

            MaxAmmo = weaponStats.ClipSize;
            CurrentAmmo = weaponStats.AmmoInClip;

            weaponSprite.sprite = weaponStats.Sprite;
        }
    }
    public bool MovementEnabled { get => movementEnabled; set => movementEnabled = value; }
    public AudioClip ShotAudio { get => shotAudio; set => shotAudio = value; }
    public AudioClip ShotLoopAudio { get => shotLoopAudio; set => shotLoopAudio = value; }

    private void Awake()
    {
        animator = GetComponent<Animator>();
        playerCollider = GetComponent<CapsuleCollider2D>();
        damageFlasher = GetComponent<FlashOnHit>();
        screenShake = FindObjectOfType<ShakeBehavior>();
        audioSource = GetComponent<AudioSource>();
        damageImmunityFlash = GetComponent<DamageImmunityFlash>();
    }

    private void Start()
    {
        SetUpMoveBoundaries();
        MaxAmmo = WeaponStats.ClipSize;
        CurrentAmmo = WeaponStats.AmmoInClip;
    }

    private void Update()
    {
        if (!gameController.IsPaused)
        {
            if (IsAlive && MovementEnabled)
            {
                Move();
                Fire();
                Animate();
            }
            else if (!IsAlive && MovementEnabled)
            {
                MoveAutomatically();
            }
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        BikerDamageDealer damageDealer = collision.gameObject.GetComponent<BikerDamageDealer>();
        if (damageDealer)
        {
            TakeDamage(damageDealer);
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        BikerDamageDealer damageDealer = collision.gameObject.GetComponent<BikerDamageDealer>();
        if (damageDealer)
        {
            TakeDamage(damageDealer);
        }
    }

    void Move()
    {
        float xMovement = Input.GetAxisRaw("Horizontal") * XSpeed;
        float yMovement = Input.GetAxisRaw("Vertical") * YSpeed;

        // multiply by delta time so speed is not tied to frame rate.
        xMovement *= Time.deltaTime;
        yMovement *= Time.deltaTime;

        // move player
        transform.Translate(xMovement, yMovement, 0);

        // clamp movement to viewport
        Vector2 clampedPosition = transform.position;
        clampedPosition.x = Mathf.Clamp(clampedPosition.x, xMin, xMax);
        clampedPosition.y = Mathf.Clamp(clampedPosition.y, yMin, yMax);
        transform.position = clampedPosition;
    }

    void MoveAutomatically()
    {
        float xMovement = XSpeed;
        float yMovement = YSpeed;

        // multiply by delta time so speed is not tied to frame rate.
        xMovement *= Time.deltaTime;
        yMovement *= Time.deltaTime;

        // move player
        transform.Translate(xMovement, yMovement, 0);
    }

    public void StopMovement()
    {
        IsAlive = false;
        MovementEnabled = false;
    }

    void Fire()
    {
        if (Input.GetMouseButtonDown(0) && currentAmmo > 0 && Time.time > nextFireTime)
        {
            nextFireTime = Time.time + (1 / WeaponStats.AttackRate);   // add time to wait until next shot

            if (WeaponStats.IsAutomatic)
            {
                animator.Play("FireFullAuto", -1, 0.0f);
                firingCoroutine = StartCoroutine(SpawnProjectileFullAuto());
            }
            else
            {
                animator.Play("Fire", -1, 0.0f);
                weaponAudioSource.PlayOneShot(ShotAudio, shotAudioVolume);

                CurrentAmmo--;

                for (int i = 0; i < WeaponStats.ProjectilesPerShot; i++)
                {
                    SpawnProjectile();
                }
            }
        }
        else if (Input.GetMouseButtonDown(0) && currentAmmo <= 0 && Time.time > nextFireTime)
        {
            weaponAudioSource.PlayOneShot(outOfAmmoAudio, outOfAmmoAudioVolume);
        }
        else if (Input.GetMouseButtonUp(0) && WeaponStats.IsAutomatic && isFiring)
        {
            StopSpawningFullAuto();
        }
    }

    void TakeDamage(BikerDamageDealer damageDealer)
    {
        CurrentHealth -= damageDealer.Damage;

        AudioUtility.PlayRandomSound(weaponAudioSource, damageAudioClips, damageAudioVolume);

        damageFlasher.TriggerFlash();
        screenShake.ShakeCamera(shakeIntensity, shakeTime);

        if (CurrentHealth <= 0 && IsAlive)
        {
            Die();
        }
        else if (currentHealth > 0 && IsAlive)
        {
            damageImmunityFlash.TriggerImmunityFlash();
        }
    }

    void Die()
    {
        IsAlive = false;

        if (isFiring)
        {
            StopSpawningFullAuto();
        }

        animator.Play("Die", -1, 0.0f);

        AudioUtility.PlayRandomSound(weaponAudioSource, deathAudioClips, deathAudioVolume);

        xSpeed = mapSpeed;
        ySpeed = 0;

        playerDied.Invoke();
    }

    void Animate()
    {
        animator.SetFloat("AnimLookX", GetDirectionToCursor().x);
        animator.SetFloat("AnimLookY", GetDirectionToCursor().y);
    }

    void SetAmmoText()
    {
        ammoText.text = CurrentAmmo + "/" + MaxAmmo;
    }

    private Vector2 GetDirectionToCursor()
    {
        // Get mouse position (in screen-space) and convert to world-space
        var mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);

        // Calculate the vector between the mouse position and object
        return (mousePos - transform.position).normalized;
    }

    float GetRandomizedProjectileSpread()
    {
        return Random.Range(-WeaponStats.Spread, WeaponStats.Spread);
    }

    private void SetProjectileAttributes(GameObject firedProjectile)
    {
        float zAngle = firedProjectile.transform.rotation.eulerAngles.z * (Mathf.PI / 180f);
        float xComponent = Mathf.Cos(zAngle);
        float yComponent = Mathf.Sin(zAngle);
        Vector2 pivotDirection = new Vector2(xComponent, yComponent);

        firedProjectile.GetComponent<ProjectileBiker>().SetAttributes(WeaponStats, pivotDirection);
    }

    private void SetUpMoveBoundaries()
    {
        gameCamera = Camera.main;

        // find minimum values
        xMin = gameCamera.ViewportToWorldPoint(new Vector3(0, 0, 0)).x + playerCollider.bounds.size.x / 2f;     // ViewportToWorldPoint will find the actual coordinates of the game at the viewport's bottom left corner.
        yMin = gameCamera.ViewportToWorldPoint(new Vector3(0, 0, 0)).y + playerCollider.bounds.size.y / 2f;     // playerCollider is there to ensure player ship doesn't go halfway off screen

        // find maximum values
        xMax = gameCamera.ViewportToWorldPoint(new Vector3(1, 0, 0)).x - playerCollider.bounds.size.x / 2f;
        yMax = gameCamera.ViewportToWorldPoint(new Vector3(0, 1, 0)).y - playerCollider.bounds.size.x / 2f;
    }

    private void UpdateHealthBar()
    {
        for (int i = 0; i < healthBlocks.Length; i++)
        {
            if (i < CurrentHealth)
            {
                healthBlocks[i].enabled = true;
            }
            else
            {
                healthBlocks[i].enabled = false;
            }
        }
    }

    private void SpawnProjectile()
    {
        GameObject firedProjectile = Instantiate(projectile, transform.position + projectileOffset, orbiter.GetPivotRotation());

        // add spread to projectile and set attributes
        firedProjectile.transform.Rotate(0, 0, GetRandomizedProjectileSpread());
        SetProjectileAttributes(firedProjectile);
    }

    IEnumerator SpawnProjectileFullAuto()
    {
        isFiring = true;

        while (true)
        {
            SpawnProjectile();

            // loop sound
            AudioUtility.LoopAudio(weaponAudioSource, ShotLoopAudio, shotAudioVolume);

            CurrentAmmo--;

            // break if ammo goes below or equal to 0
            if (currentAmmo <= 0)
            {
                isFiring = false;

                animator.Play("AimGun", -1, 0.0f);

                AudioUtility.StopLoopingAudio(weaponAudioSource);

                // play last shot
                AudioUtility.PlaySound(weaponAudioSource, shotAudio, shotAudioVolume);

                yield break;
            }

            yield return new WaitForSeconds(1 / WeaponStats.AttackRate);
        }
    }

    public void StopSpawningFullAuto(bool playShotSound = true)
    {
        if (!(firingCoroutine is null))
        {
            StopCoroutine(firingCoroutine);
            isFiring = false;

            animator.Play("AimGun", -1, 0.0f);

            AudioUtility.StopLoopingAudio(weaponAudioSource);

            // play last shot
            if (playShotSound)
            {
                AudioUtility.PlaySound(weaponAudioSource, shotAudio, shotAudioVolume);
            }
        }
    }

    public void PlayWeaponEquipSound()
    {
        weaponAudioSource.PlayOneShot(weaponEquipAudio, weaponEquipAudioVolume);
    }

    public void PlayHealSound()
    {
        weaponAudioSource.PlayOneShot(weaponHealAudio, weaponHealAudioVolume);
    }

    public void StopAnimation()
    {
        animator.enabled = false;
    }

    public void StopEngineNoise()
    {
        audioSource.enabled = false;
    }
}
