using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BikerDamageDealer : MonoBehaviour
{
    [SerializeField] int damage;

    public int Damage { get => damage; set => damage = value; }
}
