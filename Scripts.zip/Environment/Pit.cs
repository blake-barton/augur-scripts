using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Pit : MonoBehaviour
{
    private void OnTriggerEnter2D(Collider2D collision)
    {
        Player player = collision.transform.parent.GetComponent<Player>();
        Enemy enemy = collision.transform.parent.GetComponent<Enemy>();

        if (player)
        {
            player.Character.Incapacitated = true;

            // cancel actions
            Equipment playerEquipment = player.GetComponent<Equipment>();

            if (playerEquipment.MainHand)
                playerEquipment.CancelMainhandActions(destroyHeatSlider: false);

            if (playerEquipment.OffHand)
                playerEquipment.CancelOffhandActions(destroyHeatSlider: false);

            // disable collider (no getting hit)
            player.GetComponent<BoxCollider2D>().enabled = false;

            // hide equipped
            player.GetComponent<PlayerMovement>().HideEquipped();

            // hide shadow
            player.HideShadow();

            // play falling animation. Animation will call an event for the rest of the functionality (in PlayerMovement)
            player.GetComponent<Animator>().SetBool("AnimPitfall", true);
        }
        else if (enemy)
        {
            enemy.Character.Incapacitated = true;

            // disable collider (no getting hit) DISABLED BECAUSE NO COLLIDERS IN ENEMY RIGHT NOW
            // enemy.GetComponent<BoxCollider2D>().enabled = false;

            // hide equipped
            EnemyEquipment enemyEquipment = enemy.GetComponent<EnemyEquipment>();
            if (enemyEquipment)
            {
                enemyEquipment.HideEquipped();
            }

            // play falling animation. Animation will call an event for the rest of the functionality (in PlayerMovement)
            enemy.GetComponent<Animator>().Play("Pitfall", -1, 0.0f);
        }
    }
}