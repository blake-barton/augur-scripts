using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ExplosiveBarrel : MonoBehaviour
{
    public List<float> damages = new List<float>();
    public List<DamageEffects.DamageType> damageTypes = new List<DamageEffects.DamageType>();

    [SerializeField] int damageTicks;
    [SerializeField] int ticksPerSecond;
    [SerializeField] float statusEffectDamagePercentage = .1f;
    [SerializeField] float explosionDelaySeconds = 0f;

    [SerializeField] GameObject explosionTemplate;

    public void Explode()
    {
        GameObject effect = Instantiate(explosionTemplate, transform.position, Quaternion.identity);
        Explosion explosion = effect.GetComponent<Explosion>();
        explosion.DamageDealer.CopyDamageList(damages);
        explosion.DamageDealer.CopyDamageTypeList(damageTypes);
        explosion.DamageDealer.SetStatusEffectDamagePercentage(statusEffectDamagePercentage);

        explosion.Attacker = gameObject;

        Destroy(gameObject);
    }

    public void ExplodeWithoutDestroyingGameObject()
    {
        GameObject effect = Instantiate(explosionTemplate, transform.position, Quaternion.identity);
        Explosion explosion = effect.GetComponent<Explosion>();
        explosion.DamageDealer.CopyDamageList(damages);
        explosion.DamageDealer.CopyDamageTypeList(damageTypes);
        explosion.DamageDealer.SetStatusEffectDamagePercentage(statusEffectDamagePercentage);

        explosion.Attacker = gameObject;
    }

    public void TriggerExplodeAfterDelay(bool destroyGameobject)
    {
        StartCoroutine(ExplodeWithDelay(destroyGameobject));
    }

    IEnumerator ExplodeWithDelay(bool destroyGameobject)
    {
        yield return new WaitForSeconds(explosionDelaySeconds);

        if (destroyGameobject)
        {
            Explode();
        }
        else
        {
            ExplodeWithoutDestroyingGameObject();
        }
    }
}
