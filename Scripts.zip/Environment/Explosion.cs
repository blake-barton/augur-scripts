using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Explosion : MonoBehaviour
{
    [SerializeField] float blastRadius = 1.5f;
    [SerializeField] LayerMask damagableLayers;
    [SerializeField] float timeToDestroy = .5f;
    [SerializeField] DamageDealer damageDealer;

    [Header("Shaking")]
    [SerializeField] float screenShakeIntensity;
    [SerializeField] float screenShakeDuration;

    [Header("Sound")]
    [SerializeField] AudioSource audioSource;
    [SerializeField] AudioClip explosionSound;
    [SerializeField] [Range(0, 1)] float explosionVolume = .5f;

    ShakeBehavior shaker;
    GameObject attacker;
    Weapon originWeapon;

    public DamageDealer DamageDealer { get => damageDealer; set => damageDealer = value; }
    public GameObject Attacker { get => attacker; set => attacker = value; }
    public Weapon OriginWeapon { get => originWeapon; set => originWeapon = value; }

    // Start is called before the first frame update
    void Awake()
    {
        shaker = FindObjectOfType<ShakeBehavior>();
    }

    private void Start()
    {
        Collider2D[] collisions = Physics2D.OverlapCircleAll(transform.position, blastRadius, damagableLayers);

        foreach (Collider2D collision in collisions)
        {
            DamageDealer.CauseMeleeDamage(collision, Attacker, OriginWeapon);
        }

        audioSource.PlayOneShot(explosionSound, explosionVolume);

        if (shaker)
        {
            shaker.ShakeCamera(screenShakeIntensity, screenShakeDuration);
        }

        Destroy(gameObject, timeToDestroy);
    }
}
