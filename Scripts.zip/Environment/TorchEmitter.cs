using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TorchEmitter : MonoBehaviour
{
    [SerializeField] float timeBetweenEmit = 5f;
    [SerializeField] float emitTime = 2f;

    [Header("Torch")]
    [SerializeField] ParticleSystem particles;
    [SerializeField] PolygonCollider2D hitbox;
    [SerializeField] bool ticking = false;
    [SerializeField] float tickRate = 2f;
    float tickTime;

    [Header("Sound")]
    [SerializeField] AudioSource audioSource;
    [SerializeField] AudioClip castSound;
    [SerializeField] [Range(0, 1)] float castVolume = 1f;
    [SerializeField] AudioClip constantCastLoopSound;
    [SerializeField] [Range(0, 1)] float constantCastLoopSoundVolume = 1f;
    [SerializeField] AudioClip constantCastEndSound;
    [SerializeField] [Range(0, 1)] float constantCastEndSoundVolume = 1f;

    DamageDealer damageDealer;
    MuzzleFlashLight muzzleFlashLight;

    float cooldownTimer;
    float emitTimer = 0f;
    float torchTimer = 0f;
    List<Collider2D> targetColliders = new List<Collider2D>();

    public List<Collider2D> TargetColliders { get => targetColliders; set => targetColliders = value; }

    void Awake()
    {
        damageDealer = GetComponent<DamageDealer>();
        muzzleFlashLight = GetComponent<MuzzleFlashLight>();
    }

    void Start()
    {
        cooldownTimer = timeBetweenEmit;

        tickTime = tickRate > 0 ? 1 / tickRate : 1f;

        particles.Stop();
        hitbox.enabled = false;
    }

    void Update()
    {
        if (ticking)
        {
            torchTimer += Time.deltaTime;
            emitTimer += Time.deltaTime;

            if (torchTimer >= tickTime)
            {
                torchTimer = 0;
                Tick();
            }

            if (emitTimer >= emitTime)
            {
                emitTimer = 0f;

                // Time up. Stop emitting.
                StopEmitting();
            }
        }
        else
        {
            // Not emitting, count down
            cooldownTimer += Time.deltaTime;

            // Start emitting
            if (cooldownTimer >= timeBetweenEmit)
            {
                cooldownTimer = 0f;

                Emit();
            }
        }
    }

    void Emit()
    {
        // Start emitting
        ticking = true;

        particles.Play();
        hitbox.enabled = true;
        ticking = true;

        // cast sound
        if (audioSource && castSound)
        {
            audioSource.PlayOneShot(castSound, castVolume);
        }

        // constant cast sound
        if (audioSource && constantCastLoopSound)
        {
            audioSource.loop = true;
            audioSource.clip = constantCastLoopSound;
            audioSource.volume = constantCastLoopSoundVolume;
            audioSource.Play();
        }

        // muzzle flash
        if (muzzleFlashLight)
        {
            muzzleFlashLight.TurnLightOn();
        }
    }

    void StopEmitting(bool stopAudio = true)
    {
        // Start emitting
        ticking = false;

        particles.Stop();
        hitbox.enabled = false;
        ticking = false;
        torchTimer = 0;

        // stop constant cast audio
        if (audioSource && stopAudio)
        {
            audioSource.loop = false;
            audioSource.Stop();
        }

        // done casting audio
        if (audioSource && constantCastEndSound)
        {
            audioSource.PlayOneShot(constantCastEndSound, constantCastEndSoundVolume);
        }

        // muzzle flash
        if (muzzleFlashLight)
        {
            muzzleFlashLight.TurnLightOff();
        }
    }

    void Tick()
    {
        foreach (Collider2D targetCollider in TargetColliders)
        {
            damageDealer.CauseTorchDamage(targetCollider, gameObject, null, false, false, false);
        }
    }
}
