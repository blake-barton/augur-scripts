using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TorchEmitterHitbox : MonoBehaviour
{
    [SerializeField] TorchEmitter torchEmitter;

    private void OnTriggerEnter2D(Collider2D collision)
    {
        torchEmitter.TargetColliders.Add(collision);
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        torchEmitter.TargetColliders.Remove(collision);
    }
}
