using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shield : MonoBehaviour
{
    [SerializeField] [Range(0, 1)] float damageResistance = 0;

    [Header("Screen Shake")]
    [SerializeField] float shakeDuration = .1f;
    [SerializeField] float shakeIntensity = .1f;

    [Header("Audio")]
    [SerializeField] AudioClip[] impactAudioClips;
    [SerializeField] [Range(0, 1)] float impactAudioVolume = 1f;

    [Header("Cached References")]
    [SerializeField] Animator animator;
    [SerializeField] AudioSource audioSource;

    // Cached references
    ShakeBehavior shakeBehavior;
    Poise playerPoise;

    private void Awake()
    {
        shakeBehavior = FindObjectOfType<ShakeBehavior>();
        playerPoise = FindObjectOfType<Player>().GetComponent<Poise>();
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        DamageDealer incomingDamageDealer = collision.gameObject.GetComponent<DamageDealer>();

        Block(incomingDamageDealer);
    }

    public void Block(DamageDealer damageDealer)
    {
        if (damageDealer)
        {
            // Animate
            animator.Play("Impact", -1, 0.0f);

            // Audio
            AudioUtility.PlayRandomSound(audioSource, impactAudioClips, impactAudioVolume);

            // Screen shake
            shakeBehavior.ShakeCamera(shakeIntensity, shakeDuration);

            // Subtract player poise
            playerPoise.DecreasePoise(damageDealer.GetTotalDamage() * (1 - damageResistance));
            playerPoise.SetCollidingObjectDirection(transform.up);   // if poise breaks, the actor knows the direction of the impact
        }
    }

}
