using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HeatSlider : MonoBehaviour
{
    [Header("Properties")]
    [SerializeField] float backgroundWidth;
    [SerializeField] float backgroundHeight = 5f;

    [Header("Positioning")]
    public bool isMainHand = false;
    [SerializeField] Vector2 mainHandOffset = new Vector2();
    [SerializeField] Vector2 offHandOffset = new Vector2();

    [Header("Bars")]
    [SerializeField] RectTransform handleSlideArea;
    [SerializeField] RectTransform background;
    [SerializeField] Image fill;

    [Header("Colors")]
    [SerializeField] Color normalColor;
    [SerializeField] Color overheatColor;

    [Header("Cached References")]
    [SerializeField] Player player;
    [SerializeField] RectTransform sliderTransform;
    [SerializeField] Slider slider;

    // references
    [SerializeField] ThermalWeaponRanged thermalWeaponRanged;

    private void Awake()
    {
        player = FindObjectOfType<Player>();
    }

    // Start is called before the first frame update
    void Start()
    {
        FormatBar();
    }

    // Update is called once per frame
    void Update()
    {
        LockToPlayer();
    }

    // handles the size of the background and slider
    public void FormatBar()
    {
        // size background
        background.sizeDelta = new Vector2(backgroundWidth, backgroundHeight);

        // size slider
        sliderTransform.sizeDelta = new Vector2(backgroundWidth, backgroundHeight * 2);
    }

    private void LockToPlayer()
    {
        // lock position to player if player exists
        if (isMainHand)
        {
            if (player)
            {
                transform.position = Camera.main.WorldToScreenPoint((Vector2)player.transform.position + mainHandOffset);
            }
            else
            {
                Destroy(gameObject);
            }
        }
        else
        {
            if (player)
            {
                transform.position = Camera.main.WorldToScreenPoint((Vector2)player.transform.position + offHandOffset);
            }
            else
            {
                Destroy(gameObject);
            }
        }
    }

    public void SetParameters(bool isMainHand, float heatCapacity, float startingValue, ThermalWeaponRanged owner)
    {
        // determines placement of slider
        this.isMainHand = isMainHand;

        thermalWeaponRanged = owner;

        // set speed of handle based on reload speed
        slider.minValue = 0f;
        slider.maxValue = heatCapacity;

        slider.value = startingValue;
    }

    public void SwapColors(bool overheated)
    {
        if (overheated)
        {
            fill.color = overheatColor;
        }
        else
        {
            fill.color = normalColor;
        }
    }
}
