using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BowOfArtemis : MonoBehaviour
{
    [SerializeField] [Range(0, 100)] int chanceToFire = 25;
    [SerializeField] GameObject projectile;
    [SerializeField] float projectileSpeedMultiplier = 0.5f;

    ThrowingWeapon throwingWeapon;

    private void Awake()
    {
        throwingWeapon = GetComponent<ThrowingWeapon>();
    }

    public void FireSeekingArrow()
    {
        int roll = Random.Range(1, 101);
        if (roll <= chanceToFire)
        {
            throwingWeapon.SpawnProjectile(projectile, chargedSweetSpotVelocityMultiplier: projectileSpeedMultiplier, invokeEvent: false);
        }
    }
}
