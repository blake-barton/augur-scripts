using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LongswordOfGreed : MonoBehaviour
{
    [SerializeField] float damagePerCurrency = 0.0002f;

    [Header("Cached References")]
    [SerializeField] EquippedWeapon equippedWeapon;

    Crypto playerCurrency;

    private void Awake()
    {
        //playerCurrency = equippedWeapon.EquippedWeaponPlayer.GetComponent<Crypto>();
    }

    // Start is called before the first frame update
    void Start()
    {
        // Bind damage function to currency change
        //playerCurrency.currencyChangedEvent.AddListener(AdjustDamageBasedOnCurrency);

        // adjust outgoing damage
    }

    void AdjustDamageBasedOnCurrency()
    {
        
    }

    private void OnDestroy()
    {
        // Remove added damage
    }
}
