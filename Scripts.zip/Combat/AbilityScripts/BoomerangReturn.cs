using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BoomerangReturn : MonoBehaviour
{
    public Item itemTemplate;     // data from the item's serialized object
    public int quantity = 1;
    [SerializeField] AudioClip pickupSound;
    [SerializeField] float pickupVolume = .5f;

    // This item's data (starts copied from the template)
    Item itemData;

    // cache
    ThrowingProjectileDrop throwingProjectileDrop;
    Inventory inventory;
    AudioSource uiSounds;

    // getters/setters
    public Item ItemData { get => itemData; set => itemData = value; }

    void Awake()
    {
        itemData = Object.Instantiate(itemTemplate);
        inventory = FindObjectOfType<Player>().GetComponent<Inventory>();
        uiSounds = GameObject.FindWithTag("UISound").GetComponent<AudioSource>();
        throwingProjectileDrop = GetComponent<ThrowingProjectileDrop>();
    }

    // called by event
    public void AddItemToInventory()
    {
        inventory.AddItem(ItemData, quantity);

        // sound
        if (pickupSound)
        {
            uiSounds.PlayOneShot(pickupSound, pickupVolume);
        }

        // don't drop an extra projectile
        if (throwingProjectileDrop)
        {
            throwingProjectileDrop.DropChance = 0;
            throwingProjectileDrop.enabled = false;
        }

        // remove item from scene
        Destroy(gameObject);
    }
}
