using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DamageCalculation
{
    static readonly float skillModBase = 50f;
    static readonly float skillModWeight = 1f;

    // general mishandling config
    static readonly float mishandleDamageMod = .5f;

    // ranged mishandling config
    static readonly float mishandleSpreadMod = 30f;
    static readonly float mishandleReloadTimeMod = 3f;
    static readonly float mishandleRangedChargeTimeMod = 3f;

    // throwing mishandling config
    static readonly float mishandleThrowingRangeMod = .5f;

    // melee mishandling config
    static readonly float mishandleMeleeChargeTimeMod = 3f;

    public static void ModifyWeaponStatsBasedOnAttributes(Weapon weapon, AttributeScores attributeScores)
    {
        List<float> damages = weapon.Damages;

        if (attributeScores.Strength < weapon.StrengthRequirement || attributeScores.GetSkillValue(weapon.WeaponSkill) < weapon.WeaponSkillRequirement)
        {
            // insufficient strength or skills
            weapon.RequirementsMet = false;

            for (int i = 0; i < damages.Count; i++)
            {
                damages[i] *= mishandleDamageMod;
            }

            if (weapon is RangedWeapon rangedWeapon)
            {
                // do not penalize spread on thrown explosives
                if (!(rangedWeapon.IsThrowingWeapon && rangedWeapon.IsExplosive))
                    rangedWeapon.Spread += mishandleSpreadMod;

                rangedWeapon.ReloadTime *= mishandleReloadTimeMod;
                rangedWeapon.ChargeTime *= mishandleRangedChargeTimeMod;

                // do not penalize thrown explosives
                if (rangedWeapon.IsThrowingWeapon && !rangedWeapon.IsExplosive)
                {
                    rangedWeapon.MaxRange *= mishandleThrowingRangeMod;
                    rangedWeapon.EffectiveRange *= mishandleThrowingRangeMod;
                }
            }
            else if (weapon is MeleeWeapon meleeWeapon)
            {
                meleeWeapon.ChargeTime *= mishandleMeleeChargeTimeMod;
            }
        }
        else
        {
            // suffiencient strength and skills
            weapon.RequirementsMet = true;

            for (int i = 0; i < damages.Count; i++)
            {
                damages[i] = SkillDamageEquation(damages[i], attributeScores.GetSkillValue(weapon.WeaponSkill));
            }

            // force damage
            weapon.ForceDamage = SkillDamageEquation(weapon.ForceDamage, attributeScores.GetSkillValue(weapon.WeaponSkill));

            // ranged stuff
            if (weapon is RangedWeapon rangedWeapon)
            {
                ModifyRangedChargeTime(rangedWeapon, attributeScores);

                if (rangedWeapon.IsThrowingWeapon)
                {
                    // throwing weapons
                    rangedWeapon.ProjectileSpeed = SkillDamageEquation(rangedWeapon.ProjectileSpeed, attributeScores.GetSkillValue(weapon.WeaponSkill));
                    rangedWeapon.MaxRange = SkillDamageEquation(rangedWeapon.MaxRange, attributeScores.GetSkillValue(weapon.WeaponSkill));
                    rangedWeapon.EffectiveRange = SkillDamageEquation(rangedWeapon.EffectiveRange, attributeScores.GetSkillValue(weapon.WeaponSkill));
                }
                else
                {
                    ModifyReloadTime(rangedWeapon, attributeScores);
                    ModifySpread(rangedWeapon, attributeScores);
                }
            }
            else if (weapon is MeleeWeapon meleeWeapon)
            {
                // charge time
                ModifyMeleeWeaponChargeTime(meleeWeapon, attributeScores);
            }
        }
    }

    public static void ResetWeaponStats(Weapon weapon, AttributeScores attributeScores)
    {
        List<float> damages = weapon.Damages;

        // perform inverse of skill mod if the weapon requirements were met
        if (weapon.RequirementsMet)
        {
            for (int i = 0; i < damages.Count; i++)
            {
                damages[i] = InverseSkillDamageEquation(damages[i], attributeScores.GetSkillValue(weapon.WeaponSkill));
            }

            // force damage
            weapon.ForceDamage = InverseSkillDamageEquation(weapon.ForceDamage, attributeScores.GetSkillValue(weapon.WeaponSkill));

            // ranged weapons
            if (weapon is RangedWeapon rangedWeapon)
            {
                InverseModifyRangedChargeTime(rangedWeapon, attributeScores);

                if (rangedWeapon.IsThrowingWeapon)
                {
                    // throwing weapons
                    rangedWeapon.ProjectileSpeed = InverseSkillDamageEquation(rangedWeapon.ProjectileSpeed, attributeScores.GetSkillValue(weapon.WeaponSkill));
                    rangedWeapon.MaxRange = InverseSkillDamageEquation(rangedWeapon.MaxRange, attributeScores.GetSkillValue(weapon.WeaponSkill));
                    rangedWeapon.EffectiveRange = InverseSkillDamageEquation(rangedWeapon.EffectiveRange, attributeScores.GetSkillValue(weapon.WeaponSkill));
                }
                else
                {
                    InverseModifyReloadTime(rangedWeapon, attributeScores);
                    InverseModifySpread(rangedWeapon, attributeScores);
                }
            }
            else if (weapon is MeleeWeapon meleeWeapon)
            {
                InverseModifyMeleeWeaponChargeTime(meleeWeapon, attributeScores);
            }
        }
        else
        {
            // inverse insufficient strength or skills
            for (int i = 0; i < damages.Count; i++)
            {
                damages[i] /= mishandleDamageMod;
            }

            if (weapon is RangedWeapon rangedWeapon)
            {
                if (!(rangedWeapon.IsThrowingWeapon && rangedWeapon.IsExplosive))
                    rangedWeapon.Spread -= mishandleSpreadMod;

                rangedWeapon.ReloadTime /= mishandleReloadTimeMod;
                rangedWeapon.ChargeTime /= mishandleRangedChargeTimeMod;

                if (rangedWeapon.IsThrowingWeapon && !rangedWeapon.IsExplosive)
                {
                    rangedWeapon.MaxRange /= mishandleThrowingRangeMod;
                    rangedWeapon.EffectiveRange /= mishandleThrowingRangeMod;
                }
            }
            else if (weapon is MeleeWeapon meleeWeapon)
            {
                meleeWeapon.ChargeTime /= mishandleMeleeChargeTimeMod;
            }
        }
    }

    public static float SkillDamageEquation(float damage, int skillValue)
    {
        // min .5x, max 1.5x
        return damage * ((skillModBase + skillValue * skillModWeight) / 100);
    }

    public static float InverseSkillDamageEquation(float damage, int skillValue)
    {
        return damage / ((skillModBase + skillValue * skillModWeight) / 100);
    }

    public static void ModifyReloadTime(RangedWeapon rangedWeapon, AttributeScores attributeScores)
    {
        rangedWeapon.ReloadTime *= (1f / attributeScores.reloadSpeedMultiplier);
    }

    public static void InverseModifyReloadTime(RangedWeapon rangedWeapon, AttributeScores attributeScores)
    {
        rangedWeapon.ReloadTime *= attributeScores.reloadSpeedMultiplier;
    }

    public static void ModifySpread(RangedWeapon rangedWeapon, AttributeScores attributeScores)
    {
        switch (rangedWeapon.WeaponSkill)
        {
            case AttributeScores.Skills.HEAVY_WEAPONS:
                rangedWeapon.Spread /= attributeScores.heavyWeaponsSpreadMod;
                break;
            case AttributeScores.Skills.PISTOLS:
                rangedWeapon.Spread /= attributeScores.pistolsSpreadMod;
                break;
            case AttributeScores.Skills.RIFLES:
                rangedWeapon.Spread /= attributeScores.riflesSpreadMod;
                break;
        }
    }

    public static void InverseModifySpread(RangedWeapon rangedWeapon, AttributeScores attributeScores)
    {
        switch (rangedWeapon.WeaponSkill)
        {
            case AttributeScores.Skills.HEAVY_WEAPONS:
                rangedWeapon.Spread *= attributeScores.heavyWeaponsSpreadMod;
                break;
            case AttributeScores.Skills.PISTOLS:
                rangedWeapon.Spread *= attributeScores.pistolsSpreadMod;
                break;
            case AttributeScores.Skills.RIFLES:
                rangedWeapon.Spread *= attributeScores.riflesSpreadMod;
                break;
        }
    }

    public static void ModifyRangedChargeTime(RangedWeapon rangedWeapon, AttributeScores attributeScores)
    {
        switch (rangedWeapon.WeaponSkill)
        {
            case AttributeScores.Skills.HEAVY_WEAPONS:
                rangedWeapon.ChargeTime *= attributeScores.heavyWeaponsChargeMod;
                break;
            case AttributeScores.Skills.PISTOLS:
                rangedWeapon.ChargeTime *= attributeScores.pistolsChargeMod;
                break;
            case AttributeScores.Skills.RIFLES:
                rangedWeapon.ChargeTime *= attributeScores.riflesChargeMod;
                break;
            case AttributeScores.Skills.THROWING:
                rangedWeapon.ChargeTime *= attributeScores.throwingChargeMod;
                break;
        }
    }

    public static void InverseModifyRangedChargeTime(RangedWeapon rangedWeapon, AttributeScores attributeScores)
    {
        switch (rangedWeapon.WeaponSkill)
        {
            case AttributeScores.Skills.HEAVY_WEAPONS:
                rangedWeapon.ChargeTime /= attributeScores.heavyWeaponsChargeMod;
                break;
            case AttributeScores.Skills.PISTOLS:
                rangedWeapon.ChargeTime /= attributeScores.pistolsChargeMod;
                break;
            case AttributeScores.Skills.RIFLES:
                rangedWeapon.ChargeTime /= attributeScores.riflesChargeMod;
                break;
            case AttributeScores.Skills.THROWING:
                rangedWeapon.ChargeTime /= attributeScores.throwingChargeMod;
                break;
        }
    }

    public static void ModifyMeleeWeaponChargeTime(MeleeWeapon meleeWeapon, AttributeScores attributeScores)
    {
        switch (meleeWeapon.WeaponSkill)
        {
            case AttributeScores.Skills.BLUDGEONING:
                meleeWeapon.ChargeTime *= attributeScores.bludgeoningChargeMod;
                break;
            case AttributeScores.Skills.BLADE:
                meleeWeapon.ChargeTime *= attributeScores.bladeChargeMod;
                break;
            case AttributeScores.Skills.POLEARMS:
                meleeWeapon.ChargeTime *= attributeScores.polearmsChargeMod;
                break;
        }
    }

    public static void InverseModifyMeleeWeaponChargeTime(MeleeWeapon meleeWeapon, AttributeScores attributeScores)
    {
        switch (meleeWeapon.WeaponSkill)
        {
            case AttributeScores.Skills.BLUDGEONING:
                meleeWeapon.ChargeTime /= attributeScores.bludgeoningChargeMod;
                break;
            case AttributeScores.Skills.BLADE:
                meleeWeapon.ChargeTime /= attributeScores.bladeChargeMod;
                break;
            case AttributeScores.Skills.POLEARMS:
                meleeWeapon.ChargeTime /= attributeScores.polearmsChargeMod;
                break;
        }
    }

    public static void MultiplyAllDamage(List<float> damages, float damageMultiplier)
    {
        for (int i = 0; i < damages.Count; i++)
        {
            damages[i] = damages[i] * damageMultiplier;
        }
    }
}
