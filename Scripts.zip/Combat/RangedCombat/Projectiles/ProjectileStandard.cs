using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class ProjectileStandard : MonoBehaviour
{
    /*
     Free = will travel in the direction it is assigned at spawn
     Heat Seeking = Follow the closest enemy to the player
     Marked Target Seeking = Follow the target that was closest to the cursor when the projectile was spawned.
    */
    public enum FlightTypes
    {
        Free,
        Heat_seeking,
        Marked_target_seeking
    }

    [Header("Config")]
    public float speed;
    public Vector2 direction = new Vector2();
    public float effectiveRange;
    public float maxRange;
    public float dropOffDistance;
    public float rotationSpeed = 60f; // degrees per second
    [SerializeField] bool canHitMultipleTargets = false;
    [SerializeField] FlightTypes flightType;
    [SerializeField] bool boomerang;    // does the projectile return to the thrower after the turn is up?
    [SerializeField] float returnedDistance = 0.25f;    // how far does the projectile have to be from the shooter to be returned?
    [SerializeField] bool canBounce;
    [SerializeField] bool keepSpawnRotation = true;
    [SerializeField] bool destroyOnCollision = true;
    [SerializeField] bool destroyOnEnemyCollision = true;
    [SerializeField] bool destroyAtMaxRange = true;

    [Header("Return")]
    [SerializeField] bool shooterCanRetrieve = false;   // use this if you want to pick up the projectile when it returns but it's not a boomerang
    [SerializeField] float minDistanceBeforeCanRetrieve = 2f;

    [Header("Impact Effects")]
    [SerializeField] GameObject actorImpactEffect;
    [SerializeField] GameObject actorCritImpactEffect;
    [SerializeField] [Range(0, 31)] int enemyLayer = 9;
    [SerializeField] [Range(0, 31)] int playerLayer = 6;
    [SerializeField] GameObject wallImpactEffect;
    [SerializeField] [Range(0, 31)] int wallLayer = 10;
    [SerializeField] [Range(0, 31)] int knockdownLayer = 21;

    [Header("Events")]
    public UnityEvent returningToShooter;
    public UnityEvent returnedToShooter;
    public UnityEvent collisionEvent;
    public UnityEvent projectileStoppedEvent;

    [Header("State")]
    [SerializeField] bool isReturningToShooter = false;

    bool targetHit = false;
    [SerializeField] Transform target;       // used for heat seeking
    [SerializeField] Transform originWeaponTransform;

    // Character
    GameObject shooter;

    // range
    float distanceTravelled = 0;
    float rangeDamageMultiplier = 1f;
    Vector3 lastPosition;

    // cache
    RangedWeapon originWeapon;
    Rigidbody2D rb;
    public DamageDealer damageDealer;

    public FlightTypes FlightType { get => flightType; set => flightType = value; }
    public GameObject Shooter { get => shooter; }
    public RangedWeapon OriginWeapon { get => originWeapon; set => originWeapon = value; }

    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        damageDealer = GetComponent<DamageDealer>();
    }

    // Start is called before the first frame update
    void Start()
    {
        lastPosition = transform.position;
        dropOffDistance = maxRange - effectiveRange;
        
        if (FlightType == FlightTypes.Heat_seeking)
        {
            SetTargetToClosestEnemy();
        }
        else if (FlightType == FlightTypes.Marked_target_seeking)
        {
            SetTargetToEnemyClosestToCursor();
        }

        if (!keepSpawnRotation)
        {
            transform.rotation = Quaternion.identity;
        }
    }

    // Update is called once per frame
    void Update()
    {
        if (boomerang)
        {
            ReturnAtMaxRange();
        }
        else if (destroyAtMaxRange)
        {
            DestroyAtMaxRange();
        }

        // non-boomerang retrieve
        if (distanceTravelled >= minDistanceBeforeCanRetrieve && shooterCanRetrieve && !boomerang)
        {
            TryReturnToShooter();
        }

        TrackDistance();
    }

    private void FixedUpdate()
    {
        Travel();
    }

    private void TrackDistance()
    {
        distanceTravelled += Vector3.Distance(transform.position, lastPosition);
        lastPosition = transform.position;

        if (isReturningToShooter)
        {
            distanceTravelled = maxRange;
        }

        // damage dropoff
        if (distanceTravelled > effectiveRange)
        {
            if (dropOffDistance == 0)
            {
                rangeDamageMultiplier = 1;
            }
            else
            {
                rangeDamageMultiplier = (maxRange - distanceTravelled) / dropOffDistance;
            }
        }
    }

    private void ReturnAtMaxRange()
    {
        if (distanceTravelled >= maxRange && !isReturningToShooter)
        {
            // return to thrower
            isReturningToShooter = true;
            target = originWeaponTransform;
            FlightType = FlightTypes.Heat_seeking;

            returningToShooter.Invoke();
        }
        else if (isReturningToShooter)
        {
            TryReturnToShooter();
        }
    }

    private void DestroyAtMaxRange()
    {
        // max range
        if (distanceTravelled >= maxRange)
        {
            Destroy(gameObject);
        }
    }

    void Travel()
    {
        switch (FlightType)
        {
            case FlightTypes.Free:
                rb.velocity = new Vector2(direction.x * speed, direction.y * speed);
                break;
            case FlightTypes.Heat_seeking:
                SeekTarget();
                break;
            case FlightTypes.Marked_target_seeking:
                SeekTarget();
                break;
        }
    }

    private void SeekTarget()
    {
        Vector2 directionToTarget = (Vector2)target.position - rb.position;
        directionToTarget.Normalize();

        float rotationAmount = Vector3.Cross(directionToTarget, transform.right).z;

        rb.angularVelocity = -rotationAmount * rotationSpeed;
        rb.velocity = transform.right * speed;
    }

    private void TryReturnToShooter()
    {
        // announce that the projectile has returned to the shooter
        float distanceToShooter = Vector3.Distance(transform.position, originWeaponTransform.position);
        if (distanceToShooter <= returnedDistance)
        {
            returnedToShooter.Invoke();
        }
    }

    public void SetAttributes(GameObject _shooter, Transform _originWeaponTransform, RangedWeapon rangedWeapon, Vector2 pivotDirection, float speedMultiplier = 1f, float distanceMultiplier = 1f, float chargeDamageModifier = 0f)
    {
        // shooter
        shooter = _shooter;

        // speed
        speed = rangedWeapon.ProjectileSpeed * speedMultiplier;

        // copy damages
        damageDealer.CopyDamageList(rangedWeapon.Damages);
        damageDealer.CopyDamageTypeList(rangedWeapon.DamageTypes);

        // status effects
        damageDealer.SetStatusEffectDamagePercentage(rangedWeapon.StatusEffectDamagePercentage);
        damageDealer.ForceDamage = rangedWeapon.ForceDamage;
        damageDealer.BleedBuildup = rangedWeapon.BleedBuildup;

        // modify damage based on charge time
        damageDealer.MultiplyAllDamage(1f + chargeDamageModifier);
        damageDealer.ForceDamage *= (1f + chargeDamageModifier);

        // range
        effectiveRange = rangedWeapon.EffectiveRange * distanceMultiplier;
        maxRange = rangedWeapon.MaxRange * distanceMultiplier;

        canHitMultipleTargets = rangedWeapon.CanHitMultipleTargets;

        OriginWeapon = rangedWeapon;
        originWeaponTransform = _originWeaponTransform;

        direction = pivotDirection;
    }

    public void SetTargetToClosestEnemy()
    {
        var enemies = FindObjectsOfType<Enemy>();

        float minDistance = float.MaxValue;
        Enemy minDistanceEnemy = null;

        foreach (Enemy enemy in enemies)
        {
            if (enemy.Health.Alive)
            {
                float enemyDistance = Vector3.Distance(transform.position, enemy.transform.position);

                if (enemyDistance < minDistance)
                {
                    minDistance = enemyDistance;
                    minDistanceEnemy = enemy;
                }
            }
        }

        // free fire if no enemy target
        if (minDistanceEnemy)
        {
            target = minDistanceEnemy.transform;
        }
        else
        {
            FlightType = FlightTypes.Free;
        }
    }

    void SetTargetToEnemyClosestToCursor()
    {
        var enemies = FindObjectsOfType<Enemy>();
        Vector3 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);

        float minDistance = float.MaxValue;
        Enemy minDistanceEnemy = null;

        foreach (Enemy enemy in enemies)
        {
            if (enemy.Health.Alive)
            {
                float enemyDistance = Vector3.Distance(mousePos, enemy.transform.position);

                if (enemyDistance < minDistance)
                {
                    minDistance = enemyDistance;
                    minDistanceEnemy = enemy;
                }
            }
        }

        // free fire if no enemy target
        if (minDistanceEnemy)
        {
            target = minDistanceEnemy.transform;
        }
        else
        {
            FlightType = FlightTypes.Free;
        }
    }

    public void MultiplySpeed(float multiplier)
    {
        speed *= multiplier;

        if (speed <= 0.01f)
        {
            projectileStoppedEvent.Invoke();
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        // damage and destroy
        if ((!targetHit && !canHitMultipleTargets) || canHitMultipleTargets)
        {
            targetHit = true;

            // deal damage if not a thrown explosive (like a mine or a grenade)
            if (!(OriginWeapon.IsExplosive && OriginWeapon.IsThrowingWeapon))
            {
                // adjust damage based on range
                damageDealer.MultiplyAllDamage(rangeDamageMultiplier);

                // adjust force damage based on range
                damageDealer.ForceDamage *= rangeDamageMultiplier;

                damageDealer.CauseProjectileDamage(collision, Shooter, OriginWeapon);

                // knockback
                Knockback(collision);

                // spawn impact effect
                if ((collision.gameObject.layer == enemyLayer || collision.gameObject.layer == playerLayer) && actorImpactEffect)
                {
                    // hit enemy/player
                    if (damageDealer.CritSuccess)
                    {
                        Instantiate(actorCritImpactEffect, transform.position, Quaternion.identity);
                    }
                    else
                    {
                        Instantiate(actorImpactEffect, transform.position, Quaternion.identity);
                    }
                }
                else if ((collision.gameObject.layer == wallLayer) && wallImpactEffect)
                {
                    // hit wall
                    Vector2 n = collision.GetContact(0).normal.normalized;

                    float angle = Mathf.Atan2(n.y, n.x) * Mathf.Rad2Deg - 90f;

                    var newObject = Instantiate(wallImpactEffect, transform.position, Quaternion.identity);
                    newObject.transform.rotation = Quaternion.AngleAxis(angle, Vector3.forward);
                }
            }

            // If this is set to destroy on collision and not NOT set to destroy on enemy collision while colliding with an enemy, destroy
            if (destroyOnCollision && !(!destroyOnEnemyCollision && (collision.gameObject.layer == enemyLayer || collision.gameObject.layer == knockdownLayer)))
            {
                Destroy(gameObject);
            }
        }

        if (canBounce)
        {
            Bounce(collision);
        }

        collisionEvent.Invoke();
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        // damage and destroy
        if ((!targetHit && !canHitMultipleTargets) || canHitMultipleTargets)
        {
            targetHit = true;

            // deal damage if not a thrown explosive (like a mine or a grenade)
            if (!(OriginWeapon.IsExplosive && OriginWeapon.IsThrowingWeapon))
            {
                // adjust damage based on range
                damageDealer.MultiplyAllDamage(rangeDamageMultiplier);

                damageDealer.CauseTorchDamage(collision, Shooter, OriginWeapon);

                // knockback
                Knockback(collision);

                // spawn impact effect
                if ((collision.gameObject.layer == enemyLayer || collision.gameObject.layer == playerLayer) && actorImpactEffect)
                {
                    // hit enemy/player
                    if (damageDealer.CritSuccess)
                    {
                        Instantiate(actorCritImpactEffect, transform.position, Quaternion.identity);
                    }
                    else
                    {
                        Instantiate(actorImpactEffect, transform.position, Quaternion.identity);
                    }
                }
            }

            // If this is set to destroy on collision and not NOT set to destroy on enemy collision while colliding with an enemy, destroy
            if (destroyOnCollision && !(!destroyOnEnemyCollision && (collision.gameObject.layer == enemyLayer || collision.gameObject.layer == knockdownLayer)))
            {
                Destroy(gameObject);
            }

        }

        collisionEvent.Invoke();
    }

    public void Bounce(Collision2D collision)
    {
        Vector2 n = collision.GetContact(0).normal.normalized;
        direction = Vector3.Reflect(direction, n);
    }

    void Knockback(Collider2D collision)
    {
        if (OriginWeapon.KnockbackForce > 0)
        {
            Knockback actorKnockback = collision.gameObject.GetComponent<Knockback>();
            if (actorKnockback)
            {
                actorKnockback.TriggerKnockback(transform.right, OriginWeapon.KnockbackForce, OriginWeapon.KnockbackTime);
            }
        }
    }

    void Knockback(Collision2D collision)
    {
        if (OriginWeapon.KnockbackForce > 0)
        {
            Knockback actorKnockback = collision.gameObject.GetComponent<Knockback>();
            if (actorKnockback)
            {
                actorKnockback.TriggerKnockback(transform.right, OriginWeapon.KnockbackForce, OriginWeapon.KnockbackTime);
            }
        }
    }
}
