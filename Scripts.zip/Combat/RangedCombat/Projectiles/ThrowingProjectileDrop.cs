using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ThrowingProjectileDrop : MonoBehaviour
{
    [SerializeField] GameObject itemToDrop;
    [SerializeField] int dropChance = 50;
    [SerializeField] bool dropped = false;
    [SerializeField] LayerMask pitLayerMask;
    [SerializeField] float pitDetectionRadius = .25f;

    public int DropChance { get => dropChance; set => dropChance = value; }

    private void OnDestroy()
    {
        bool fellInPit = Physics2D.OverlapCircle(transform.position, pitDetectionRadius, pitLayerMask);

        if (RollForDrop() && !fellInPit && !dropped)
        {
            dropped = true;
            GameObject droppedItem = Instantiate(itemToDrop, transform.position, Quaternion.identity);

            // transfer stats if item is mine
            Mine mine = droppedItem.GetComponent<Mine>();
            if (mine)
            {
                // copy damages and damage list from projectile to mine
                ProjectileStandard projectile = GetComponent<ProjectileStandard>();

                mine.CopyDamageList(projectile.damageDealer.Damages);
                mine.CopyDamageTypeList(projectile.damageDealer.DamageTypes);
                mine.SetStatusEffectDamagePercentage(projectile.damageDealer.StatusEffectDamagePercentage);

                mine.Owner = projectile.Shooter;
            }
        }
    }

    private bool RollForDrop()
    {
        // get a random number between 1 and 100
        int roll = Random.Range(1, 101);

        // ex: a critChance of 100 will always succeed, a 0 will always fail
        if (roll <= DropChance)
        {
            return true;
        }

        return false;
    }
}
