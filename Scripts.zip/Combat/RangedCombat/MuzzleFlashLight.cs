using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MuzzleFlashLight : MonoBehaviour
{
    [Header("Config")]
    [SerializeField] Vector3 defaultScale = new Vector3(0.1f, 0.1f, 0f);
    [SerializeField] float scaleVariance = 0.05f;
    [SerializeField] float muzzleFlashTime = 0.1f;

    [Header("References")]
    [SerializeField] GameObject lightMask;
    [SerializeField] Transform innerMask;
    [SerializeField] Transform outerMask;

    public void TriggerMuzzleFlash()
    {
        StartCoroutine(MuzzleFlash());
    }

    IEnumerator MuzzleFlash()
    {
        lightMask.SetActive(true);

        float scaleDelta = Random.Range(-scaleVariance, scaleVariance);

        innerMask.localScale += new Vector3(scaleDelta, scaleDelta, 0f);
        outerMask.localScale += new Vector3(scaleDelta, scaleDelta, 0f);

        yield return new WaitForSeconds(muzzleFlashTime);

        innerMask.localScale = defaultScale;
        outerMask.localScale = defaultScale;

        lightMask.SetActive(false);
    }

    // doesn't turn back off
    public void TurnLightOn()
    {
        lightMask.SetActive(true);
    }

    public void TurnLightOff()
    {
        lightMask.SetActive(false);
    }
}
