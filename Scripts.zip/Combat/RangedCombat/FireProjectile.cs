using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FireProjectile : MonoBehaviour
{
    [Header("Projectile")]
    [SerializeField] GameObject projectile;
    [SerializeField] Vector3 projectileOffset = new Vector3(0, 0, 0);

    [Header("Audio")]
    [SerializeField] AudioSource audioSource;
    [SerializeField] AudioClip shotAudio;               // for single shot or last shot in an automatic weapon
    [SerializeField] [Range(0, 1)] float shotVolume;
    [SerializeField] AudioClip fireLoopAudio;           // for automatic weapon
    [SerializeField] [Range(0, 1)] float fireLoopAudioVolume = 1f;
    [SerializeField] AudioClip warmupAudio;
    [SerializeField] [Range(0, 1)] float warmupAudioVolume = 1f;

    [Header("Animation")]
    [SerializeField] Animator animator;

    [Header("State")]
    public bool isFiring = false;

    // cache
    EquippedWeapon equippedWeapon;
    RangedWeapon rangedWeapon;
    ShakeBehavior shaker;
    WeaponReloader weaponReloader;
    AttributeScores playerAttributes;
    MuzzleFlashLight muzzleFlashLight;

    // coroutines
    Coroutine firingCoroutine;

    // Start is called before the first frame update
    void Start()
    {
        equippedWeapon = GetComponent<EquippedWeapon>();
        playerAttributes = equippedWeapon.owner.GetComponent<AttributeScores>();
        rangedWeapon = (RangedWeapon)equippedWeapon.ItemData;
        shaker = FindObjectOfType<ShakeBehavior>();
        weaponReloader = GetComponent<WeaponReloader>();
        muzzleFlashLight = GetComponent<MuzzleFlashLight>();
    }

    float GetRandomizedDirection()
    {
        return Random.Range(-rangedWeapon.Spread, rangedWeapon.Spread);
    }

    public void TrySpawnProjectile(float chargedSweetSpotDamageMultiplier = 1f, float chargedSweetSpotVelocityMultiplier = 1f, float chargedSweetSpotShakeMultiplier = 1f, float chargeDamageModifier = 0f)
    {
        if (weaponReloader.AmmoInClip - rangedWeapon.AmmoUsedPerShot >= 0)
        {
            if (rangedWeapon.TimeBetweenProjectilesInShot > 0)
            {
                // burst fire, delay shots
                StartCoroutine(BurstFireProjectiles(chargedSweetSpotDamageMultiplier, chargedSweetSpotVelocityMultiplier, chargedSweetSpotShakeMultiplier, chargeDamageModifier));
            }
            else
            {
                // spawn all projectiles at the same time
                for (int i = 0; i < rangedWeapon.ProjectilesPerShot; i++)
                {
                    SpawnProjectile(chargedSweetSpotDamageMultiplier, chargedSweetSpotVelocityMultiplier, chargedSweetSpotShakeMultiplier, chargeDamageModifier);
                }

                // play sound
                AudioUtility.PlaySound(audioSource, shotAudio, shotVolume);
            }

            // decrease ammo count
            weaponReloader.DecreaseAmmoInClip(rangedWeapon.AmmoUsedPerShot);

            // decrease sweet spot bonus damage rounds
            if (weaponReloader.BonusDamageRoundsLoaded > 0)
            {
                weaponReloader.BonusDamageRoundsLoaded--;
            }
        }
        else
        {
            // Empty magazine
            equippedWeapon.StatusMessageManager.DisplayMessage("EMPTY");
        }
    }

    IEnumerator BurstFireProjectiles(float chargedSweetSpotDamageMultiplier = 1f, float chargedSweetSpotVelocityMultiplier = 1f, float chargedSweetSpotShakeMultiplier = 1f, float chargeDamageModifier = 0f)
    {
        for (int i = 0; i < rangedWeapon.ProjectilesPerShot; i++)
        {
            SpawnProjectile(chargedSweetSpotDamageMultiplier, chargedSweetSpotVelocityMultiplier, chargedSweetSpotShakeMultiplier, chargeDamageModifier);

            // play sound
            AudioUtility.PlaySound(audioSource, shotAudio, shotVolume);

            // delay next shot
            yield return new WaitForSeconds(rangedWeapon.TimeBetweenProjectilesInShot);
        }
    }

    private void SpawnProjectile(float chargedSweetSpotDamageMultiplier = 1f, float chargedSweetSpotVelocityMultiplier = 1f, float chargedSweetSpotShakeMultiplier = 1f, float chargeDamageModifier = 0f)
    {
        GameObject firedProjectile = Instantiate(projectile, transform.position + projectileOffset, equippedWeapon.pivot.rotation);

        // add spread to projectile and set attributes
        firedProjectile.transform.Rotate(0, 0, GetRandomizedDirection());
        SetProjectileAttributes(firedProjectile, chargedSweetSpotVelocityMultiplier, chargeDamageModifier);

        DamageDealer damageDealer = firedProjectile.GetComponent<DamageDealer>();

        // set projectile's crit chance and damage
        damageDealer.CritChance = playerAttributes.critChance + rangedWeapon.BonusCritChance;
        damageDealer.CritMultiplier = playerAttributes.critDamageMultiplier + rangedWeapon.BonusCritMultiplier;

        // add bonus damage on reload sweet spot hit
        if (weaponReloader.BonusDamageRoundsLoaded > 0)
        {
            damageDealer.MultiplyAllDamage(weaponReloader.SweetSpotDamageMultiplier);
        }

        // add bonus damage on charge weapon sweet spot hit
        damageDealer.MultiplyAllDamage(chargedSweetSpotDamageMultiplier);

        // animate
        if (animator && !rangedWeapon.IsAutomatic)
        {
            animator.Play("Fire", -1, 0.0f);
        }

        // muzzle flash
        if (muzzleFlashLight)
        {
            muzzleFlashLight.TriggerMuzzleFlash();
        }

        // shake the screen
        shaker.ShakeCamera(rangedWeapon.ScreenShakeIntensity * chargedSweetSpotShakeMultiplier, rangedWeapon.ScreenShakeDuration);
    }

    private void SetProjectileAttributes(GameObject firedProjectile, float chargedSweetSpotVelocityMultiplier = 1f, float chargeDamageModifier = 0f)
    {
        float zAngle = firedProjectile.transform.rotation.eulerAngles.z * (Mathf.PI / 180f);
        float xComponent = Mathf.Cos(zAngle);
        float yComponent = Mathf.Sin(zAngle);
        Vector2 pivotDirection = new Vector2(xComponent, yComponent);

        firedProjectile.GetComponent<ProjectileStandard>().SetAttributes(equippedWeapon.owner, transform, rangedWeapon, pivotDirection, chargedSweetSpotVelocityMultiplier, chargeDamageModifier: chargeDamageModifier);
    }

    public void TriggerSpawnProjectileFullAuto()
    {
        firingCoroutine = StartCoroutine(SpawnProjectileFullAuto());
    }

    public void StopSpawningFullAuto(bool playLastShotSound = false)
    {
        if (!(firingCoroutine is null) && isFiring)
        {
            StopCoroutine(firingCoroutine);
            isFiring = false;

            // animation
            if (animator)
            {
                animator.SetBool("AnimIsFiring", false);
                animator.SetBool("AnimIsCharging", false);
            }

            // sound
            AudioUtility.StopLoopingAudio(audioSource);

            // play last shot
            if (playLastShotSound)
            {
                AudioUtility.PlaySound(audioSource, shotAudio, shotVolume);
            }
        }
    }

    IEnumerator SpawnProjectileFullAuto()
    {
        // check that there's enough ammo in the clip
        if (weaponReloader.AmmoInClip - rangedWeapon.AmmoUsedPerShot >= 0)
        {
            isFiring = true;

            // wait for a moment to warm up
            if (rangedWeapon.WarmupTime > 0)
            {
                // animation
                if (animator)
                {
                    animator.SetBool("AnimIsCharging", true);
                }

                // play warmup audio
                AudioUtility.PlaySound(audioSource, warmupAudio, warmupAudioVolume);

                yield return new WaitForSeconds(rangedWeapon.WarmupTime);
            }

            // loop sound
            AudioUtility.LoopAudio(audioSource, fireLoopAudio, fireLoopAudioVolume);

            // animation
            if (animator)
            {
                animator.SetBool("AnimIsFiring", true);
            }

            while (true)
            {
                SpawnProjectile();

                // decrease ammo count
                weaponReloader.DecreaseAmmoInClip(rangedWeapon.AmmoUsedPerShot);

                // decrease sweet spot bonus damage rounds
                if (weaponReloader.BonusDamageRoundsLoaded > 0)
                {
                    weaponReloader.BonusDamageRoundsLoaded--;
                }

                // break if ammo goes below or equal to 0
                if (weaponReloader.AmmoInClip <= 0)
                {
                    // out of ammo
                    isFiring = false;

                    // animation
                    if (animator)
                    {
                        animator.SetBool("AnimIsFiring", false);
                        animator.SetBool("AnimIsCharging", false);
                    }

                    AudioUtility.StopLoopingAudio(audioSource);

                    // play last shot
                    AudioUtility.PlaySound(audioSource, shotAudio, shotVolume);

                    yield break;
                }

                yield return new WaitForSeconds(1 / rangedWeapon.AttackRate);
            }
        }
        else
        {
            // out of ammo
            isFiring = false;

            // animation
            if (animator)
            {
                animator.SetBool("AnimIsFiring", false);
            }

            // Empty magazine
            equippedWeapon.StatusMessageManager.DisplayMessage("EMPTY");

            AudioUtility.StopLoopingAudio(audioSource);

            yield break;
        }
    }
}
