using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class DamageDealer : MonoBehaviour
{
    [Header("Floating Text")]
    [SerializeField] GameObject floatingText;

    [Header("Damage Info")]
    [SerializeField] List<float> damages = new List<float>();
    [SerializeField] List<DamageEffects.DamageType> damageTypes;

    [Header("Status Effects")]
    [SerializeField] float statusEffectDamagePercentage;
    [SerializeField] float bleedBuildup;

    [Header("Poise")]
    [SerializeField] float forceDamage;

    [Header("Critical Hits")]
    [SerializeField] int critChance = 0;
    [SerializeField] float critMultiplier = 2f;
    [SerializeField] bool critSuccess = false;    // set to true if there is a critical hit

    // Cached references
    StatusMessageManager statusMessageManager;
    LaserWeapon laserWeapon;
    AIFireLaser aiLaserWeapon;


    private void Awake()
    {
        statusMessageManager = FindObjectOfType<StatusMessageManager>();
        laserWeapon = GetComponent<LaserWeapon>();
        aiLaserWeapon = GetComponent<AIFireLaser>();
    }

    public List<float> Damages { get => damages; }
    public List<DamageEffects.DamageType> DamageTypes { get => damageTypes; }
    public float StatusEffectDamagePercentage { get => statusEffectDamagePercentage; set => statusEffectDamagePercentage = value; }
    public float ForceDamage { get => forceDamage; set => forceDamage = value; }
    public int CritChance { get => critChance; set => critChance = value; }
    public float CritMultiplier { get => critMultiplier; set => critMultiplier = value; }
    public bool CritSuccess { get => critSuccess; set => critSuccess = value; }
    public float BleedBuildup { get => bleedBuildup; set => bleedBuildup = value; }

    public void MultiplyAllDamage(float damageMultiplier)
    {
        for (int i = 0; i < damages.Count; i++)
        {
            damages[i] = damages[i] * damageMultiplier;
        }
    }

    public void MultiplyAllDamage(List<float> damageList, float damageMultiplier)
    {
        for (int i = 0; i < damageList.Count; i++)
        {
            damageList[i] = damageList[i] * damageMultiplier;
        }
    }

    public void CopyDamageList(List<float> weaponDamages)
    {
        foreach (float oldDamage in weaponDamages)
        {
            damages.Add(oldDamage);
        }
    }

    public void CopyDamageTypeList(List<DamageEffects.DamageType> weaponDamageTypes)
    {
        foreach (DamageEffects.DamageType oldType in weaponDamageTypes)
        {
            damageTypes.Add(oldType);
        }
    }

    List<float> CopyDealerDamagesToNewList()
    {
        List<float> newDamages = new List<float>();

        foreach (float oldDamage in damages)
        {
            newDamages.Add(oldDamage);
        }

        return newDamages;
    }

    List<DamageEffects.DamageType> CopyDealerDamageTypesToNewList()
    {
        List<DamageEffects.DamageType> newTypes = new List<DamageEffects.DamageType>();

        foreach (DamageEffects.DamageType oldType in damageTypes)
        {
            newTypes.Add(oldType);
        }

        return newTypes;
    }

    public void SetStatusEffectDamagePercentage(float _statusEffectDamagePercentage)
    {
        statusEffectDamagePercentage = _statusEffectDamagePercentage;
    }

    public void ClearLists()
    {
        damages.Clear();
        damageTypes.Clear();
    }

    public bool CauseProjectileDamage(Collision2D collision, GameObject initiator, RangedWeapon originWeapon)
    {
        // get target's effect lists and health
        DamageThresholds damageThresholds = collision.gameObject.GetComponent<DamageThresholds>();
        DamageEffects resistances = collision.gameObject.GetComponent<DamageEffects>();
        Health health = collision.gameObject.GetComponent<Health>();
        Poise poise = collision.gameObject.GetComponent<Poise>();
        StatusEffects statusEffects = collision.gameObject.GetComponent<StatusEffects>();
        FlashOnHit flashOnHit = collision.gameObject.GetComponent<FlashOnHit>();
        Enemy enemy = collision.gameObject.GetComponent<Enemy>();

        bool targetKilled = false;

        if (health)
        {
            bool criticalHit = RollForCrit();

            // modify damage based on damage threshold
            if (!criticalHit)
            {
                // subtract DT
                if (damageThresholds)
                {
                    damageThresholds.ModifyIncomingDamage(damages, damageTypes);
                }

                // modify damage based on target resistances, immunities, and vulnerabilities
                if (resistances)
                {
                    resistances.ModifyIncomingDamage(damages, damageTypes);
                }
            }

            // deal crit damage
            if (criticalHit)
            {
                CritSuccess = true;
                MultiplyAllDamage(CritMultiplier);
                ForceDamage *= CritMultiplier;
            }

            // multiply damage by character's outgoing damage multiplier
            Character initiatingCharacter = initiator.GetComponent<Character>();
            if (initiatingCharacter)
            {
                MultiplyAllDamage(initiatingCharacter.OutgoingDamageMultiplier);
            }

            // deal damage to target health
            targetKilled = DealAllDamage(health);

            // trigger status effects
            if (statusEffects && health.Alive)
            {
                statusEffects.IncreaseBuildup(damages, damageTypes, statusEffectDamagePercentage, BleedBuildup);
            }

            // decrease poise
            if (poise)
            {
                poise.DecreasePoise(ForceDamage);
                poise.SetCollidingObjectDirection(GetComponent<Rigidbody2D>().velocity.normalized);   // if poise breaks, the actor knows the direction of the impact
            }

            // flash
            if (flashOnHit)
            {
                flashOnHit.TriggerFlash();
            }
        }

        // send message to CombatSystem if target killed
        if (targetKilled && enemy && originWeapon)
        {
            CombatSystemMessenger.Instance.SendEnemyKilledMessage(new EnemyKilledMessage(new Equippable(originWeapon), enemy.EnemyName));
        }

        return targetKilled;
    }

    // Returns true if target killed
    public bool CauseMeleeDamage(Collider2D collision, GameObject initiator, Weapon originWeapon)
    {
        // get target's effect lists and health
        DamageThresholds damageThresholds = collision.GetComponent<DamageThresholds>();
        DamageEffects resistances = collision.GetComponent<DamageEffects>();
        Health health = collision.GetComponent<Health>();
        Poise poise = collision.gameObject.GetComponent<Poise>();
        StatusEffects statusEffects = collision.GetComponent<StatusEffects>();
        FlashOnHit flashOnHit = collision.gameObject.GetComponent<FlashOnHit>();
        Enemy enemy = collision.gameObject.GetComponent<Enemy>();

        bool targetKilled = false;

        if (health)
        {
            bool criticalHit = RollForCrit();

            // modify damage based on damage threshold
            if (!criticalHit)
            {
                // subtract DT
                if (damageThresholds)
                {
                    damageThresholds.ModifyIncomingDamage(damages, damageTypes);
                }

                // modify damage based on target resistances, immunities, and vulnerabilities
                if (resistances)
                {
                    resistances.ModifyIncomingDamage(damages, damageTypes);
                }
            }

            // deal crit damage
            if (criticalHit)
            {
                CritSuccess = true;
                MultiplyAllDamage(CritMultiplier);
                ForceDamage *= CritMultiplier;
            }

            // multiply damage by character's outgoing damage multiplier
            Character initiatingCharacter = initiator.GetComponent<Character>();
            if (initiatingCharacter)
            {
                MultiplyAllDamage(initiatingCharacter.OutgoingDamageMultiplier);
            }

            // deal damage to target health
            targetKilled = DealAllDamage(health);

            // trigger status effects
            if (statusEffects && health.Alive)
            {
                statusEffects.IncreaseBuildup(damages, damageTypes, statusEffectDamagePercentage, BleedBuildup);
            }

            // decrease poise
            if (poise)
            {
                poise.DecreasePoise(ForceDamage);
                poise.SetCollidingObjectDirection(transform.up);   // if poise breaks, the actor knows the direction of the impact
            }

            // flash
            if (flashOnHit)
            {
                flashOnHit.TriggerFlash();
            }
        }

        // send message to CombatSystem if target killed
        if (targetKilled && enemy && originWeapon)
        {
            CombatSystemMessenger.Instance.SendEnemyKilledMessage(new EnemyKilledMessage(new Equippable(originWeapon), enemy.EnemyName));
        }

        return targetKilled;
    }

    public bool CauseLaserDamage(Collider2D collision, GameObject initiator, Weapon originWeapon)
    {
        // get target's effect lists and health
        DamageThresholds damageThresholds = collision.GetComponent<DamageThresholds>();
        DamageEffects resistances = collision.GetComponent<DamageEffects>();
        Health health = collision.GetComponent<Health>();
        Poise poise = collision.gameObject.GetComponent<Poise>();
        StatusEffects statusEffects = collision.GetComponent<StatusEffects>();
        FlashOnHit flashOnHit = collision.gameObject.GetComponent<FlashOnHit>();
        Enemy enemy = collision.gameObject.GetComponent<Enemy>();

        bool targetKilled = false;

        if (health)
        {
            CritSuccess = false;                // reset crit success
            bool criticalHit = RollForCrit();

            // modify damage based on damage threshold
            if (!criticalHit)
            {
                // subtract DT
                if (damageThresholds)
                {
                    damageThresholds.ModifyIncomingDamage(damages, damageTypes);
                }

                // modify damage based on target resistances, immunities, and vulnerabilities
                if (resistances)
                {
                    resistances.ModifyIncomingDamage(damages, damageTypes);
                }
            }

            // deal crit damage
            if (criticalHit)
            {
                CritSuccess = true;
                MultiplyAllDamage(CritMultiplier);
                ForceDamage *= CritMultiplier;
            }

            // multiply damage by character's outgoing damage multiplier
            Character initiatingCharacter = initiator.GetComponent<Character>();
            if (initiatingCharacter)
            {
                MultiplyAllDamage(initiatingCharacter.OutgoingDamageMultiplier);
            }

            // deal damage to target health
            targetKilled = DealAllDamage(health);

            // trigger status effects
            if (statusEffects && health.Alive)
            {
                statusEffects.IncreaseBuildup(damages, damageTypes, statusEffectDamagePercentage, BleedBuildup);
            }

            // decrease poise
            if (poise)
            {
                poise.DecreasePoise(ForceDamage);
                poise.SetCollidingObjectDirection(transform.up);   // if poise breaks, the actor knows the direction of the impact
            }

            // flash
            if (flashOnHit)
            {
                flashOnHit.TriggerFlash();
            }
        }

        // reset damage
        ClearLists();

        if (laserWeapon)
        {
            laserWeapon.CopyDamageListsToDamageDealer();
        }
        else if (aiLaserWeapon)
        {
            aiLaserWeapon.CopyDamageListsToDamageDealer();
        }

        // send message to CombatSystem if target killed
        if (targetKilled && enemy && originWeapon)
        {
            CombatSystemMessenger.Instance.SendEnemyKilledMessage(new EnemyKilledMessage(new Equippable(originWeapon), enemy.EnemyName));
        }

        return targetKilled;
    }

    public bool CauseTorchDamage(Collider2D collision, GameObject initiator, Weapon originWeapon, bool playHitSound = false, bool shakeScreen = true, bool performImmunityFlash = true)
    {
        // get target's effect lists and health
        DamageThresholds damageThresholds = collision.GetComponent<DamageThresholds>();
        DamageEffects resistances = collision.GetComponent<DamageEffects>();
        Health health = collision.GetComponent<Health>();
        Poise poise = collision.gameObject.GetComponent<Poise>();
        StatusEffects statusEffects = collision.GetComponent<StatusEffects>();
        FlashOnHit flashOnHit = collision.gameObject.GetComponent<FlashOnHit>();
        Enemy enemy = collision.gameObject.GetComponent<Enemy>();

        bool targetKilled = false;

        if (health)
        {
            List<float> copiedDamageList = CopyDealerDamagesToNewList();
            List<DamageEffects.DamageType> copiedDamageTypes = CopyDealerDamageTypesToNewList();
            float copiedForceDamage = forceDamage;

            bool criticalHit = RollForCrit();

            // modify damage based on damage threshold
            if (!criticalHit)
            {
                // subtract DT
                if (damageThresholds)
                {
                    damageThresholds.ModifyIncomingDamage(copiedDamageList, damageTypes);
                }

                // modify damage based on target resistances, immunities, and vulnerabilities
                if (resistances)
                {
                    resistances.ModifyIncomingDamage(copiedDamageList, damageTypes);
                }
            }

            // deal crit damage
            if (criticalHit)
            {
                CritSuccess = true;
                MultiplyAllDamage(copiedDamageList, CritMultiplier);
                copiedForceDamage *= CritMultiplier;
            }

            // multiply damage by character's outgoing damage multiplier
            Character initiatingCharacter = initiator.GetComponent<Character>();
            if (initiatingCharacter)
            {
                MultiplyAllDamage(initiatingCharacter.OutgoingDamageMultiplier);
            }

            // deal damage to target health
            targetKilled = DealAllDamage(copiedDamageList, health, playHitSound, shakeScreen, performImmunityFlash);

            // trigger status effects
            if (statusEffects && health.Alive)
            {
                statusEffects.IncreaseBuildup(CopyDealerDamagesToNewList(), CopyDealerDamageTypesToNewList(), statusEffectDamagePercentage, BleedBuildup);
            }

            // decrease poise
            if (poise)
            {
                poise.DecreasePoise(copiedForceDamage);
                poise.SetCollidingObjectDirection(transform.up);   // if poise breaks, the actor knows the direction of the impact
            }

            // flash
            if (flashOnHit)
            {
                flashOnHit.TriggerFlash();
            }
        }

        // send message to CombatSystem if target killed
        if (targetKilled && enemy && originWeapon)
        {
            CombatSystemMessenger.Instance.SendEnemyKilledMessage(new EnemyKilledMessage(new Equippable(originWeapon), enemy.EnemyName));
        }

        return targetKilled;
    }

    private bool RollForCrit()
    {
        // get a random number between 1 and 100
        int roll = Random.Range(1, 101);

        // ex: a critChance of 100 will always succeed, a 0 will always fail
        if (roll <= CritChance)
        {
            statusMessageManager.DisplayCriticalHitMessage();

            return true;
        }

        return false;
    }

    // Returns true if target was killed
    private bool DealAllDamage(Health health)
    {
        bool killedTarget = false;

        for (int i = 0; i < damages.Count; i++)
        {
            // don't do negative damage
            float val = Mathf.Max(damages[i], 0f);

            // damage popup, damage displayed is rounded
            if (floatingText)
            {
                GameObject damageText = Instantiate(floatingText, health.transform.position, Quaternion.identity);
                damageText.GetComponent<FloatingText>().SetParameters(val, damageTypes[i]);
            }

            // decrease health, noting if target was killed
            if (health.DecreaseHealth(val, damageTypes[i]))
            {
                killedTarget = true;
            }
        }

        return killedTarget;
    }

    // Returns true if target was killed
    private bool DealAllDamage(List<float> damageList, Health health, bool playHitSound = true, bool shakeScreen = true, bool performImmunityFlash = true)
    {
        bool killedTarget = false;

        for (int i = 0; i < damageList.Count; i++)
        {
            // don't do negative damage
            float val = Mathf.Max(damageList[i], 0f);

            // damage popup, damage displayed is rounded
            if (floatingText)
            {
                GameObject damageText = Instantiate(floatingText, health.transform.position, Quaternion.identity);
                damageText.GetComponent<FloatingText>().SetParameters(val, damageTypes[i]);
            }

            if (health.DecreaseHealth(val, damageTypes[i], playHitSound, shakeScreen, performImmunityFlash))
            {
                killedTarget = true;
            }
        }

        return killedTarget;
    }

    public float GetTotalDamage()
    {
        float total = 0;

        foreach (float dam in Damages)
        {
            total += dam;
        }

        return total;
    }
}
