using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TouchDamage : MonoBehaviour
{
    DamageDealer damageDealer;

    private void Awake()
    {
        damageDealer = GetComponent<DamageDealer>();
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.GetComponent<Player>())
        {
            damageDealer.CauseProjectileDamage(collision, gameObject, null);
        }
    }
}
