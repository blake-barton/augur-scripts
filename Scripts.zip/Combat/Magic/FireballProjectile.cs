using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FireballProjectile : MonoBehaviour
{
    [SerializeField] GameObject explosionTemplate;

    private GameObject caster;
    private List<float> damages = new List<float>();
    private List<DamageEffects.DamageType> damageTypes = new List<DamageEffects.DamageType>();
    private int critChance;
    private float critDamageMultiplier;
    private int damageTicks;
    private int ticksPerSecond;
    private float statusEffectDamagePercentage = .1f;

    public List<float> Damages { get => damages; set => damages = value; }
    public List<DamageEffects.DamageType> DamageTypes { get => damageTypes; set => damageTypes = value; }
    public int CritChance { get => critChance; set => critChance = value; }
    public float CritDamageMultiplier { get => critDamageMultiplier; set => critDamageMultiplier = value; }
    public int DamageTicks { get => damageTicks; set => damageTicks = value; }
    public int TicksPerSecond { get => ticksPerSecond; set => ticksPerSecond = value; }
    public float StatusEffectDamagePercentage { get => statusEffectDamagePercentage; set => statusEffectDamagePercentage = value; }
    public GameObject Caster { get => caster; set => caster = value; }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        GameObject effect = Instantiate(explosionTemplate, transform.position, Quaternion.identity);
        Explosion explosion = effect.GetComponent<Explosion>();
        explosion.DamageDealer.CopyDamageList(Damages);
        explosion.DamageDealer.CopyDamageTypeList(DamageTypes);
        explosion.DamageDealer.SetStatusEffectDamagePercentage(StatusEffectDamagePercentage);

        // set explosion's crit chance and damage
        explosion.DamageDealer.CritChance = CritChance;
        explosion.DamageDealer.CritMultiplier = CritDamageMultiplier;

        explosion.Attacker = Caster;
    }
}
