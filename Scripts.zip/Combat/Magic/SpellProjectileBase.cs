using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpellProjectileBase : MonoBehaviour
{
    [SerializeField] float speed;
    [SerializeField] Vector2 direction = new Vector2();
    [SerializeField] float maxRange;
    [SerializeField] float dropOffDistance;
    [SerializeField] bool canHitMultipleTargets = false;

    bool targetHit = false;

    // range
    float distanceTravelled = 0;
    Vector3 lastPosition;

    GameObject caster;

    // cache
    Rigidbody2D rb;

    public GameObject Caster { get => caster; }

    private void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
    }

    // Start is called before the first frame update
    void Start()
    {
        lastPosition = transform.position;
    }

    // Update is called once per frame
    void Update()
    {
        DestroyAtMaxRange();
    }

    private void FixedUpdate()
    {
        Travel();
    }

    private void DestroyAtMaxRange()
    {
        distanceTravelled += Vector3.Distance(transform.position, lastPosition);
        lastPosition = transform.position;

        // max range
        if (distanceTravelled >= maxRange)
        {
            Destroy(gameObject);
        }
    }

    void Travel()
    {
        rb.velocity = new Vector2(direction.x * speed, direction.y * speed);
    }

    public void SetAttributes(GameObject _caster, float _speed, float _maxRange, bool _canHitMultipleTargets, Vector2 pivotDirection)
    {
        caster = _caster;

        speed = _speed;
        maxRange = _maxRange;
        canHitMultipleTargets = _canHitMultipleTargets;

        direction = pivotDirection;
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if ((!targetHit && !canHitMultipleTargets) || canHitMultipleTargets)
        {
            targetHit = true;

            Destroy(gameObject);
        }
    }
}
