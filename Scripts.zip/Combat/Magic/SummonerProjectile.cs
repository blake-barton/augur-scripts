using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SummonerProjectile : MonoBehaviour
{
    [SerializeField] GameObject creature;
    [SerializeField] int numberToSpawn;
    [SerializeField] List<Character.ECharacterAttributes> positiveAttributes = new List<Character.ECharacterAttributes>();
    [SerializeField] List<Character.ECharacterAttributes> negativeAttributes = new List<Character.ECharacterAttributes>();

    private void OnCollisionEnter2D(Collision2D collision)
    {
        Character character = collision.gameObject.GetComponent<Character>();

        if (character)
        {
            bool allPositiveAttributes = true;
            bool noNegativeAttributes = true;

            // ensure that the enemy has all the attributes in positiveAttributes
            if (positiveAttributes.Count > 0)
            {
                foreach (Character.ECharacterAttributes attr in positiveAttributes)
                {
                    if (!character.CharacterAttributes.Contains(attr))
                    {
                        allPositiveAttributes = false;
                        break;
                    }
                }
            }

            if (allPositiveAttributes)
            {
                // ensure that enemy has none of the negative attributes
                if (negativeAttributes.Count > 0)
                {
                    foreach (Character.ECharacterAttributes attr in negativeAttributes)
                    {
                        if (character.CharacterAttributes.Contains(attr))
                        {
                            noNegativeAttributes = false;
                            break;
                        }
                    }
                }

                // spawn if all positive and no negative
                if (allPositiveAttributes && noNegativeAttributes)
                {
                    for (int i = 0; i < numberToSpawn; i++)
                    {
                        GameObject newCreature = Instantiate(creature, character.transform.position, Quaternion.identity);

                        // play spawn animation
                        newCreature.GetComponent<Animator>().Play("Spawn", -1, 0.0f);
                    }

                    // destroy corpse
                    Destroy(collision.gameObject);
                }
            }
        }
    }
}
