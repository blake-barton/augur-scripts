using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EquippedSpell : MonoBehaviour
{
    private Spell spell;
    private GameObject owner;

    [Header("Rotation")]
    public bool isMainHand = false;
    Transform target;
    [SerializeField] float radius = 0.5f;
    public Transform pivot;

    Player player;

    public Spell Spell { get => spell; set => spell = value; }
    public GameObject Owner { get => owner; set => owner = value; }

    private void Awake()
    {
        player = FindObjectOfType<Player>();
    }

    // Start is called before the first frame update
    void Start()
    {
        // rotation
        target = transform.parent;
        pivot = new GameObject().transform;
        transform.parent = pivot;
    }

    // Update is called once per frame
    void Update()
    {
        RotateAroundPlayer();
    }

    void RotateAroundPlayer()
    {
        if (player.IsGamepad)
        {
            // If deadzone exceeded, rotate. Otherwise just track position
            if (Mathf.Abs(player.AimDirection.x) > player.GamepadDeadzone || Mathf.Abs(player.AimDirection.y) > player.GamepadDeadzone)
            {
                float angle = Mathf.Atan2(player.AimDirection.y, player.AimDirection.x) * Mathf.Rad2Deg;

                Vector2 newPosition = Quaternion.AngleAxis(angle, Vector3.forward) * (Vector3.right * radius);
                transform.position = (Vector2)target.position + newPosition;

                pivot.SetPositionAndRotation(target.position, Quaternion.AngleAxis(angle, Vector3.forward));
            }
            else
            {
                // Look at orbiter
                Vector3 v3Pos = player.GamepadOrbiter.transform.position - target.position;
                float angle = Mathf.Atan2(v3Pos.y, v3Pos.x) * Mathf.Rad2Deg;

                v3Pos = Quaternion.AngleAxis(angle, Vector3.forward) * (Vector3.right * radius);
                transform.position = target.position + v3Pos;

                pivot.SetPositionAndRotation(target.position, Quaternion.AngleAxis(angle, Vector3.forward));
            }
        }
        else
        {
            Vector3 v3Pos = Camera.main.WorldToScreenPoint(target.position);
            v3Pos = Input.mousePosition - v3Pos;
            float angle = Mathf.Atan2(v3Pos.y, v3Pos.x) * Mathf.Rad2Deg;

            v3Pos = Quaternion.AngleAxis(angle, Vector3.forward) * (Vector3.right * radius);
            transform.position = target.position + v3Pos;

            pivot.SetPositionAndRotation(target.position, Quaternion.AngleAxis(angle, Vector3.forward));
        }
    }
}
