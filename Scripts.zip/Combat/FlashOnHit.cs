using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FlashOnHit : MonoBehaviour
{
    public enum FlashType
    {
        Color,
        Material
    }

    [SerializeField] FlashType flashType;
    [SerializeField] SpriteRenderer spriteRenderer;
    [SerializeField] Color colorFlashOnHit;
    [SerializeField] float colorFlashTime = .2f;
    [SerializeField] Material flashMaterial;

    [Header("State")]
    [SerializeField] bool isFlashing = false;

    // colors
    Color originalColor;
    Material originalMaterial;

    // coroutines
    Coroutine continousFlash;

    public bool IsFlashing { get => isFlashing; set => isFlashing = value; }

    private void Awake()
    {
        originalColor = spriteRenderer.color;
        originalMaterial = spriteRenderer.material;
    }

    private IEnumerator ChangeColor()
    {
        spriteRenderer.color = colorFlashOnHit;
        yield return new WaitForSeconds(colorFlashTime);

        spriteRenderer.color = originalColor;
    }

    private IEnumerator ChangeColorContinuously()
    {
        IsFlashing = true;

        while (true)
        {
            // toggle color
            if (spriteRenderer.color == colorFlashOnHit)
            {
                spriteRenderer.color = originalColor;
            }
            else
            {
                spriteRenderer.color = colorFlashOnHit;
            }

            yield return new WaitForSeconds(colorFlashTime);
        }
    }

    private IEnumerator ChangeMaterialContinuously()
    {
        IsFlashing = true;

        while (true)
        {
            // toggle color
            if (spriteRenderer.material == flashMaterial)
            {
                spriteRenderer.material = originalMaterial;
            }
            else
            {
                spriteRenderer.material = flashMaterial;
            }

            yield return new WaitForSeconds(colorFlashTime);
        }
    }

    private IEnumerator ChangeMaterial()
    {
        spriteRenderer.material = flashMaterial;
        yield return new WaitForSeconds(colorFlashTime);

        spriteRenderer.material = originalMaterial;
    }

    public void TriggerFlash()
    {
        switch (flashType)
        {
            case FlashType.Color:
                StartCoroutine(ChangeColor());
                break;
            case FlashType.Material:
                StartCoroutine(ChangeMaterial());
                break;
        }
    }

    public void TriggerFlashContinous()
    {
        switch (flashType)
        {
            case FlashType.Color:
                continousFlash = StartCoroutine(ChangeColorContinuously());
                break;
            case FlashType.Material:
                continousFlash = StartCoroutine(ChangeMaterialContinuously());
                break;
            default:
                break;
        }
    }

    public void StopFlashContinuous()
    {
        if (continousFlash != null)
        {
            StopCoroutine(continousFlash);
        }

        IsFlashing = false;
        spriteRenderer.color = originalColor;
        spriteRenderer.material = originalMaterial;
    }
}
