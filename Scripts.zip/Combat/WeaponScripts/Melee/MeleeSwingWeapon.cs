using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class MeleeSwingWeapon : WeaponScript
{
    public EquippedWeapon equippedWeapon;
    MeleeWeapon meleeWeapon;
    MeleeAttack meleeAttack;
    PlayerMovement playerMovement;
    TabMenuManager tabMenuManager;
    WeaponWheelManager weaponWheelManager;
    Player player;

    float nextAttackTime;

    private void Awake()
    {
        equippedWeapon = GetComponent<EquippedWeapon>();
        meleeAttack = GetComponent<MeleeAttack>();
        playerMovement = FindObjectOfType<PlayerMovement>();
        tabMenuManager = FindObjectOfType<TabMenuManager>();
        weaponWheelManager = FindObjectOfType<WeaponWheelManager>();
        player = FindObjectOfType<Player>();
    }

    // Start is called before the first frame update
    void Start()
    {
        meleeWeapon = (MeleeWeapon)equippedWeapon.ItemData;
    }

    public override void Use(InputAction.CallbackContext context)
    {
        // start swing if not already charging and not dashing
        if (!tabMenuManager.InMenu && !player.InDialogue && !weaponWheelManager.WheelDisplayed && !equippedWeapon.IsCharging && !playerMovement.Dodging && !player.Character.Incapacitated && Time.time > nextAttackTime)
        {
            if (meleeWeapon.ChargeTime > 0)
            {
                // charge attack and slow player down
                meleeAttack.ChargeUpAttack();
                playerMovement.AdjustMoveSpeed(meleeWeapon.ChargedMovementSpeedSlowdownMultiplier);
            }
            else
            {
                nextAttackTime = Time.time + (1 / meleeWeapon.AttackRate);   // add time to wait until next attack

                // No charge time, attack instantly
                meleeAttack.InstantAttack();
            }
        }
    }

    public override void Release(InputAction.CallbackContext context)
    {
        // release swing if charging and not swinging
        if (!tabMenuManager.InMenu && !player.InDialogue && !weaponWheelManager.WheelDisplayed && equippedWeapon.IsCharging && !equippedWeapon.IsSwinging && meleeWeapon.ChargeTime > 0)
        {
            // swing and speed player back up
            meleeAttack.ReleaseCharge();
            playerMovement.AdjustMoveSpeed(-meleeWeapon.ChargedMovementSpeedSlowdownMultiplier);
            nextAttackTime = Time.time + (1 / meleeWeapon.AttackRate);   // add time to wait until next attack
        }
    }

    public override void Utility(InputAction.CallbackContext context)
    {
        if (!tabMenuManager.InMenu && !player.InDialogue && !weaponWheelManager.WheelDisplayed && equippedWeapon.IsCharging)
        {
            CancelCharge();
        }
    }

    public void CancelCharge()
    {
        playerMovement.AdjustMoveSpeed(-meleeWeapon.ChargedMovementSpeedSlowdownMultiplier);
        equippedWeapon.IsCharging = false;
        meleeAttack.CancelCharge();
    }

    public override void Interrupt()
    {
        // Cancel on incapacitate or dodge
        if (equippedWeapon.IsCharging)
        {
            CancelCharge();
        }
    }
}
