using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.InputSystem;

public class ThrowingWeapon : WeaponScript
{
    [Header("Projectile")]
    [SerializeField] GameObject projectile;
    [SerializeField] Vector3 projectileOffset = new Vector3(0, 0, 0);
    [SerializeField] bool letSliderDetermineVelocity;

    [Header("Visual Config")]
    [SerializeField] float weaponReadyRotation = 90f;
    [SerializeField] float weaponSwingRotation = 90f;
    [SerializeField] float weaponSwingTime = .5f;
    [SerializeField] bool hasAnimatedAttack = false;

    [Header("Charge Slider")]
    [SerializeField] GameObject chargeSliderTemplate;
    [SerializeField] [Range(0, 1)] float sweetSpotStartPercentage;      // sweetSpotStart < sweetSpotEnd < normalSpotEnd
    [SerializeField] [Range(0, 1)] float sweetSpotEndPercentage;

    [Header("Audio")]
    [SerializeField] AudioSource audioSource;
    [SerializeField] AudioClip[] swingEffects;
    [SerializeField] [Range(0, 1)] float swingVolume = 0.5f;
    [SerializeField] AudioClip readySound;
    [SerializeField] [Range(0, 1)] float readySoundVolume = 0.5f;

    [Header("Sweet Spot Effects")]
    public float sweetSpotDamageMultiplier = 2f;
    public float sweetSpotVelocityMultiplier = 1.5f;
    public float sweetSpotScreenShakeMagnitudeMultiplier = 2f;
    public float sweetSpotDistanceMultiplier = 1.5f;

    [Header("State")]
    bool isCharging = false;

    // events
    public UnityEvent fired;

    public EquippedWeapon equippedWeapon;
    RangedWeapon rangedWeapon;
    Player player;
    AttributeScores playerAttributes;
    PlayerMovement playerMovement;
    Inventory playerInventory;
    TabMenuManager tabMenuManager;
    WeaponWheelManager weaponWheelManager;
    Canvas canvas;
    ShakeBehavior shaker;
    Animator animator;
    WeaponReloader weaponReloader;

    GameObject chargeSlider;
    Transform handTransform;

    // Single-Fire rate
    float nextFireTime;
    float sliderChargeDistanceMod;          // [0, 1]
    float sliderChargeVelocityMod;

    private void Awake()
    {
        equippedWeapon = GetComponent<EquippedWeapon>();
        player = FindObjectOfType<Player>();
        playerAttributes = player.GetComponent<AttributeScores>();
        playerMovement = player.GetComponent<PlayerMovement>();
        playerInventory = player.GetComponent<Inventory>();
        tabMenuManager = FindObjectOfType<TabMenuManager>();
        weaponWheelManager = FindObjectOfType<WeaponWheelManager>();
        canvas = GameObject.FindGameObjectWithTag("GameCanvas").GetComponent<Canvas>();
        shaker = FindObjectOfType<ShakeBehavior>();
        animator = GetComponent<Animator>();
        weaponReloader = GetComponent<WeaponReloader>();
    }

    // Start is called before the first frame update
    void Start()
    {
        rangedWeapon = (RangedWeapon)equippedWeapon.ItemData;

        SetHandTransform();
    }

    private void SetHandTransform()
    {
        if (rangedWeapon.EquippedMain)
        {
            handTransform = equippedWeapon.owner.GetComponent<Equipment>().MainHandArm.transform.parent;
        }
        else
        {
            handTransform = equippedWeapon.owner.GetComponent<Equipment>().OffHandArm.transform.parent;
        }
    }

    public void ChargeUpAttack()
    {
        // fail to fire if no ammo
        if (!rangedWeapon.IsThrowingWeapon && weaponReloader)
        {
            if (weaponReloader.AmmoInClip - rangedWeapon.AmmoUsedPerShot < 0)
            {
                return;
            }
        }

        // set that the weapon is charging
        if (rangedWeapon.IsThrowingWeapon)
        {
            equippedWeapon.IsCharging = true;
        }
        else
        {
            isCharging = true;
        }

        // player is busy
        player.IsBusy = true;

        // move weapon to swing position
        if (hasAnimatedAttack && animator)
        {
            animator.SetTrigger("AnimReady");
        }
        else
        {
            equippedWeapon.ActivateChargedMeleeRotation(weaponReadyRotation);
        }

        // audio
        if (readySound)
        {
            audioSource.clip = readySound;
            audioSource.volume = readySoundVolume;
            audioSource.Play();
        }

        // instantiate charge slider
        chargeSlider = Instantiate(chargeSliderTemplate, canvas.transform);

        // set slider parameters
        chargeSlider.GetComponent<ChargeSlider>().SetParameters(rangedWeapon.EquippedMain, rangedWeapon.ChargeTime, sweetSpotStartPercentage, sweetSpotEndPercentage);
    }

    public void ReleaseCharge()
    {
        // no longer charging
        if (rangedWeapon.IsThrowingWeapon)
            equippedWeapon.IsCharging = false;
        else
            isCharging = false;

        bool inSweetSpot = false;

        // player is not busy
        player.IsBusy = false;

        // get slider state and then destroy
        if (chargeSlider)
        {
            ChargeSlider slider = chargeSlider.GetComponent<ChargeSlider>();
            inSweetSpot = slider.CheckSweetSpot();
            sliderChargeDistanceMod = slider.GetSliderValueAsFraction();
            sliderChargeVelocityMod = slider.GetSliderValueAsFraction();

            Destroy(chargeSlider);
        }

        // if in sweet spot, do sweet spot stuff
        if (inSweetSpot)
        {
            // status message
            equippedWeapon.StatusMessageManager.DisplayMessage("PERFECT");

            sliderChargeDistanceMod = sweetSpotDistanceMultiplier;

            // fire
            if (hasAnimatedAttack && animator)
            {
                animator.SetTrigger("AnimFire");
            }
            else
            {
                equippedWeapon.TriggerRotateOverTime(new Vector3(0, 0, weaponSwingRotation), weaponSwingTime);
            }

            // explosives only get bonus velocity
            if (rangedWeapon.IsExplosive)
                TrySpawnProjectile(1f, sweetSpotVelocityMultiplier, 1f);
            else
                TrySpawnProjectile(sweetSpotDamageMultiplier, sweetSpotVelocityMultiplier, sweetSpotScreenShakeMagnitudeMultiplier);
        }
        else
        {
            // fire
            if (hasAnimatedAttack && animator)
            {
                animator.SetTrigger("AnimFire");
            }
            else
            {
                equippedWeapon.TriggerRotateOverTime(new Vector3(0, 0, weaponSwingRotation), weaponSwingTime);
            }

            if (letSliderDetermineVelocity)
                TrySpawnProjectile(chargedSweetSpotVelocityMultiplier: sliderChargeVelocityMod);
            else
                TrySpawnProjectile();
        }

        // sound
        PlayRandomSound(swingEffects, swingVolume);
    }

    void InstantAttack()
    {
        // fail to fire if no ammo
        if (!rangedWeapon.IsThrowingWeapon && weaponReloader)
        {
            if (weaponReloader.AmmoInClip - rangedWeapon.AmmoUsedPerShot < 0)
            {
                return;
            }
        }

        // move weapon to swing position
        if (hasAnimatedAttack && animator)
        {
            animator.SetTrigger("AnimReady");
        }
        else
        {
            equippedWeapon.ActivateChargedMeleeRotation(weaponReadyRotation);
        }

        // fire
        if (hasAnimatedAttack && animator)
        {
            animator.SetTrigger("AnimFire");
        }
        else
        {
            equippedWeapon.TriggerRotateOverTime(new Vector3(0, 0, weaponSwingRotation), weaponSwingTime);
        }

        // set distance to max
        sliderChargeDistanceMod = 1;

        TrySpawnProjectile();

        // sound
        PlayRandomSound(swingEffects, swingVolume);
    }

    void TrySpawnProjectile(float chargedSweetSpotDamageMultiplier = 1f, float chargedSweetSpotVelocityMultiplier = 1f, float chargedSweetSpotShakeMultiplier = 1f)
    {
        for (int i = 0; i < rangedWeapon.ProjectilesPerShot; i++)
        {
            SpawnProjectile(projectile, chargedSweetSpotDamageMultiplier, chargedSweetSpotVelocityMultiplier, chargedSweetSpotShakeMultiplier);
        }

        // remove from inventory
        if (rangedWeapon.IsThrowingWeapon)
        {
            playerInventory.RemoveItem(equippedWeapon.itemPair);
        }
        else
        {
            if (weaponReloader)
            {
                // decrease ammo count
                weaponReloader.DecreaseAmmoInClip(rangedWeapon.AmmoUsedPerShot);
            }
        }
    }

    public void SpawnProjectile(GameObject _projectile, float chargedSweetSpotDamageMultiplier = 1f, float chargedSweetSpotVelocityMultiplier = 1f, float chargedSweetSpotShakeMultiplier = 1f, bool invokeEvent = true)
    {
        GameObject firedProjectile = Instantiate(_projectile, transform.position + projectileOffset, handTransform.rotation);

        // add spread to projectile and set attributes
        firedProjectile.transform.Rotate(0, 0, GetRandomizedDirection());
        SetProjectileAttributes(firedProjectile, chargedSweetSpotVelocityMultiplier);

        DamageDealer damageDealer = firedProjectile.GetComponent<DamageDealer>();

        // set projectile's crit chance and damage
        damageDealer.CritChance = playerAttributes.critChance + rangedWeapon.BonusCritChance;
        damageDealer.CritMultiplier = playerAttributes.critDamageMultiplier + rangedWeapon.BonusCritMultiplier;

        // add bonus damage on charge weapon sweet spot hit
        damageDealer.MultiplyAllDamage(chargedSweetSpotDamageMultiplier);

        // shake the screen
        shaker.ShakeCamera(rangedWeapon.ScreenShakeIntensity * chargedSweetSpotShakeMultiplier, rangedWeapon.ScreenShakeDuration);

        // invoke event
        if (invokeEvent)
            fired.Invoke();
    }

    private void SetProjectileAttributes(GameObject firedProjectile, float chargedSweetSpotVelocityMultiplier = 1f)
    {
        float zAngle = firedProjectile.transform.rotation.eulerAngles.z * (Mathf.PI / 180f);
        float xComponent = Mathf.Cos(zAngle);
        float yComponent = Mathf.Sin(zAngle);
        Vector2 pivotDirection = new Vector2(xComponent, yComponent);

        firedProjectile.GetComponent<ProjectileStandard>().SetAttributes(equippedWeapon.owner, player.transform, rangedWeapon, pivotDirection, chargedSweetSpotVelocityMultiplier, sliderChargeDistanceMod);
    }

    public override void Use(InputAction.CallbackContext context)
    {
        if (!tabMenuManager.InMenu && !player.InDialogue && !weaponWheelManager.WheelDisplayed)
        {
            // start the charge bar
            if (!playerMovement.Dodging && !equippedWeapon.IsCharging && !player.Character.Incapacitated && Time.time > nextFireTime)
            {
                if (rangedWeapon.ChargeTime > 0)
                {
                    ChargeUpAttack();
                }
                else
                {
                    nextFireTime = Time.time + (1 / rangedWeapon.AttackRate);   // add time to wait until next attack

                    // No charge time, throw instantly
                    InstantAttack();
                }
            }
        }
    }

    public override void Release(InputAction.CallbackContext context)
    {
        if (!tabMenuManager.InMenu && !player.InDialogue && !weaponWheelManager.WheelDisplayed && !playerMovement.Dodging && !player.Character.Incapacitated)
        {
            // Let go of charge
            if (equippedWeapon.IsCharging || isCharging)
            {
                // Fire
                nextFireTime = Time.time + (1 / rangedWeapon.AttackRate);   // add time to wait until next shot
                ReleaseCharge();
            }
        }
    }

    public override void Utility(InputAction.CallbackContext context)
    {
        if (!tabMenuManager.InMenu && !player.InDialogue && !weaponWheelManager.WheelDisplayed && !playerMovement.Dodging && !player.Character.Incapacitated)
        {
            if (equippedWeapon.IsCharging || isCharging)
            {
                CancelCharge();
            }
        }
    }

    public override void Interrupt()
    {
        if (equippedWeapon.IsCharging || isCharging)
        {
            CancelCharge();
        }
    }

    public void CancelCharge()
    {
        // no longer charging
        equippedWeapon.IsCharging = false;
        isCharging = false;

        // player is not busy
        player.IsBusy = false;

        // destroy slider
        if (chargeSlider)
        {
            Destroy(chargeSlider);
        }

        // rotate back
        if (hasAnimatedAttack && animator)
        {
            animator.SetTrigger("AnimFire");
        }
        else
        {
            equippedWeapon.TriggerRotateOverTime(new Vector3(0, 0, weaponSwingRotation), weaponSwingTime);
        }

        nextFireTime = 0;
    }

    private void PlayRandomSound(AudioClip[] clips, float volume)
    {
        audioSource.Stop();     // if ready sound is playing
        int randomIndex = Random.Range(0, clips.Length);
        audioSource.PlayOneShot(clips[randomIndex], volume);
    }

    float GetRandomizedDirection()
    {
        return Random.Range(-rangedWeapon.Spread, rangedWeapon.Spread);
    }
}