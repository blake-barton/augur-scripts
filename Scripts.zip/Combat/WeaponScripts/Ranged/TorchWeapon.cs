using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class TorchWeapon : WeaponScript
{
    [Header("Torch")]
    [SerializeField] ParticleSystem particles;
    [SerializeField] PolygonCollider2D hitbox;
    [SerializeField] bool ticking = false;
    float tickTime;

    [Header("Sound")]
    [SerializeField] AudioSource audioSource;
    [SerializeField] AudioClip castSound;
    [SerializeField] [Range(0, 1)] float castVolume = 1f;
    [SerializeField] AudioClip constantCastLoopSound;
    [SerializeField] [Range(0, 1)] float constantCastLoopSoundVolume = 1f;
    [SerializeField] AudioClip constantCastEndSound;
    [SerializeField] [Range(0, 1)] float constantCastEndSoundVolume = 1f;

    [Header("Animation")]
    [SerializeField] Animator animator;

    DamageDealer damageDealer;
    public EquippedWeapon equippedWeapon;
    RangedWeapon rangedWeapon;
    Player player;
    PlayerMovement playerMovement;
    TabMenuManager tabMenuManager;
    WeaponWheelManager weaponWheelManager;
    AttributeScores playerAttributes;
    ShakeBehavior shaker;
    MuzzleFlashLight muzzleFlashLight;
    WeaponReloader weaponReloader;
    AmmoCounter playerAmmo;

    float timer = 0f;
    List<Collider2D> enemyColliders = new List<Collider2D>();

    public List<Collider2D> EnemyColliders { get => enemyColliders; set => enemyColliders = value; }

    void Awake()
    {
        damageDealer = GetComponent<DamageDealer>();
        equippedWeapon = GetComponent<EquippedWeapon>();
        player = FindObjectOfType<Player>();
        playerMovement = player.GetComponent<PlayerMovement>();
        playerAttributes = player.GetComponent<AttributeScores>();
        tabMenuManager = FindObjectOfType<TabMenuManager>();
        weaponWheelManager = FindObjectOfType<WeaponWheelManager>();
        shaker = FindObjectOfType<ShakeBehavior>();
        muzzleFlashLight = GetComponent<MuzzleFlashLight>();
        weaponReloader = GetComponent<WeaponReloader>();
    }

    void Start()
    {
        rangedWeapon = (RangedWeapon)equippedWeapon.ItemData;
        playerAmmo = player.GetComponent<AmmoCounter>();

        tickTime = rangedWeapon.AttackRate > 0 ? 1 / rangedWeapon.AttackRate : 1f;

        particles.Stop();
        hitbox.enabled = false;

        CopyDamageListsToDamageDealer();
    }

    void Update()
    {
        if (ticking)
        {
            timer += Time.deltaTime;

            if (timer >= tickTime)
            {
                timer = 0;
                Tick();
            }
        }
    }

    public void CopyDamageListsToDamageDealer()
    {
        damageDealer.CopyDamageList(rangedWeapon.Damages);
        damageDealer.CopyDamageTypeList(rangedWeapon.DamageTypes);

        // status effects
        damageDealer.SetStatusEffectDamagePercentage(rangedWeapon.StatusEffectDamagePercentage);

        // set projectile's crit chance and damage (COMMENTED OUT BECAUSE IT MAKES THE THING TOO POWERFUL)
        //damageDealer.CritChance = playerAttributes.critChance + rangedWeapon.BonusCritChance;
        //damageDealer.CritMultiplier = playerAttributes.critDamageMultiplier + rangedWeapon.BonusCritMultiplier;
    }

    void ConstantCast()
    {
        particles.Play();
        hitbox.enabled = true;
        ticking = true;

        // cast sound
        if (audioSource && castSound)
        {
            audioSource.PlayOneShot(castSound, castVolume);
        }

        // animation
        if (animator)
        {
            animator.SetBool("AnimIsFiring", true);
        }

        // constant cast sound
        if (audioSource && constantCastLoopSound)
        {
            audioSource.loop = true;
            audioSource.clip = constantCastLoopSound;
            audioSource.volume = constantCastLoopSoundVolume;
            audioSource.Play();
        }

        // muzzle flash
        if (muzzleFlashLight)
        {
            muzzleFlashLight.TurnLightOn();
        }
    }

    void StopConstantCast(bool stopAudio = true)
    {
        particles.Stop();
        hitbox.enabled = false;
        ticking = false;
        timer = 0;

        // animation
        if (animator)
        {
            animator.SetBool("AnimIsFiring", false);
        }

        // stop constant cast audio
        if (audioSource && stopAudio)
        {
            audioSource.loop = false;
            audioSource.Stop();
        }

        // done casting audio
        if (audioSource && constantCastEndSound)
        {
            audioSource.PlayOneShot(constantCastEndSound, constantCastEndSoundVolume);
        }

        // muzzle flash
        if (muzzleFlashLight)
        {
            muzzleFlashLight.TurnLightOff();
        }
    }

    void Tick()
    {
        if (weaponReloader.AmmoInClip - rangedWeapon.AmmoUsedPerShot >= 0)
        {
            foreach (Collider2D enemyCollider in EnemyColliders)
            {
                damageDealer.CauseTorchDamage(enemyCollider, equippedWeapon.owner, rangedWeapon);
            }

            // screen shake
            shaker.ShakeCamera(rangedWeapon.ScreenShakeIntensity, rangedWeapon.ScreenShakeDuration);

            // Decrease ammo in clip
            weaponReloader.DecreaseAmmoInClip(rangedWeapon.AmmoUsedPerShot);
        }
        else
        {
            // out of ammo (don't stop audio source)
            StopConstantCast(false);
        }
    }

    public override void Use(InputAction.CallbackContext context)
    {
        if (!tabMenuManager.InMenu && !player.InDialogue && !weaponWheelManager.WheelDisplayed && !weaponReloader.IsReloading)
        {
            if (!playerMovement.Dodging && !player.Character.Incapacitated)
            {
                if (weaponReloader.AmmoInClip - rangedWeapon.AmmoUsedPerShot >= 0)
                {
                    ConstantCast();
                }
                else
                {
                    equippedWeapon.StatusMessageManager.DisplayMessage("EMPTY");
                }
            }
        }
    }

    public override void Utility(InputAction.CallbackContext context)
    {
        // not currently reloading and not firing
        if (!tabMenuManager.InMenu && !player.InDialogue && !weaponWheelManager.WheelDisplayed && !weaponReloader.IsReloading && !ticking && !equippedWeapon.IsTechCharging && !playerMovement.Dodging && !player.Character.Incapacitated)
        {
            // if ammo in reserves and clip is not full
            if (playerAmmo.GetAmmoCountByType(rangedWeapon.AmmunitionType) > 0 && (weaponReloader.AmmoInClip != weaponReloader.ClipSize))
            {
                weaponReloader.TriggerActiveReload();
            }
        }
    }

    public override void Release(InputAction.CallbackContext context)
    {
        if (!tabMenuManager.InMenu && !player.InDialogue && !weaponWheelManager.WheelDisplayed && ticking)
        {
            // stop firing
            StopConstantCast();
        }
    }

    public override void Interrupt()
    {
        // Stop constant cast on incapacitated or dodge
        if (ticking)
        {
            // stop firing
            StopConstantCast();
        }
    }
}
