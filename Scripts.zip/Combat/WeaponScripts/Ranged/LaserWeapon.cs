using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class LaserWeapon : WeaponScript
{
    [Header("Laser")]
    [SerializeField] float fireDuration = .2f;
    [SerializeField] Vector2 fireDirection = new Vector2();
    [SerializeField] Vector2 hitPoint = new Vector2();
    [SerializeField] LineRenderer lineRenderer;
    [SerializeField] Transform firePoint;
    [SerializeField] LayerMask layersToCollideWith;
    [SerializeField] string enemyTag;
    [SerializeField] bool penetrateEnemies = false;     // does the laser continue until it hits a wall?

    [Header("Charge Slider")]
    [SerializeField] GameObject chargeSliderTemplate;
    [SerializeField] [Range(0, 1)] float sweetSpotStartPercentage;      // sweetSpotStart < sweetSpotEnd < normalSpotEnd
    [SerializeField] [Range(0, 1)] float sweetSpotEndPercentage;
    GameObject chargeSlider;

    [Header("Slider Interpreted Values")]
    [SerializeField] float chargeDamageModifier;

    [Header("Sweet Spot Effects")]
    [SerializeField] float sweetSpotDamageMultiplier;
    [SerializeField] float sweetSpotScreenShakeMagnitudeMultiplier;
    //TODO: projectile color

    [Header("Impact Effects")]
    [SerializeField] GameObject actorImpactEffect;
    [SerializeField] GameObject actorCritImpactEffect;
    [SerializeField] [Range(0, 31)] int enemyLayer = 9;
    [SerializeField] [Range(0, 31)] int playerLayer = 6;
    [SerializeField] GameObject wallImpactEffect;
    [SerializeField] [Range(0, 31)] int wallLayer = 10;

    [Header("State")]
    [SerializeField] bool firingEnabled = false;
    [SerializeField] bool colliderHit = false;

    [Header("Audio")]
    [SerializeField] AudioSource audioSource;
    [SerializeField] AudioClip shotAudio;
    [SerializeField] [Range(0, 1)] float shotVolume = 1f;
    [SerializeField] AudioClip chargeSound;
    [SerializeField] [Range(0, 1)] float chargeVolume = 1f;

    [Header("Animation")]
    [SerializeField] Animator animator;

    public EquippedWeapon equippedWeapon;
    WeaponReloader weaponReloader;
    RangedWeapon rangedWeapon;
    Player player;
    PlayerMovement playerMovement;
    AmmoCounter playerAmmo;
    TabMenuManager tabMenuManager;
    WeaponWheelManager weaponWheelManager;
    Canvas canvas;
    DamageDealer damageDealer;
    ShakeBehavior shaker;
    AttributeScores playerAttributes;
    MuzzleFlashLight muzzleFlashLight;

    // Single-Fire rate
    float nextFireTime;

    // coroutines
    Coroutine fullAutoFiring;

    public bool FiringEnabled { get => firingEnabled; set => firingEnabled = value; }
    public bool ColliderHit { get => colliderHit; set => colliderHit = value; }
    public float SweetSpotDamageMultiplier { get => sweetSpotDamageMultiplier; set => sweetSpotDamageMultiplier = value; }
    public float SweetSpotScreenShakeMagnitudeMultiplier { get => sweetSpotScreenShakeMagnitudeMultiplier; set => sweetSpotScreenShakeMagnitudeMultiplier = value; }

    private void Awake()
    {
        damageDealer = GetComponent<DamageDealer>();
        equippedWeapon = GetComponent<EquippedWeapon>();
        weaponReloader = GetComponent<WeaponReloader>();
        player = FindObjectOfType<Player>();
        playerAttributes = player.GetComponent<AttributeScores>();
        playerMovement = player.GetComponent<PlayerMovement>();
        tabMenuManager = FindObjectOfType<TabMenuManager>();
        weaponWheelManager = FindObjectOfType<WeaponWheelManager>();
        canvas = GameObject.FindGameObjectWithTag("GameCanvas").GetComponent<Canvas>();
        shaker = FindObjectOfType<ShakeBehavior>();
        muzzleFlashLight = GetComponent<MuzzleFlashLight>();
    }

    // Start is called before the first frame update
    void Start()
    {
        rangedWeapon = (RangedWeapon)equippedWeapon.ItemData;
        playerAmmo = player.GetComponent<AmmoCounter>();

        CopyDamageListsToDamageDealer();
    }

    // Update is called once per frame
    void Update()
    {
        if (FiringEnabled)
        {
            FireLaser();
        }
    }

    public override void Use(InputAction.CallbackContext context)
    {
        if (!tabMenuManager.InMenu && !player.InDialogue && !weaponWheelManager.WheelDisplayed)
        {
            if (!weaponReloader.IsReloading)
            {
                // automatic
                if (rangedWeapon.IsAutomatic)
                {
                    if (!playerMovement.Dodging && !player.Character.Incapacitated)
                    {
                        if (weaponReloader.AmmoInClip - rangedWeapon.AmmoUsedPerShot >= 0)
                        {
                            fullAutoFiring = StartCoroutine(FireFullAuto());
                        }
                        else
                        {
                            equippedWeapon.StatusMessageManager.DisplayMessage("EMPTY");
                        }
                    }
                }
                else
                {
                    // start the charge bar
                    if (!playerMovement.Dodging && !player.Character.Incapacitated && Time.time > nextFireTime && rangedWeapon.ChargeTime > 0)
                    {
                        if (weaponReloader.AmmoInClip - rangedWeapon.AmmoUsedPerShot >= 0)
                        {
                            nextFireTime = Time.time + (1 / rangedWeapon.AttackRate);   // add time to wait until next shot
                            ChargeUpAttack();
                        }
                        else
                        {
                            equippedWeapon.StatusMessageManager.DisplayMessage("EMPTY");
                        }
                    }
                    else if (!playerMovement.Dodging && !player.Character.Incapacitated && Time.time > nextFireTime && rangedWeapon.ChargeTime <= 0)
                    {
                        if (weaponReloader.AmmoInClip - rangedWeapon.AmmoUsedPerShot >= 0)
                        {
                            // no charging, just fire
                            nextFireTime = Time.time + (1 / rangedWeapon.AttackRate);   // add time to wait until next shot
                            ReleaseCharge();
                        }
                        else
                        {
                            equippedWeapon.StatusMessageManager.DisplayMessage("EMPTY");
                        }
                    }
                }
            }
        }
    }

    public override void Release(InputAction.CallbackContext context)
    {
        if (!tabMenuManager.InMenu && !player.InDialogue && !weaponWheelManager.WheelDisplayed)
        {
            // Automatic
            if (rangedWeapon.IsAutomatic)
            {
                // stop firing
                StopFiringFullAuto();
            }
            // Charging
            else if (equippedWeapon.IsTechCharging)
            {
                // Fire
                ReleaseCharge();
            }
        }
    }

    public override void Utility(InputAction.CallbackContext context)
    {
        if (!tabMenuManager.InMenu && !player.InDialogue && !weaponWheelManager.WheelDisplayed)
        {
            // Reload
            if (!weaponReloader.IsReloading && !FiringEnabled && !equippedWeapon.IsTechCharging && !playerMovement.Dodging && !player.Character.Incapacitated)
            {
                // if ammo in reserves and clip is not full
                if (playerAmmo.GetAmmoCountByType(rangedWeapon.AmmunitionType) > 0 && (weaponReloader.AmmoInClip != weaponReloader.ClipSize))
                {
                    weaponReloader.TriggerActiveReload();
                }
            }
            // Is reloading, get active reload input
            else if (weaponReloader.IsReloading)
            {
                weaponReloader.ReceiveActiveReloadInput();
            }
            // Cancel charge
            else if (equippedWeapon.IsTechCharging)
            {
                CancelCharge();
            }
        }
    }

    public override void Interrupt()
    {
        if (rangedWeapon.IsAutomatic)
        {
            // stop firing
            StopFiringFullAuto();
        }
        // Cancel charge
        else if (equippedWeapon.IsTechCharging)
        {
            CancelCharge();
        }
    }

    public void CopyDamageListsToDamageDealer()
    {
        damageDealer.CopyDamageList(rangedWeapon.Damages);
        damageDealer.CopyDamageTypeList(rangedWeapon.DamageTypes);

        // status effects
        damageDealer.SetStatusEffectDamagePercentage(rangedWeapon.StatusEffectDamagePercentage);

        // set projectile's crit chance and damage
        damageDealer.CritChance = playerAttributes.critChance + rangedWeapon.BonusCritChance;
        damageDealer.CritMultiplier = playerAttributes.critDamageMultiplier + rangedWeapon.BonusCritMultiplier;
    }

    Vector2 RotateRandomly(Vector2 aPoint)
    {
        float angle = Random.Range(-rangedWeapon.Spread, rangedWeapon.Spread);

        float rad = angle * Mathf.Deg2Rad;
        float s = Mathf.Sin(rad);
        float c = Mathf.Cos(rad);
        return new Vector2(
            aPoint.x * c - aPoint.y * s,
            aPoint.y * c + aPoint.x * s
        );
    }

    IEnumerator TriggerFiring()
    {
        FiringEnabled = true;

        // calculate direction
        if (player.IsGamepad)
        {
            fireDirection = (player.GamepadOrbiter.transform.position - firePoint.position).normalized;
        }
        else
        {
            fireDirection = (Input.mousePosition - Camera.main.WorldToScreenPoint(firePoint.position)).normalized;
        }

        if (rangedWeapon.Spread > 0)
            fireDirection = RotateRandomly(fireDirection);

        // cast a ray towards the mouse
        RaycastHit2D[] hits = Physics2D.RaycastAll(transform.position, fireDirection, Mathf.Infinity, layerMask: layersToCollideWith);

        // if hit something
        if (hits.Length > 0)
        {
            for (int i = 0; i < hits.Length; i++)
            {
                var hit = hits[i];

                // deal damage
                damageDealer.CauseLaserDamage(hit.collider, equippedWeapon.owner, rangedWeapon);

                // spawn impact effect
                SpawnImpactEffect(hit);

                // break on first hit if not penetrating or break if this is a wall
                if (!penetrateEnemies || (hit.collider.gameObject.layer == wallLayer))
                {
                    // enable line renderer
                    ColliderHit = true;

                    // track where the collision occurred
                    hitPoint = hit.point;

                    break;
                }
                else if (penetrateEnemies && i == hits.Length - 1)
                {
                    // penetrating and hitting last collider, enable laser
                    // enable line renderer
                    ColliderHit = true;

                    // track where the collision occurred
                    hitPoint = hit.point;
                }
            }
        }
        else
        {
            damageDealer.ClearLists();
            CopyDamageListsToDamageDealer();
            ColliderHit = false;
        }

        yield return new WaitForSeconds(fireDuration);

        FiringEnabled = false;
        ColliderHit = false;

        lineRenderer.positionCount = 0;
    }

    void FireLaser()
    {
        // if hits something
        if (ColliderHit)
        {
            // draw the laser
            DrawRay(firePoint.position, hitPoint);
        }
        else
        {
            // draw a ray as far as the weapon allows (ideally very far)
            DrawRay(firePoint.position, fireDirection * rangedWeapon.MaxRange);
        }
    }

    void DrawRay(Vector2 startPos, Vector2 endPos)
    {
        lineRenderer.positionCount = 2;
        lineRenderer.SetPosition(0, startPos);
        lineRenderer.SetPosition(1, endPos);
    }

    public void ChargeUpAttack()
    {
        // player is busy
        player.IsBusy = true;

        // set that the weapon is charging
        equippedWeapon.IsTechCharging = true;

        // animate charge
        if (animator)
        {
            animator.SetBool("AnimIsCharging", true);
        }

        // charge audio
        if (audioSource && chargeSound)
        {
            audioSource.clip = chargeSound;
            audioSource.volume = chargeVolume;
            audioSource.Play();
        }

        // instantiate charge slider
        chargeSlider = Instantiate(chargeSliderTemplate, canvas.transform);

        // set slider parameters
        chargeSlider.GetComponent<ChargeSlider>().SetParameters(rangedWeapon.EquippedMain, rangedWeapon.ChargeTime, sweetSpotStartPercentage, sweetSpotEndPercentage);
    }

    public void ReleaseCharge()
    {
        bool inSweetSpot = false;

        // player is not busy
        player.IsBusy = false;

        // animate charge
        if (animator)
        {
            animator.SetBool("AnimIsCharging", false);
        }

        // get slider state and then destroy
        if (chargeSlider)
        {
            ChargeSlider slider = chargeSlider.GetComponent<ChargeSlider>();
            inSweetSpot = slider.CheckSweetSpot();

            // get bonus charge damage fraction
            chargeDamageModifier = Mathf.Lerp(0f, rangedWeapon.MaxBonusChargeDamageAsFraction, slider.GetSliderValueAsFraction());

            Destroy(chargeSlider);
        }

        // add bonus damage on reload sweet spot hit
        if (weaponReloader.BonusDamageRoundsLoaded > 0)
        {
            damageDealer.MultiplyAllDamage(weaponReloader.SweetSpotDamageMultiplier);
            weaponReloader.BonusDamageRoundsLoaded--;
        }

        // if in sweet spot, do sweet spot stuff
        if (inSweetSpot)
        {
            // status message
            equippedWeapon.StatusMessageManager.DisplayMessage("PERFECT");

            damageDealer.MultiplyAllDamage(SweetSpotDamageMultiplier);
        }
        else
        {
            // if not in sweet spot, multiply damage based on charge time
            damageDealer.MultiplyAllDamage(1f + chargeDamageModifier);
            damageDealer.ForceDamage *= (1f + chargeDamageModifier);
        }

        // animate
        if (animator && !rangedWeapon.IsAutomatic)
        {
            animator.Play("Fire", -1, 0.0f);
        }

        // play sound
        if (audioSource)
        {
            audioSource.Stop(); // stop charge audio
            audioSource.PlayOneShot(shotAudio, shotVolume);
        }

        // screen shake
        if (inSweetSpot)
        {
            shaker.ShakeCamera(rangedWeapon.ScreenShakeIntensity * SweetSpotScreenShakeMagnitudeMultiplier, rangedWeapon.ScreenShakeDuration);
        }
        else
        {
            shaker.ShakeCamera(rangedWeapon.ScreenShakeIntensity, rangedWeapon.ScreenShakeDuration);
        }

        // muzzle flash
        if (muzzleFlashLight)
        {
            muzzleFlashLight.TriggerMuzzleFlash();
        }

        StartCoroutine(TriggerFiring());

        // decrease ammo count
        weaponReloader.DecreaseAmmoInClip(rangedWeapon.AmmoUsedPerShot);

        equippedWeapon.IsTechCharging = false;
    }

    IEnumerator FireFullAuto()
    {
        // wait for a moment to warm up
        if (rangedWeapon.WarmupTime > 0)
        {
            yield return new WaitForSeconds(rangedWeapon.WarmupTime);
        }

        // check that there's enough ammo in the clip
        if (weaponReloader.AmmoInClip - rangedWeapon.AmmoUsedPerShot >= 0)
        {
            FiringEnabled = true;

            // animation
            if (animator)
            {
                animator.SetBool("AnimIsFiring", true);
            }

            while (true)
            {
                ReleaseCharge();

                // break if ammo goes below or equal to 0
                if (weaponReloader.AmmoInClip <= 0)
                {
                    // out of ammo
                    FiringEnabled = false;

                    // animation
                    if (animator)
                    {
                        animator.SetBool("AnimIsFiring", false);
                    }

                    yield break;
                }

                yield return new WaitForSeconds(1 / rangedWeapon.AttackRate);
            }
        }
        else
        {
            // out of ammo
            FiringEnabled = false;

            // animation
            if (animator)
            {
                animator.SetBool("AnimIsFiring", false);
            }

            yield break;
        }
    }

    public void StopFiringFullAuto()
    {
        if (!(fullAutoFiring is null))
        {
            StopCoroutine(fullAutoFiring);
            FiringEnabled = false;

            // animation
            if (animator)
            {
                animator.SetBool("AnimIsFiring", false);
            }
        }
    }

    private void SpawnImpactEffect(RaycastHit2D hit)
    {
        if ((hit.collider.gameObject.layer == enemyLayer || hit.collider.gameObject.layer == playerLayer) && actorImpactEffect)
        {
            // hit enemy/player
            if (damageDealer.CritSuccess)
            {
                Instantiate(actorCritImpactEffect, hit.point, Quaternion.identity);
            }
            else
            {
                Instantiate(actorImpactEffect, hit.point, Quaternion.identity);
            }
        }
        else if ((hit.collider.gameObject.layer == wallLayer) && wallImpactEffect)
        {
            // hit wall
            Vector2 n = hit.normal.normalized;

            float angle = Mathf.Atan2(n.y, n.x) * Mathf.Rad2Deg - 90f;

            var newObject = Instantiate(wallImpactEffect, hit.point, Quaternion.identity);
            newObject.transform.rotation = Quaternion.AngleAxis(angle, Vector3.forward);
        }
    }

    public void CancelCharge()
    {
        // destroy slider
        if (chargeSlider)
        {
            Destroy(chargeSlider);
        }

        // animate charge
        if (animator)
        {
            animator.SetBool("AnimIsCharging", false);
        }

        // player is not busy
        player.IsBusy = false;

        equippedWeapon.IsTechCharging = false;
        nextFireTime = 0;
    }
}
