using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.InputSystem;

public class ThermalWeaponRanged : WeaponScript
{
    [Header("Heat Slider")]
    [SerializeField] GameObject heatSliderTemplate;

    [Header("Projectile")]
    [SerializeField] GameObject projectile;
    [SerializeField] Vector3 projectileOffset = new Vector3(0, 0, 0);

    [Header("Audio")]
    [SerializeField] AudioSource audioSource;
    [SerializeField] AudioClip shotAudio;
    [SerializeField] [Range(0, 1)] float shotVolume;
    [SerializeField] AudioClip fireLoopAudio;           // for automatic weapon
    [SerializeField] [Range(0, 1)] float fireLoopAudioVolume = 1f;
    [SerializeField] AudioClip warmupAudio;
    [SerializeField] [Range(0, 1)] float warmupAudioVolume = 1f;
    [SerializeField] AudioClip overheatAudio;
    [SerializeField] [Range(0, 1)] float overheatAudioVolume = 1f;

    [Header("Animation")]
    [SerializeField] Animator animator;

    [Header("ParticleFX")]
    [SerializeField] GameObject overHeatParticles;

    [Header("State")]
    public bool isFiring = false;

    [Header("Charge Slider")]
    [SerializeField] GameObject chargeSliderTemplate;
    [SerializeField] [Range(0, 1)] float sweetSpotStartPercentage;      // sweetSpotStart < sweetSpotEnd < normalSpotEnd
    [SerializeField] [Range(0, 1)] float sweetSpotEndPercentage;
    GameObject chargeSlider;

    [Header("Sweet Spot Effects")]
    public float sweetSpotDamageMultiplier = 2f;
    public float sweetSpotVelocityMultiplier = 1.5f;
    public float sweetSpotScreenShakeMagnitudeMultiplier = 2f;

    [Header("Slider Interpreted Values")]
    [SerializeField] float chargeDamageModifier;

    public EquippedWeapon equippedWeapon;
    RangedWeapon rangedWeapon;
    Player player;
    PlayerMovement playerMovement;
    TabMenuManager tabMenuManager;
    WeaponWheelManager weaponWheelManager;
    Canvas canvas;
    AttributeScores playerAttributes;
    ShakeBehavior shaker;
    MuzzleFlashLight muzzleFlashLight;

    // Single-Fire rate
    float nextFireTime;

    // instantiated objects
    GameObject heatSliderObject;
    GameObject instantiatedOverheatParticles;

    // coroutines
    Coroutine autoFireCoroutine;

    private void Awake()
    {
        player = FindObjectOfType<Player>();
        playerMovement = player.Character.GetComponent<PlayerMovement>();
        playerAttributes = player.Character.GetComponent<AttributeScores>();
        tabMenuManager = FindObjectOfType<TabMenuManager>();
        weaponWheelManager = FindObjectOfType<WeaponWheelManager>();
        shaker = FindObjectOfType<ShakeBehavior>();
        canvas = GameObject.FindGameObjectWithTag("GameCanvas").GetComponent<Canvas>();
        muzzleFlashLight = GetComponent<MuzzleFlashLight>();
    }

    // Start is called before the first frame update
    void Start()
    {
        rangedWeapon = (RangedWeapon)equippedWeapon.ItemData;
        heatSliderObject = Instantiate(heatSliderTemplate, canvas.transform);
        heatSliderObject.GetComponent<HeatSlider>().SetParameters(rangedWeapon.EquippedMain, rangedWeapon.HeatCapacity, rangedWeapon.AccumulatedHeat, this);

        // check if starting overheated
        if (rangedWeapon.IsOverheated)
        {
            // change bar color
            heatSliderObject.GetComponent<HeatSlider>().SwapColors(true);

            // particles
            instantiatedOverheatParticles = Instantiate(overHeatParticles, transform);
        }
    }

    // Update is called once per frame
    void Update()
    {
        // heat always going down (limit to 0)
        rangedWeapon.AccumulatedHeat -= rangedWeapon.HeatDecreaseSpeed * Time.deltaTime;
        if (rangedWeapon.AccumulatedHeat <= 0)
        {
            rangedWeapon.AccumulatedHeat = 0;

            // set slider as inactive if heat is at 0
            if (heatSliderObject.activeInHierarchy)
            {
                heatSliderObject.SetActive(false);
            }
        }
        else if (rangedWeapon.AccumulatedHeat > 0 && !heatSliderObject.activeInHierarchy)
        {
            // set slider active
            heatSliderObject.SetActive(true);
        }
        heatSliderObject.GetComponent<Slider>().value = rangedWeapon.AccumulatedHeat;

        // check overheat
        if (rangedWeapon.AccumulatedHeat >= rangedWeapon.HeatCapacity && !rangedWeapon.IsOverheated)
        {
            // overheated!
            rangedWeapon.IsOverheated = true;
            player.IsBusy = true;

            // change bar color
            heatSliderObject.GetComponent<HeatSlider>().SwapColors(true);

            // stop firing full auto
            StopSpawningFullAuto();

            // sound
            if (audioSource && overheatAudio)
            {
                audioSource.PlayOneShot(overheatAudio, overheatAudioVolume);
            }

            // status message
            equippedWeapon.StatusMessageManager.DisplayMessage("OVERHEATED");

            // particles
            instantiatedOverheatParticles = Instantiate(overHeatParticles, transform);
        }
        else if (rangedWeapon.AccumulatedHeat <= 0 && rangedWeapon.IsOverheated)
        {
            // no longer overheated
            rangedWeapon.IsOverheated = false;
            player.IsBusy = false;
            heatSliderObject.GetComponent<HeatSlider>().SwapColors(false);

            // get rid of particles
            if (instantiatedOverheatParticles)
            {
                Destroy(instantiatedOverheatParticles);
            }
        }
    }

    void ChargeUpAttack()
    {
        // set that the weapon is charging
        equippedWeapon.IsTechCharging = true;

        // animate charge
        if (animator)
        {
            animator.SetBool("AnimIsCharging", true);
        }

        // player is busy
        player.IsBusy = true;

        // instantiate charge slider
        chargeSlider = Instantiate(chargeSliderTemplate, canvas.transform);

        // set slider parameters
        chargeSlider.GetComponent<ChargeSlider>().SetParameters(rangedWeapon.EquippedMain, rangedWeapon.ChargeTime, sweetSpotStartPercentage, sweetSpotEndPercentage);
    }

    void ReleaseCharge()
    {
        bool inSweetSpot = false;

        // player is not busy
        player.IsBusy = false;

        // animate charge
        if (animator)
        {
            animator.SetBool("AnimIsCharging", false);
        }

        // get slider state and then destroy
        if (chargeSlider)
        {
            ChargeSlider slider = chargeSlider.GetComponent<ChargeSlider>();

            // check if in sweet spot
            inSweetSpot = slider.CheckSweetSpot();

            // get bonus charge damage fraction
            chargeDamageModifier = Mathf.Lerp(0f, rangedWeapon.MaxBonusChargeDamageAsFraction, slider.GetSliderValueAsFraction());

            Destroy(chargeSlider);
        }

        // if in sweet spot, do sweet spot stuff
        if (inSweetSpot)
        {
            // status message
            equippedWeapon.StatusMessageManager.DisplayMessage("PERFECT");

            TrySpawnProjectile(sweetSpotDamageMultiplier, sweetSpotVelocityMultiplier, sweetSpotScreenShakeMagnitudeMultiplier);
        }
        else
        {
            // fire projectile
            TrySpawnProjectile(chargeDamageModifier: chargeDamageModifier);
        }

        equippedWeapon.IsTechCharging = false;
    }

    public override void Use(InputAction.CallbackContext context)
    {
        if (!tabMenuManager.InMenu && !player.InDialogue && !weaponWheelManager.WheelDisplayed && !rangedWeapon.IsOverheated)
        {
            // charge weapon
            if (rangedWeapon.ChargeTime > 0)
            {
                if (!playerMovement.Dodging && !player.Character.Incapacitated && Time.time > nextFireTime)
                {
                    nextFireTime = Time.time + (1 / rangedWeapon.AttackRate);   // add time to wait until next shot
                    ChargeUpAttack();
                }
            }
            else
            {
                // no charge

                // automatic fire
                if (rangedWeapon.IsAutomatic && !playerMovement.Dodging && !player.Character.Incapacitated)
                {
                    autoFireCoroutine = StartCoroutine(SpawnProjectileFullAuto());
                }

                // single fire
                if (!rangedWeapon.IsAutomatic && !playerMovement.Dodging && !player.Character.Incapacitated && Time.time > nextFireTime)
                {
                    nextFireTime = Time.time + (1 / rangedWeapon.AttackRate);   // add time to wait until next shot
                    TrySpawnProjectile();
                }
            }
        }

    }

    public override void Release(InputAction.CallbackContext context)
    {
        if (!tabMenuManager.InMenu && !player.InDialogue && !weaponWheelManager.WheelDisplayed && !rangedWeapon.IsOverheated)
        {
            // Stop charging
            if (equippedWeapon.IsTechCharging)
            {
                // Fire
                ReleaseCharge();
            }
            // Stop firing full auto
            else if (rangedWeapon.IsAutomatic && isFiring)
            {
                // stop firing
                StopSpawningFullAuto();
            }
        }
    }

    public override void Utility(InputAction.CallbackContext context)
    {
        if (!tabMenuManager.InMenu && !player.InDialogue && !weaponWheelManager.WheelDisplayed && !rangedWeapon.IsOverheated)
        {
            // Cancel charge
            if (equippedWeapon.IsTechCharging)
            {
                CancelCharge();
            }
        }
    }

    public override void Interrupt()
    {
        // Stop charging
        if (equippedWeapon.IsTechCharging)
        {
            CancelCharge();
        }

        // Stop firing full auto
        if (rangedWeapon.IsAutomatic && isFiring)
        {
            // stop firing
            StopSpawningFullAuto();
        }
    }

    float GetRandomizedDirection()
    {
        return Random.Range(-rangedWeapon.Spread, rangedWeapon.Spread);
    }

    public void TrySpawnProjectile(float chargedSweetSpotDamageMultiplier = 1f, float chargedSweetSpotVelocityMultiplier = 1f, float chargedSweetSpotShakeMultiplier = 1f, float chargeDamageModifier = 0f)
    {
        for (int i = 0; i < rangedWeapon.ProjectilesPerShot; i++)
        {
            SpawnProjectile(chargedSweetSpotDamageMultiplier, chargedSweetSpotVelocityMultiplier, chargedSweetSpotShakeMultiplier, chargeDamageModifier);
        }

        // increase weapon heat
        rangedWeapon.AccumulatedHeat += rangedWeapon.HeatIncreasePerShot;
        heatSliderObject.GetComponent<Slider>().value = rangedWeapon.AccumulatedHeat;

        // play sound
        if (audioSource)
        {
            audioSource.PlayOneShot(shotAudio, shotVolume);
        }
    }

    private void SpawnProjectile(float chargedSweetSpotDamageMultiplier = 1f, float chargedSweetSpotVelocityMultiplier = 1f, float chargedSweetSpotShakeMultiplier = 1f, float chargeDamageModifier = 0f)
    {
        GameObject firedProjectile = Instantiate(projectile, transform.position + projectileOffset, equippedWeapon.pivot.rotation);

        // add spread to projectile and set attributes
        firedProjectile.transform.Rotate(0, 0, GetRandomizedDirection());
        SetProjectileAttributes(firedProjectile, chargedSweetSpotVelocityMultiplier, chargeDamageModifier);

        DamageDealer damageDealer = firedProjectile.GetComponent<DamageDealer>();

        // set projectile's crit chance and damage
        damageDealer.CritChance = playerAttributes.critChance + rangedWeapon.BonusCritChance;
        damageDealer.CritMultiplier = playerAttributes.critDamageMultiplier + rangedWeapon.BonusCritMultiplier;

        // add bonus damage on charge weapon sweet spot hit
        damageDealer.MultiplyAllDamage(chargedSweetSpotDamageMultiplier);

        // animate
        if (animator && !rangedWeapon.IsAutomatic)
        {
            animator.Play("Fire", -1, 0.0f);
        }

        // shake the screen
        shaker.ShakeCamera(rangedWeapon.ScreenShakeIntensity * chargedSweetSpotShakeMultiplier, rangedWeapon.ScreenShakeDuration);

        // muzzle flash
        if (muzzleFlashLight)
        {
            muzzleFlashLight.TriggerMuzzleFlash();
        }
    }

    private void SetProjectileAttributes(GameObject firedProjectile, float chargedSweetSpotVelocityMultiplier = 1f, float chargeDamageModifier = 0f)
    {
        float zAngle = firedProjectile.transform.rotation.eulerAngles.z * (Mathf.PI / 180f);
        float xComponent = Mathf.Cos(zAngle);
        float yComponent = Mathf.Sin(zAngle);
        Vector2 pivotDirection = new Vector2(xComponent, yComponent);

        firedProjectile.GetComponent<ProjectileStandard>().SetAttributes(equippedWeapon.owner, transform, rangedWeapon, pivotDirection, chargedSweetSpotVelocityMultiplier, chargeDamageModifier: chargeDamageModifier);
    }

    IEnumerator SpawnProjectileFullAuto()
    {
        isFiring = true;

        // wait for a moment to warm up
        if (rangedWeapon.WarmupTime > 0)
        {
            // animation
            if (animator)
            {
                animator.SetBool("AnimIsCharging", true);
            }

            // play warmup audio
            if (warmupAudio)
            {
                AudioUtility.PlaySound(audioSource, warmupAudio, warmupAudioVolume);
            }

            yield return new WaitForSeconds(rangedWeapon.WarmupTime);
        }

        // loop sound
        AudioUtility.LoopAudio(audioSource, fireLoopAudio, fireLoopAudioVolume);

        // animation
        if (animator)
        {
            animator.SetBool("AnimIsFiring", true);
        }

        while (true)
        {
            SpawnProjectile();

            // increase weapon heat
            rangedWeapon.AccumulatedHeat += rangedWeapon.HeatIncreasePerShot;
            heatSliderObject.GetComponent<Slider>().value = rangedWeapon.AccumulatedHeat;

            yield return new WaitForSeconds(1 / rangedWeapon.AttackRate);
        }
    }

    public void StopSpawningFullAuto()
    {
        if (!(autoFireCoroutine is null) && isFiring)
        {
            StopCoroutine(autoFireCoroutine);
            isFiring = false;

            // animation
            if (animator)
            {
                animator.SetBool("AnimIsFiring", false);
                animator.SetBool("AnimIsCharging", false);
            }

            AudioUtility.StopLoopingAudio(audioSource);

            AudioUtility.PlaySound(audioSource, shotAudio, shotVolume);
        }
    }

    public void CancelCharge()
    {
        // destroy slider
        if (chargeSlider)
        {
            Destroy(chargeSlider);
        }

        // player is not busy
        player.IsBusy = false;

        equippedWeapon.IsTechCharging = false;
        nextFireTime = 0;
    }

    public void DestroyHeatSlider()
    {
        Destroy(heatSliderObject);

        // destroy particles
        if (instantiatedOverheatParticles)
            Destroy(instantiatedOverheatParticles);
    }
}
