using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class TechWeapon : WeaponScript
{
    [Header("Charge Slider")]
    [SerializeField] GameObject chargeSliderTemplate;
    [SerializeField] [Range(0, 1)] float sweetSpotStartPercentage;      // sweetSpotStart < sweetSpotEnd < normalSpotEnd
    [SerializeField] [Range(0, 1)] float sweetSpotEndPercentage;
    GameObject chargeSlider;

    [Header("Sweet Spot Effects")]
    public float sweetSpotDamageMultiplier = 2f;
    public float sweetSpotVelocityMultiplier = 1.5f;
    public float sweetSpotScreenShakeMagnitudeMultiplier = 2f;
    //TODO: projectile color

    [Header("Slider Interpreted Values")]
    [SerializeField] float chargeDamageModifier;

    [Header("Audio")]
    [SerializeField] AudioClip chargeSound;
    [SerializeField] [Range(0, 1)] float chargeVolume = 1f;

    public EquippedWeapon equippedWeapon;
    WeaponReloader weaponReloader;
    FireProjectile fireProjectile;
    RangedWeapon rangedWeapon;
    Player player;
    PlayerMovement playerMovement;
    AmmoCounter playerAmmo;
    TabMenuManager tabMenuManager;
    WeaponWheelManager weaponWheelManager;
    Canvas canvas;
    Animator animator;
    AudioSource audioSource;

    // Single-Fire rate
    float nextFireTime;

    private void Awake()
    {
        equippedWeapon = GetComponent<EquippedWeapon>();
        weaponReloader = GetComponent<WeaponReloader>();
        fireProjectile = GetComponent<FireProjectile>();
        player = FindObjectOfType<Player>();
        playerMovement = FindObjectOfType<PlayerMovement>();
        tabMenuManager = FindObjectOfType<TabMenuManager>();
        weaponWheelManager = FindObjectOfType<WeaponWheelManager>();
        canvas = GameObject.FindGameObjectWithTag("GameCanvas").GetComponent<Canvas>();
        animator = GetComponent<Animator>();
        audioSource = GetComponent<AudioSource>();
    }

    // Start is called before the first frame update
    void Start()
    {
        rangedWeapon = (RangedWeapon)equippedWeapon.ItemData;
        playerAmmo = player.GetComponent<AmmoCounter>();
    }

    public void ChargeUpAttack()
    {
        // set that the weapon is charging
        equippedWeapon.IsTechCharging = true;

        // player is busy
        player.IsBusy = true;

        // animate charge
        if (animator)
        {
            animator.SetBool("AnimIsCharging", true);
        }

        // charge audio
        if (audioSource && chargeSound)
        {
            audioSource.clip = chargeSound;
            audioSource.volume = chargeVolume;
            audioSource.Play();
        }

        // instantiate charge slider
        chargeSlider = Instantiate(chargeSliderTemplate, canvas.transform);

        // set slider parameters
        chargeSlider.GetComponent<ChargeSlider>().SetParameters(rangedWeapon.EquippedMain, rangedWeapon.ChargeTime, sweetSpotStartPercentage, sweetSpotEndPercentage);
    }

    public void ReleaseCharge()
    {
        bool inSweetSpot = false;

        // player is not busy
        player.IsBusy = false;

        // animate charge
        if (animator)
        {
            animator.SetBool("AnimIsCharging", false);
        }

        // audio
        if (audioSource)
        {
            audioSource.Stop(); // stop charge audio
        }

        // get slider state and then destroy
        if (chargeSlider)
        {
            ChargeSlider slider = chargeSlider.GetComponent<ChargeSlider>();

            // check if in sweet spot
            inSweetSpot = slider.CheckSweetSpot();

            // get bonus charge damage fraction
            chargeDamageModifier = Mathf.Lerp(0f, rangedWeapon.MaxBonusChargeDamageAsFraction, slider.GetSliderValueAsFraction());

            Destroy(chargeSlider);
        }

        // if in sweet spot, do sweet spot stuff
        if (inSweetSpot)
        {
            // status message
            equippedWeapon.StatusMessageManager.DisplayMessage("PERFECT");

            fireProjectile.TrySpawnProjectile(sweetSpotDamageMultiplier, sweetSpotVelocityMultiplier, sweetSpotScreenShakeMagnitudeMultiplier);
        }
        else
        {
            // fire projectile
            fireProjectile.TrySpawnProjectile(chargeDamageModifier: chargeDamageModifier);
        }

        equippedWeapon.IsTechCharging = false;
    }

    public override void Use(InputAction.CallbackContext context)
    {
        // not reloading
        if (!weaponReloader.IsReloading && !tabMenuManager.InMenu && !player.InDialogue && !weaponWheelManager.WheelDisplayed)
        {
            // start the charge bar
            if (weaponReloader.AmmoInClip > 0 && !playerMovement.Dodging && !player.Character.Incapacitated && Time.time > nextFireTime)
            {
                nextFireTime = Time.time + (1 / rangedWeapon.AttackRate);   // add time to wait until next shot
                ChargeUpAttack();
            }
        }
    }

    public override void Release(InputAction.CallbackContext context)
    {
        // Let go of charge
        if (!tabMenuManager.InMenu && !player.InDialogue && !weaponWheelManager.WheelDisplayed && equippedWeapon.IsTechCharging)
        {
            // Fire
            ReleaseCharge();
        }
    }

    public override void Utility(InputAction.CallbackContext context)
    {
        if (!tabMenuManager.InMenu && !player.InDialogue && !weaponWheelManager.WheelDisplayed)
        {
            // Reload
            if (!equippedWeapon.IsTechCharging && !fireProjectile.isFiring && !playerMovement.Dodging && !player.Character.Incapacitated)
            {
                if (!weaponReloader.IsReloading)
                {
                    // if ammo in reserves and clip is not full
                    if (playerAmmo.GetAmmoCountByType(rangedWeapon.AmmunitionType) > 0 && (weaponReloader.AmmoInClip != weaponReloader.ClipSize))
                    {
                        weaponReloader.TriggerActiveReload();
                    }
                }
                // Is reloading, get active reload input
                else
                {
                    weaponReloader.ReceiveActiveReloadInput();
                }
            }
            // Cancel charge
            else if (equippedWeapon.IsTechCharging)
            {
                CancelCharge();
            }
        }
    }

    public void CancelCharge()
    {
        // destroy slider
        if (chargeSlider)
        {
            Destroy(chargeSlider);
        }

        // audio
        if (audioSource)
        {
            audioSource.Stop(); // stop charge audio
        }

        // player is not busy
        player.IsBusy = false;

        equippedWeapon.IsTechCharging = false;
        nextFireTime = 0;
    }

    public override void Interrupt()
    {
        // if dodging or incapacitated while charging
        if (equippedWeapon.IsTechCharging)
        {
            CancelCharge();
        }
    }
}
