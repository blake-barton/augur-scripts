using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public class AssaultRifle : WeaponScript
{
    EquippedWeapon equippedWeapon;
    WeaponReloader weaponReloader;
    FireProjectile fireProjectile;
    RangedWeapon rangedWeapon;
    Player player;
    PlayerMovement playerMovement;
    AmmoCounter playerAmmo;
    TabMenuManager tabMenuManager;
    WeaponWheelManager weaponWheelManager;

    // Single-Fire rate
    float nextFireTime;

    private void Awake()
    {
        equippedWeapon = GetComponent<EquippedWeapon>();
        weaponReloader = GetComponent<WeaponReloader>();
        fireProjectile = GetComponent<FireProjectile>();
        player = FindObjectOfType<Player>();
        playerMovement = FindObjectOfType<PlayerMovement>();
        tabMenuManager = FindObjectOfType<TabMenuManager>();
        weaponWheelManager = FindObjectOfType<WeaponWheelManager>();
    }

    // Start is called before the first frame update
    void Start()
    {
        rangedWeapon = (RangedWeapon)equippedWeapon.ItemData;
        playerAmmo = player.Character.GetComponent<AmmoCounter>();
    }

    public override void Use(InputAction.CallbackContext context)
    {
        // not reloading
        if (!weaponReloader.IsReloading && !tabMenuManager.InMenu && !player.InDialogue && !weaponWheelManager.WheelDisplayed)
        {
            // automatic fire
            if (rangedWeapon.IsAutomatic && !playerMovement.Dodging && !player.Character.Incapacitated)
            {
                fireProjectile.TriggerSpawnProjectileFullAuto();
            }

            // single fire
            if (!rangedWeapon.IsAutomatic && !playerMovement.Dodging && !player.Character.Incapacitated && Time.time > nextFireTime)
            {
                nextFireTime = Time.time + (1 / rangedWeapon.AttackRate);   // add time to wait until next shot
                fireProjectile.TrySpawnProjectile();
            }
        }
    }

    public override void Utility(InputAction.CallbackContext context)
    {
        // not currently reloading and not firing
        if (!tabMenuManager.InMenu && !player.InDialogue && !weaponWheelManager.WheelDisplayed && !fireProjectile.isFiring && !playerMovement.Dodging && !player.Character.Incapacitated)
        {
            // Reload
            if (!weaponReloader.IsReloading)
            {
                // if ammo in reserves and clip is not full
                if (playerAmmo.GetAmmoCountByType(rangedWeapon.AmmunitionType) > 0 && (weaponReloader.AmmoInClip != weaponReloader.ClipSize))
                {
                    weaponReloader.TriggerActiveReload();
                }
            }
            // Is reloading, get active reload input
            else
            {
                weaponReloader.ReceiveActiveReloadInput();
            }
        }
    }

    public override void Release(InputAction.CallbackContext context) 
    {
        // Stop firing full auto
        if (!weaponReloader.IsReloading && !tabMenuManager.InMenu && !player.InDialogue && !weaponWheelManager.WheelDisplayed && rangedWeapon.IsAutomatic)
        {
            // stop firing
            fireProjectile.StopSpawningFullAuto(true);
        }
    }

    public override void Interrupt()
    {
        // On dodge or incapacitated
        if (rangedWeapon.IsAutomatic)
        {
            // stop firing
            fireProjectile.StopSpawningFullAuto(true);
        }
    }
}
