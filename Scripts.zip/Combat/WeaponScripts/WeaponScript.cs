using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;

public abstract class WeaponScript : MonoBehaviour
{
    public abstract void Use(InputAction.CallbackContext context);
    public abstract void Release(InputAction.CallbackContext context);
    public abstract void Utility(InputAction.CallbackContext context);
    public abstract void Interrupt();
    public virtual void InterruptMagic() {}
}
