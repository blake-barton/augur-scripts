using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EquippedWeapon : MonoBehaviour
{
    [Header("Data")]
    [SerializeField] Item itemData;
    public GameObject owner;
    public Pair<Item, int> itemPair;

    [Header("Rotation")]
    [SerializeField] float spriteRotationalOffset = 0f;
    [SerializeField] float radius = 0.5f;
    public Transform pivot;
    [SerializeField] bool flipped;
    [SerializeField] float minFlipThreshold = 90f;
    [SerializeField] float maxFlipThreshold = 270f;

    [Header("Thrusting")]
    [SerializeField] float weaponPullBackDistance;
    [SerializeField] Vector2 weaponPullBackDirection = new Vector2();

    [Header("Ranged Combat")]
    [SerializeField] bool isTechCharging = false;

    [Header("Melee Combat")]
    [SerializeField] bool isCharging = false;     // if the weapon is charging up, stop tracking it to the mouse
    [SerializeField] bool isSwinging = false;     // ensures that weapon cannot be reswung in the middle of its action
    [SerializeField] float weaponChargedRotation = 0;

    // cached references
    SpriteRenderer spriteRenderer;
    Transform target;               // what are we rotating around
    StatusMessageManager statusMessageManager;
    DynamicYSort dynamicYSort;
    Player player;

    bool isThrustWeapon = false;

    public Item ItemData { get => itemData; set => itemData = value; }
    public float WeaponChargedRotation { get => weaponChargedRotation; }
    public float WeaponPullBackDistance { get => weaponPullBackDistance; set => weaponPullBackDistance = value; }
    public bool Flipped { get => flipped; set => flipped = value; }
    public StatusMessageManager StatusMessageManager { get => statusMessageManager; set => statusMessageManager = value; }
    public bool IsCharging { get => isCharging; set => isCharging = value; }
    public bool IsSwinging { get => isSwinging; set => isSwinging = value; }
    public bool IsTechCharging { get => isTechCharging; set => isTechCharging = value; }
    public Player EquippedWeaponPlayer { get => player; }

    // Start is called before the first frame update
    private void Awake()
    {
        spriteRenderer = GetComponent<SpriteRenderer>();
        StatusMessageManager = FindObjectOfType<StatusMessageManager>();
        dynamicYSort = GetComponent<DynamicYSort>();
        player = FindObjectOfType<Player>();
    }

    // Start is called before the first frame update
    void Start()
    {
        if (itemData is MeleeWeapon meleeWeapon)
        {
            if (meleeWeapon.AttackType == MeleeWeapon.MeleeAttackType.STAB)
            {
                isThrustWeapon = true;
            }
        }
        
        spriteRenderer.sprite = ItemData.Sprite;
        transform.Rotate(0, 0, spriteRotationalOffset);

        // rotate children as well
        foreach (Transform child in transform)
        {
            child.Rotate(0, 0, -spriteRotationalOffset);
        }

        // rotation
        target = transform.parent;
        pivot = new GameObject().transform;
        pivot.name = itemData.ItemName + " Pivot";
        transform.parent = pivot;

        // move offhand weapon to the back
        if (dynamicYSort.SortableSprites.Length > 0)
        {
            if (itemData.EquippedMain)
            {
                dynamicYSort.SortableSprites[0].relativeOrder += 2;
            }
            else if (itemData.EquippedOff)
            {
                dynamicYSort.SortableSprites[0].relativeOrder -= 2;
            }
        }
    }

    private void Update()
    {
        if (!IsSwinging)
        {
            PullBackWeaponIfThrusting();
            RotateAroundPlayer();
            FlipSprite();
        }
        else
        {
            LockPositionToOwner();
        }
    }

    private void PullBackWeaponIfThrusting()
    {
        if (IsCharging && isThrustWeapon)
        {
            CalculateWeaponPullBackDirection();
        }
        else
        {
            weaponPullBackDirection = Vector2.zero;
        }
    }

    private void LockPositionToOwner()
    {
        pivot.position = target.position;
    }

    // Got this online
    void RotateAroundPlayer()
    {
        if (EquippedWeaponPlayer.IsGamepad)
        {
            // If deadzone exceeded, rotate. Otherwise just track position
            if (Mathf.Abs(EquippedWeaponPlayer.AimDirection.x) > EquippedWeaponPlayer.GamepadDeadzone || Mathf.Abs(EquippedWeaponPlayer.AimDirection.y) > EquippedWeaponPlayer.GamepadDeadzone)
            {
                float angle = Mathf.Atan2(EquippedWeaponPlayer.AimDirection.y, EquippedWeaponPlayer.AimDirection.x) * Mathf.Rad2Deg;

                Vector2 newPosition = Quaternion.AngleAxis(angle + weaponChargedRotation, Vector3.forward) * (Vector3.right * radius);
                transform.position = (Vector2)target.position + newPosition + weaponPullBackDirection;

                pivot.SetPositionAndRotation(target.position + (Vector3)weaponPullBackDirection, Quaternion.AngleAxis(angle, Vector3.forward));
            }
            else
            {
                // Look at orbiter
                Vector3 v3Pos = EquippedWeaponPlayer.GamepadOrbiter.transform.position - target.position;
                float angle = Mathf.Atan2(v3Pos.y, v3Pos.x) * Mathf.Rad2Deg;

                v3Pos = Quaternion.AngleAxis(angle + weaponChargedRotation, Vector3.forward) * (Vector3.right * radius);
                transform.position = target.position + v3Pos + (Vector3)weaponPullBackDirection;

                pivot.SetPositionAndRotation(target.position + (Vector3)weaponPullBackDirection, Quaternion.AngleAxis(angle + weaponChargedRotation, Vector3.forward));
            }
        }
        else
        {
            Vector3 v3Pos = Camera.main.WorldToScreenPoint(target.position);
            v3Pos = Input.mousePosition - v3Pos;
            float angle = Mathf.Atan2(v3Pos.y, v3Pos.x) * Mathf.Rad2Deg;

            v3Pos = Quaternion.AngleAxis(angle + weaponChargedRotation, Vector3.forward) * (Vector3.right * radius);
            transform.position = target.position + v3Pos + (Vector3)weaponPullBackDirection;

            pivot.SetPositionAndRotation(target.position + (Vector3)weaponPullBackDirection, Quaternion.AngleAxis(angle + weaponChargedRotation, Vector3.forward));
        }
    }

    void FlipSprite()
    {
        if (pivot.transform.localEulerAngles.z > minFlipThreshold && pivot.transform.localEulerAngles.z < maxFlipThreshold)
        {
            if (!Flipped)
            {
                if (IsCharging && !isThrustWeapon)
                {
                    minFlipThreshold = 0f;
                    maxFlipThreshold = 180f;
                    weaponChargedRotation = -1f * Mathf.Abs(weaponChargedRotation);
                }

                transform.Rotate(0, 0, spriteRotationalOffset * -2);

                // rotate children as well
                foreach (Transform child in transform)
                {
                    child.Rotate(0, 0, spriteRotationalOffset * 2);
                }
            }

            spriteRenderer.flipY = true;
            Flipped = true;
        }
        else
        {
            if (Flipped)
            {
                if (IsCharging && !isThrustWeapon)
                {
                    minFlipThreshold = 180f;
                    maxFlipThreshold = 360f;
                    weaponChargedRotation = Mathf.Abs(weaponChargedRotation);
                }

                transform.Rotate(0, 0, spriteRotationalOffset * 2);

                // rotate children as well
                foreach (Transform child in transform)
                {
                    child.Rotate(0, 0, spriteRotationalOffset * -2);
                }
            }

            spriteRenderer.flipY = false;
            Flipped = false;
        }
    }

    public void ActivateChargedMeleeRotation(float weaponReadyRotation)
    {
        weaponChargedRotation = weaponReadyRotation;
        AlternateFlipThreshold();
    }

    private void AlternateFlipThreshold()
    {
        if (weaponChargedRotation != 0)
        {
            if (!Flipped)
            {
                minFlipThreshold = 180f;
                maxFlipThreshold = 360f;
            }
            else
            {
                weaponChargedRotation *= -1f;
                minFlipThreshold = 0f;
                maxFlipThreshold = 180f;
            }
        }
    }

    void DeactivateChargedMeleeRotation()
    {
        minFlipThreshold = 90f;
        maxFlipThreshold = 270f;
        weaponChargedRotation = 0f;
    }

    private void CalculateWeaponPullBackDirection()
    {
        // Get mouse position (in screen-space) and convert to world-space
        var mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);

        // Calculate the vector between the mouse position and object
        weaponPullBackDirection = (target.transform.position - mousePos).normalized * weaponPullBackDistance;
    }

    // instantly rotate the pivot
    public void RotatePivot(Vector3 byAngles)
    {
        if (Flipped)
        {
            pivot.Rotate(-1f * byAngles);
        }
        else
        {
            pivot.Rotate(byAngles);
        }
    }

    public void TriggerRotateOverTime(Vector3 byAngles, float inTime)
    {
        StartCoroutine(RotateOverTime(byAngles, inTime));
    }

    // rotate the pivot byAngles degrees in inTime seconds
    IEnumerator RotateOverTime(Vector3 byAngles, float inTime)
    {
        IsSwinging = true;

        var fromAngle = pivot.rotation;

        if (!Flipped)
        {
            byAngles = -1f * byAngles;
        }

        var toAngle = Quaternion.Euler(pivot.eulerAngles + byAngles);

        for (var t = 0f; t < 1; t += Time.deltaTime / inTime)
        {
            // rotate pivot
            pivot.rotation = Quaternion.Lerp(fromAngle, toAngle, t);

            yield return null;
        }

        IsSwinging = false;
        DeactivateChargedMeleeRotation();
    }

    public void TriggerThrustOverTime()
    {
        IsCharging = false;
        IsSwinging = false;
        weaponPullBackDirection = Vector2.zero;
    }
}
