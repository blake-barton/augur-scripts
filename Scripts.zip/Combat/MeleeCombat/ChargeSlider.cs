using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ChargeSlider : MonoBehaviour
{
    [Header("Properties")]
    [SerializeField] float backgroundWidth;
    [SerializeField] float backgroundHeight = 5f;
    [SerializeField] float sweetSpotPos;
    [SerializeField] float sweetSpotHeight;

    [Header("Positioning")]
    public bool isMainHand = false;
    public static Vector2 mainHandOffset = new Vector2(-0.6f, 0f);
    public static Vector2 offHandOffset = new Vector2(0.6f, 0f);

    [Header("Bars")]
    [SerializeField] RectTransform handleSlideArea;
    [SerializeField] RectTransform background;
    [SerializeField] RectTransform sweetSpot;

    // cached references
    [SerializeField] Player player;
    [SerializeField] RectTransform sliderTransform;
    [SerializeField] Slider slider;
    public MeleeAttack meleeAttack;

    // state
    [SerializeField] bool attackComplete = false;

    // references
    AttributeScores playerAttributes;

    // calculated
    float sweetSpotStartTime;
    float sweetSpotEndTime;

    private void Awake()
    {
        sliderTransform = GetComponent<RectTransform>();
        player = FindObjectOfType<Player>();
        playerAttributes = player.GetComponent<AttributeScores>();
        slider = GetComponent<Slider>();
    }

    // Start is called before the first frame update
    void Start()
    {
        FormatBar();
    }

    // Update is called once per frame
    void Update()
    {
        LockToPlayer();

        if (!attackComplete)
        {
            // immediately start moving the handle
            slider.value = Time.time;
        }
    }

    // handles the size of the background and slider
    public void FormatBar()
    {
        // size background
        background.sizeDelta = new Vector2(backgroundWidth, backgroundHeight);

        // size slider
        sliderTransform.sizeDelta = new Vector2(backgroundWidth, backgroundHeight);
    }

    void FormatReloadSpots()
    {
        // size sweet spot
        sweetSpot.sizeDelta = new Vector2(backgroundWidth, sweetSpotHeight);

        // clamp sweetSpotPos to the background height
        sweetSpotPos = Mathf.Clamp(sweetSpotPos, (-1f * backgroundHeight / 2) + sweetSpotHeight / 2, backgroundHeight / 2 - sweetSpotHeight / 2);

        // set sweet spot pos
        sweetSpot.anchoredPosition = new Vector3(0, sweetSpotPos, 0);
    }

    private void LockToPlayer()
    {
        // lock position to player if player exists
        if (isMainHand)
        {
            if (player)
            {
                transform.position = Camera.main.WorldToScreenPoint((Vector2)player.transform.position + mainHandOffset);
            }
            else
            {
                Destroy(gameObject);
            }
        }
        else
        {
            if (player)
            {
                transform.position = Camera.main.WorldToScreenPoint((Vector2)player.transform.position + offHandOffset);
            }
            else
            {
                Destroy(gameObject);
            }
        }
    }

    public void SetParameters(bool isMainHand, float attackTime, float sweetSpotStartPercentage, float sweetSpotEndPercentage)
    {
        // add bonus percentage from playerAttributes
        sweetSpotEndPercentage += playerAttributes.sweetSpotBonusPercentage;

        // determines placement of slider
        this.isMainHand = isMainHand;

        // set speed of handle based on reload speed
        slider.minValue = Time.time;
        slider.maxValue = Time.time + attackTime;

        // set the reload bar's spot positions and size
        SetSpotParameters(sweetSpotStartPercentage, sweetSpotEndPercentage);
        FormatReloadSpots();
    }

    private void SetSpotParameters(float sweetSpotStartPercentage, float sweetSpotEndPercentage)
    {
        // basically here we're using the sweet spot start and end percentages to get the start and end values for the sweet spot in terms of actual seconds
        sweetSpotStartTime = Mathf.Lerp(slider.minValue, slider.maxValue, sweetSpotStartPercentage);
        sweetSpotEndTime = Mathf.Lerp(slider.minValue, slider.maxValue, sweetSpotEndPercentage);

        // Now we're using the percentages to get the position of the sweet spot on the bar
        float sweetMidpointTimeAsPercentage = (sweetSpotStartPercentage + sweetSpotEndPercentage) / 2f;
        sweetSpotPos = sweetMidpointTimeAsPercentage * backgroundHeight - backgroundHeight / 2;

        // this gives the height of the sweet spot in relation to the background, adding in the player's sleight of hand bonus
        float sweetSpotPercentOfHeight = sweetSpotEndPercentage - sweetSpotStartPercentage;
        sweetSpotHeight = sweetSpotPercentOfHeight * backgroundHeight;
    }

    // returns true if the attack is finished in the sweet spot
    public bool CheckSweetSpot()
    {
        // freeze slider
        attackComplete = true;
        slider.value = slider.value;    // this might not be necessary?

        // check if slider is in zones
        if (slider.value >= sweetSpotStartTime && slider.value < sweetSpotEndTime)
        {
            return true;
        }
        else
        {
            return false;
        }
    }

    public float GetSliderValueAsFraction()
    {
        return Mathf.InverseLerp(slider.minValue, slider.maxValue, slider.value);
    }
}