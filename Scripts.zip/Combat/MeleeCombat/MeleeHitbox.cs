using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MeleeHitbox : MonoBehaviour
{
    [Header("Rotation")]
    [SerializeField] float spriteRotationalOffset = 0f;
    [SerializeField] bool flipped;
    [SerializeField] float minFlipThreshold = 90f;
    [SerializeField] float maxFlipThreshold = 270f;

    [Header("Impact Effects")]
    [SerializeField] List<GameObject> actorImpactEffects = new List<GameObject>();
    [SerializeField] [Range(0, 31)] int enemyLayer = 9;
    [SerializeField] [Range(0, 31)] int knockDownLayer = 21;
    [SerializeField] [Range(0, 31)] int playerLayer = 6;
    [SerializeField] [Range(0, 31)] int wallLayer = 10;
    [SerializeField] Color critImpactEffectColor;

    [Header("Kill Effects")]
    [SerializeField] float hitStopTime = 0.1f;

    // Assigned at runtime
    private GameObject attacker;
    private Transform sourceLocation;
    private bool inSweetSpot = false;
    private float sweetSpotDamageMultiplier;
    private float screenShakeIntensity;
    private float screenShakeDuration;
    private float sweetSpotMagnitudeMultiplier = 2f;
    private bool canHitMultipleTargets = false;
    private float attackDistance;
    private Vector2 attackEffectOffset = new Vector2();
    private float chargeDamageModifier;
    private Weapon originWeapon;

    private bool targetHit = false;

    // cached references
    ShakeBehavior shaker;
    DamageDealer damageDealer;
    SpriteRenderer spriteRenderer;

    public Weapon OriginWeapon { get => originWeapon; set => originWeapon = value; }
    public Transform Source { get => sourceLocation; set => sourceLocation = value; }
    public bool InSweetSpot { get => inSweetSpot; set => inSweetSpot = value; }
    public float SweetSpotDamageMultiplier { get => sweetSpotDamageMultiplier; set => sweetSpotDamageMultiplier = value; }
    public float ScreenShakeIntensity { get => screenShakeIntensity; set => screenShakeIntensity = value; }
    public float ScreenShakeDuration { get => screenShakeDuration; set => screenShakeDuration = value; }
    public float SweetSpotMagnitudeMultiplier { get => sweetSpotMagnitudeMultiplier; set => sweetSpotMagnitudeMultiplier = value; }
    public bool CanHitMultipleTargets { get => canHitMultipleTargets; set => canHitMultipleTargets = value; }
    public float AttackDistance { get => attackDistance; set => attackDistance = value; }
    public Vector2 AttackEffectOffset { get => attackEffectOffset; set => attackEffectOffset = value; }
    public float ChargeDamageModifier { get => chargeDamageModifier; set => chargeDamageModifier = value; }
    public GameObject Attacker { get => attacker; set => attacker = value; }

    void Awake()
    {
        shaker = FindObjectOfType<ShakeBehavior>();
        damageDealer = GetComponent<DamageDealer>();
        spriteRenderer = GetComponent<SpriteRenderer>();
    }

    private void Start()
    {
        attackEffectOffset.x = Mathf.Cos(Mathf.Deg2Rad * transform.localEulerAngles.z);
        attackEffectOffset.y = Mathf.Sin(Mathf.Deg2Rad * transform.localEulerAngles.z);
        AttackEffectOffset = AttackDistance * AttackEffectOffset;
    }

    private void Update()
    {
        // lock position to source
        transform.position = Source.position + (Vector3)AttackEffectOffset;

        FlipSprite();
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if ((!targetHit && !CanHitMultipleTargets) || CanHitMultipleTargets)
        {
            if (InSweetSpot)
            {
                // multiply damage
                damageDealer.MultiplyAllDamage(SweetSpotDamageMultiplier);
                damageDealer.ForceDamage *= SweetSpotDamageMultiplier;

                // cause damage
                damageDealer.CauseMeleeDamage(collision, Attacker, OriginWeapon);

                // knockback
                Knockback(collision);

                // shake the screen (multiplied)
                shaker.ShakeCamera(ScreenShakeIntensity * SweetSpotMagnitudeMultiplier, ScreenShakeDuration);
            }
            else
            {
                // modify damage based on charge
                damageDealer.MultiplyAllDamage(1f + ChargeDamageModifier);
                damageDealer.ForceDamage *= (1f + ChargeDamageModifier);

                // cause damage
                if (damageDealer.CauseMeleeDamage(collision, Attacker, OriginWeapon))
                {
                    if (Time.timeScale == 1)
                    {
                        // target killed
                        StartCoroutine(OnKillHitStop());
                    }
                }

                // knockback
                Knockback(collision);

                // shake the screen
                shaker.ShakeCamera(ScreenShakeIntensity, ScreenShakeDuration);
            }

            // spawn impact effect
            if ((collision.gameObject.layer == enemyLayer || collision.gameObject.layer == playerLayer || collision.gameObject.layer == knockDownLayer) && actorImpactEffects.Count > 0)
            {
                GameObject impactEffectToSpawn = GetRandomImpactEffect();

                // hit enemy/player
                if (damageDealer.CritSuccess)
                {
                    // critical hit
                    var impactEffect = Instantiate(impactEffectToSpawn, collision.gameObject.transform.position, Quaternion.identity);
                    impactEffect.GetComponent<SpriteRenderer>().color = critImpactEffectColor;
                }
                else
                {
                    // normal hit
                    Instantiate(impactEffectToSpawn, collision.gameObject.transform.position, Quaternion.identity);
                }
            }

            targetHit = true;
        }
    }

    void FlipSprite()
    {
        if (transform.localEulerAngles.z > minFlipThreshold && transform.localEulerAngles.z < maxFlipThreshold)
        {
            if (!flipped)
            {
                transform.Rotate(0, 0, spriteRotationalOffset * -2);
            }

            spriteRenderer.flipY = true;
            flipped = true;
        }
        else
        {
            if (flipped)
            {
                transform.Rotate(0, 0, spriteRotationalOffset * 2);
            }

            spriteRenderer.flipY = false;
            flipped = false;
        }
    }

    GameObject GetRandomImpactEffect()
    {
        int rand = Random.Range(0, actorImpactEffects.Count);
        return actorImpactEffects[rand];
    }

    // called by animation event
    public void ShakeScreen()
    {
        shaker.ShakeCamera(ScreenShakeIntensity, ScreenShakeDuration);
    }

    IEnumerator OnKillHitStop()
    {
        float currentTimeScale = Time.timeScale;
        float pauseEndTime = Time.realtimeSinceStartup + hitStopTime;

        Time.timeScale = 0;

        while (Time.realtimeSinceStartup < pauseEndTime)
        {
            yield return null;
        }

        Time.timeScale = currentTimeScale;
    }

    void Knockback(Collider2D collision)
    {
        if (originWeapon.KnockbackForce > 0)
        {
            Knockback actorKnockback = collision.gameObject.GetComponent<Knockback>();
            if (actorKnockback)
            {
                actorKnockback.TriggerKnockback(transform.right, originWeapon.KnockbackForce, originWeapon.KnockbackTime);
            }
        }
    }

    // called by animation event
    public void DespawnSlash()
    {
        Destroy(gameObject);
    }
}
