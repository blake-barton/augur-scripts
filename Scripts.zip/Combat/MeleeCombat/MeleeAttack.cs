using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MeleeAttack : MonoBehaviour
{
    // config
    [Header("Base Stats")]
    [SerializeField] float attackTime;
    [SerializeField] float chargeTime;
    [SerializeField] List<float> damages = new List<float>();
    [SerializeField] List<DamageEffects.DamageType> damageTypes = new List<DamageEffects.DamageType>();
    [SerializeField] float screenShakeIntensity;
    [SerializeField] float screenShakeDuration;

    [Header("Equipped Weapon Movement")]
    [SerializeField] float weaponReadyRotation = -45f;
    [SerializeField] float weaponSwingRotation = 90f;
    [SerializeField] float weaponPullBackDistance = .5f;
 
    [Header("Charge Slider")]
    [SerializeField] GameObject chargeSliderTemplate;
    [SerializeField] [Range(0, 1)] float sweetSpotStartPercentage;      // sweetSpotStart < sweetSpotEnd < normalSpotEnd
    [SerializeField] [Range(0, 1)] float sweetSpotEndPercentage;
    GameObject chargeSlider;

    [Header("Audio")]
    [SerializeField] AudioSource audioSource;
    [SerializeField] AudioClip[] swingEffects;
    [SerializeField] [Range(0, 1)] float swingVolume = 0.5f;

    [Header("Melee Slash")]
    [SerializeField] GameObject attackEffect;
    [SerializeField] GameObject spawnedAttackEffect;
    [SerializeField] float attackDistance;

    [Header("Sweet Spot Effects")]
    public float sweetSpotDamageMultiplier;
    public float sweetSpotScreenShakeMagnitudeMultiplier;
    public float sweetSpotKnockbackMultiplier;
    public float sweetSpotSwingSpeedMultiplier;

    [Header("Slider Interpreted Values")]
    [SerializeField] float chargeDamageModifier;

    Transform handTransform;

    // cached reference
    Canvas canvas;
    EquippedWeapon equippedWeapon;
    MeleeWeapon meleeWeapon;
    Player player;
    AttributeScores playerAttributes;
    PlayerMovement playerMovement;

    // Start is called before the first frame update
    void Start()
    {
        equippedWeapon = GetComponent<EquippedWeapon>();
        player = equippedWeapon.owner.GetComponent<Player>();
        playerAttributes = equippedWeapon.owner.GetComponent<AttributeScores>();
        playerMovement = player.GetComponent<PlayerMovement>();
        meleeWeapon = (MeleeWeapon)equippedWeapon.ItemData;
        attackTime = meleeWeapon.AttackTime;
        chargeTime = meleeWeapon.ChargeTime;
        damages = meleeWeapon.Damages;
        damageTypes = meleeWeapon.DamageTypes;
        screenShakeIntensity = meleeWeapon.ScreenShakeIntensity;
        screenShakeDuration = meleeWeapon.ScreenShakeDuration;

        SetHandTransform();

        canvas = GameObject.FindGameObjectWithTag("GameCanvas").GetComponent<Canvas>();
    }

    private void SetHandTransform()
    {
        if (meleeWeapon.EquippedMain)
        {
            handTransform = equippedWeapon.owner.GetComponent<Equipment>().MainHandArm.transform.parent;
        }
        else
        {
            handTransform = equippedWeapon.owner.GetComponent<Equipment>().OffHandArm.transform.parent;
        }
    }

    public void ChargeUpAttack()
    {
        // set that the weapon is charging
        equippedWeapon.IsCharging = true;
        player.IsBusy = true;

        // move weapon to swing position
        if (meleeWeapon.AttackType == MeleeWeapon.MeleeAttackType.SWING)
        {
            equippedWeapon.ActivateChargedMeleeRotation(weaponReadyRotation);
        }
        else if (meleeWeapon.AttackType == MeleeWeapon.MeleeAttackType.STAB)
        {
            // pull back for stab
            equippedWeapon.WeaponPullBackDistance = weaponPullBackDistance;
        }

        // instantiate charge slider
        if (equippedWeapon.ItemData.EquippedMain)
        {
            chargeSlider = Instantiate(chargeSliderTemplate, Camera.main.WorldToScreenPoint((Vector2)equippedWeapon.owner.transform.position + ChargeSlider.mainHandOffset), Quaternion.identity, canvas.transform);
        }
        else
        {
            chargeSlider = Instantiate(chargeSliderTemplate, Camera.main.WorldToScreenPoint((Vector2)equippedWeapon.owner.transform.position + ChargeSlider.offHandOffset), Quaternion.identity, canvas.transform);
        }

        // set slider parameters
        chargeSlider.GetComponent<ChargeSlider>().SetParameters(((MeleeWeapon)equippedWeapon.ItemData).EquippedMain, chargeTime, sweetSpotStartPercentage, sweetSpotEndPercentage);
    }

    public void ReleaseCharge()
    {
        // no longer charging
        equippedWeapon.IsCharging = false;
        player.IsBusy = false;

        bool inSweetSpot = false;

        // get slider state and then destroy
        if (chargeSlider)
        {
            ChargeSlider slider = chargeSlider.GetComponent<ChargeSlider>();
            
            // check if in sweet spot
            inSweetSpot = slider.CheckSweetSpot();

            // get bonus charge damage fraction
            chargeDamageModifier = Mathf.Lerp(0f, meleeWeapon.MaxBonusChargeDamageAsFraction, slider.GetSliderValueAsFraction());

            Destroy(chargeSlider);
        }

        // if in sweet spot, do sweet spot stuff
        if (inSweetSpot)
        {
            if (meleeWeapon.AttackType == MeleeWeapon.MeleeAttackType.SWING)
            {
                equippedWeapon.TriggerRotateOverTime(new Vector3(0, 0, weaponSwingRotation), attackTime / sweetSpotSwingSpeedMultiplier);
            }
            else if (meleeWeapon.AttackType == MeleeWeapon.MeleeAttackType.STAB)
            {
                // stab
                equippedWeapon.TriggerThrustOverTime();
            }

            // status message
            equippedWeapon.StatusMessageManager.DisplayMessage("PERFECT");

            // Lunge
            Lunge();

            // Spawn effect
            SpawnAttackEffect(true);
        }
        else
        {
            // rotate weapon over time
            if (meleeWeapon.AttackType == MeleeWeapon.MeleeAttackType.SWING)
            {
                equippedWeapon.TriggerRotateOverTime(new Vector3(0, 0, weaponSwingRotation), attackTime);
            }
            else if (meleeWeapon.AttackType == MeleeWeapon.MeleeAttackType.STAB)
            {
                // stab
                equippedWeapon.TriggerThrustOverTime();
            }

            // Lunge
            Lunge();

            // Spawn effect
            SpawnAttackEffect(false);
        }

        // sound
        PlayRandomSound(swingEffects, swingVolume);
    }

    public void InstantAttack()
    {
        // Ready weapon
        if (meleeWeapon.AttackType == MeleeWeapon.MeleeAttackType.SWING)
        {
            // move weapon to swing position
            equippedWeapon.ActivateChargedMeleeRotation(weaponReadyRotation);
        }
        else if (meleeWeapon.AttackType == MeleeWeapon.MeleeAttackType.STAB)
        {
            // pull back for stab
            equippedWeapon.WeaponPullBackDistance = weaponPullBackDistance;
        }

        // Attack
        if (meleeWeapon.AttackType == MeleeWeapon.MeleeAttackType.SWING)
        {
            // swing
            equippedWeapon.TriggerRotateOverTime(new Vector3(0, 0, weaponSwingRotation), attackTime);
        }
        else if (meleeWeapon.AttackType == MeleeWeapon.MeleeAttackType.STAB)
        {
            // stab
            equippedWeapon.TriggerThrustOverTime();
        }

        // Lunge
        Lunge();

        // Spawn effect
        SpawnAttackEffect(false);

        // sound
        PlayRandomSound(swingEffects, swingVolume);
    }

    public void CancelCharge()
    {
        // no longer charging
        equippedWeapon.IsCharging = false;
        player.IsBusy = false;

        // destroy slider
        if (chargeSlider)
        {
            Destroy(chargeSlider);
        }
        
        // rotate back
        if (meleeWeapon.AttackType == MeleeWeapon.MeleeAttackType.SWING)
        {
            equippedWeapon.TriggerRotateOverTime(new Vector3(0, 0, weaponSwingRotation), attackTime / sweetSpotSwingSpeedMultiplier);

        }
        else if (meleeWeapon.AttackType == MeleeWeapon.MeleeAttackType.STAB)
        {
            equippedWeapon.TriggerThrustOverTime();
        }
    }

    private void SpawnAttackEffect(bool inSweetSpot)
    {
        // spawn slash, adding move direction to the position so that the lunge actually has an effect
        spawnedAttackEffect = Instantiate(attackEffect, (Vector2)equippedWeapon.owner.transform.position, handTransform.rotation);

        // hitbox
        MeleeHitbox meleeHitbox = spawnedAttackEffect.GetComponent<MeleeHitbox>();
        meleeHitbox.Attacker = equippedWeapon.owner;
        meleeHitbox.Source = handTransform;
        meleeHitbox.CanHitMultipleTargets = meleeWeapon.CanHitMultipleTargets;
        meleeHitbox.AttackDistance = attackDistance;
        meleeHitbox.ChargeDamageModifier = chargeDamageModifier;
        meleeHitbox.OriginWeapon = meleeWeapon;

        // add damage to slash
        DamageDealer damageDealer = spawnedAttackEffect.GetComponent<DamageDealer>();
        damageDealer.CopyDamageList(damages);
        damageDealer.CopyDamageTypeList(damageTypes);

        // status effects
        damageDealer.SetStatusEffectDamagePercentage(meleeWeapon.StatusEffectDamagePercentage);
        damageDealer.ForceDamage = meleeWeapon.ForceDamage;
        damageDealer.BleedBuildup = meleeWeapon.BleedBuildup;

        // set slash's crit chance and damage
        damageDealer.CritChance = playerAttributes.critChance + meleeWeapon.BonusCritChance;
        damageDealer.CritMultiplier = playerAttributes.critDamageMultiplier + meleeWeapon.BonusCritMultiplier;

        // sweet spot
        meleeHitbox.SweetSpotDamageMultiplier = sweetSpotDamageMultiplier;
        meleeHitbox.SweetSpotMagnitudeMultiplier = sweetSpotScreenShakeMagnitudeMultiplier;
        meleeHitbox.InSweetSpot = inSweetSpot;

        // screen shake
        meleeHitbox.ScreenShakeIntensity = screenShakeIntensity;
        meleeHitbox.ScreenShakeDuration = screenShakeDuration;
    }

    void Lunge()
    {
        if (meleeWeapon.LungeForce > 0)
        {
            playerMovement.TriggerLunge(handTransform.right, meleeWeapon.LungeForce, meleeWeapon.LungeTime);
        }
    }

    private void PlayRandomSound(AudioClip[] clips, float volume)
    {
        int randomIndex = Random.Range(0, clips.Length);
        audioSource.PlayOneShot(clips[randomIndex], volume);
    }
}
