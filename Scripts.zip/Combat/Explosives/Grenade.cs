using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Grenade : MonoBehaviour
{
    [Header("Prefabs")]
    [SerializeField] GameObject explosionTemplate;

    [Header("Timing")]
    [SerializeField] float timeToExplode = 6f;

    float timer = 0f;
    bool exploded = false;

    // cached references
    ProjectileStandard projectileStandard;
    DamageDealer damageDealer;

    private void Awake()
    {
        damageDealer = GetComponent<DamageDealer>();
        projectileStandard = GetComponent<ProjectileStandard>();
    }

    private void Update()
    {
        timer += Time.deltaTime;

        if (timer >= timeToExplode && !exploded)
        {
            exploded = true;
            Explode();
        }
    }

    void Explode()
    {
        GameObject effect = Instantiate(explosionTemplate, transform.position, Quaternion.identity);
        Explosion explosion = effect.GetComponent<Explosion>();
        explosion.DamageDealer.CopyDamageList(damageDealer.Damages);
        explosion.DamageDealer.CopyDamageTypeList(damageDealer.DamageTypes);
        explosion.DamageDealer.SetStatusEffectDamagePercentage(damageDealer.StatusEffectDamagePercentage);

        if (projectileStandard)
        {
            explosion.Attacker = projectileStandard.Shooter;
        }

        Destroy(gameObject);
    }
}
