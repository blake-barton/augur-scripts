using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ExplosiveProjectile : MonoBehaviour
{
    [Header("Prefabs")]
    [SerializeField] GameObject explosionTemplate;

    // cached references
    DamageDealer damageDealer;
    ProjectileStandard projectileStandard;

    private void Awake()
    {
        damageDealer = GetComponent<DamageDealer>();
        projectileStandard = GetComponent<ProjectileStandard>();
    }

    private void OnDestroy()
    {
        Explode();
    }

    void Explode()
    {
        GameObject effect = Instantiate(explosionTemplate, transform.position, Quaternion.identity);
        Explosion explosion = effect.GetComponent<Explosion>();
        explosion.DamageDealer.CopyDamageList(damageDealer.Damages);
        explosion.DamageDealer.CopyDamageTypeList(damageDealer.DamageTypes);
        explosion.DamageDealer.SetStatusEffectDamagePercentage(damageDealer.StatusEffectDamagePercentage);
        
        if (projectileStandard)
        {
            explosion.Attacker = projectileStandard.Shooter;
            explosion.OriginWeapon = projectileStandard.OriginWeapon;
        }
    }
}
