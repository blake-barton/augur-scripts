using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Mine : MonoBehaviour
{
    [Header("Prefabs")]
    [SerializeField] GameObject explosionTemplate;
    [SerializeField] GameObject objectToDestroy;

    [Header("Damage")]
    [SerializeField] List<float> damages = new List<float>();
    [SerializeField] List<DamageEffects.DamageType> damageTypes = new List<DamageEffects.DamageType>();

    [Header("Status Effects")]
    [SerializeField] float statusEffectDamagePercentage = .1f;

    [Header("Timing")]
    [SerializeField] float timeToSet = .75f;
    [SerializeField] float explosionDelay = .15f;

    [Header("Audio")]
    [SerializeField] AudioSource audioSource;
    [SerializeField] AudioClip triggerSound;
    [SerializeField] [Range(0, 1)] float triggerSoundVolume = 1f;
    [SerializeField] AudioClip dropSound;
    [SerializeField] [Range(0, 1)] float dropSoundVolume = 1f;


    [Header("Cached References")]
    [SerializeField] Animator animator;

    GameObject owner;

    float timer = 0f;
    bool explosivePrimed = false;
    bool exploded = false;

    public GameObject Owner { get => owner; set => owner = value; }

    private void Start()
    {
        AudioUtility.PlaySound(audioSource, dropSound, dropSoundVolume);
    }

    private void Update()
    {
        if (timer < timeToSet)
        {
            timer += Time.deltaTime;
        }
        else if (timer >= timeToSet && !explosivePrimed)
        {
            explosivePrimed = true;

            if (animator)
            {
                animator.SetBool("AnimEnabled", true);
            }
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        TriggerExplosionWithDelay();
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        TriggerExplosionInstant();
    }

    void TriggerExplosionInstant()
    {
        if (!exploded && explosivePrimed)
        {
            exploded = true;

            GameObject effect = Instantiate(explosionTemplate, transform.position, Quaternion.identity);
            Explosion explosion = effect.GetComponent<Explosion>();
            explosion.DamageDealer.CopyDamageList(damages);
            explosion.DamageDealer.CopyDamageTypeList(damageTypes);
            explosion.DamageDealer.SetStatusEffectDamagePercentage(statusEffectDamagePercentage);

            explosion.Attacker = owner;

            Destroy(objectToDestroy);
        }
    }

    void TriggerExplosionWithDelay()
    {
        if (!exploded && explosivePrimed)
        {
            exploded = true;

            AudioUtility.PlaySound(audioSource, triggerSound, triggerSoundVolume);

            StartCoroutine(Explode());
        }
    }

    IEnumerator Explode()
    {
        yield return new WaitForSeconds(explosionDelay);

        GameObject effect = Instantiate(explosionTemplate, transform.position, Quaternion.identity);
        Explosion explosion = effect.GetComponent<Explosion>();
        explosion.DamageDealer.CopyDamageList(damages);
        explosion.DamageDealer.CopyDamageTypeList(damageTypes);
        explosion.DamageDealer.SetStatusEffectDamagePercentage(statusEffectDamagePercentage);

        explosion.Attacker = owner;

        Destroy(objectToDestroy);
    }

    public void CopyDamageList(List<float> weaponDamages)
    {
        foreach (float oldDamage in weaponDamages)
        {
            damages.Add(oldDamage);
        }
    }

    public void CopyDamageTypeList(List<DamageEffects.DamageType> weaponDamageTypes)
    {
        foreach (DamageEffects.DamageType oldType in weaponDamageTypes)
        {
            damageTypes.Add(oldType);
        }
    }

    public void SetStatusEffectDamagePercentage(float _statusEffectDamagePercentage)
    {
        statusEffectDamagePercentage = _statusEffectDamagePercentage;
    }
}
