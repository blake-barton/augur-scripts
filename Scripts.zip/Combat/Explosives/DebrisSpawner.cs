using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DebrisSpawner : MonoBehaviour
{
    [SerializeField] GameObject debrisParticle;
    [SerializeField] Color debrisParticleColor;

    [SerializeField] Vector2 debrisGroundVelocityRange;
    [SerializeField] Vector2 debrisVerticalVelocityRange;

    [SerializeField] Vector2 debrisParticleSizeRange;

    [SerializeField] Vector2Int debrisCountRange;

    public void SpawnDebris()
    { 

    }
}
