using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TrainingDummy : MonoBehaviour
{
    [SerializeField] Animator animator;

    public void PlayHitAnimation()
    {
        animator.Play("Damaged", -1, 0.0f);
    }
}
