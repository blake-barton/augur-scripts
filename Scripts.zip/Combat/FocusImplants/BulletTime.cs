using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletTime : FocusImplant
{
    [SerializeField] float newTimeScale = .2f;

    public override void Activate()
    {
        Time.timeScale = newTimeScale;
    }

    public override void Deactivate()
    {
        Time.timeScale = 1f;
    }
}
