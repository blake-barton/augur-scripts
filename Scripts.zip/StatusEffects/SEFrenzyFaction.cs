using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Status Effects/Frenzy Faction")]
public class SEFrenzyFaction : StatusEffect
{
    // Insanity original faction
    Character.Faction originalFaction;

    public override void Apply(StatusEffects statusEffects)
    {
        if (statusEffects.ActorCharacter && statusEffects.ActorLineOfSight && !statusEffects.ActorPlayer)
        {
            // store original faction
            originalFaction = statusEffects.ActorCharacter.CharacterFaction;

            // change faction to frenzied
            statusEffects.ActorCharacter.CharacterFaction = Character.Faction.Frenzied;

            // force retarget
            statusEffects.ActorLineOfSight.Target = null;
        }
    }

    public override void Remove(StatusEffects statusEffects)
    {
        if (statusEffects.ActorCharacter && statusEffects.ActorLineOfSight && !statusEffects.ActorPlayer)
        {
            // revert faction
            statusEffects.ActorCharacter.CharacterFaction = originalFaction;

            // force retarget
            statusEffects.ActorLineOfSight.Target = null;
        }
    }
}
