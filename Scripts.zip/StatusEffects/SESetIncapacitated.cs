using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Status Effects/Set Incapacitated")]
public class SESetIncapacitated : StatusEffect
{
    [SerializeField] bool incapacitated = true;

    Character character;

    public override void Apply(StatusEffects statusEffects)
    {
        character = statusEffects.GetComponent<Character>();
        if (character)
        {
            character.Incapacitated = incapacitated;
        }
    }

    public override void Remove(StatusEffects statusEffects)
    {
        if (character)
        {
            character.Incapacitated = !incapacitated;
        }
    }
}
