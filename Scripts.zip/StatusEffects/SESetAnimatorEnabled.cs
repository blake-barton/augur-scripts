using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Status Effects/Set Animator Enabled")]
public class SESetAnimatorEnabled : StatusEffect
{
    [SerializeField] bool isEnabled = false;

    Character character;

    public override void Apply(StatusEffects statusEffects)
    {
        if (statusEffects.ActorAnimator)
        {
            statusEffects.ActorAnimator.enabled = isEnabled;
        }
    }

    public override void Remove(StatusEffects statusEffects)
    {
        if (statusEffects.ActorAnimator)
        {
            statusEffects.ActorAnimator.enabled = !isEnabled;
        }
    }
}
