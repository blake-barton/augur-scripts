using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Status Effects/Freeze Poise Regen")]
public class SEFreezePoiseRegen : StatusEffect
{
    Poise poise;

    public override void Apply(StatusEffects statusEffects)
    {
        poise = statusEffects.GetComponent<Poise>();
        if (poise)
        {
            poise.FreezePoiseRegen();
        }
    }

    public override void Remove(StatusEffects statusEffects)
    {
        if (poise)
        {
            poise.StartPoiseRegen();
        }
    }
}
