using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class StatusEffect : ScriptableObject
{
    public enum EStatusEffectAlignment
    {
        Negative,
        Neutral,
        Positive
    }

    [Header("Display Info")]
    [SerializeField] string effectName;
    [SerializeField] string effectDescription;
    [SerializeField] Sprite effectSprite;
    [SerializeField] EStatusEffectAlignment statusEffectAlignment;

    Object initiator = null;    // what object granted this status effect?

    public string EffectName { get => effectName; set => effectName = value; }
    public string EffectDescription { get => effectDescription; set => effectDescription = value; }
    public Sprite EffectSprite { get => effectSprite; set => effectSprite = value; }
    public Object Initiator { get => initiator; set => initiator = value; }
    public EStatusEffectAlignment StatusEffectAlignment { get => statusEffectAlignment; set => statusEffectAlignment = value; }

    public abstract void Apply(StatusEffects statusEffects);
    public abstract void Remove(StatusEffects statusEffects);
}
