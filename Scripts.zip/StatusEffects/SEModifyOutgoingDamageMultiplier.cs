using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Status Effects/Modifiy Outgoing Damage Multiplier")]
public class SEModifyOutgoingDamageMultiplier : StatusEffect
{
    [SerializeField] float amount;

    Character character;

    public override void Apply(StatusEffects statusEffects)
    {
        character = statusEffects.GetComponent<Character>();
        if (character)
        {
            character.OutgoingDamageMultiplier += amount;
        }
    }

    public override void Remove(StatusEffects statusEffects)
    {
        if (character)
        {
            character.OutgoingDamageMultiplier -= amount;
        }
    }
}
