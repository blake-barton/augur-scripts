using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Status Effects/Stop Dust Trail")]
public class SEStopDustTrail : StatusEffect
{
    public override void Apply(StatusEffects statusEffects)
    {
        if (statusEffects.ActorPlayerMovement)
        {
            statusEffects.ActorPlayerMovement.StopDustTrail();
        }
    }

    public override void Remove(StatusEffects statusEffects)
    {
        if (statusEffects.ActorPlayerMovement)
        {
            statusEffects.ActorPlayerMovement.PlayDustTrail();
        }
    }
}
