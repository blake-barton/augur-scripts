using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Status Effects/Decay")]
public class SEDecay : StatusEffect
{
    // Decayed DT multipliers
    float bluntMult;
    float pierceMult;
    float slashMult;
    float energyMult;
    float fireMult;
    float poisonMult;
    float frostMult;
    float shockMult;
    float acidMult;
    float psionicMult;

    public override void Apply(StatusEffects statusEffects)
    {
        // reduce damage thresholds to 0
        if (statusEffects.ActorDamageThresholds)
        {
            acidMult = statusEffects.ActorDamageThresholds.AcidDT.Multiplier;
            bluntMult = statusEffects.ActorDamageThresholds.BluntDT.Multiplier;
            energyMult = statusEffects.ActorDamageThresholds.EnergyDT.Multiplier;
            fireMult = statusEffects.ActorDamageThresholds.FireDT.Multiplier;
            frostMult = statusEffects.ActorDamageThresholds.FrostDT.Multiplier;
            pierceMult = statusEffects.ActorDamageThresholds.PiercingDT.Multiplier;
            poisonMult = statusEffects.ActorDamageThresholds.PoisonDT.Multiplier;
            psionicMult = statusEffects.ActorDamageThresholds.PsionicDT.Multiplier;
            shockMult = statusEffects.ActorDamageThresholds.ShockDT.Multiplier;
            slashMult = statusEffects.ActorDamageThresholds.SlashingDT.Multiplier;

            statusEffects.ActorDamageThresholds.AcidDT.Multiplier -= acidMult;
            statusEffects.ActorDamageThresholds.BluntDT.Multiplier -= bluntMult;
            statusEffects.ActorDamageThresholds.EnergyDT.Multiplier -= energyMult;
            statusEffects.ActorDamageThresholds.FireDT.Multiplier -= fireMult;
            statusEffects.ActorDamageThresholds.FrostDT.Multiplier -= frostMult;
            statusEffects.ActorDamageThresholds.PiercingDT.Multiplier -= pierceMult;
            statusEffects.ActorDamageThresholds.PoisonDT.Multiplier -= poisonMult;
            statusEffects.ActorDamageThresholds.PsionicDT.Multiplier -= psionicMult;
            statusEffects.ActorDamageThresholds.ShockDT.Multiplier -= shockMult;
            statusEffects.ActorDamageThresholds.SlashingDT.Multiplier -= slashMult;
        }
    }

    public override void Remove(StatusEffects statusEffects)
    {
        // add what was removed from multipliers
        if (statusEffects.ActorDamageThresholds)
        {
            statusEffects.ActorDamageThresholds.AcidDT.Multiplier += acidMult;
            statusEffects.ActorDamageThresholds.BluntDT.Multiplier += bluntMult;
            statusEffects.ActorDamageThresholds.EnergyDT.Multiplier += energyMult;
            statusEffects.ActorDamageThresholds.FireDT.Multiplier += fireMult;
            statusEffects.ActorDamageThresholds.FrostDT.Multiplier += frostMult;
            statusEffects.ActorDamageThresholds.PiercingDT.Multiplier += pierceMult;
            statusEffects.ActorDamageThresholds.PoisonDT.Multiplier += poisonMult;
            statusEffects.ActorDamageThresholds.PsionicDT.Multiplier += psionicMult;
            statusEffects.ActorDamageThresholds.ShockDT.Multiplier += shockMult;
            statusEffects.ActorDamageThresholds.SlashingDT.Multiplier += slashMult;
        }
    }
}
