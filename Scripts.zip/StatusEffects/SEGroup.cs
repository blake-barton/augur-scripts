using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/* Activates multiple status effects at once */
[CreateAssetMenu(menuName = "Status Effects/Utility/Status Effect Group")]
public class SEGroup : StatusEffect
{
    [SerializeField] List<StatusEffect> statusEffectGroup = new List<StatusEffect>();

    public override void Apply(StatusEffects statusEffects)
    {
        foreach (StatusEffect statusEffect in statusEffectGroup)
        {
            statusEffect.Apply(statusEffects);
        }
    }

    public override void Remove(StatusEffects statusEffects)
    {
        foreach (StatusEffect statusEffect in statusEffectGroup)
        {
            statusEffect.Remove(statusEffects);
        }
    }
}
