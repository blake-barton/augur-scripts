using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Status Effects/Particle Effects")]
public class SEParticleEffects : StatusEffect
{
    [Header("Particle Effects")]
    [SerializeField] GameObject particles;

    GameObject instantiatedParticles;

    public override void Apply(StatusEffects statusEffects)
    {
        // spawn fire particles
        instantiatedParticles = Instantiate(particles, statusEffects.transform);
    }

    public override void Remove(StatusEffects statusEffects)
    {
        if (instantiatedParticles)
        {
            Destroy(instantiatedParticles);
        }
    }
}
