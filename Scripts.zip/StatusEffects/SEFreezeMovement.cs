using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Status Effects/Freeze Movement")]
public class SEFreezeMovement : StatusEffect
{
    public override void Apply(StatusEffects statusEffects)
    {
        UtilActor.FreezeMovement(statusEffects.gameObject);
    }

    public override void Remove(StatusEffects statusEffects)
    {
    }
}
