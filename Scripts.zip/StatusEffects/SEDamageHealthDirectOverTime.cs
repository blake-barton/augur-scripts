using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Status Effects/Damage Health Direct Over Time")]
public class SEDamageHealthDirectOverTime : StatusEffect
{
    [Header("Damage Health Direct Over Time")]
    [SerializeField] float damagePerTick;
    [SerializeField] int ticksPerSecond = 1;
    [SerializeField] float durationSeconds = 1f;
    [SerializeField] bool indefinite = false;   // ignore duration
    [SerializeField] DamageEffects.DamageType damageType;   // for damage number colors
    [SerializeField] bool causeDamageSound = false;
    [SerializeField] bool causeScreenShake = false;
    [SerializeField] bool causeImmunityFlash = false;

    bool ticking = false;
    Coroutine tickingCoroutine;

    public float DamagePerTick { get => damagePerTick; set => damagePerTick = value; }

    public override void Apply(StatusEffects statusEffects)
    {
        Health health = statusEffects.GetComponent<Health>();

        tickingCoroutine = statusEffects.StartCoroutine(DrainHealth(health, statusEffects));
    }

    public override void Remove(StatusEffects statusEffects)
    {
        if (ticking)
        {
            statusEffects.StopCoroutine(tickingCoroutine);
        }
    }

    IEnumerator DrainHealth(Health health, StatusEffects statusEffects)
    {
        float timer = durationSeconds;
        ticking = true;

        float secondsPerTick = 1f / ticksPerSecond;

        // cause tick-based damage until halted
        while (timer > 0)
        {
            // damage popup, damage displayed is rounded
            statusEffects.SpawnFloatingText(DamagePerTick, damageType);

            if (health)
            {
                health.DecreaseHealth(DamagePerTick, damageType, causeDamageSound, causeScreenShake, causeImmunityFlash);
            }
            else
            {
                break;
            }

            // reduce timer
            if (!indefinite)
            {
                timer -= secondsPerTick;
            }

            // wait
            yield return new WaitForSeconds(secondsPerTick);
        }

        // Done ticking
        ticking = false;

        // Tell status effects to remove
        statusEffects.RemoveStatusEffect(this);
    }
}
