using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Status Effects/Frenzy Layer")]
public class SEFrenzyLayer : StatusEffect
{
    int oldLayer;

    public override void Apply(StatusEffects statusEffects)
    {
        if (statusEffects.ActorEnemy)
        {
            // Track old layer
            oldLayer = statusEffects.gameObject.layer;

            // Switch layer to frenzy layer
            statusEffects.gameObject.layer = statusEffects.ActorEnemy.FrenzyLayer;
        }
        else
        {
            Debug.LogError("SEFrenzyLayer::Apply: Tried applying to null actorEnemy.");
        }
    }

    public override void Remove(StatusEffects statusEffects)
    {
        if (statusEffects.ActorEnemy)
        {
            // Switch layer to frenzy layer
            statusEffects.gameObject.layer = oldLayer;
        }
        else
        {
            Debug.LogError("SEFrenzyLayer::Remove: Tried removing from null actorEnemy.");
        }
    }
}
