using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(menuName = "Status Effects/Modify Gameplay Attribute Modifier")]
public class SEModifyGameplayAttributeModifier : StatusEffect
{
    enum EGameplayAttribute
    {
        MaxHealth,
        MaxPoise
    }

    [SerializeField] EGameplayAttribute gameplayAttribute;
    [SerializeField] float amount;

    Health health;
    Poise poise;

    public override void Apply(StatusEffects statusEffects)
    {
        switch (gameplayAttribute)
        {
            case EGameplayAttribute.MaxHealth:
                ApplyMaxHealth(statusEffects);
                break;
            case EGameplayAttribute.MaxPoise:
                ApplyMaxPoise(statusEffects);
                break;
            default:
                break;
        }
    }

    public override void Remove(StatusEffects statusEffects)
    {
        switch (gameplayAttribute)
        {
            case EGameplayAttribute.MaxHealth:
                RemoveMaxHealth();
                break;
            case EGameplayAttribute.MaxPoise:
                RemoveMaxPoise();
                break;
            default:
                break;
        }
    }

    private void ApplyMaxHealth(StatusEffects statusEffects)
    {
        health = statusEffects.GetComponent<Health>();

        if (health)
        {
            health.IncreaseMaxHealthModifier(amount);
        }
    }

    private void RemoveMaxHealth()
    {
        if (health)
        {
            health.IncreaseMaxHealthModifier(-amount);
        }
    }

    private void ApplyMaxPoise(StatusEffects statusEffects)
    {
        poise = statusEffects.GetComponent<Poise>();

        if (poise)
        {
            poise.IncreaseMaxPoiseModifier(amount);
        }
    }

    private void RemoveMaxPoise()
    {
        if (poise)
        {
            poise.IncreaseMaxPoiseModifier(-amount);
        }
    }
}
