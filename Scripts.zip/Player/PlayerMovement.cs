using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.Events;

public class PlayerMovement : MonoBehaviour
{
    // config variables 
    [Header("Basic Movement")]
    [SerializeField] float initialMoveSpeed = 10f;
    [SerializeField] float moveSpeed = 10f;
    [SerializeField] float bonusMoveSpeed = 0f;     // used to calculate final move speed
    [SerializeField] float moveSpeedMultiplier = 1f;

    [Header("Dodging")]
    [SerializeField] float dodgeSpeed = 10f;
    [SerializeField] float dodgeRollSpeedMultiplier = -0.5f;
    [SerializeField] bool dodging = false;
    [SerializeField] bool rolling = false;
    [SerializeField] [Range(0, 31)] int playerLayer;
    [SerializeField] [Range(0, 31)] int dodgeLayer;

    [Header("Dodge Audio")]
    [SerializeField] AudioClip leapAudioClip;
    [SerializeField] [Range(0, 1)] float leapAudioClipVolume = 1f;
    [SerializeField] AudioClip rollAudioClip;
    [SerializeField] [Range(0, 1)] float rollAudioClipVolume = 1f;

    [Header("Dodge Visuals")]
    [SerializeField] GameObject dodgeRollDustEffect;
    [SerializeField] float timeToDestroyDodgeRollDustEffect;

    [Header("Lunging")]
    [SerializeField] bool lunging = false;

    [Header("Hands")]
    public SpriteRenderer mainhandSpriteRenderer;
    public SpriteRenderer offhandSpriteRenderer;

    [Header("Particle System")]
    [SerializeField] ParticleSystem dustTrail;

    [Header("Knockdown")]
    [SerializeField] Poise poise;

    [Header("Equip Load Values")]
    [SerializeField] float lightSpeedMult = 0f;
    [SerializeField] float mediumSpeedMult = -0.2f;
    [SerializeField] float heavySpeedMult = -0.4f;
    [SerializeField] float overEncumberedSpeedMult = -0.5f;

    [SerializeField] [Range(0, 1)] float lightUpperBound = .25f;
    [SerializeField] [Range(0, 1)] float mediumUpperBound = .5f;
    [SerializeField] [Range(0, 1)] float heavyUpperBound = 1f;

    [SerializeField] float lightDodgeSpeed = 2f;
    [SerializeField] float mediumDodgeSpeed = 1.4f;
    [SerializeField] float heavyDodgeSpeed = .8f;
    [SerializeField] float overEncumberedDodgeSpeed = -1f;

    [SerializeField] float currentEquipLoadSpeedMult = 1f;

    [Header("Pitfalls")]
    [SerializeField] BoxCollider2D feetCollider;
    [SerializeField] float pitfallDamage = 25f;
    [SerializeField] float timeInPit = 0.25f;

    [Header("Footsteps")]
    [SerializeField] List<AudioClip> footstepSounds = new List<AudioClip>();
    [SerializeField] [Range(0, 1)] float footstepAudio = 1;

    // cached references
    [Header("References")]
    [SerializeField] SpriteRenderer spriteRenderer;
    [SerializeField] Animator playerAnim;
    [SerializeField] Equipment equipment;
    [SerializeField] AudioSource audioSource;

    // Events
    public UnityEvent dodged;

    private Rigidbody2D playerRB;
    Player player;

    private Vector2 moveDirection;

    public float MoveSpeed { get => moveSpeed; set => moveSpeed = value; }
    public float InitialMoveSpeed { get => initialMoveSpeed; set => initialMoveSpeed = value; }
    public bool Dodging { get => dodging; set => dodging = value; }
    public bool Rolling { get => rolling; set => rolling = value; }
    public bool Lunging { get => lunging; set => lunging = value; }

    // basically we always track our initial move speed and the only way it changes is by adding or subtracting from this multiplier
    public void AdjustMoveSpeed(float multiplier, float bonusSpeed = 0)
    {
        bonusMoveSpeed += bonusSpeed;
        moveSpeedMultiplier += multiplier;
        moveSpeed = (initialMoveSpeed + bonusMoveSpeed) * moveSpeedMultiplier;
    }

    // Start is called before the first frame update
    void Awake()
    {
        playerRB = GetComponent<Rigidbody2D>();
        player = GetComponent<Player>();

        dodgeSpeed = lightDodgeSpeed;
    }

    // Update is called once per frame
    void Update()
    {
        if (!Dodging && !player.InDialogue && !player.Character.Incapacitated && !Lunging)
        {
            ProcessInputs();
        }
        Animate();
    }

    private void FixedUpdate()
    {
        if (!Lunging)
        {
            Move();
        }
    }

    private void ProcessInputs()
    {
        Vector2 moveActionDirection = player.MoveAction.ReadValue<Vector2>();

        // raw means that the output is either 0 or 1
        float moveX = moveActionDirection.x;
        float moveY = moveActionDirection.y;

        // enable particles
        if (moveX != 0 || moveY != 0)
        {
            PlayDustTrail();
        }
        else if (moveX == 0 && moveY == 0)
        {
            StopDustTrail();
        }

        // do this so that player doesn't move faster diagonally
        moveDirection = new Vector2(moveX, moveY).normalized;
    }

    private void Move()
    {
        playerRB.velocity = new Vector2(moveDirection.x * moveSpeed, moveDirection.y * moveSpeed);
    }

    public void OnDodge(InputAction.CallbackContext context)
    {
        if (!Dodging && !player.InDialogue && !player.Character.Incapacitated && !Lunging && moveDirection.magnitude > .1)
        {
            // cancel reloads
            var reloaders = FindObjectsOfType<WeaponReloader>();
            foreach (WeaponReloader reloader in reloaders)
            {
                if (reloader.IsReloading)
                {
                    reloader.CancelReload();
                }
            }

            StartDodge();
        }
    }

    private void StartDodge()
    {
        // event
        dodged.Invoke();

        // animation
        playerAnim.SetBool("AnimIsDodging", true);

        // sound
        AudioUtility.PlaySound(audioSource, leapAudioClip, leapAudioClipVolume);

        // particles
        StopDustTrail();

        HideEquipped();

        // increase player speed for dashTime seconds and then reset player speed
        Dodging = true;
        AdjustMoveSpeed(multiplier: 0, dodgeSpeed);
    }

    // part of animation where player hits the ground during their dodge
    public void DodgeRoll(AnimationEvent animEvent)
    {
        if (!Rolling)
        {
            Rolling = true;
            AdjustMoveSpeed(dodgeRollSpeedMultiplier);  // speed goes down

            // vfx
            GameObject instantiatedDust = Instantiate(dodgeRollDustEffect, dustTrail.transform.position, Quaternion.identity);
            Destroy(instantiatedDust, timeToDestroyDodgeRollDustEffect);

            // sound
            AudioUtility.PlaySound(audioSource, rollAudioClip, rollAudioClipVolume);
        }
    }

    public void StopDodge()
    {
        if (Dodging)
        {
            Dodging = false;
            Rolling = false;
            AdjustMoveSpeed(-dodgeRollSpeedMultiplier, -dodgeSpeed); // speed goes back up

            playerAnim.SetBool("AnimIsDodging", false);

            UnhideEquipped();
        }
    }

    public void TriggerLunge(Vector2 direction, float force, float lungeTime)
    {
        StartCoroutine(Lunge(direction, force, lungeTime));
    }

    IEnumerator Lunge(Vector2 direction, float force, float lungeTime)
    {
        // stop movement
        FreezeMovement();
        Lunging = true;

        // add force
        if (playerRB)
        {
            playerRB.AddForce(direction * force, ForceMode2D.Impulse);
        }

        // wait
        yield return new WaitForSeconds(lungeTime);

        // enable movement
        FreezeMovement();
        Lunging = false;
    }

    private void UnhideEquipped()
    {
        mainhandSpriteRenderer.enabled = true;
        offhandSpriteRenderer.enabled = true;

        // hide equipped items
        if (equipment.MainHand)
        {
            SpriteRenderer spriteRendererMain = equipment.MainHand.GetComponent<SpriteRenderer>();

            if (spriteRendererMain)
            {
                equipment.MainHand.GetComponent<SpriteRenderer>().enabled = true;
            }
            else
            {
                // spell
                equipment.MainHand.GetComponent<ParticleSystem>().Play();
            }
        }
        if (equipment.OffHand)
        {
            SpriteRenderer spriteRendererOff = equipment.OffHand.GetComponent<SpriteRenderer>();

            if (spriteRendererOff)
            {
                equipment.OffHand.GetComponent<SpriteRenderer>().enabled = true;
            }
            else
            {
                // spell
                equipment.OffHand.GetComponent<ParticleSystem>().Play();
            }
        }
    }

    public void HideEquipped()
    {
        // hide hands
        mainhandSpriteRenderer.enabled = false;
        offhandSpriteRenderer.enabled = false;

        // hide equipped items
        if (equipment.MainHand)
        {
            SpriteRenderer spriteRendererMain = equipment.MainHand.GetComponent<SpriteRenderer>();

            if (spriteRendererMain)
            {
                equipment.MainHand.GetComponent<SpriteRenderer>().enabled = false;
            }
            else
            {
                // spell
                equipment.MainHand.GetComponent<ParticleSystem>().Stop();
            }
        }
        if (equipment.OffHand)
        {
            SpriteRenderer spriteRendererOff = equipment.OffHand.GetComponent<SpriteRenderer>();

            if (spriteRendererOff)
            {
                equipment.OffHand.GetComponent<SpriteRenderer>().enabled = false;
            }
            else
            {
                // spell
                equipment.OffHand.GetComponent<ParticleSystem>().Stop();
            }
        }
    }

    public void HideWeapons()
    {
        // hide equipped items
        if (equipment.MainHand)
        {
            SpriteRenderer spriteRendererMain = equipment.MainHand.GetComponent<SpriteRenderer>();

            if (spriteRendererMain)
            {
                equipment.MainHand.GetComponent<SpriteRenderer>().enabled = false;
            }
            else
            {
                // spell
                equipment.MainHand.GetComponent<ParticleSystem>().Stop();
            }
        }
        if (equipment.OffHand)
        {
            SpriteRenderer spriteRendererOff = equipment.OffHand.GetComponent<SpriteRenderer>();

            if (spriteRendererOff)
            {
                equipment.OffHand.GetComponent<SpriteRenderer>().enabled = false;
            }
            else
            {
                // spell
                equipment.OffHand.GetComponent<ParticleSystem>().Stop();
            }
        }
    }

    public void UnhideWeapons()
    {
        // hide equipped items
        if (equipment.MainHand)
        {
            SpriteRenderer spriteRendererMain = equipment.MainHand.GetComponent<SpriteRenderer>();

            if (spriteRendererMain)
            {
                equipment.MainHand.GetComponent<SpriteRenderer>().enabled = true;
            }
            else
            {
                // spell
                equipment.MainHand.GetComponent<ParticleSystem>().Play();
            }
        }
        if (equipment.OffHand)
        {
            SpriteRenderer spriteRendererOff = equipment.OffHand.GetComponent<SpriteRenderer>();

            if (spriteRendererOff)
            {
                equipment.OffHand.GetComponent<SpriteRenderer>().enabled = true;
            }
            else
            {
                // spell
                equipment.OffHand.GetComponent<ParticleSystem>().Play();
            }
        }
    }

    public void HideHands()
    {
        // hide hands
        mainhandSpriteRenderer.enabled = false;
        offhandSpriteRenderer.enabled = false;
    }

    public void UnhideHands()
    {
        mainhandSpriteRenderer.enabled = true;
        offhandSpriteRenderer.enabled = true;
    }

    public void UnhideEquippedAndSetNotBusy()
    {
        UnhideEquipped();
        player.IsBusy = false;
    }

    public void UnhideEquippedAndSetNotIncapacitated()
    {
        UnhideEquipped();
        player.Character.Incapacitated = false;
    }

    public void FreezeMovement()
    {
        moveDirection = Vector2.zero;
        playerRB.velocity = Vector2.zero;
    }

    private void Animate()
    {
        // these magic strings coincide with the parameter's in the players animation controller
        playerAnim.SetFloat("AnimMoveX", moveDirection.x);
        playerAnim.SetFloat("AnimMoveY", moveDirection.y);
        playerAnim.SetFloat("AnimMoveMagnitude", moveDirection.magnitude);

        // these are for idle animations
        playerAnim.SetFloat("AnimLookX", GetDirectionToCursor().x);
        playerAnim.SetFloat("AnimLookY", GetDirectionToCursor().y);
    }

    private Vector2 GetDirectionToCursor()
    {
        // Get mouse position (in screen-space) and convert to world-space
        var mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);

        // Calculate the vector between the mouse position and object
        return (mousePos - transform.position).normalized;
    }

    public void PlayDustTrail()
    {
        if (dustTrail.isStopped)
        {
            dustTrail.Play();
        }
    }

    public void StopDustTrail()
    {
        if (dustTrail.isPlaying)
        {
            dustTrail.Stop();
        }
    }

    // called during standup animation
    public void StandUp()
    {
        if (player.Character.Incapacitated)
        {
            // no longer incapacitated
            player.Character.Incapacitated = false;

            // restart regen
            poise.StartPoiseRegen();

            // max out poise
            poise.RefillPoiseToMax();
        }
    }

    public void FinishStandingUp()
    {
        // done standing
        playerAnim.SetBool("AnimStandingUp", false);

        // show items
        UnhideEquipped();

        // restart trail
        PlayDustTrail();
    }

    public void ActivateIFrames(AnimationEvent animEvent)
    {
        if (animEvent.animatorClipInfo.weight > 0.5f)
        {
            gameObject.layer = dodgeLayer;
            feetCollider.enabled = false;
        }
    }

    public void DeactivateIFrames(AnimationEvent animEvent)
    {
        if (animEvent.animatorClipInfo.weight > 0.5f)
        {
            gameObject.layer = playerLayer;
            feetCollider.enabled = true;
        }
    }

    public void UpdateMovementWithEquipLoad(float equipLoadRatio)
    {
        // reset move speed
        AdjustMoveSpeed(-currentEquipLoadSpeedMult);

        if (equipLoadRatio <= lightUpperBound)
        {
            AdjustMoveSpeed(lightSpeedMult);
            dodgeSpeed = lightDodgeSpeed;
            currentEquipLoadSpeedMult = lightSpeedMult;
        }
        else if (equipLoadRatio <= mediumUpperBound)
        {
            AdjustMoveSpeed(mediumSpeedMult);
            dodgeSpeed = mediumDodgeSpeed;
            currentEquipLoadSpeedMult = mediumSpeedMult;
        }
        else if (equipLoadRatio <= heavyUpperBound)
        {
            AdjustMoveSpeed(heavySpeedMult);
            dodgeSpeed = heavyDodgeSpeed;
            currentEquipLoadSpeedMult = heavySpeedMult;
        }
        else
        {
            // overencumbered
            AdjustMoveSpeed(overEncumberedSpeedMult);
            dodgeSpeed = overEncumberedDodgeSpeed;
            currentEquipLoadSpeedMult = overEncumberedSpeedMult;
        }
    }

    public string GetEquipLoadRatioAsString(float equipLoadRatio)
    {
        if (equipLoadRatio <= lightUpperBound)
        {
            return "(LIGHT)";
        }
        else if (equipLoadRatio <= mediumUpperBound)
        {
            return "(MEDIUM)";
        }
        else if (equipLoadRatio <= heavyUpperBound)
        {
            return "(HEAVY)";
        }
        else
        {
            // overencumbered
            return "(OVER-ENCUMBERED)";
        }
    }

    public void ForceMovement(Vector2 direction, float moveTime)
    {
        StartCoroutine(MoveOverTime(direction, moveTime));
    }

    IEnumerator MoveOverTime(Vector2 direction, float moveTime)
    {
        player.Character.Incapacitated = true;

        moveDirection = direction.normalized;

        yield return new WaitForSeconds(moveTime);

        FreezeMovement();

        player.Character.Incapacitated = false;
    }

    // called by pitfall animation
    public void HandlePitfall()
    {
        // stop dust trail
        StopDustTrail();

        // disable sprite
        spriteRenderer.enabled = false;

        // climb out of pit
        StartCoroutine(ClimbOutOfPit());
    }

    IEnumerator ClimbOutOfPit()
    {
        yield return new WaitForSeconds(timeInPit);

        // cause damage
        GetComponent<Health>().DecreaseHealth(pitfallDamage, DamageEffects.DamageType.BLUNT);

        // idle anim
        playerAnim.SetBool("AnimPitfall", false);

        Vector3 oldPos = new Vector3(transform.position.x, transform.position.y);

        // move to nearest walkable tile
        transform.position = RoomManager.GetClosestWalkableNodeCoordinatesToPoint(oldPos);

        // reenable sprite
        spriteRenderer.enabled = true;

        // play dust trail
        PlayDustTrail();

        // stop dodging if dodging
        StopDodge();

        // unhide equipped
        UnhideEquipped();

        // enable shadow
        player.ShowShadow();

        // no longer incapacitated
        player.Character.Incapacitated = false;

        // enable collider
        GetComponent<BoxCollider2D>().enabled = true;
    }

    // called by animation event
    public void PlayFootstepSound(AnimationEvent animEvent)
    {
        if (animEvent.animatorClipInfo.weight > 0.5f)
        {
            PlayRandomSound(footstepSounds, footstepAudio);
        }
    }

    private void PlayRandomSound(List<AudioClip> audioClips, float volume)
    {
        int randomIndex = UnityEngine.Random.Range(0, audioClips.Count);
        audioSource.PlayOneShot(audioClips[randomIndex], volume);
    }
}
