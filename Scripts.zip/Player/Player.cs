using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.Events;

public class Player : MonoBehaviour
{
    [SerializeField] bool playSpawnAnimationOnStart = false;

    [Header("Aim")]
    [SerializeField] Vector2 aimDirection = new Vector2();
    [SerializeField] float gamepadDeadzone = 0.1f;

    [Header("State")]
    [SerializeField] bool isBusy = false;
    [SerializeField] bool inDialogue = false;
    [SerializeField] bool isGamepad = false;

    [Header("Death")]
    [SerializeField] LayerMask deathSceneLayerMask;
    [SerializeField] float timeBeforeDeathAnimation = 1f;
    [SerializeField] float timeBeforeDeathMessage = 2f;
    [SerializeField] List<AudioClip> deathScreams = new List<AudioClip>();
    [SerializeField] [Range(0, 1)] float deathScreamVolume = 0.5f;

    [Header("Cached References")]
    [SerializeField] PlayerMovement playerMovement;
    [SerializeField] Health health;
    [SerializeField] Animator animator;
    [SerializeField] BoxCollider2D boxCollider;
    [SerializeField] HUDManager hud;
    [SerializeField] StatusEffects statusEffects;
    [SerializeField] DamageImmunityFlash damageImmunityFlash;
    [SerializeField] AudioSource ambientSound;
    [SerializeField] MusicPlayer musicPlayer;
    [SerializeField] SpriteRenderer spriteRenderer;
    [SerializeField] DeathMenuManager deathMenuManager;
    [SerializeField] AudioSource playerAudio;
    [SerializeField] SpriteRenderer shadowSpriteRenderer;
    [SerializeField] QuickAidManager quickAidManager;
    [SerializeField] Focus playerFocus;
    [SerializeField] Equipment playerEquipment;
    [SerializeField] PlayerInput playerInput;
    [SerializeField] GamepadOrbiter gamepadOrbiter;
    [SerializeField] TabMenuManager tabMenuManager;
    [SerializeField] AttributePanelManager attributePanelManager;
    [SerializeField] Character character;

    // Input
    AugurInput inputManager;
    InputAction moveAction;
    InputAction lookAction;

    public bool IsBusy { get => isBusy; set => isBusy = value; }
    public bool InDialogue { get => inDialogue; set => inDialogue = value; }
    public AugurInput InputManager { get => inputManager; set => inputManager = value; }
    public InputAction MoveAction { get => moveAction; set => moveAction = value; }
    public InputAction LookAction { get => lookAction; set => lookAction = value; }
    public Vector2 AimDirection { get => aimDirection; set => aimDirection = value; }
    public bool IsGamepad { get => isGamepad; set => isGamepad = value; }
    public float GamepadDeadzone { get => gamepadDeadzone; set => gamepadDeadzone = value; }
    public GamepadOrbiter GamepadOrbiter { get => gamepadOrbiter; set => gamepadOrbiter = value; }
    public Health Health { get => health; }
    public Character Character { get => character; set => character = value; }

    private void Awake()
    {
        InputManager = new AugurInput();
    }

    private void Start()
    {
        if (playSpawnAnimationOnStart)
        {
            Character.Incapacitated = true;
            playerMovement.HideHands();
            animator.Play("PlayerSpawn", -1, 0.0f);
        }
    }

    private void Update()
    {
        AimDirection = LookAction.ReadValue<Vector2>();
    }

    private void OnEnable()
    {
        // Move
        MoveAction = InputManager.Player.Move;
        MoveAction.Enable();

        // Look
        LookAction = InputManager.Player.Look;
        LookAction.Enable();

        // Dodge
        InputManager.Player.Dodge.performed += playerMovement.OnDodge;
        InputManager.Player.Dodge.Enable();

        // Interact
        InputManager.Player.Interact.performed += OnInteract;
        InputManager.Player.Interact.Enable();

        // Use quick aid
        InputManager.Player.Consumable.performed += quickAidManager.OnUseActiveItem;
        InputManager.Player.Consumable.Enable();

        // Next quick aid
        InputManager.Player.NextConsumable.performed += quickAidManager.OnNextActiveItem;
        InputManager.Player.NextConsumable.Enable();

        // Focus implant
        InputManager.Player.FocusImplant.performed += playerFocus.OnInputFocusImplant;
        InputManager.Player.FocusImplant.Enable();

        // Fire main
        InputManager.Player.FireMainhand.performed += playerEquipment.UseMainHand;
        InputManager.Player.FireMainhand.canceled += playerEquipment.ReleaseMainHand;
        InputManager.Player.FireMainhand.Enable();

        // Utility main
        InputManager.Player.UtilityMainhand.performed += playerEquipment.UtilityMainHand;
        InputManager.Player.UtilityMainhand.Enable();

        // Fire off
        InputManager.Player.FireOffhand.performed += playerEquipment.UseOffHand;
        InputManager.Player.FireOffhand.canceled += playerEquipment.ReleaseOffHand;
        InputManager.Player.FireOffhand.Enable();

        // Utility off
        InputManager.Player.UtilityOffhand.performed += playerEquipment.UtilityOffHand;
        InputManager.Player.UtilityOffhand.Enable();

        // Menu
        InputManager.Player.Menu.performed += tabMenuManager.OnMenu;
        InputManager.Player.Menu.Enable();

        /* --- UI --- */
        InputManager.UI.Exit.Enable();
        InputManager.UI.Exit.performed += tabMenuManager.OnExit;
        InputManager.UI.Exit.performed += attributePanelManager.OnExit;
    }

    private void OnDisable()
    {
        // Move
        MoveAction.Disable();

        // Look
        LookAction.Disable();

        // Dodge
        InputManager.Player.Dodge.performed -= playerMovement.OnDodge;
        InputManager.Player.Dodge.Disable();

        // Interact
        InputManager.Player.Interact.performed -= OnInteract;
        InputManager.Player.Interact.Disable();

        // Use quick aid
        InputManager.Player.Consumable.performed -= quickAidManager.OnUseActiveItem;
        InputManager.Player.Consumable.Disable();

        // Next quick aid
        InputManager.Player.NextConsumable.performed -= quickAidManager.OnNextActiveItem;
        InputManager.Player.NextConsumable.Disable();

        // Focus implant
        InputManager.Player.FocusImplant.performed -= playerFocus.OnInputFocusImplant;
        InputManager.Player.FocusImplant.Disable();

        // Fire main
        InputManager.Player.FireMainhand.performed -= playerEquipment.UseMainHand;
        InputManager.Player.FireMainhand.canceled -= playerEquipment.ReleaseMainHand;
        InputManager.Player.FireMainhand.Disable();

        // Utility main
        InputManager.Player.UtilityMainhand.performed -= playerEquipment.UtilityMainHand;
        InputManager.Player.UtilityMainhand.Disable();

        // Fire off
        InputManager.Player.FireOffhand.performed -= playerEquipment.UseOffHand;
        InputManager.Player.FireOffhand.canceled -= playerEquipment.ReleaseOffHand;
        InputManager.Player.FireOffhand.Disable();

        // Utility off
        InputManager.Player.UtilityOffhand.performed -= playerEquipment.UtilityOffHand;
        InputManager.Player.UtilityOffhand.Disable();

        // Menu
        InputManager.Player.Menu.performed -= tabMenuManager.OnMenu;
        InputManager.Player.Menu.Disable();

        /* --- UI --- */
        InputManager.UI.Exit.Disable();
        InputManager.UI.Exit.performed -= tabMenuManager.OnExit;
        InputManager.UI.Exit.performed -= attributePanelManager.OnExit;
    }

    public void OnDeviceChange(PlayerInput pi)
    {
        isGamepad = pi.currentControlScheme.Equals("Gamepad") ? true : false;
    }

    // Called by health's OnDeath event
    public void TriggerDeath()
    {
        StartCoroutine(Die());
    }

    IEnumerator Die()
    {
        Character.Incapacitated = true;

        playerMovement.FreezeMovement();
        playerMovement.HideWeapons();
        playerMovement.StopDustTrail();
        boxCollider.enabled = false;

        Time.timeScale = 1f;

        // cure status effects
        statusEffects.CureAllStatusEffects();
        statusEffects.enabled = false;

        // stop damage immunity flash
        damageImmunityFlash.StopImmunityFlash();

        // no more health
        Health.enabled = false;

        // black out everything but player and UI
        Camera.main.cullingMask = deathSceneLayerMask;

        // kill ambient sound
        ambientSound.Stop();
        musicPlayer.StopMusic();

        // get rid of hud
        hud.ToggleHUD();

        // wait to animate
        yield return new WaitForSeconds(timeBeforeDeathAnimation);

        // hide hands
        playerMovement.HideHands();

        // animate
        animator.SetTrigger("AnimDie");

        // play scream
        PlayRandomSound(deathScreams, deathScreamVolume);

        // wait for animation
        yield return new WaitForSeconds(timeBeforeDeathMessage);

        // show death message
        deathMenuManager.TriggerDeathMenu();
    }

    private void OnInteract(InputAction.CallbackContext context)
    {
        // When next to an interactable, the player presses E to interact with the closest one
        if (!tabMenuManager.InMenu && !inDialogue && !Character.Incapacitated)
        {
            Interactable.FindClosestInteractable();

            // if exists...
            if (Interactable.closestInteractable)
            {
                Interactable.closestInteractable.Interact();
            }
        }
    }

    public void PlayConsumableAnimation()
    {
        animator.Play("Consumable", -1, 0.0f);
    }

    public void PlayExitRoomAnimation()
    {
        // render player uncontrollable
        Character.Incapacitated = true;
        isBusy = true;
        playerMovement.FreezeMovement();
        playerMovement.StopDustTrail();
        playerMovement.HideEquipped();

        // play animation
        animator.Play("Exit Room", -1, 0.0f);
    }

    // called from death animation
    public void DisableSpriteRenderer()
    {
        spriteRenderer.enabled = false;
    }

    public void ActivateIdleAnimation()
    {
        animator.Play("Idle", -1, 0.0f);
        playerMovement.UnhideHands();
    }

    public void HideShadow()
    {
        shadowSpriteRenderer.enabled = false;
    }

    public void ShowShadow()
    {
        shadowSpriteRenderer.enabled = true;
    }

    private void PlayRandomSound(List<AudioClip> audioClips, float volume)
    {
        int randomIndex = UnityEngine.Random.Range(0, audioClips.Count);
        playerAudio.PlayOneShot(audioClips[randomIndex], volume);
    }
}